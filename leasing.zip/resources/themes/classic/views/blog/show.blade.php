<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $post->title }}</title>
    <link rel="stylesheet" href="{{ $themeAsset('css/style.css') }}">
</head>
<body>
<header style="padding:24px; background:#0f172a; color:white;">
    <div style="max-width:1040px; margin:0 auto;">
        <div style="font-size:22px; font-weight:700;">{{ $company->name ?? 'Company' }}</div>
        <div style="opacity:0.8;">Blog</div>
    </div>
</header>
<main style="max-width:1040px; margin:32px auto; padding:0 16px; font-family:Arial,sans-serif;">
    @if(!empty($themeLocales))
        <div style="margin:12px 0; display:flex; gap:8px; align-items:center;">
            <span class="muted small">{{ ___('Languages') }}:</span>
            <select id="langSelect">
                @foreach($themeLocales as $loc)
                    <option value="{{ $loc }}" @selected(($currentLocale ?? $themeDefaultLocale ?? 'en') === $loc)>{{ strtoupper($loc) }}</option>
                @endforeach
            </select>
        </div>
    @endif
    <a href="{{ url($company->slug.'/blog') }}" class="btn ghost" style="margin-bottom:12px; display:inline-block;">← {{ ___('Back') }}</a>
    <h1>{{ $post->title }}</h1>
    @if($post->published_at)
        <div class="muted small">{{ $post->published_at }}</div>
    @endif
    @if($post->excerpt)
        <p><strong>{{ $post->excerpt }}</strong></p>
    @endif
    <div>{!! nl2br(e($post->content)) !!}</div>
</main>
<script>
    (function(){
        const sel = document.getElementById('langSelect');
        if(!sel) return;
        sel.addEventListener('change', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('lang', sel.value);
            window.location.href = url.toString();
        });
    })();
</script>
</body>
</html>
