<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $company->name }} - Blog</title>
    <link rel="stylesheet" href="{{ $themeAsset('css/style.css') }}">
</head>
<body>
<header style="padding:24px; background:#0f172a; color:white;">
    <div style="max-width:1040px; margin:0 auto;">
        <div style="font-size:22px; font-weight:700;">{{ $company->name ?? 'Company' }}</div>
        <div style="opacity:0.8;">Blog</div>
    </div>
</header>
<main style="max-width:1040px; margin:32px auto; padding:0 16px; font-family:Arial,sans-serif;">
    @if(!empty($themeLocales))
        <div style="margin:12px 0; display:flex; gap:8px; align-items:center;">
            <span class="muted small">{{ ___('Languages') }}:</span>
            <select id="langSelect">
                @foreach($themeLocales as $loc)
                    <option value="{{ $loc }}" @selected(($currentLocale ?? $themeDefaultLocale ?? 'en') === $loc)>{{ strtoupper($loc) }}</option>
                @endforeach
            </select>
        </div>
    @endif
    <a href="{{ url($company->slug) }}" class="btn ghost" style="margin-bottom:12px; display:inline-block;">← {{ ___('Back') }}</a>
    <h1>{{ ___('Blog') }}</h1>
    @forelse($posts as $post)
        <article style="margin-bottom:18px; padding-bottom:12px; border-bottom:1px solid #e2e8f0;">
            <h3 style="margin:0;"><a href="{{ url($company->slug.'/'.$post->slug) }}">{{ $post->title }}</a></h3>
            @if($post->excerpt)
                <p>{{ $post->excerpt }}</p>
            @endif
            <div class="muted small">{{ $post->published_at }}</div>
        </article>
    @empty
        <div class="muted">{{ ___('No posts yet.') }}</div>
    @endforelse
</main>
<script>
    (function(){
        const sel = document.getElementById('langSelect');
        if(!sel) return;
        sel.addEventListener('change', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('lang', sel.value);
            window.location.href = url.toString();
        });
    })();
</script>
</body>
</html>
