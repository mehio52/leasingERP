<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ ___('Payment') }}</title>
    <link rel="stylesheet" href="{{ $themeAsset('css/style.css') }}">
</head>
<body>
@php
    $themeStyles = $themeStyles ?? [];
    $bg = $themeStyles['background_color'] ?? '#f8fafc';
    $text = $themeStyles['text_color'] ?? '#0f172a';
    $heading = $themeStyles['heading_color'] ?? '#0f172a';
    $link = $themeStyles['link_color'] ?? '#0f172a';
    $cardBg = $themeStyles['card_bg_color'] ?? '#ffffff';
@endphp
<style>
    :root {
        --bg: {{ $bg }};
        --text: {{ $text }};
        --heading: {{ $heading }};
        --link: {{ $link }};
        --card: {{ $cardBg }};
    }
    body { background: var(--bg); color: var(--text); }
    h1,h2,h3,h4 { color: var(--heading); }
    a { color: var(--link); }
    .card-block { background: var(--card); border:1px solid #e2e8f0; border-radius:12px; padding:16px; }
    .grid { display:grid; gap:12px; }
    .row { display:flex; gap:12px; flex-wrap:wrap; }
    .field { display:flex; flex-direction:column; gap:6px; min-width:220px; }
    .input { padding:10px 12px; border:1px solid #e2e8f0; border-radius:8px; }
    .btn { padding:10px 14px; border-radius:8px; border:1px solid #0f172a; background:#0f172a; color:white; cursor:pointer; }
    .btn.ghost { background:transparent; color:#0f172a; }
    .muted { color:#475569; }
    .badge { display:inline-flex; padding:4px 8px; border-radius:999px; background:#e2e8f0; font-size:12px; }
    .badge.ok { background:#dcfce7; color:#166534; }
    .badge.bad { background:#fee2e2; color:#991b1b; }
</style>

<header style="padding:24px; background:#0f172a; color:white;">
    <div style="max-width:1040px; margin:0 auto;">
        <div style="font-size:22px; font-weight:700;">{{ $company->name ?? 'Company' }}</div>
        <div style="opacity:0.8;">{{ ___('Loan payment') }}</div>
    </div>
</header>

<main style="max-width:1040px; margin:32px auto; padding:0 16px; font-family:Arial,sans-serif;">
    @if(!empty($themeLocales))
        <div style="margin:12px 0; display:flex; gap:8px; align-items:center;">
            <span class="muted small">{{ ___('Languages') }}:</span>
            <select id="langSelect">
                @foreach($themeLocales as $loc)
                    <option value="{{ $loc }}" @selected(($currentLocale ?? $themeDefaultLocale ?? 'en') === $loc)>{{ strtoupper($loc) }}</option>
                @endforeach
            </select>
        </div>
    @endif

    <a href="{{ url($company->slug) }}" class="btn ghost" style="margin-bottom:12px; display:inline-block;">&larr; {{ ___('Back') }}</a>

    @if(($orderStatus ?? '') === 'success')
        <div class="card-block" style="margin-bottom:12px;">
            <span class="badge ok">{{ ___('Payment successful') }}</span>
            @if($orderTx)
                <div class="muted" style="margin-top:6px;">{{ ___('Order ID') }}: {{ $orderTx->order_id }}</div>
            @endif
        </div>
    @elseif(($orderStatus ?? '') === 'error')
        <div class="card-block" style="margin-bottom:12px;">
            <span class="badge bad">{{ ___('Payment failed') }}</span>
            @if($orderTx)
                <div class="muted" style="margin-top:6px;">{{ ___('Order ID') }}: {{ $orderTx->order_id }}</div>
            @endif
            @if($orderTx && $orderTx->message)
                <div class="muted" style="margin-top:6px;">{{ $orderTx->message }}</div>
            @elseif(session('gateway_error'))
                <div class="muted" style="margin-top:6px;">{{ session('gateway_error') }}</div>
            @endif
        </div>
    @endif

    @if($errors->any())
        <div class="card-block" style="margin-bottom:12px;">
            <span class="badge bad">{{ ___('Error') }}</span>
            <ul style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card-block">
        <h2 style="margin-top:0;">{{ ___('Find your contract') }}</h2>
        <form method="POST" action="{{ url($company->slug.'/pay') }}" class="grid">
            @csrf
            <input type="hidden" name="intent" value="lookup">
            <div class="row">
                <div class="field">
                    <label>{{ ___('Contract number') }}</label>
                    <input class="input" name="contract_no" value="{{ old('contract_no', $account?->contract?->contract_no) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('FIN code') }}</label>
                    <input class="input" name="fin_code" value="{{ old('fin_code', request('fin_code')) }}" required>
                </div>
            </div>
            <div style="display:flex; justify-content:flex-end;">
                <button class="btn" type="submit">{{ ___('Show debt') }}</button>
            </div>
        </form>
    </div>

    @if($account && $paymentSummary)
        @php
            $currentDue = (float)($paymentSummary['currentDue'] ?? 0);
            $penaltyOutstanding = (float)($paymentSummary['penaltyOutstanding'] ?? 0);
            $totalDue = (float)($paymentSummary['totalDue'] ?? 0);
            $maxAmount = !$paymentOption->allow_overpayment
                ? number_format($totalDue, 2, '.', '')
                : null;
        @endphp
        <div class="card-block" style="margin-top:16px;">
            <h3 style="margin-top:0;">{{ ___('Debt summary') }}</h3>
            <div class="row" style="margin-bottom:8px;">
                <div class="field">
                    <div class="muted">{{ ___('Customer') }}</div>
                    <div><strong>{{ $account->customer?->full_name ?? '' }}</strong></div>
                </div>
                <div class="field">
                    <div class="muted">{{ ___('Contract') }}</div>
                    <div><strong>{{ $account->contract?->contract_no ?? '' }}</strong></div>
                </div>
                <div class="field">
                    <div class="muted">{{ ___('Status') }}</div>
                    <div><span class="badge">{{ $account->status }}</span></div>
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <div class="muted">{{ ___('Current due') }}</div>
                    <div><strong>{{ number_format($currentDue, 2) }} {{ $paymentCurrency ?? 'AZN' }}</strong></div>
                </div>
                <div class="field">
                    <div class="muted">{{ ___('Penalty') }}</div>
                    <div><strong>{{ number_format($penaltyOutstanding, 2) }} {{ $paymentCurrency ?? 'AZN' }}</strong></div>
                    @if(($paymentSummary['overdueDays'] ?? 0) > 0)
                        <div class="muted small">{{ ___('Overdue days') }}: {{ $paymentSummary['overdueDays'] }}</div>
                    @endif
                </div>
                <div class="field">
                    <div class="muted">{{ ___('Total due') }}</div>
                    <div><strong>{{ number_format($totalDue, 2) }} {{ $paymentCurrency ?? 'AZN' }}</strong></div>
                </div>
                <div class="field">
                    <div class="muted">{{ ___('Remaining principal') }}</div>
                    <div><strong>{{ $paymentSummary['remainingPrincipal'] ?? '' }} {{ $paymentCurrency ?? 'AZN' }}</strong></div>
                </div>
            </div>
        </div>

        <div class="card-block" style="margin-top:16px;">
            <h3 style="margin-top:0;">{{ ___('Pay with card') }}</h3>
            <form method="POST" action="{{ url($company->slug.'/pay') }}" class="grid">
                @csrf
                <input type="hidden" name="intent" value="checkout">
                <input type="hidden" name="contract_no" value="{{ old('contract_no', $account->contract?->contract_no) }}">
                <input type="hidden" name="fin_code" value="{{ old('fin_code', request('fin_code')) }}">
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Amount (:currency)', ['currency' => $paymentCurrency ?? 'AZN']) }}</label>
                        <input class="input" name="amount" type="number" step="0.01" value="{{ old('amount', number_format($totalDue,2,'.','')) }}" @if($maxAmount !== null) max="{{ $maxAmount }}" @endif required>
                        <div class="muted small">{{ ___('Penalty is included automatically.') }}</div>
                        @if($maxAmount !== null)
                            <div class="muted small">{{ ___('Overpayment is disabled. Max: :amount :currency', ['amount' => $maxAmount, 'currency' => $paymentCurrency ?? 'AZN']) }}</div>
                        @endif
                    </div>
                </div>
                @if(($paymentProvider ?? '') === 'iyzico')
                    <div class="row">
                        <div class="field">
                            <label>{{ ___('Email') }}</label>
                            <input class="input" name="buyer_email" type="email" value="{{ old('buyer_email', $companyOptions?->contact_email ?? '') }}" required>
                        </div>
                        <div class="field">
                            <label>{{ ___('Phone') }}</label>
                            <input class="input" name="buyer_phone" value="{{ old('buyer_phone', $account->customer?->phone ?? $companyOptions?->contact_phone ?? '') }}" required>
                        </div>
                        <div class="field">
                            <label>{{ ___('Identity number') }}</label>
                            <input class="input" name="buyer_identity" value="{{ old('buyer_identity', $account->customer?->id_card_number ?? $account->customer?->fin_code ?? '') }}">
                        </div>
                    </div>
                    <div class="row">
                        <div class="field" style="min-width:320px;">
                            <label>{{ ___('Address') }}</label>
                            <input class="input" name="buyer_address" value="{{ old('buyer_address', $companyOptions?->address ?? '') }}" required>
                        </div>
                        <div class="field">
                            <label>{{ ___('City') }}</label>
                            <input class="input" name="buyer_city" value="{{ old('buyer_city', $companyOptions?->city ?? '') }}" required>
                        </div>
                        <div class="field">
                            <label>{{ ___('Country') }}</label>
                            <input class="input" name="buyer_country" value="{{ old('buyer_country', $companyOptions?->country ?? '') }}" required>
                        </div>
                        <div class="field">
                            <label>{{ ___('ZIP') }}</label>
                            <input class="input" name="buyer_zip" value="{{ old('buyer_zip', '') }}">
                        </div>
                    </div>
                @endif
                <div style="display:flex; justify-content:flex-end;">
                    <button class="btn" type="submit">{{ ___('Pay') }}</button>
                </div>
            </form>
        </div>
    @endif
</main>
<script>
    (function(){
        const sel = document.getElementById('langSelect');
        if(!sel) return;
        sel.addEventListener('change', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('lang', sel.value);
            window.location.href = url.toString();
        });
    })();
</script>
</body>
</html>
