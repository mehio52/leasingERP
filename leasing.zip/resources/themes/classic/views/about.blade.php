@extends('themes.classic.views.layout')

@section('content')
    <h1>About {{ $company->name }}</h1>
    <p>Public information about the company can be placed here.</p>
@endsection
