<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $vehicle->public_title ?: ($vehicle->brand.' '.$vehicle->model) }}</title>
    <link rel="stylesheet" href="{{ $themeAsset('css/style.css') }}">
</head>
<body>
<header style="padding:24px; background:#0f172a; color:white;">
    <div style="max-width:1040px; margin:0 auto;">
        <div style="font-size:22px; font-weight:700;">{{ $company->name ?? 'Company' }}</div>
    </div>
</header>
<main style="max-width:1040px; margin:32px auto; padding:0 16px; font-family:Arial,sans-serif;">
    @if(!empty($themeLocales))
        <div style="margin:12px 0; display:flex; gap:8px; align-items:center;">
            <span class="muted small">{{ ___('Languages') }}:</span>
            <select id="langSelect">
                @foreach($themeLocales as $loc)
                    <option value="{{ $loc }}" @selected(($currentLocale ?? $themeDefaultLocale ?? 'en') === $loc)>{{ strtoupper($loc) }}</option>
                @endforeach
            </select>
        </div>
    @endif
    <a href="{{ url($company->slug) }}" class="btn ghost" style="margin-bottom:12px; display:inline-block;">← {{ ___('Back') }}</a>
    <h1>{{ $vehicle->public_title ?: ($vehicle->brand.' '.$vehicle->model) }} @if($vehicle->year) ({{ $vehicle->year }}) @endif</h1>
    @if($vehicle->public_description)
        <p>{{ $vehicle->public_description }}</p>
    @endif

    @if(!empty($vehicle->specs))
        <h3>{{ ___('Specs') }}</h3>
        <ul>
            @foreach($vehicle->specs as $k => $v)
                <li><strong>{{ $k }}:</strong> {{ $v }}</li>
            @endforeach
        </ul>
    @endif

    @if(!empty($vehicle->comforts))
        <h3>{{ ___('Comfort') }}</h3>
        <ul>
            @foreach($vehicle->comforts as $k => $v)
                <li><strong>{{ $k }}:</strong> {{ $v }}</li>
            @endforeach
        </ul>
    @endif
</main>
<script>
    (function(){
        const sel = document.getElementById('langSelect');
        if(!sel) return;
        sel.addEventListener('change', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('lang', sel.value);
            window.location.href = url.toString();
        });
    })();
</script>
</body>
</html>
