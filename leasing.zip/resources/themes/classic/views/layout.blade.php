<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $company->name ?? 'Company' }}</title>
    <link rel="stylesheet" href="{{ $themeAsset('css/style.css') }}">
</head>
<body>
<header style="padding:24px; background:#0f172a; color:white;">
    <div style="max-width:1040px; margin:0 auto;">
        <div style="font-size:22px; font-weight:700;">{{ $company->name ?? 'Company' }}</div>
    </div>
</header>
<main style="max-width:1040px; margin:32px auto; padding:0 16px; font-family:Arial,sans-serif;">
    @yield('content')
</main>
</body>
</html>