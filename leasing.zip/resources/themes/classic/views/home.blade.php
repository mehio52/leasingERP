<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $company->name ?? 'Company' }} - {{ $themeMeta['name'] ?? 'Theme' }}</title>
    <link rel="stylesheet" href="{{ $themeAsset('css/style.css') }}">
</head>
<body>
    @php
        $bg = $themeStyles['background_color'] ?? '#f8fafc';
        $text = $themeStyles['text_color'] ?? '#0f172a';
        $heading = $themeStyles['heading_color'] ?? '#0f172a';
        $link = $themeStyles['link_color'] ?? '#0f172a';
        $cardBg = $themeStyles['card_bg_color'] ?? '#ffffff';
        $fontSize = $themeStyles['font_size'] ?? '16px';
    @endphp
    <style>
        :root {
            --bg: {{ $bg }};
            --text: {{ $text }};
            --heading: {{ $heading }};
            --link: {{ $link }};
            --card: {{ $cardBg }};
            --font-size: {{ $fontSize }};
        }
        body { background: var(--bg); color: var(--text); font-size: var(--font-size); }
        h1,h2,h3,h4 { color: var(--heading); }
        a { color: var(--link); }
        .card-block { background: var(--card); border:1px solid #e2e8f0; }
    </style>
    <header style="padding:24px; background:#0f172a; color:white;">
        <div style="max-width:1040px; margin:0 auto;">
            <div style="font-size:22px; font-weight:700;">{{ $company->name ?? 'Company' }}</div>
            <div style="opacity:0.8;">Public site powered by {{ $themeMeta['name'] ?? 'Theme' }} v{{ $themeMeta['version'] ?? '' }}</div>
        </div>
    </header>

    <main style="max-width:1040px; margin:32px auto; padding:0 16px; font-family:Arial,sans-serif;">
        <h1>Welcome to {{ $company->name ?? 'our company' }}</h1>
        <p>This is the default landing page for the <strong>{{ $theme }}</strong> theme.</p>
        @if(($showBlogLink ?? true))
            <p><a href="{{ url($company->slug.'/blog') }}" style="font-weight:700; color:var(--link); text-decoration:none;">{{ ___('Visit our blog') }} →</a></p>
        @endif
        @if(($paymentGatewayEnabled ?? false))
            <p><a href="{{ url($company->slug.'/pay') }}" style="font-weight:700; color:var(--link); text-decoration:none;">{{ ___('Pay') }} →</a></p>
        @endif

        @if(!empty($themeLocales))
        <div style="margin:12px 0; display:flex; gap:8px; align-items:center;">
            <span class="muted small">{{ ___('Languages') }}:</span>
            <select id="langSelect">
                @foreach($themeLocales as $loc)
                    <option value="{{ $loc }}" @selected(($currentLocale ?? $themeDefaultLocale) === $loc)>{{ strtoupper($loc) }}</option>
                @endforeach
            </select>
        </div>
        @endif

        @if($showCalculator ?? true)
        <section class="card-block" style="margin-top:24px; padding:16px; border-radius:12px;">
            <h3>Credit Calculator (shared controller action)</h3>
            <form method="POST" action="{{ url($company->slug.'/_action/credit-calc') }}" onsubmit="return submitCalc(event)">
                @csrf
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <label>Amount <input type="number" step="0.01" name="amount" required></label>
                    <label>Months <input type="number" step="1" name="months" required></label>
                    <label>Rate % <input type="number" step="0.01" name="rate" required @if(isset($rateMin)) min="{{ $rateMin }}" @endif @if(isset($rateMax)) max="{{ $rateMax }}" @endif></label>
                </div>
                @if(isset($rateMin) || isset($rateMax))
                    <div class="muted small" style="margin-top:4px;">
                        {{ ___('Rate range') }}: {{ $rateMin ?? '?' }} - {{ $rateMax ?? '?' }} %
                    </div>
                @endif
                <button type="submit" style="margin-top:12px;">Calculate</button>
            </form>
            <pre id="calcResult" style="background:#f8fafc; padding:10px; margin-top:10px;"></pre>
        </section>
        @endif

        @if(($showPublicVehicles ?? true) && isset($publicVehicles) && $publicVehicles->count())
        <section class="card-block" style="margin-top:24px; padding:16px; border-radius:12px;">
            <h3>{{ ___('Available vehicles') }}</h3>
            <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:12px; margin-top:12px;">
                @foreach($publicVehicles as $v)
                    <div style="border:1px solid #e2e8f0; border-radius:10px; padding:12px; background:var(--card);">
                        <div style="font-weight:700; margin-bottom:6px;">{{ $v->public_title ?: ($v->brand.' '.$v->model) }} @if($v->year) ({{ $v->year }}) @endif</div>
                        @if($v->public_description)
                            <div style="font-size:13px; margin-bottom:8px; color:#334155;">{{ $v->public_description }}</div>
                        @endif
                        @if(!empty($v->specs))
                            <div style="font-size:13px; margin-bottom:6px; color:#334155;">Specs:</div>
                            <ul style="margin:0 0 8px 16px; padding:0; font-size:13px; color:#0f172a;">
                                @foreach($v->specs as $k => $val)
                                    <li><strong>{{ $k }}:</strong> {{ $val }}</li>
                                @endforeach
                            </ul>
                        @endif
                        @if(!empty($v->comforts))
                            <div style="font-size:13px; margin-bottom:6px; color:#334155;">Comfort:</div>
                            <ul style="margin:0 0 0 16px; padding:0; font-size:13px; color:#0f172a;">
                                @foreach($v->comforts as $k => $val)
                                    <li><strong>{{ $k }}:</strong> {{ $val }}</li>
                                @endforeach
                            </ul>
                        @endif
                        <div style="margin-top:10px;">
                            <a href="{{ url($company->slug.'/vehicles/'.$v->id) }}" style="font-weight:700; color:var(--link); text-decoration:none;">{{ ___('View details') }} →</a>
                        </div>
                    </div>
                @endforeach
            </div>
        </section>
        @endif

        @if(($showTestDrive ?? true))
        <section class="card-block" style="margin-top:24px; padding:16px; border-radius:12px;">
            <h3>{{ ___('Test drive request') }}</h3>
            <form method="POST" action="{{ url($company->slug.'/_action/test-drive') }}" onsubmit="return submitTestDrive(event)">
                @csrf
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <label>Name <input type="text" name="name" required></label>
                    <label>Phone <input type="text" name="phone"></label>
                    <label>Email <input type="email" name="email"></label>
                    @if(isset($publicVehicles) && $publicVehicles->count())
                        <label>Vehicle
                            <select name="vehicle_id">
                                <option value="">{{ ___('Any') }}</option>
                                @foreach($publicVehicles as $v)
                                    <option value="{{ $v->id }}">{{ $v->brand }} {{ $v->model }}</option>
                                @endforeach
                            </select>
                        </label>
                    @endif
                </div>
                <button type="submit" style="margin-top:12px;">{{ ___('Send request') }}</button>
            </form>
            <div id="tdStatus" class="muted small" style="margin-top:8px;"></div>
        </section>
        @endif
    </main>

    @if(($showPagesFooter ?? true) && !empty($publicPages ?? []))
    <footer style="background:#0f172a; color:#e2e8f0; padding:20px 0; margin-top:40px;">
        <div style="max-width:1040px; margin:0 auto; padding:0 16px; display:flex; flex-wrap:wrap; gap:12px;">
            <span class="muted small">{{ ___('Pages') }}:</span>
            @foreach($publicPages as $page)
                <a href="{{ url($company->slug.'/'.$page->slug) }}" style="color:#e2e8f0; text-decoration:none;">{{ $page->title }}</a>
            @endforeach
        </div>
    </footer>
    @endif

    <script>
        async function submitCalc(e){
            e.preventDefault();
            const form = e.target;
            const data = new FormData(form);
            const res = await fetch(form.action, {method:'POST', body:data, headers: {'X-Requested-With':'XMLHttpRequest'}});
            const out = document.getElementById('calcResult');
            if(res.ok){
                const json = await res.json();
                out.textContent = 'Monthly: '+json.monthly_payment+' | Total: '+json.total;
            } else {
                out.textContent = 'Error: '+res.status;
            }
            return false;
        }

        async function submitTestDrive(e){
            e.preventDefault();
            const form = e.target;
            const data = new FormData(form);
            const status = document.getElementById('tdStatus');
            const res = await fetch(form.action, {method:'POST', body:data, headers:{'X-Requested-With':'XMLHttpRequest'}});
            if(res.ok){
                status.textContent = '{{ ___('Request sent') }}';
                form.reset();
            } else {
                status.textContent = '{{ ___('Failed to send') }}';
            }
            return false;
        }

        (function(){
            const sel = document.getElementById('langSelect');
            if(!sel) return;
            sel.addEventListener('change', () => {
                const url = new URL(window.location.href);
                url.searchParams.set('lang', sel.value);
                window.location.href = url.toString();
            });
        })();
    </script>
</body>
</html>
