﻿@extends('theme-rentacar::layout')

@section('content')
@php
    $img = null;
    if (!empty($vehicle->images)) {
        $first = $vehicle->images[0] ?? null;
        if ($first) {
            $img = \Illuminate\Support\Facades\Storage::disk('public')->url($first);
        }
    }
@endphp

<div class="page-wrap">
    <div class="page-card">
        <div style="display:grid; grid-template-columns: minmax(240px, 1fr) 1.2fr; gap:20px;">
            <div>
                <div class="vehicle-card" style="border:none;">
                    <div class="img" style="height:240px;">
                        @if($img)
                            <img src="{{ $img }}" alt="{{ $vehicle->display_name }}">
                        @else
                            {{ ___('No image') }}
                        @endif
                    </div>
                </div>
            </div>
            <div>
                <h2 style="margin:0 0 6px;">{{ $vehicle->public_title ?: $vehicle->display_name }}</h2>
                <div class="meta" style="margin-bottom:10px; color:var(--muted);">{{ $vehicle->public_description ?: ___('Comfortable and reliable for your trip.') }}</div>
                <div class="price" style="font-size:20px; margin-bottom:10px; color:var(--primary); font-weight:800;">
                    {{ $vehicle->rent_daily_price ? number_format((float)$vehicle->rent_daily_price, 0) : '120' }} AZN/{{ ___('day') }}
                </div>
                @if(!empty($vehicle->specs))
                    <div style="font-weight:700; margin:12px 0 6px;">{{ ___('Specifications') }}</div>
                    <ul style="margin:0; padding-left:18px; color:var(--muted);">
                        @foreach($vehicle->specs as $k => $val)
                            <li><strong>{{ $k }}:</strong> {{ $val }}</li>
                        @endforeach
                    </ul>
                @endif
                @if(!empty($vehicle->comforts))
                    <div style="font-weight:700; margin:12px 0 6px;">{{ ___('Comfort') }}</div>
                    <ul style="margin:0; padding-left:18px; color:var(--muted);">
                        @foreach($vehicle->comforts as $k => $val)
                            <li><strong>{{ $k }}:</strong> {{ $val }}</li>
                        @endforeach
                    </ul>
                @endif
                <div style="margin-top:16px; display:flex; gap:10px; flex-wrap:wrap;">
                    <a class="btn primary" href="{{ $publicUrl('#search') }}">{{ ___('Book this car') }}</a>
                    <a class="btn" href="{{ $publicUrl('') }}">{{ ___('Back to cars') }}</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
