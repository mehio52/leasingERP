﻿@php
    $companyName = $company->name ?? 'Company';
    $logo = $company?->logo_path ?: $company?->options?->logo_path;
    $logoUrl = null;
    if ($logo) {
        $logoUrl = (str_starts_with($logo, 'http') || str_starts_with($logo, '/'))
            ? $logo
            : \Illuminate\Support\Facades\Storage::disk('public')->url($logo);
        if (request()->isSecure() && str_starts_with($logoUrl, 'http://')) {
            $logoUrl = preg_replace('#^http://#', 'https://', $logoUrl);
        }
    }
    $path = trim(request()->path(), '/');
    $slug = $company->slug ?? '';
    $pathAfterSlug = $path;
    if ($slug !== '' && str_starts_with($pathAfterSlug, $slug)) {
        $pathAfterSlug = trim(substr($pathAfterSlug, strlen($slug)), '/');
    }
    $isHome = $pathAfterSlug === '';
    $isBlog = $pathAfterSlug === 'blog' || str_starts_with($pathAfterSlug, 'blog/');
    $isPay = $pathAfterSlug === 'pay';
    $domainRequest = request()->attributes->get('public_domain_request');
    $publicBase = $domainRequest ? url('/') : url($company->slug);
    $publicUrl = function (string $path = '') use ($publicBase) {
        if ($path === '') {
            return rtrim($publicBase, '/');
        }
        if (str_starts_with($path, '#')) {
            return rtrim($publicBase, '/') . $path;
        }
        return rtrim($publicBase, '/') . '/' . ltrim($path, '/');
    };
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $companyName }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&family=Oswald:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ $themeAsset('css/style.css') }}">
    @php
        $styles = $themeStyles ?? [];
        $accent = $styles['accent_color'] ?? null;
        $bg = $styles['background_color'] ?? null;
    @endphp
    @if($accent || $bg)
        <style>
            :root {
                @if($accent) --primary: {{ $accent }}; @endif
                @if($bg) --bg: {{ $bg }}; @endif
            }
        </style>
    @endif
</head>
<body>
<div class="top-strip">
    <div class="top-strip-inner">
        <div>{{ ___('Rent a car in') }} {{ $companyName }}</div>
        <div class="badge">{{ ___('Best price') }}</div>
    </div>
</div>
<header class="site-header">
    <div class="site-header-inner">
        <div class="brand">
            @if($logoUrl)
                <img src="{{ $logoUrl }}" alt="{{ $companyName }}" style="width:38px; height:38px; object-fit:contain; border-radius:10px;">
            @else
                <span class="logo">R</span>
            @endif
            <span>{{ $companyName }}</span>
        </div>
        <nav class="nav">
            <a class="{{ $isHome ? 'active' : '' }}" href="{{ $publicUrl('') }}">{{ ___('Home') }}</a>
            <a href="{{ $publicUrl('#cars') }}">{{ ___('Cars') }}</a>
            <a class="{{ $isBlog ? 'active' : '' }}" href="{{ $publicUrl('blog') }}">{{ ___('Blog') }}</a>
            <a href="{{ $publicUrl('#contact') }}">{{ ___('Contact') }}</a>
            @if(($paymentGatewayEnabled ?? false))
                <a class="{{ $isPay ? 'active' : '' }}" href="{{ $publicUrl('pay') }}">{{ ___('Pay') }}</a>
            @endif
        </nav>
        <div class="header-actions">
            <a class="btn" href="tel:+9940000000">+994 00 000 00 00</a>
            <a class="btn primary" href="{{ $publicUrl('#search') }}">{{ ___('Book now') }}</a>
        </div>
    </div>
</header>

@yield('content')

@php
    $companyAddress = $company->options?->address ?? $company->address ?? ___('Baku, Azerbaijan');
    $companyPhone = $company->options?->contact_phone ?? $company->contact_phone ?? '+994 00 000 00 00';
    $companyEmail = $company->options?->contact_email ?? $company->contact_email ?? ('info@' . ($company->slug ?? 'rentacar') . '.az');
@endphp
<footer class="site-footer" id="contact">
    <div class="site-footer-inner">
        <div>
            <div style="font-weight:800; margin-bottom:6px;">{{ $companyName }}</div>
            <div>{{ $companyAddress }}</div>
            <div style="margin-top:8px;">{{ $companyPhone }}</div>
        </div>
        <div>
            <div style="font-weight:700; margin-bottom:6px;">{{ ___('Quick links') }}</div>
            <div style="display:flex; flex-direction:column; gap:6px;">
                <a href="{{ $publicUrl('') }}">{{ ___('Home') }}</a>
                <a href="{{ $publicUrl('blog') }}">{{ ___('Blog') }}</a>
                @if(($paymentGatewayEnabled ?? false))
                    <a href="{{ $publicUrl('pay') }}">{{ ___('Pay') }}</a>
                @endif
            </div>
        </div>
        <div>
            <div style="font-weight:700; margin-bottom:6px;">{{ ___('Working hours') }}</div>
            <div>Mon - Sun: 09:00 - 20:00</div>
            <div style="margin-top:8px;">{{ ___('Email') }}: {{ $companyEmail }}</div>
        </div>
    </div>
</footer>
</body>
</html>
