﻿@extends('theme-rentacar::layout')

@section('content')
<div class="page-wrap">
    <div class="page-card">
        <h2 style="margin-top:0;">{{ ___('Blog') }}</h2>
        @if($posts->isEmpty())
            <div class="meta">{{ ___('No posts yet.') }}</div>
        @else
            <div style="display:grid; gap:12px;">
                @foreach($posts as $post)
                    <a href="{{ $publicUrl('blog/'.$post->slug) }}" style="display:block; border:1px solid var(--line); border-radius:12px; padding:12px; background:#fff;">
                        <div style="font-weight:700;">{{ $post->title }}</div>
                        <div class="meta" style="margin-top:4px; color:var(--muted); font-size:12px;">
                            {{ $post->published_at ? $post->published_at->format('M d, Y') : '' }}
                        </div>
                        <div style="margin-top:6px; color:var(--muted); font-size:13px;">
                            {{ \Illuminate\Support\Str::limit(strip_tags($post->content ?? ''), 140) }}
                        </div>
                    </a>
                @endforeach
            </div>
        @endif
    </div>
</div>
@endsection
