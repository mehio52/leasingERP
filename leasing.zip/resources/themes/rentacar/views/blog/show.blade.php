﻿@extends('theme-rentacar::layout')

@section('content')
<div class="page-wrap">
    <div class="page-card">
        <h2 style="margin-top:0;">{{ $post->title }}</h2>
        <div class="meta" style="color:var(--muted); font-size:12px; margin-bottom:12px;">
            {{ $post->published_at ? $post->published_at->format('M d, Y') : '' }}
        </div>
        <div>{!! $post->content !!}</div>
        <div style="margin-top:16px;">
            <a class="btn" href="{{ $publicUrl('blog') }}">{{ ___('Back to blog') }}</a>
        </div>
    </div>
</div>
@endsection
