﻿@extends('theme-rentacar::layout')

@section('content')
<div class="page-wrap">
    <div class="page-card">
        <h2 style="margin-top:0;">{{ $page->title }}</h2>
        <div style="color:var(--muted); font-size:14px; margin-bottom:10px;">{{ $page->published_at ? $page->published_at->format('M d, Y') : '' }}</div>
        <div>{!! $page->content !!}</div>
    </div>
</div>
@endsection
