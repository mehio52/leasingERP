﻿@extends('theme-rentacar::layout')

@section('content')
<div class="page-wrap">
    @if(!empty($themeLocales))
        <div style="margin:0 0 12px; display:flex; gap:8px; align-items:center;">
            <span style="color:var(--muted); font-size:13px;">{{ ___('Languages') }}:</span>
            <select id="langSelect" class="btn" style="padding:6px 10px;">
                @foreach($themeLocales as $loc)
                    <option value="{{ $loc }}" @selected(($currentLocale ?? $themeDefaultLocale ?? 'en') === $loc)>{{ strtoupper($loc) }}</option>
                @endforeach
            </select>
        </div>
    @endif

    <div class="page-card">
        <h2 style="margin-top:0;">{{ ___('Loan payment') }}</h2>
        @if(($orderStatus ?? '') === 'success')
            <div style="margin-bottom:10px; color:var(--primary); font-weight:700;">{{ ___('Payment successful') }}</div>
        @elseif(($orderStatus ?? '') === 'error')
            <div style="margin-bottom:10px; color:var(--primary); font-weight:700;">{{ ___('Payment failed') }}</div>
        @endif

        @if($errors->any())
            <div style="margin-bottom:12px; color:#b91c1c;">
                <ul style="margin:0; padding-left:18px;">
                    @foreach($errors->all() as $err)
                        <li>{{ $err }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ $publicUrl('pay') }}" style="display:grid; gap:12px;">
            @csrf
            <input type="hidden" name="intent" value="lookup">
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px;">
                <div>
                    <label>{{ ___('Contract number') }}</label>
                    <input name="contract_no" value="{{ old('contract_no', $account?->contract?->contract_no) }}" required>
                </div>
                <div>
                    <label>{{ ___('FIN code') }}</label>
                    <input name="fin_code" value="{{ old('fin_code', request('fin_code')) }}" required>
                </div>
            </div>
            <div style="display:flex; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ ___('Show debt') }}</button>
            </div>
        </form>
    </div>

    @if($account && $paymentSummary)
        @php
            $currentDue = (float)($paymentSummary['currentDue'] ?? 0);
            $penaltyOutstanding = (float)($paymentSummary['penaltyOutstanding'] ?? 0);
            $totalDue = (float)($paymentSummary['totalDue'] ?? 0);
            $maxAmount = !$paymentOption->allow_overpayment
                ? number_format($totalDue, 2, '.', '')
                : null;
        @endphp
        <div class="page-card" style="margin-top:16px;">
            <h3 style="margin-top:0;">{{ ___('Debt summary') }}</h3>
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap:12px;">
                <div>
                    <div style="color:var(--muted); font-size:12px;">{{ ___('Customer') }}</div>
                    <div><strong>{{ $account->customer?->full_name ?? '' }}</strong></div>
                </div>
                <div>
                    <div style="color:var(--muted); font-size:12px;">{{ ___('Contract') }}</div>
                    <div><strong>{{ $account->contract?->contract_no ?? '' }}</strong></div>
                </div>
                <div>
                    <div style="color:var(--muted); font-size:12px;">{{ ___('Total due') }}</div>
                    <div><strong>{{ number_format($totalDue, 2) }} {{ $paymentCurrency ?? 'AZN' }}</strong></div>
                </div>
            </div>
        </div>

        <div class="page-card" style="margin-top:16px;">
            <h3 style="margin-top:0;">{{ ___('Pay with card') }}</h3>
            <form method="POST" action="{{ $publicUrl('pay') }}" style="display:grid; gap:12px;">
                @csrf
                <input type="hidden" name="intent" value="checkout">
                <input type="hidden" name="contract_no" value="{{ old('contract_no', $account->contract?->contract_no) }}">
                <input type="hidden" name="fin_code" value="{{ old('fin_code', request('fin_code')) }}">
                <div>
                    <label>{{ ___('Amount (:currency)', ['currency' => $paymentCurrency ?? 'AZN']) }}</label>
                    <input name="amount" type="number" step="0.01" value="{{ old('amount', number_format($totalDue,2,'.','')) }}" @if($maxAmount !== null) max="{{ $maxAmount }}" @endif required>
                </div>
                @if(($paymentProvider ?? '') === 'iyzico')
                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px;">
                        <div>
                            <label>{{ ___('Email') }}</label>
                            <input name="buyer_email" type="email" value="{{ old('buyer_email', $companyOptions?->contact_email ?? '') }}" required>
                        </div>
                        <div>
                            <label>{{ ___('Phone') }}</label>
                            <input name="buyer_phone" value="{{ old('buyer_phone', $account->customer?->phone ?? $companyOptions?->contact_phone ?? '') }}" required>
                        </div>
                        <div>
                            <label>{{ ___('Identity number') }}</label>
                            <input name="buyer_identity" value="{{ old('buyer_identity', $account->customer?->id_card_number ?? $account->customer?->fin_code ?? '') }}">
                        </div>
                    </div>
                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px;">
                        <div style="grid-column: span 2;">
                            <label>{{ ___('Address') }}</label>
                            <input name="buyer_address" value="{{ old('buyer_address', $companyOptions?->address ?? '') }}" required>
                        </div>
                        <div>
                            <label>{{ ___('City') }}</label>
                            <input name="buyer_city" value="{{ old('buyer_city', $companyOptions?->city ?? '') }}" required>
                        </div>
                        <div>
                            <label>{{ ___('Country') }}</label>
                            <input name="buyer_country" value="{{ old('buyer_country', $companyOptions?->country ?? '') }}" required>
                        </div>
                        <div>
                            <label>{{ ___('ZIP') }}</label>
                            <input name="buyer_zip" value="{{ old('buyer_zip', '') }}">
                        </div>
                    </div>
                @endif
                <div style="display:flex; justify-content:flex-end;">
                    <button class="btn primary" type="submit">{{ ___('Pay') }}</button>
                </div>
            </form>
        </div>
    @endif
</div>

<script>
    (function(){
        const sel = document.getElementById('langSelect');
        if(!sel) return;
        sel.addEventListener('change', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('lang', sel.value);
            window.location.href = url.toString();
        });
    })();
</script>
@endsection
