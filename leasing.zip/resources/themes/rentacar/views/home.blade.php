﻿@extends('theme-rentacar::layout')

@section('content')
@php
    $vehicles = $publicVehicles ?? collect();
    $hotVehicles = $vehicles->take(4);
    $gridVehicles = $vehicles->slice(4, 36);
    $fallbackTypes = ['Economy', 'SUV', 'Business', 'Family', 'Sport', 'Van'];
@endphp

<section class="hero">
    <div class="hero-inner">
        <div>
            <div class="pill">{{ ___('Fast booking') }} · {{ ___('Best rates') }}</div>
            <h1>{{ ___('Choose from a variety of cars at the best rates.') }}</h1>
            <p>{{ ___('Rent a car in Baku') }} · {{ ___('Fast, easy, affordable') }}</p>
            <div class="search-bar" id="search">
                <input type="text" placeholder="{{ ___('Pick-up location') }}">
                <input type="date">
                <input type="date">
                <select>
                    <option>{{ ___('Car type') }}</option>
                    @foreach($fallbackTypes as $t)
                        <option>{{ $t }}</option>
                    @endforeach
                </select>
                <button type="button">{{ ___('Search') }}</button>
            </div>
        </div>
        <div class="hero-card">
            <div style="font-weight:700; margin-bottom:8px;">{{ ___('Why choose us') }}</div>
            <ul style="margin:0; padding-left:18px; color:#e2e8f0; display:flex; flex-direction:column; gap:8px;">
                <li>{{ ___('Up to 40% off weekly rentals') }}</li>
                <li>{{ ___('Unlimited mileage options') }}</li>
                <li>{{ ___('24/7 customer support') }}</li>
            </ul>
            <div style="margin-top:14px;">
                <a class="btn primary" href="{{ $publicUrl('#cars') }}">{{ ___('View cars') }}</a>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="features">
        <div class="feature-card">
            <div class="feature-icon">%</div>
            <div>
                <div style="font-weight:700;">{{ ___('Best price') }}</div>
                <div style="color:var(--muted); font-size:13px;">{{ ___('Flexible rates for every trip') }}</div>
            </div>
        </div>
        <div class="feature-card">
            <div class="feature-icon">24</div>
            <div>
                <div style="font-weight:700;">{{ ___('24/7 Support') }}</div>
                <div style="color:var(--muted); font-size:13px;">{{ ___('Always ready to help') }}</div>
            </div>
        </div>
        <div class="feature-card">
            <div class="feature-icon">★</div>
            <div>
                <div style="font-weight:700;">{{ ___('Trusted service') }}</div>
                <div style="color:var(--muted); font-size:13px;">{{ ___('Top-rated by customers') }}</div>
            </div>
        </div>
    </div>
</section>

<section class="section" id="cars">
    <h2>{{ ___('Car types') }}</h2>
    <div class="subtitle">{{ ___('Pick the right vehicle for your journey') }}</div>
    <div class="types">
        @foreach($fallbackTypes as $t)
            <div class="type-card">{{ $t }}</div>
        @endforeach
    </div>
</section>

<section class="section">
    <h2>{{ ___('Hot deals') }}</h2>
    <div class="subtitle">{{ ___('Limited offers updated daily') }}</div>
    <div class="card-grid">
        @forelse($hotVehicles as $v)
            @php
                $img = null;
                if (!empty($v->images)) {
                    $first = $v->images[0] ?? null;
                    if ($first) {
                        $img = \Illuminate\Support\Facades\Storage::disk('public')->url($first);
                    }
                }
            @endphp
            <div class="vehicle-card">
                <div class="img">
                    @if($img)
                        <img src="{{ $img }}" alt="{{ $v->display_name }}">
                    @else
                        {{ ___('No image') }}
                    @endif
                </div>
                <div class="body">
                    <div class="title">{{ $v->public_title ?: $v->display_name }}</div>
                    <div class="meta">{{ $v->public_description ?: ___('Best price offer') }}</div>
                    <div class="actions">
                        <span class="price">{{ $v->rent_daily_price ? number_format((float)$v->rent_daily_price, 0) : '120' }} AZN/{{ ___('day') }}</span>
                        <a href="{{ $publicUrl('vehicles/'.$v->id) }}">{{ ___('View') }}</a>
                    </div>
                </div>
            </div>
        @empty
            <div class="page-card">{{ ___('No vehicles available yet.') }}</div>
        @endforelse
    </div>
</section>

<section class="section">
    <h2>{{ ___('Car collection') }}</h2>
    <div class="subtitle">{{ ___('Browse all available vehicles') }}</div>
    <div class="card-grid">
        @foreach($gridVehicles as $v)
            @php
                $img = null;
                if (!empty($v->images)) {
                    $first = $v->images[0] ?? null;
                    if ($first) {
                        $img = \Illuminate\Support\Facades\Storage::disk('public')->url($first);
                    }
                }
            @endphp
            <div class="vehicle-card">
                <div class="img">
                    @if($img)
                        <img src="{{ $img }}" alt="{{ $v->display_name }}">
                    @else
                        {{ ___('No image') }}
                    @endif
                </div>
                <div class="body">
                    <div class="title">{{ $v->public_title ?: $v->display_name }}</div>
                    <div class="meta">{{ $v->public_description ?: ___('Comfort and quality guaranteed') }}</div>
                    <div class="actions">
                        <span class="price">{{ $v->rent_daily_price ? number_format((float)$v->rent_daily_price, 0) : '120' }} AZN/{{ ___('day') }}</span>
                        <a href="{{ $publicUrl('vehicles/'.$v->id) }}">{{ ___('Details') }}</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</section>

<section class="split">
    <div class="split-inner">
        <div class="split-card">
            <div style="font-weight:700; margin-bottom:6px;">{{ ___('Corporate rentals') }}</div>
            <div>{{ ___('Special rates for business customers and long-term contracts.') }}</div>
        </div>
        <div class="split-card">
            <div style="font-weight:700; margin-bottom:6px;">{{ ___('Airport pickup') }}</div>
            <div>{{ ___('Get your car delivered right at the airport in minutes.') }}</div>
        </div>
        <div class="split-card">
            <div style="font-weight:700; margin-bottom:6px;">{{ ___('Premium cars') }}</div>
            <div>{{ ___('Luxury selection for premium experiences.') }}</div>
        </div>
    </div>
</section>
@endsection
