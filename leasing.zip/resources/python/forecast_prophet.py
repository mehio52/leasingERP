import json
import sys
from datetime import datetime

def fallback_forecast(data, months):
    """Simple linear/exponential fallback if Prophet is unavailable."""
    if not data:
        return []
    ys = [row["y"] for row in data]
    avg = sum(ys) / len(ys)
    last_date = datetime.strptime(data[-1]["ds"], "%Y-%m-%d")
    out = []
    yhat = avg
    for i in range(1, months + 1):
        # simple drift: +2% each month
        yhat = yhat * 1.02
        month = last_date.month - 1 + i
        year = last_date.year + month // 12
        month = month % 12 + 1
        day = 1
        out.append({
            "ds": f"{year:04d}-{month:02d}-{day:02d}",
            "yhat": yhat,
            "yhat_lower": yhat * 0.9,
            "yhat_upper": yhat * 1.1,
        })
    return out


def main():
    if len(sys.argv) < 3:
        print("Usage: python forecast_prophet.py input.json output.json")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]

    with open(input_path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    data = payload.get("data", [])
    months = int(payload.get("months", 6))

    try:
        from prophet import Prophet  # type: ignore
        import pandas as pd
        df = pd.DataFrame(data)
        if df.empty:
            forecast_rows = []
        else:
            m = Prophet(seasonality_mode="additive", yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False)
            m.fit(df)
            future = m.make_future_dataframe(periods=months, freq="MS")
            forecast = m.predict(future)
            forecast = forecast.tail(months)[["ds", "yhat", "yhat_lower", "yhat_upper"]]
            forecast["ds"] = forecast["ds"].dt.strftime("%Y-%m-%d")
            forecast_rows = forecast.to_dict(orient="records")
    except Exception:
        forecast_rows = fallback_forecast(data, months)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({"forecast": forecast_rows}, f, ensure_ascii=False)


if __name__ == "__main__":
    main()
