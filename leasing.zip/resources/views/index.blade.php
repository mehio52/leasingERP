@extends('layouts.guest')

@section('title', 'Lizinq SaaS - Fleet Management & Leasing Platform')

@push('styles')
<link rel="stylesheet" href="{{ asset('css/landing.css') }}">
<style>
    :root {
        --primary: #2563eb;
        --primary-light: #3b82f6;
        --primary-dark: #1e40af;
        --secondary: #0ea5e9;
        --text: #0f172a;
        --text-light: #475569;
        --text-lighter: #94a3b8;
        --bg: #f8fafc;
        --bg-light: #ffffff;
        --border: #e2e8f0;
        --success: #16a34a;
        --danger: #dc2626;
        --warning: #f59e0b;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        color: var(--text);
        background: var(--bg);
        line-height: 1.6;
    }

    .wrap {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 24px;
    }

    /* HEADER */
    .top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 0;
        border-bottom: 1px solid var(--border);
        position: sticky;
        top: 0;
        background: var(--bg-light);
        z-index: 100;
    }

    .brand {
        font-size: 20px;
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .nav-buttons {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
    }

    .nav-dropdown {
        position: relative;
    }

    .nav-dropdown summary {
        list-style: none;
        padding: 8px 14px;
        border: 1px solid var(--border);
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        font-size: 14px;
        color: var(--text);
        background: var(--bg-light);
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .nav-dropdown summary::-webkit-details-marker {
        display: none;
    }

    .nav-dropdown[open] summary {
        border-color: var(--primary);
        color: var(--primary);
    }

    .nav-menu {
        position: absolute;
        right: 0;
        top: calc(100% + 8px);
        background: var(--bg-light);
        border: 1px solid var(--border);
        border-radius: 10px;
        box-shadow: 0 12px 30px rgba(15, 23, 42, 0.12);
        min-width: 240px;
        max-height: 320px;
        overflow-y: auto;
        padding: 8px;
        z-index: 200;
    }

    .nav-menu a {
        display: block;
        padding: 8px 10px;
        border-radius: 6px;
        color: var(--text);
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
    }

    .nav-menu a:hover {
        background: var(--bg);
        color: var(--primary);
    }

    .nav-menu .nav-empty {
        padding: 8px 10px;
        color: var(--text-light);
        font-size: 13px;
    }

    .nav-menu .nav-footer {
        margin-top: 6px;
        border-top: 1px solid var(--border);
        padding-top: 6px;
    }

    .btn {
        padding: 10px 20px;
        border: 1px solid var(--border);
        background: transparent;
        color: var(--text);
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        font-size: 14px;
        transition: all 0.2s ease;
    }

    .btn:hover {
        border-color: var(--primary);
        color: var(--primary);
    }

    .btn.primary {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
    }

    .btn.primary:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
    }

    /* Language Switch */
    .lang-switch {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .lang-switch select {
        padding: 8px 12px;
        border: 1px solid var(--border);
        background: var(--bg-light);
        color: var(--text);
        border-radius: 6px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.2s ease;
    }

    .lang-switch select:hover {
        border-color: var(--primary);
    }

    .lang-switch select:focus {
        outline: none;
        border-color: var(--primary);
        background: var(--bg-light);
    }

    /* HERO SECTION */
    .hero {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 32px;
        padding: 60px 0;
        align-items: center;
    }

    .hero-content h1 {
        font-size: 42px;
        font-weight: 700;
        line-height: 1.2;
        margin-bottom: 20px;
        color: var(--text);
    }

    .hero-content > p {
        font-size: 16px;
        color: var(--text-light);
        margin-bottom: 24px;
        line-height: 1.6;
    }

    .pill {
        display: inline-block;
        background: rgba(37, 99, 235, 0.1);
        color: var(--primary);
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 16px;
    }

    .stats {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 24px;
        margin-bottom: 32px;
    }

    .stat {
        padding: 20px;
        background: var(--bg);
        border-radius: 12px;
        border: 1px solid var(--border);
    }

    .stat-number {
        font-size: 28px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 8px;
    }

    .stat-text {
        font-size: 14px;
        color: var(--text-light);
    }

    .hero-card {
        background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        border-radius: 12px;
        padding: 40px;
        color: white;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .hero-card h3 {
        font-size: 24px;
        margin-bottom: 16px;
    }

    .hero-card p {
        margin-bottom: 24px;
        opacity: 0.9;
    }

    .actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }

    /* FEATURES SECTION */
    .section {
        padding: 80px 0;
        border-top: 1px solid var(--border);
    }

    .section-header {
        text-align: center;
        margin-bottom: 60px;
    }

    .section-header h2 {
        font-size: 36px;
        font-weight: 700;
        margin-bottom: 12px;
        color: var(--text);
    }

    .section-header p {
        font-size: 18px;
        color: var(--text-light);
        max-width: 600px;
        margin: 0 auto;
    }

    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 32px;
    }

    .feature-card {
        background: var(--bg-light);
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 32px;
        transition: all 0.3s ease;
    }

    .feature-card:hover {
        border-color: var(--primary);
        box-shadow: 0 10px 30px rgba(37, 99, 235, 0.1);
        transform: translateY(-5px);
    }

    .feature-icon {
        width: 48px;
        height: 48px;
        background: rgba(37, 99, 235, 0.1);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        margin-bottom: 16px;
        color: var(--primary);
    }

    .feature-card h3 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 12px;
        color: var(--text);
    }

    .feature-card p {
        font-size: 14px;
        color: var(--text-light);
        line-height: 1.6;
    }

    /* BENEFITS SECTION */
    .benefits-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 40px;
    }

    .benefit {
        display: flex;
        gap: 20px;
    }

    .benefit-icon {
        width: 48px;
        height: 48px;
        background: var(--primary);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 700;
        flex-shrink: 0;
    }

    .benefit-content h3 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--text);
    }

    .benefit-content p {
        font-size: 14px;
        color: var(--text-light);
    }

    /* BLOG SECTION */
    .blog-filters {
        display: flex;
        gap: 12px;
        margin-bottom: 40px;
        flex-wrap: wrap;
        justify-content: center;
    }

    .blog-filter-btn {
        padding: 8px 16px;
        border: 1px solid var(--border);
        background: transparent;
        color: var(--text);
        border-radius: 20px;
        cursor: pointer;
        font-weight: 500;
        font-size: 14px;
        transition: all 0.2s ease;
    }

    .blog-filter-btn:hover,
    .blog-filter-btn.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
    }

    .blog-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
        gap: 32px;
    }

    .blog-post {
        background: var(--bg-light);
        border: 1px solid var(--border);
        border-radius: 12px;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .blog-post:hover {
        border-color: var(--primary);
        box-shadow: 0 10px 30px rgba(37, 99, 235, 0.1);
    }

    .blog-header {
        background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        height: 200px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 48px;
    }

    .blog-content {
        padding: 24px;
    }

    .blog-category {
        display: inline-block;
        background: rgba(37, 99, 235, 0.1);
        color: var(--primary);
        padding: 4px 10px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 12px;
    }

    .blog-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 12px;
        color: var(--text);
    }

    .blog-excerpt {
        font-size: 14px;
        color: var(--text-light);
        margin-bottom: 16px;
        line-height: 1.6;
    }

    .blog-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 16px;
        border-top: 1px solid var(--border);
        font-size: 12px;
        color: var(--text-lighter);
    }

    .blog-link {
        color: var(--primary);
        text-decoration: none;
        font-weight: 600;
        cursor: pointer;
    }

    /* PRICING SECTION */
    .pricing-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 32px;
    }

    .pricing-card {
        background: var(--bg-light);
        border: 2px solid var(--border);
        border-radius: 12px;
        padding: 40px;
        transition: all 0.3s ease;
        position: relative;
    }

    .pricing-card.featured {
        border-color: var(--primary);
        transform: scale(1.05);
        box-shadow: 0 20px 60px rgba(37, 99, 235, 0.2);
    }

    .pricing-label {
        position: absolute;
        top: -12px;
        right: 20px;
        background: var(--primary);
        color: white;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
    }

    .pricing-name {
        font-size: 20px;
        font-weight: 700;
        margin-bottom: 8px;
        color: var(--text);
    }

    .pricing-desc {
        font-size: 14px;
        color: var(--text-light);
        margin-bottom: 24px;
    }

    .pricing-price {
        font-size: 36px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 4px;
    }

    .pricing-period {
        font-size: 14px;
        color: var(--text-light);
        margin-bottom: 32px;
    }

    .pricing-features {
        list-style: none;
        margin-bottom: 32px;
    }

    .pricing-features li {
        padding: 12px 0;
        border-bottom: 1px solid var(--border);
        font-size: 14px;
        color: var(--text-light);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .pricing-features li:before {
        content: '✓';
        color: var(--success);
        font-weight: 700;
    }

    /* CTA SECTION */
    .cta-section {
        background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        color: white;
        padding: 60px 40px;
        border-radius: 12px;
        text-align: center;
        margin: 80px 0;
    }

    .cta-section h2 {
        font-size: 32px;
        font-weight: 700;
        margin-bottom: 16px;
    }

    .cta-section p {
        font-size: 18px;
        margin-bottom: 32px;
        opacity: 0.9;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
    }

    .landing-footer {
        border-top: 1px solid var(--border);
        background: var(--bg-light);
        padding: 40px 0;
        margin-top: 60px;
    }

    .footer-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 32px;
        align-items: start;
    }

    .footer-brand {
        font-size: 18px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 8px;
    }

    .footer-muted {
        color: var(--text-light);
        font-size: 14px;
    }

    .footer-title {
        font-size: 16px;
        font-weight: 700;
        margin-bottom: 12px;
    }

    .footer-links {
        display: grid;
        gap: 8px;
    }

    .footer-links a {
        color: var(--text);
        text-decoration: none;
        font-size: 14px;
    }

    .footer-links a:hover {
        color: var(--primary);
    }

    /* MODALS */
    .modal-backdrop {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 2000;
        align-items: center;
        justify-content: center;
    }

    .modal-backdrop.active {
        display: flex;
    }

    .modal {
        background: var(--bg-light);
        border-radius: 12px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
        animation: slideUp 0.3s ease;
    }

    .modal-h {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        border-bottom: 1px solid var(--border);
    }

    .modal-h > div {
        font-weight: 700;
        color: var(--text);
    }

    .x {
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: var(--text-light);
        transition: color 0.2s ease;
    }

    .x:hover {
        color: var(--text);
    }

    .modal-b {
        padding: 20px;
        max-height: 70vh;
        overflow-y: auto;
    }

    .ok, .bad {
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 16px;
        font-size: 14px;
        display: none;
    }

    .ok {
        background: rgba(22, 163, 74, 0.1);
        color: var(--success);
    }

    .bad {
        background: rgba(220, 38, 38, 0.1);
        color: var(--danger);
    }

    .ok.show, .bad.show {
        display: block;
    }

    .row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 12px;
    }

    .row1 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    .row > div, .row1 > div {
        display: flex;
        flex-direction: column;
    }

    label {
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 6px;
        color: var(--text);
    }

    input {
        padding: 10px;
        border: 1px solid var(--border);
        border-radius: 6px;
        font-size: 14px;
        background: var(--bg);
        color: var(--text);
        transition: border-color 0.2s ease;
    }

    select {
        padding: 10px;
        border: 1px solid var(--border);
        border-radius: 6px;
        font-size: 14px;
        background: var(--bg);
        color: var(--text);
        transition: border-color 0.2s ease;
    }

    input:focus {
        outline: none;
        border-color: var(--primary);
        background: var(--bg-light);
    }

    select:focus {
        outline: none;
        border-color: var(--primary);
        background: var(--bg-light);
    }

    input::placeholder {
        color: var(--text-light);
    }

    .err {
        font-size: 12px;
        color: var(--danger);
        margin-top: 4px;
        display: none;
    }

    .err.show {
        display: block;
    }

    .hint {
        font-size: 12px;
        color: var(--text-light);
        margin-top: 12px;
    }

    @keyframes slideUp {
        from {
            transform: translateY(20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    @media (max-width: 768px) {
        .hero {
            grid-template-columns: 1fr;
        }

        .hero-content h1 {
            font-size: 28px;
        }

        .section-header h2 {
            font-size: 28px;
        }

        .pricing-card.featured {
            transform: scale(1);
        }

        .benefits-grid {
            grid-template-columns: 1fr;
        }

        .row, .row1 {
            grid-template-columns: 1fr;
        }

        .top {
            flex-direction: column;
            gap: 12px;
        }

        .stats {
            grid-template-columns: 1fr;
        }

        .blog-grid {
            grid-template-columns: 1fr;
        }

        .footer-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
@endpush

@push('scripts')
<script>
    // Modal Management
    document.querySelectorAll('[data-open-modal]').forEach(btn => {
        btn.addEventListener('click', function() {
            const modalId = this.getAttribute('data-open-modal');
            document.getElementById('modal-' + modalId).classList.add('active');
            document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
        });
    });

    document.querySelectorAll('[data-close-modal]').forEach(btn => {
        btn.addEventListener('click', function() {
            const modalId = this.getAttribute('data-close-modal');
            document.getElementById('modal-' + modalId).classList.remove('active');
            document.body.style.overflow = 'auto'; // Restore scrolling
        });
    });

    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
        backdrop.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
                document.body.style.overflow = 'auto'; // Restore scrolling
            }
        });
    });

    // Form Submission
    const registerForm = document.getElementById('form-register');
    const loginForm = document.getElementById('form-login');
    const isSuccessResponse = data => data && (data.ok === true || data.success === true);

    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Clear previous errors
            document.querySelectorAll('.err.show').forEach(el => el.classList.remove('show'));
            document.getElementById('reg-ok').classList.remove('show');
            document.getElementById('reg-bad').classList.remove('show');

            const formData = new FormData(this);
            const url = this.getAttribute('data-url');

            fetch(url, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (isSuccessResponse(data)) {
                    document.getElementById('reg-ok').classList.add('show');
                    document.getElementById('reg-bad').classList.remove('show');
                    // Clear form inputs on success
                    registerForm.reset();
                    setTimeout(() => {
                        window.location.href = data.redirect || '/dashboard';
                    }, 1500);
                } else {
                    document.getElementById('reg-bad').classList.add('show');
                    document.getElementById('reg-ok').classList.remove('show');
                    if (data.errors) {
                        Object.keys(data.errors).forEach(key => {
                            const errEl = document.querySelector(`[data-err="${key}"]`);
                            if (errEl) {
                                errEl.textContent = data.errors[key][0];
                                errEl.classList.add('show');
                            }
                        });
                    }
                }
            })
            .catch(error => {
                console.error('Error submitting form:', error);
                document.getElementById('reg-bad').classList.add('show');
                document.getElementById('reg-ok').classList.remove('show');
            });
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Clear previous errors
            document.querySelectorAll('.err.show').forEach(el => el.classList.remove('show'));
            document.getElementById('log-ok').classList.remove('show');
            document.getElementById('log-bad').classList.remove('show');

            const formData = new FormData(this);
            const url = this.getAttribute('data-url');

            fetch(url, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (isSuccessResponse(data)) {
                    document.getElementById('log-ok').classList.add('show');
                    document.getElementById('log-bad').classList.remove('show');
                    // Clear form inputs on success
                    loginForm.reset();
                    setTimeout(() => {
                        window.location.href = data.redirect || '/dashboard';
                    }, 1500);
                } else {
                    document.getElementById('log-bad').classList.add('show');
                    document.getElementById('log-ok').classList.remove('show');
                    if (data.errors) {
                        Object.keys(data.errors).forEach(key => {
                            const errEl = document.querySelector(`[data-err="${key}"]`);
                            if (errEl) {
                                errEl.textContent = data.errors[key][0];
                                errEl.classList.add('show');
                            }
                        });
                    }
                }
            })
            .catch(error => {
                console.error('Error submitting form:', error);
                document.getElementById('log-bad').classList.add('show');
                document.getElementById('log-ok').classList.remove('show');
            });
        });
    }
</script>
@endpush

@section('content')
@php
    $platformBlogPosts = $platformBlogPosts ?? collect();
    $latestPlatformBlogPosts = $latestPlatformBlogPosts ?? $platformBlogPosts->take(6);
@endphp
<div class="wrap">
    <!-- HEADER -->
    <div class="top">
        <div class="brand">🚗 Lizinq SaaS</div>
        <div class="nav-buttons">
            <details class="nav-dropdown">
                <summary>{{ ___('Blogs') }}</summary>
                <div class="nav-menu">
                    @forelse($platformBlogPosts as $post)
                        <a href="{{ route('public.blog.show', $post->slug) }}">{{ $post->title }}</a>
                    @empty
                        <div class="nav-empty">{{ ___('No posts yet.') }}</div>
                    @endforelse
                    <div class="nav-footer">
                        <a href="{{ route('public.blog.index') }}">{{ ___('View all blogs') }}</a>
                    </div>
                </div>
            </details>
            <!-- Language Switch -->
            <div class="lang-switch">
                @php
                    $langs = ['en' => 'EN', 'az' => 'AZ', 'tr' => 'TR', 'ru' => 'RU'];
                    $current = app()->getLocale();
                @endphp
                <select onchange="if(this.value) window.location=this.value;">
                    @foreach($langs as $code => $label)
                        <option value="{{ route('locale.switch', $code) }}" @selected($current === $code)>{{ $label }}</option>
                    @endforeach
                </select>
            </div>

            @guest
                <button class="btn" data-open-modal="login">{{ ___('Login') }}</button>
                <button class="btn primary" data-open-modal="register">{{ ___('Register') }}</button>
            @else
                <a class="btn primary" href="{{ route('dashboard') }}">{{ ___('İdarəetmə paneli') }}</a>
            @endguest
        </div>
    </div>

    <!-- HERO SECTION -->
    <div class="hero">
        <div class="hero-content">
            <div class="pill">{{ ___('Complete Fleet Management Solution') }}</div>
            <h1>{{ ___('Simplify your leasing & car rental operations') }}</h1>
            <p>{{ ___('All-in-one platform designed for leasing companies and rent-a-car businesses to streamline operations, reduce costs, and increase profitability.') }}</p>

            <div class="stats">
                <div class="stat">
                    <div class="stat-number">500+</div>
                    <div class="stat-text">{{ ___('Active Companies') }}</div>
                </div>
                <div class="stat">
                    <div class="stat-number">50K+</div>
                    <div class="stat-text">{{ ___('Vehicles Managed') }}</div>
                </div>
            </div>

            <div class="actions">
                @guest
                    <button class="btn primary" data-open-modal="register">{{ ___('Start Free Trial') }}</button>
                    <button class="btn" data-open-modal="login">{{ ___('Login to Account') }}</button>
                @else
                    <a class="btn primary" href="{{ route('dashboard') }}">{{ ___('İdarəetmə paneli') }}</a>
                @endguest
            </div>
        </div>

        <div class="hero-card">
            <h3>{{ ___('Quick Access') }}</h3>
            <p>{{ ___('Sign in with your owner account to access the complete dashboard and manage your fleet.') }}</p>
            @guest
                <button class="btn primary" style="width: fit-content;" data-open-modal="login">{{ ___('Login Now') }}</button>
            @else
                <a class="btn primary" style="width: fit-content;" href="{{ route('dashboard') }}">{{ ___('İdarəetmə paneli') }}</a>
            @endguest
        </div>
    </div>

    <!-- FEATURES SECTION -->
    <div class="section">
        <div class="section-header">
            <h2>{{ ___('Powerful Features for Your Business') }}</h2>
            <p>{{ ___('Everything you need to manage leasing and rental operations efficiently and profitably.') }}</p>
        </div>

        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">📄</div>
                <h3>{{ ___('Document Automation') }}</h3>
                <p>{{ ___('Automated document generation and management for contracts, leasing agreements, and compliance requirements.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">🛰️</div>
                <h3>{{ ___('GPS Tracking System') }}</h3>
                <p>{{ ___('Real-time vehicle tracking, route monitoring, and geofencing capabilities for complete fleet visibility.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">💰</div>
                <h3>{{ ___('Credit Amortization') }}</h3>
                <p>{{ ___('Automated payment calculation and amortization schedules with flexible payment terms management.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">⏰</div>
                <h3>{{ ___('Late Payment Tracking') }}</h3>
                <p>{{ ___('Automatic monitoring and alerts for overdue payments with escalation workflows and customer notifications.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">⚖️</div>
                <h3>{{ ___('Fine Enforcement') }}</h3>
                <p>{{ ___('Automated penalty and fine application with configurable rules and compliance tracking.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">🧮</div>
                <h3>{{ ___('Smart Calculators') }}</h3>
                <p>{{ ___('Automated calculators for payments, interest, insurance, maintenance costs, and profitability analysis.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <h3>{{ ___('Risk Analysis') }}</h3>
                <p>{{ ___('Advanced analytics for credit risk assessment, payment behavior analysis, and customer scoring.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">💬</div>
                <h3>{{ ___('WhatsApp Notifications') }}</h3>
                <p>{{ ___('Automated SMS and WhatsApp notifications for payments, reminders, and important updates.') }}</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">💼</div>
                <h3>{{ ___('Financial Management') }}</h3>
                <p>{{ ___('Comprehensive financial tools including invoicing, reporting, forecasting, and cash flow management.') }}</p>
            </div>
        </div>
    </div>

    <!-- BENEFITS SECTION -->
    <div class="section">
        <div class="section-header">
            <h2>{{ ___('Why Choose Lizinq SaaS?') }}</h2>
            <p>{{ ___('Experience the benefits that hundreds of leasing companies trust us with daily.') }}</p>
        </div>

        <div class="benefits-grid">
            <div class="benefit">
                <div class="benefit-icon">✓</div>
                <div class="benefit-content">
                    <h3>{{ ___('Increased Efficiency') }}</h3>
                    <p>{{ ___('Automate routine tasks and reduce manual work by up to 80% with our intelligent workflow system.') }}</p>
                </div>
            </div>

            <div class="benefit">
                <div class="benefit-icon">✓</div>
                <div class="benefit-content">
                    <h3>{{ ___('Reduced Operational Costs') }}</h3>
                    <p>{{ ___('Lower overhead expenses through automation, better resource management, and optimized operations.') }}</p>
                </div>
            </div>

            <div class="benefit">
                <div class="benefit-icon">✓</div>
                <div class="benefit-content">
                    <h3>{{ ___('Improved Cash Flow') }}</h3>
                    <p>{{ ___('Faster payment processing, reduced late payments, and better financial forecasting capabilities.') }}</p>
                </div>
            </div>

            <div class="benefit">
                <div class="benefit-icon">✓</div>
                <div class="benefit-content">
                    <h3>{{ ___('Better Decision Making') }}</h3>
                    <p>{{ ___('Real-time analytics and comprehensive reports to support data-driven business decisions.') }}</p>
                </div>
            </div>

            <div class="benefit">
                <div class="benefit-icon">✓</div>
                <div class="benefit-content">
                    <h3>{{ ___('Enhanced Security') }}</h3>
                    <p>{{ ___('Enterprise-grade security, data encryption, and compliance with international standards.') }}</p>
                </div>
            </div>

            <div class="benefit">
                <div class="benefit-icon">✓</div>
                <div class="benefit-content">
                    <h3>{{ ___('24/7 Support') }}</h3>
                    <p>{{ ___('Dedicated support team available around the clock to assist with any questions or issues.') }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- BLOG SECTION -->
    <div class="section">
        <div class="section-header">
            <h2>{{ ___('Learn from Our Knowledge Base') }}</h2>
            <p>{{ ___('Tips, tutorials, and best practices for maximizing your fleet management efficiency.') }}</p>
        </div>

        <div class="blog-grid">
            @forelse($latestPlatformBlogPosts as $post)
                @php
                    $raw = $post->excerpt ?: ($post->content ?? '');
                    $plain = strip_tags($raw);
                    $plain = preg_replace('/\{[^}]+\}/', '', $plain);
                    $excerpt = \Illuminate\Support\Str::limit(trim($plain), 140);
                    $date = $post->published_at ?? $post->created_at;
                @endphp
                <div class="blog-post">
                    <div class="blog-header">{{ ___('Blog') }}</div>
                    <div class="blog-content">
                        <span class="blog-category">{{ ___('Blog') }}</span>
                        <h3 class="blog-title">{{ $post->title }}</h3>
                        <p class="blog-excerpt">{{ $excerpt }}</p>
                        <div class="blog-footer">
                            <span>{{ $date?->format('Y-m-d') }}</span>
                            <a class="blog-link" href="{{ route('public.blog.show', $post->slug) }}">{{ ___('Read more') }}</a>
                        </div>
                    </div>
                </div>
            @empty
                <div style="grid-column: 1 / -1; text-align:center; color: var(--text-light);">
                    {{ ___('No posts yet.') }}
                </div>
            @endforelse
        </div>
    </div>

    <!-- PRICING SECTION -->
    <div class="section">
        <div class="section-header">
            <h2>{{ ___('Simple, Transparent Pricing') }}</h2>
            <p>{{ ___('Choose the plan that fits your business needs. All plans include 14-day free trial.') }}</p>
        </div>

        <div class="pricing-grid">
            <div class="pricing-card">
                <div class="pricing-name">{{ ___('Starter') }}</div>
                <div class="pricing-desc">{{ ___('Perfect for small rental companies') }}</div>
                <div class="pricing-price">₼299</div>
                <div class="pricing-period">{{ ___('/month') }}</div>
                <ul class="pricing-features">
                    <li>{{ ___('Up to 50 vehicles') }}</li>
                    <li>{{ ___('Basic GPS tracking') }}</li>
                    <li>{{ ___('Document automation') }}</li>
                    <li>{{ ___('Payment management') }}</li>
                    <li>{{ ___('Monthly reports') }}</li>
                </ul>
                @guest
                    <button class="btn primary" style="width:100%;" data-open-modal="register">{{ ___('Start Free Trial') }}</button>
                @endguest
            </div>

            <div class="pricing-card featured">
                <div class="pricing-label">{{ ___('POPULAR') }}</div>
                <div class="pricing-name">{{ ___('Professional') }}</div>
                <div class="pricing-desc">{{ ___('For growing leasing operations') }}</div>
                <div class="pricing-price">₼799</div>
                <div class="pricing-period">{{ ___('/month') }}</div>
                <ul class="pricing-features">
                    <li>{{ ___('Up to 500 vehicles') }}</li>
                    <li>{{ ___('Advanced GPS & tracking') }}</li>
                    <li>{{ ___('Full automation suite') }}</li>
                <li>{{ ___('Risk analysis tools') }}</li>
                <li>{{ ___('WhatsApp notifications') }}</li>
                <li>{{ ___('Custom reports') }}</li>
            </ul>
                @guest
                    <button class="btn primary" style="width:100%;" data-open-modal="register">{{ ___('Start Free Trial') }}</button>
                @endguest
            </div>

            <div class="pricing-card">
                <div class="pricing-name">{{ ___('Enterprise') }}</div>
                <div class="pricing-desc">{{ ___('For large-scale operations') }}</div>
                <div class="pricing-price">{{ ___('Custom') }}</div>
                <div class="pricing-period">{{ ___('Contact sales') }}</div>
                <ul class="pricing-features">
                    <li>{{ ___('Unlimited vehicles') }}</li>
                    <li>{{ ___('All features included') }}</li>
                    <li>{{ ___('API access') }}</li>
                    <li>{{ ___('Dedicated support') }}</li>
                    <li>{{ ___('Custom integration') }}</li>
                    <li>{{ ___('SLA guarantee') }}</li>
                </ul>
                @guest
                    <button class="btn" style="width:100%;" data-open-modal="register">{{ ___('Contact Sales') }}</button>
                @endguest
            </div>
        </div>
    </div>

    <!-- CTA SECTION -->
    <div class="cta-section">
        <h2>{{ ___('Ready to Transform Your Fleet Operations?') }}</h2>
        <p>{{ ___('Join hundreds of leasing and rental companies already using Lizinq SaaS to streamline their business.') }}</p>
        @guest
            <button class="btn" style="background:white;color:var(--primary);border:none;" data-open-modal="register">{{ ___('Start Your Free Trial Today') }}</button>
        @endguest
    </div>
</div>

<footer class="landing-footer">
    <div class="wrap">
        <div class="footer-grid">
            <div>
                <div class="footer-brand">dYs- Lizinq SaaS</div>
                <div class="footer-muted">{{ ___('Built for leasing and rental businesses that want to grow faster.') }}</div>
            </div>
            <div>
                <div class="footer-title">{{ ___('Blogs') }}</div>
                <div class="footer-links">
                    @forelse($platformBlogPosts as $post)
                        <a href="{{ route('public.blog.show', $post->slug) }}">{{ $post->title }}</a>
                    @empty
                        <span class="footer-muted">{{ ___('No posts yet.') }}</span>
                    @endforelse
                    <a href="{{ route('public.blog.index') }}" style="margin-top:6px;">{{ ___('View all blogs') }}</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- REGISTER MODAL -->
<div class="modal-backdrop" id="modal-register">
    <div class="modal">
        <div class="modal-h">
            <div>{{ ___('Create Account') }}</div>
            <button class="x" type="button" data-close-modal="register">×</button>
        </div>
        <div class="modal-b">
            <div class="ok" id="reg-ok">{{ ___('Great! You can continue now...') }}</div>
            <div class="bad" id="reg-bad">{{ ___('Error. Please check the form.') }}</div>

            <form id="form-register" data-url="{{ route('api.company.register') }}">
                @csrf
                <div class="row">
                    <div>
                        <label>{{ ___('Company name') }}</label>
                        <input name="company_name" placeholder="{{ ___('Your Company') }}">
                        <div class="err" data-err="company_name"></div>
                    </div>
                    <div>
                        <label>{{ ___('Company phone') }}</label>
                        <input name="company_phone" placeholder="{{ ___('0501234567') }}">
                        <div class="err" data-err="company_phone"></div>
                    </div>
                </div>

                <div style="height:12px;"></div>

                <div class="row">
                    <div>
                        <label>{{ ___('Module') }}</label>
                        <select name="module">
                            <option value="leasing" selected>{{ ___('Leasing') }}</option>
                            <option value="rentacar">{{ ___('Rent a car') }}</option>
                            <option value="taxipark">{{ ___('Taxi park') }}</option>
                        </select>
                        <div class="err" data-err="module"></div>
                    </div>
                    <div></div>
                </div>

                <div style="height:12px;"></div>

                <div class="row">
                    <div>
                        <label>{{ ___('Owner first name') }}</label>
                        <input name="owner_first_name" placeholder="{{ ___('John') }}">
                        <div class="err" data-err="owner_first_name"></div>
                    </div>
                    <div>
                        <label>{{ ___('Owner last name') }}</label>
                        <input name="owner_last_name" placeholder="{{ ___('Doe') }}">
                        <div class="err" data-err="owner_last_name"></div>
                    </div>
                </div>

                <div style="height:12px;"></div>

                <div class="row">
                    <div>
                        <label>{{ ___('Owner phone') }}</label>
                        <input name="owner_phone" placeholder="{{ ___('0507654321') }}">
                        <div class="err" data-err="owner_phone"></div>
                    </div>
                    <div></div>
                </div>

                <div style="height:12px;"></div>

                <div class="row">
                    <div>
                        <label>{{ ___('Password') }}</label>
                        <input type="password" name="password" placeholder="{{ ___('Min 6 characters') }}">
                        <div class="err" data-err="password"></div>
                    </div>
                    <div>
                        <label>{{ ___('Confirm password') }}</label>
                        <input type="password" name="password_confirmation" placeholder="{{ ___('Repeat') }}">
                        <div class="err" data-err="password_confirmation"></div>
                    </div>
                </div>

                <div class="actions">
                    <button type="button" class="btn" data-close-modal="register">{{ ___('Cancel') }}</button>
                    <button type="submit" class="btn primary" id="btn-reg">{{ ___('Register') }}</button>
                </div>
                <div class="hint">{{ ___('By registering, you agree to our Terms of Service and Privacy Policy.') }}</div>
            </form>
        </div>
    </div>
</div>

<!-- LOGIN MODAL -->
<div class="modal-backdrop" id="modal-login">
    <div class="modal">
        <div class="modal-h">
            <div>{{ ___('Login') }}</div>
            <button class="x" type="button" data-close-modal="login">×</button>
        </div>
        <div class="modal-b">
            <div class="ok" id="log-ok">{{ ___('Login successful!') }}</div>
            <div class="bad" id="log-bad">{{ ___('Invalid phone or password.') }}</div>

            <form id="form-login" data-url="{{ route('auth.login') }}">
                @csrf
                <div class="row1">
                    <div>
                        <label>{{ ___('Phone') }}</label>
                        <input name="phone" placeholder="{{ ___('0501234567') }}">
                        <div class="err" data-err="phone"></div>
                    </div>
                    <div>
                        <label>{{ ___('Password') }}</label>
                        <input type="password" name="password" placeholder="{{ ___('Your password') }}">
                        <div class="err" data-err="password"></div>
                    </div>
                </div>

                <div class="actions" style="justify-content:flex-end;">
                    <button type="button" class="btn" data-close-modal="login">{{ ___('Cancel') }}</button>
                    <button type="submit" class="btn primary" id="btn-log">{{ ___('Login') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection
