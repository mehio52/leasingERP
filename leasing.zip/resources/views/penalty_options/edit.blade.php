@extends('layouts.app')

@section('title', ___('Penalty Ayarlari'))
@section('page_title', ___('Penalty Ayarlari'))
@section('page_subtitle')
Company ID: {{ $options->company_id }} - User: {{ $user->first_name }} {{ $user->last_name }}
@endsection

@section('content')
@if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @php
        $settingsAssoc = $options->settings ?? [];
        $settingsOldK = old('settings_k');
        $settingsOldV = old('settings_v');

        if (is_array($settingsOldK) && is_array($settingsOldV)) {
            $rows = [];
            foreach ($settingsOldK as $idx => $k) {
                $rows[] = ['k' => $k, 'v' => $settingsOldV[$idx] ?? ''];
            }
        } else {
            $rows = [];
            if (is_array($settingsAssoc)) {
                foreach ($settingsAssoc as $k => $v) {
                    $rows[] = ['k' => $k, 'v' => is_scalar($v) ? (string)$v : json_encode($v, JSON_UNESCAPED_UNICODE)];
                }
            }
        }
    @endphp

    <form class="grid" method="POST" action="{{ route('company.penalty_options.update') }}">
        @csrf

        <div class="card">
            <div class="h">{{ ___('Times') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Discount days') }}</label>
                    <input name="grace_days" value="{{ old('grace_days', $options->grace_days) }}" placeholder="0">
                    <div class="muted">{{ ___('Example: 0 / 3 / 5') }}</div>
                </div>

                <div class="field">
                    <label>{{ ___('How many days is the delay counted?') }}</label>
                    <input name="overdue_after_days" value="{{ old('overdue_after_days', $options->overdue_after_days) }}" placeholder="0">
                    <div class="muted">{{ ___('Example: 0 (dərhal) / 1 / 7') }}</div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('penalty rule') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Penalty type') }}</label>
                    <select name="penalty_type" id="penaltyType">
                        <option value="none" @selected(old('penalty_type', $options->penalty_type) === 'none')>{{ ___('Not') }}</option>
                        <option value="fixed" @selected(old('penalty_type', $options->penalty_type) === 'fixed')>{{ ___('Fixed') }}</option>
                        <option value="percent" @selected(old('penalty_type', $options->penalty_type) === 'percent')>{{ ___('Percent') }}</option>
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('Penalty value') }}</label>
                    <input name="penalty_value" id="penaltyValue" value="{{ old('penalty_value', $options->penalty_value) }}" placeholder="0">
                    <div class="muted">{{ ___('Fixed: AZN,  percent value: % (0-100)') }}</div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('penalty frequency') }}</label>
                    <select name="penalty_frequency">
                        <option value="once" @selected(old('penalty_frequency', $options->penalty_frequency) === 'once')>{{ ___('Once') }}</option>
                        <option value="daily" @selected(old('penalty_frequency', $options->penalty_frequency) === 'daily')>{{ ___('Daily') }}</option>
                        <option value="monthly" @selected(old('penalty_frequency', $options->penalty_frequency) === 'monthly')>{{ ___('Monthly') }}</option>
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('What should the penalty be applied to?') }}</label>
                    <select name="apply_on">
                        <option value="remaining_due" @selected(old('apply_on', $options->apply_on) === 'remaining_due')>{{ ___('The remaining debt') }}</option>
                        <option value="principal_only" @selected(old('apply_on', $options->apply_on) === 'principal_only')>{{ ___('Only the main debt') }}</option>
                        <option value="total_installment" @selected(old('apply_on', $options->apply_on) === 'total_installment')>{{ ___('Total payment') }}</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Limits (cap)') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Max penalty amount (AZN)') }}</label>
                    <input name="penalty_cap_amount" value="{{ old('penalty_cap_amount', $options->penalty_cap_amount) }}" placeholder="{{ ___('Optional') }}">
                    <div class="muted">{{ ___('If you leave it blank, it will be unlimited.') }}</div>
                </div>

                <div class="field">
                    <label>{{ ___('Maximum penalty percent (%)') }}</label>
                    <input name="penalty_cap_percent" value="{{ old('penalty_cap_percent', $options->penalty_cap_percent) }}" placeholder="0-100">
                    <div class="muted">{{ ___('If you leave it blank, it will be unlimited.') }}</div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Rounding') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Rounding step') }}</label>
                    <input name="rounding_step" value="{{ old('rounding_step', $options->rounding_step) }}" placeholder="0.01">
                    <div class="muted">{{ ___('Example: 0.01 / 0.05 / 0.1') }}</div>
                </div>
                <div class="field">
                    <label>{{ ___('Rounding mode') }}</label>
                    <select name="rounding_mode">
                        <option value="nearest" @selected(old('rounding_mode', $options->rounding_mode) === 'nearest')>{{ ___('Close') }}</option>
                        <option value="up" @selected(old('rounding_mode', $options->rounding_mode) === 'up')>{{ ___('Up') }}</option>
                        <option value="down" @selected(old('rounding_mode', $options->rounding_mode) === 'down')>{{ ___('below') }}</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Note') }}</div>
            <div class="field">
                <label>{{ ___('Internal recording') }}</label>
                <textarea name="notes" rows="4" placeholder="{{ ___('Internal note...') }}">{{ old('notes', $options->notes) }}</textarea>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Parametrs (key/value)') }}</div>
            <div class="muted" style="margin-bottom:10px;">{{ ___('Any additional parameter key/like to value. “im+” with add.') }}</div>

            <div id="settingsRows" style="display:grid; gap:10px;">
                @foreach($rows as $i => $row)
                    <div class="settings-row" style="display:grid; grid-template-columns: 260px 1fr 90px; gap:10px; align-items:center;">
                        <input name="settings_k[{{ $i }}]" value="{{ $row['k'] ?? '' }}" placeholder="{{ ___('key (ex: penalty.debug)') }}">
                        <input name="settings_v[{{ $i }}]" value="{{ $row['v'] ?? '' }}" placeholder="{{ ___('value (ex: 1)') }}">
                        <button type="button" class="btn danger settings-remove">{{ ___('Delete') }}</button>
                    </div>
                @endforeach
            </div>

            <div class="actions" style="justify-content:flex-start;">
                <button type="button" class="btn" id="settingsAdd">{{ ___('+ To add') }}</button>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Remember') }}</button>
            </div>
        </div>

    </form>
</div>

<script>
(function(){
    // penalty_type -> penalty_value disable
    const type = document.getElementById('penaltyType');
    const val  = document.getElementById('penaltyValue');

    function syncPenalty(){
        if (!type || !val) return;
        const none = (type.value === 'none');
        val.disabled = none;
        if (none) val.value = '0';
    }
    type?.addEventListener('change', syncPenalty);
    syncPenalty();

    // settings add/remove
    const settingsRows = document.getElementById('settingsRows');
    const settingsAdd  = document.getElementById('settingsAdd');

    function nextSettingsIndex(){
        return settingsRows.querySelectorAll('.settings-row').length;
    }

    function settingsRowHtml(i){
        return `
        <div class="settings-row" style="display:grid; grid-template-columns: 260px 1fr 90px; gap:10px; align-items:center;">
            <input name="settings_k[${i}]" value="" placeholder="{{ ___('key (ex: penalty.debug)') }}">
            <input name="settings_v[${i}]" value="" placeholder="{{ ___('value (ex: 1)') }}">
            <button type="button" class="btn danger settings-remove">{{ ___('Delete') }}</button>
        </div>`;
    }

    settingsAdd?.addEventListener('click', () => {
        const i = nextSettingsIndex();
        settingsRows.insertAdjacentHTML('beforeend', settingsRowHtml(i));
    });

    settingsRows?.addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('settings-remove')) {
            e.target.closest('.settings-row')?.remove();
        }
    });
})();
</script>
@endsection