<!doctype html>
<html lang="az">
<head>
    <meta charset="utf-8">
    <title>{{ ___('Provider dashboard report') }}</title>
    <style>
        body { font-family: Arial, sans-serif; color: #111; margin: 24px; }
        h1, h2 { margin: 0 0 8px; }
        .meta { margin-bottom: 16px; color: #444; }
        table { width: 100%; border-collapse: collapse; margin: 12px 0 20px; }
        th, td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; }
        th { background: #f3f4f6; }
        .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .card { border: 1px solid #ddd; padding: 10px; border-radius: 8px; }
    </style>
</head>
<body>
    <h1>{{ ___('Provider dashboard report') }}</h1>
    <div class="meta">
        <div>@include('partials.provider_label', ['provider' => $provider, 'size' => 18])</div>
        <div>{{ $fromDate }} - {{ $toDate }}</div>
    </div>

    <div class="grid">
        <div class="card">
            <h2>{{ ___('Connections summary') }}</h2>
            <div>{{ ___('Pending') }}: {{ $metrics['connections']['pending'] }}</div>
            <div>{{ ___('Approved') }}: {{ $metrics['connections']['approved'] }}</div>
            <div>{{ ___('Rejected') }}: {{ $metrics['connections']['rejected'] }}</div>
            <div>{{ ___('Avg approval') }}: {{ $metrics['connections']['avg_approval_hours'] }}h</div>
        </div>
        <div class="card">
            <h2>{{ ___('Vehicle requests summary') }}</h2>
            <div>{{ ___('Pending') }}: {{ $metrics['vehicle_requests']['pending'] }}</div>
            <div>{{ ___('Approved') }}: {{ $metrics['vehicle_requests']['approved'] }}</div>
            <div>{{ ___('Rejected') }}: {{ $metrics['vehicle_requests']['rejected'] }}</div>
            <div>{{ ___('Avg approval') }}: {{ $metrics['vehicle_requests']['avg_approval_hours'] }}h</div>
        </div>
    </div>

    <h2>{{ ___('Daily connections') }}</h2>
    <table>
        <thead>
        <tr>
            <th>{{ ___('Date') }}</th>
            <th>{{ ___('Total') }}</th>
            <th>{{ ___('Approved') }}</th>
            <th>{{ ___('Rejected') }}</th>
        </tr>
        </thead>
        <tbody>
        @foreach($metrics['daily_connections'] as $row)
            <tr>
                <td>{{ $row['date'] }}</td>
                <td>{{ $row['total'] }}</td>
                <td>{{ $row['approved'] }}</td>
                <td>{{ $row['rejected'] }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <h2>{{ ___('Daily vehicle requests') }}</h2>
    <table>
        <thead>
        <tr>
            <th>{{ ___('Date') }}</th>
            <th>{{ ___('Total') }}</th>
            <th>{{ ___('Approved') }}</th>
            <th>{{ ___('Rejected') }}</th>
        </tr>
        </thead>
        <tbody>
        @foreach($metrics['daily_vehicle_requests'] as $row)
            <tr>
                <td>{{ $row['date'] }}</td>
                <td>{{ $row['total'] }}</td>
                <td>{{ $row['approved'] }}</td>
                <td>{{ $row['rejected'] }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <h2>{{ ___('Top companies (connections)') }}</h2>
    <table>
        <thead>
        <tr>
            <th>{{ ___('Company') }}</th>
            <th>{{ ___('Requests') }}</th>
        </tr>
        </thead>
        <tbody>
        @foreach($metrics['top_connections'] as $row)
            <tr>
                <td>@include('partials.company_label', ['name' => $row['name'] ?? ''])</td>
                <td>{{ $row['total'] }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <h2>{{ ___('Top companies (vehicle requests)') }}</h2>
    <table>
        <thead>
        <tr>
            <th>{{ ___('Company') }}</th>
            <th>{{ ___('Requests') }}</th>
        </tr>
        </thead>
        <tbody>
        @foreach($metrics['top_vehicle_requests'] as $row)
            <tr>
                <td>@include('partials.company_label', ['name' => $row['name'] ?? ''])</td>
                <td>{{ $row['total'] }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <h2>{{ ___('Pending SLA') }}</h2>
    <table>
        <thead>
        <tr>
            <th>{{ ___('Metric') }}</th>
            <th>{{ ___('Value') }}</th>
        </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{ ___('Connections > 24h') }}</td>
                <td>{{ $metrics['sla']['connections_over_24h'] }}</td>
            </tr>
            <tr>
                <td>{{ ___('Connections > 72h') }}</td>
                <td>{{ $metrics['sla']['connections_over_72h'] }}</td>
            </tr>
            <tr>
                <td>{{ ___('Vehicle requests > 24h') }}</td>
                <td>{{ $metrics['sla']['vehicles_over_24h'] }}</td>
            </tr>
            <tr>
                <td>{{ ___('Vehicle requests > 72h') }}</td>
                <td>{{ $metrics['sla']['vehicles_over_72h'] }}</td>
            </tr>
        </tbody>
    </table>
</body>
</html>
