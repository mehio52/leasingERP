@extends('layouts.provider')

@section('title', ___('Provider settings'))
@section('page_title', ___('Provider settings'))
@section('page_subtitle')
    {{ $provider?->name ?? 'GPS Provider' }}
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

@if($errors->any())
    <div class="banner error">
        <div class="badge bad">{{ ___('Xeta') }}</div>
        <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

@php
    $settings = $settings ?? [];
    $platforms = $platforms ?? ['traccar'];
    $activePlatform = $activePlatform ?? 'traccar';
    $traccar = $settings['traccar'] ?? [];
    $wialon = $settings['wialon'] ?? [];
    $gpsDataMode = $settings['gps_data_mode'] ?? 'by_user';
    $features = $settings['features'] ?? [];
    $alertsTemplates = $settings['alerts_templates'] ?? [];
    $commandsBlocklist = $settings['commands_blocklist'] ?? ($settings['commands_whitelist'] ?? []);
    $commandOptions = $commandOptions ?? [];
    $limits = $settings['limits'] ?? [];
    $policy = $settings['policy'] ?? [];
    $providerLogoPath = $settings['logo_path'] ?? null;
    $providerLogoUrl = null;
    if ($providerLogoPath) {
        if (str_starts_with($providerLogoPath, 'http')) {
            $providerLogoUrl = $providerLogoPath;
        } elseif (str_starts_with($providerLogoPath, '/')) {
            $publicPath = public_path(ltrim($providerLogoPath, '/'));
            if (file_exists($publicPath)) {
                $providerLogoUrl = url($providerLogoPath);
            }
        } elseif (\Illuminate\Support\Facades\Storage::disk('public')->exists($providerLogoPath)) {
            $providerLogoUrl = \Illuminate\Support\Facades\Storage::disk('public')->url($providerLogoPath);
        }

        if ($providerLogoUrl && request()->isSecure() && str_starts_with($providerLogoUrl, 'http://')) {
            $providerLogoUrl = preg_replace('#^http://#', 'https://', $providerLogoUrl);
        }
    }
@endphp

<div class="wrap">
    <form method="POST" action="{{ route('gps_provider.settings.update') }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="card">
            <div class="h">{{ ___('Provider info') }}</div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Provider name') }}</label>
                    <input name="name" value="{{ old('name', $provider->name) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Provider logo') }}</label>
                    <input type="file" name="logo" accept="image/*">
                    @if($providerLogoUrl)
                        <div class="muted" style="margin-top:6px;">{{ ___('Current:') }}</div>
                        <div style="margin-top:6px;">
                            <img src="{{ $providerLogoUrl }}" alt="logo" style="max-height:80px; max-width:200px; border:1px solid #ddd; border-radius:8px; background:#fff; padding:4px;">
                        </div>
                        <label style="display:flex; align-items:center; gap:6px; margin-top:8px;">
                            <input type="checkbox" name="remove_logo" value="1">
                            <span>{{ ___('Remove logo') }}</span>
                        </label>
                    @endif
                </div>
            </div>
        </div>

        <div style="height:12px;"></div>

        <div class="card">
            <div class="h">{{ ___('Platforms') }}</div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Allowed platforms') }}</label>
                    <div style="display:flex; gap:12px; flex-wrap:wrap;">
                        @foreach(['traccar' => 'Traccar', 'wialon' => 'Wialon'] as $key => $label)
                            <label style="display:flex; align-items:center; gap:6px;">
                                <input type="checkbox" name="platforms[]" value="{{ $key }}" @checked(in_array($key, old('platforms', $platforms), true))>
                                <span>{{ $label }}</span>
                            </label>
                        @endforeach
                    </div>
                </div>
                <div class="field">
                    <label>{{ ___('Active platform') }}</label>
                    <select name="active_platform">
                        @foreach(['traccar' => 'Traccar', 'wialon' => 'Wialon'] as $key => $label)
                            <option value="{{ $key }}" @selected(old('active_platform', $activePlatform) === $key)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>

        <div style="height:12px;"></div>

        <div class="card">
            <div class="h">{{ ___('GPS data mode') }}</div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Mode') }}</label>
                    <select name="gps_data_mode">
                        <option value="by_user" @selected(old('gps_data_mode', $gpsDataMode) === 'by_user')>{{ ___('By user') }}</option>
                        <option value="by_unit_group" @selected(old('gps_data_mode', $gpsDataMode) === 'by_unit_group')>{{ ___('By unit group') }}</option>
                        <option value="by_account" @selected(old('gps_data_mode', $gpsDataMode) === 'by_account')>{{ ___('By account') }}</option>
                    </select>
                    <div class="muted small">{{ ___('Provider decides how company GPS data is grouped.') }}</div>
                </div>
            </div>
        </div>

        <div style="height:12px;"></div>

        <div class="card">
            <div class="h">{{ ___('Features & policies') }}</div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Enabled features') }}</label>
                    <div style="display:flex; gap:12px; flex-wrap:wrap;">
                        @foreach([
                            'live_map' => 'Live map',
                            'history' => 'History',
                            'reports' => 'Reports',
                            'alerts' => 'Alerts',
                            'geofences' => 'Geofences',
                            'drivers' => 'Drivers',
                            'commands' => 'Commands',
                            'export' => 'Export',
                        ] as $key => $label)
                            <label style="display:flex; align-items:center; gap:6px;">
                                <input type="checkbox" name="features[]" value="{{ $key }}" @checked(in_array($key, old('features', $features), true))>
                                <span>{{ ___($label) }}</span>
                            </label>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Alerts templates') }}</label>
                    <div style="display:flex; gap:12px; flex-wrap:wrap;">
                        @foreach(['speed' => 'Speed', 'geofence' => 'Geofence', 'ignition' => 'Ignition'] as $key => $label)
                            <label style="display:flex; align-items:center; gap:6px;">
                                <input type="checkbox" name="alerts_templates[]" value="{{ $key }}" @checked(in_array($key, old('alerts_templates', $alertsTemplates), true))>
                                <span>{{ ___($label) }}</span>
                            </label>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Blocked commands list') }}</label>
                    @if(!empty($commandOptions))
                        <select id="commandsBlocklistSelect" name="commands_blocklist[]" multiple data-placeholder="{{ ___('Select commands') }}">
                            @foreach($commandOptions as $opt)
                                <option value="{{ $opt['value'] }}" @selected(in_array($opt['value'], old('commands_blocklist', $commandsBlocklist), true))>
                                    {{ $opt['label'] }}
                                </option>
                            @endforeach
                        </select>
                        <div class="muted small">{{ ___('Select blocked commands from Wialon list.') }}</div>
                    @else
                        <input name="commands_blocklist[]" value="{{ old('commands_blocklist.0', $commandsBlocklist[0] ?? '') }}" placeholder="engine_block">
                        <div class="muted small">{{ ___('No Wialon commands found. You can enter manually.') }}</div>
                    @endif
                    <div class="muted small">{{ ___('Leave empty to allow all commands.') }}</div>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Max units') }}</label>
                    <input type="number" min="0" name="max_units" value="{{ old('max_units', $limits['max_units'] ?? '') }}" placeholder="0">
                </div>
                <div class="field">
                    <label>{{ ___('Max alert rules') }}</label>
                    <input type="number" min="0" name="max_alert_rules" value="{{ old('max_alert_rules', $limits['max_alert_rules'] ?? '') }}" placeholder="0">
                </div>
                <div class="field">
                    <label>{{ ___('API poll interval (sec)') }}</label>
                    <input type="number" min="3" max="300" name="api_poll_interval" value="{{ old('api_poll_interval', $limits['api_poll_interval'] ?? '') }}" placeholder="5">
                </div>
                <div class="field">
                    <label>{{ ___('Rate limit / min') }}</label>
                    <input type="number" min="0" name="rate_limit_per_min" value="{{ old('rate_limit_per_min', $limits['rate_limit_per_min'] ?? '') }}" placeholder="0">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label style="display:flex; align-items:center; gap:6px;">
                        <input type="checkbox" name="policy_require_provider_approval" value="1" @checked(old('policy_require_provider_approval', (int) ($policy['require_provider_approval'] ?? 0)) === 1)>
                        <span>{{ ___('Require provider approval for commands') }}</span>
                    </label>
                </div>
                <div class="field">
                    <label style="display:flex; align-items:center; gap:6px;">
                        <input type="checkbox" name="policy_require_2fa" value="1" @checked(old('policy_require_2fa', (int) ($policy['require_2fa'] ?? 0)) === 1)>
                        <span>{{ ___('Require 2FA for commands') }}</span>
                    </label>
                </div>
            </div>
        </div>

        <div style="height:12px;"></div>

        <div class="card">
            <div class="h">{{ ___('Traccar credentials') }}</div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Base URL') }}</label>
                    <input name="traccar_base_url" value="{{ old('traccar_base_url', $traccar['base_url'] ?? '') }}" placeholder="https://traccar.example.com">
                </div>
                <div class="field">
                    <label>{{ ___('Token') }}</label>
                    <input name="traccar_token" value="{{ old('traccar_token', $traccar['token'] ?? '') }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Username') }}</label>
                    <input name="traccar_username" value="{{ old('traccar_username', $traccar['username'] ?? '') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Password') }}</label>
                    <input name="traccar_password" value="{{ old('traccar_password', $traccar['password'] ?? '') }}">
                </div>
            </div>
        </div>

        <div style="height:12px;"></div>

        <div class="card">
            <div class="h">{{ ___('Wialon credentials') }}</div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Base URL') }}</label>
                    <input name="wialon_base_url" value="{{ old('wialon_base_url', $wialon['base_url'] ?? '') }}" placeholder="https://hst-api.wialon.com">
                </div>
                <div class="field">
                    <label>{{ ___('Token') }}</label>
                    <input name="wialon_token" value="{{ old('wialon_token', $wialon['token'] ?? '') }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Login') }}</label>
                    <input name="wialon_username" value="{{ old('wialon_username', $wialon['username'] ?? '') }}" placeholder="user@example.com">
                </div>
                <div class="field">
                    <label>{{ ___('Password') }}</label>
                    <input name="wialon_password" value="{{ old('wialon_password', $wialon['password'] ?? '') }}">
                </div>
            </div>
            <div class="muted small">{{ ___('Use token or login/password. Base URL can be Wialon hosted or your own server.') }}</div>
        </div>

        <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
            <button class="btn ghost" type="submit" formaction="{{ route('gps_provider.settings.test_wialon') }}" formmethod="POST">
                {{ ___('Test Wialon') }}
            </button>
            <button class="btn primary" type="submit">{{ ___('Save') }}</button>
        </div>
    </form>
</div>

@push('styles')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.default.min.css">
    <style>
        .ts-wrapper { width: 100%; }
        .ts-control {
            background: var(--bg-soft);
            border-color: var(--border);
            color: var(--text);
            min-height: 42px;
            padding: 6px 8px;
            border-radius: 10px;
        }
        .ts-control input { color: var(--text); }
        .ts-control .item {
            background: var(--surface);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .ts-dropdown {
            background: var(--bg-soft);
            border-color: var(--border);
            color: var(--text);
        }
        .ts-dropdown .active { background: var(--surface); }
        .ts-dropdown .option { color: var(--text); }
        .ts-control .remove { color: var(--muted); }
    </style>
@endpush

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
    <script>
        (function(){
            const el = document.getElementById('commandsBlocklistSelect');
            if(!el || typeof TomSelect === 'undefined') return;
            const placeholder = el.dataset.placeholder || 'Select commands';
            new TomSelect(el, {
                plugins: ['remove_button'],
                create: false,
                persist: false,
                closeAfterSelect: false,
                hideSelected: true,
                maxOptions: 1000,
                placeholder: placeholder
            });
        })();
    </script>
@endpush
@endsection
