@extends('layouts.provider')

@section('title', ___('Company mapping'))
@section('page_title', ___('Company mapping'))
@section('page_subtitle')
    @include('partials.company_label', ['company' => $connection->company, 'companyId' => $connection->company_id, 'size' => 18])
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

@if($errors->any())
    <div class="banner error">
        <div class="badge bad">{{ ___('Xeta') }}</div>
        <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

@php
    $settings = $settings ?? [];
@endphp

<div class="wrap">
    <form method="POST" action="{{ route('gps_provider.companies.update', $connection) }}">
        @csrf
        @method('PUT')

        <div class="card">
            <div class="h">{{ ___('Mapping settings') }}</div>
            <div class="muted" style="margin-bottom:10px;">
                {{ ___('Provider decides how company vehicles are selected in Wialon.') }}
            </div>

            @if($mode === 'by_unit_group')
                <div class="field">
                    <label>{{ ___('Wialon unit group IDs') }}</label>
                    <input name="wialon_unit_group_ids" value="{{ old('wialon_unit_group_ids', implode(',', $settings['wialon_unit_group_ids'] ?? [])) }}" placeholder="101,102">
                    <div class="muted small">{{ ___('Comma-separated list of unit group IDs.') }}</div>
                </div>
            @elseif($mode === 'by_account')
                <div class="field">
                    <label>{{ ___('Wialon account ID') }}</label>
                    <input name="wialon_account_id" value="{{ old('wialon_account_id', $settings['wialon_account_id'] ?? '') }}" placeholder="account-id">
                </div>
            @else
                <div class="field">
                    <label>{{ ___('Wialon user ID/username') }}</label>
                    <input name="wialon_user" value="{{ old('wialon_user', $settings['wialon_user'] ?? '') }}" placeholder="user@example.com">
                </div>
            @endif
        </div>

        <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
            <a class="btn ghost" href="{{ route('gps_provider.companies.index') }}">{{ ___('Back') }}</a>
            <button class="btn primary" type="submit">{{ ___('Save') }}</button>
        </div>
    </form>
</div>
@endsection
