@extends('layouts.provider')

@section('title', ___('Companies'))
@section('page_title', ___('Companies'))
@section('page_subtitle')
    @include('partials.provider_label', ['provider' => $provider, 'size' => 18])
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <div class="h">{{ ___('Approved companies') }}</div>
        @if($connections->isEmpty())
            <div class="muted" style="margin-top:10px;">{{ ___('No approved companies yet.') }}</div>
        @else
            <div class="table" style="margin-top:10px;">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Company') }}</th>
                        <th>{{ ___('Status') }}</th>
                        <th>{{ ___('Actions') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($connections as $row)
                        <tr>
                            <td>
                                <div style="font-weight:700;">@include('partials.company_label', ['company' => $row->company, 'companyId' => $row->company_id])</div>
                                <div class="muted small">Company ID: {{ $row->company_id }}</div>
                            </td>
                            <td>{{ strtoupper($row->status) }}</td>
                            <td>
                                <a class="btn ghost" href="{{ route('gps_provider.companies.edit', $row) }}">{{ ___('Configure') }}</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div style="margin-top:10px;">{{ $connections->links() }}</div>
        @endif
    </div>
</div>
@endsection
