@extends('layouts.provider')

@section('title', ___('Vehicle requests'))
@section('page_title', ___('Vehicle requests'))
@section('page_subtitle')
    @include('partials.provider_label', ['provider' => $provider, 'size' => 18])
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

@if($errors->any())
    <div class="banner error">
        <div class="badge bad">{{ ___('Error') }}</div>
        <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <div style="display:flex; gap:10px; align-items:center; justify-content:space-between; flex-wrap:wrap;">
            <div class="h">{{ ___('Requests') }}</div>
            <div style="display:flex; gap:8px;">
                @foreach(['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected', 'all' => 'All'] as $key => $label)
                    <a class="btn ghost {{ $status === $key ? 'primary' : '' }}" href="{{ route('gps_provider.vehicle_requests.index', ['status' => $key]) }}">
                        {{ ___($label) }}
                    </a>
                @endforeach
            </div>
        </div>

        @if($requests->isEmpty())
            <div class="muted" style="margin-top:10px;">{{ ___('No requests found.') }}</div>
        @else
            <div class="table" style="margin-top:10px;">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Company') }}</th>
                        <th>{{ ___('Vehicle') }}</th>
                        <th>{{ ___('Unique ID') }}</th>
                        <th>{{ ___('Status') }}</th>
                        <th>{{ ___('Actions') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($requests as $row)
                        @php
                            $vehicle = $row->vehicle;
                            $name = $row->unit_name ?: ($vehicle?->plate_number . ' ' . $vehicle?->display_name);
                        @endphp
                        <tr>
                            <td>
                                <div style="font-weight:700;">@include('partials.company_label', ['company' => $row->company, 'companyId' => $row->company_id])</div>
                                <div class="muted small">Company ID: {{ $row->company_id }}</div>
                            </td>
                            <td>
                                <div style="font-weight:700;">{{ trim((string) $name) ?: ('#' . $row->vehicle_id) }}</div>
                                <div class="muted small">Vehicle ID: {{ $row->vehicle_id }}</div>
                            </td>
                            <td>{{ $row->unique_id ?? '-' }}</td>
                            <td>{{ strtoupper($row->status) }}</td>
                            <td>
                                @if($row->status === 'pending')
                                    <form method="POST" action="{{ route('gps_provider.vehicle_requests.approve', $row) }}" style="display:inline-block; min-width:220px;">
                                        @csrf
                                        @method('PUT')
                                        <select name="hw_type_id" required style="width:100%; margin-bottom:6px;">
                                            <option value="">{{ ___('Select device type') }}</option>
                                            @foreach($hwTypes as $type)
                                                @php
                                                    $typeId = $type['id'] ?? $type['hwTypeId'] ?? $type['hwType'] ?? null;
                                                    $typeName = $type['nm'] ?? $type['name'] ?? ('#' . $typeId);
                                                @endphp
                                                @if($typeId)
                                                    <option value="{{ $typeId }}">{{ $typeName }}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                        <button class="btn primary" type="submit">{{ ___('Approve & create') }}</button>
                                    </form>
                                    <form method="POST" action="{{ route('gps_provider.vehicle_requests.reject', $row) }}" style="display:inline-block;">
                                        @csrf
                                        @method('PUT')
                                        <button class="btn danger" type="submit">{{ ___('Reject') }}</button>
                                    </form>
                                @else
                                    <span class="muted">—</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div style="margin-top:10px;">{{ $requests->links() }}</div>
        @endif
    </div>
</div>
@endsection
