@extends('layouts.provider')

@section('title', ___('Provider dashboard'))
@section('page_title', ___('Provider dashboard'))
@section('page_subtitle')
    @include('partials.provider_label', ['provider' => $provider, 'size' => 18])
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

<div class="wrap">
    <form method="GET" action="{{ route('gps_provider.dashboard') }}" class="card" style="margin-bottom:12px;">
        <div class="row" style="align-items:flex-end;">
            <div class="field">
                <label>{{ ___('From') }}</label>
                <input type="date" name="from" value="{{ $fromDate }}">
            </div>
            <div class="field">
                <label>{{ ___('To') }}</label>
                <input type="date" name="to" value="{{ $toDate }}">
            </div>
            <div class="field" style="margin-left:auto; display:flex; gap:8px;">
                <button class="btn ghost" type="submit">{{ ___('Apply') }}</button>
                <a class="btn ghost" href="{{ route('gps_provider.dashboard.export_csv', ['from' => $fromDate, 'to' => $toDate]) }}">{{ ___('Export CSV') }}</a>
                <a class="btn ghost" target="_blank" href="{{ route('gps_provider.dashboard.export_pdf', ['from' => $fromDate, 'to' => $toDate]) }}">{{ ___('Export PDF') }}</a>
            </div>
        </div>
        <div class="muted small">{{ ___('Custom date range for operational reports.') }}</div>
    </form>

    <div class="row">
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Connections (pending)') }}</div>
                <a class="btn ghost btn-xs" href="{{ route('gps_provider.requests.index', ['status' => 'pending']) }}">{{ ___('View') }}</a>
            </div>
            <div class="metric">{{ $metrics['connections']['pending'] }}</div>
            <div class="muted small">{{ ___('Avg approval') }}: {{ $metrics['connections']['avg_approval_hours'] }}h</div>
        </div>
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Connections (approved)') }}</div>
                <a class="btn ghost btn-xs" href="{{ route('gps_provider.requests.index', ['status' => 'approved']) }}">{{ ___('View') }}</a>
            </div>
            <div class="metric">{{ $metrics['connections']['approved'] }}</div>
            <div class="muted small">{{ ___('Rejected') }}: {{ $metrics['connections']['rejected'] }}</div>
        </div>
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Vehicle requests (pending)') }}</div>
                <a class="btn ghost btn-xs" href="{{ route('gps_provider.vehicle_requests.index', ['status' => 'pending']) }}">{{ ___('View') }}</a>
            </div>
            <div class="metric">{{ $metrics['vehicle_requests']['pending'] }}</div>
            <div class="muted small">{{ ___('Avg approval') }}: {{ $metrics['vehicle_requests']['avg_approval_hours'] }}h</div>
        </div>
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Vehicle requests (approved)') }}</div>
                <a class="btn ghost btn-xs" href="{{ route('gps_provider.vehicle_requests.index', ['status' => 'approved']) }}">{{ ___('View') }}</a>
            </div>
            <div class="metric">{{ $metrics['vehicle_requests']['approved'] }}</div>
            <div class="muted small">{{ ___('Rejected') }}: {{ $metrics['vehicle_requests']['rejected'] }}</div>
        </div>
    </div>

    <div style="height:12px;"></div>

    <div class="row">
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Daily connections') }}</div>
                <button type="button" class="btn ghost btn-xs" data-modal-open="chart-connections">{{ ___('Expand') }}</button>
            </div>
            <div id="connectionsChart" class="dash-chart"></div>
        </div>
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Daily vehicle requests') }}</div>
                <button type="button" class="btn ghost btn-xs" data-modal-open="chart-vehicles">{{ ___('Expand') }}</button>
            </div>
            <div id="vehiclesChart" class="dash-chart"></div>
        </div>
    </div>

    <div style="height:12px;"></div>

    <div class="row">
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Top companies (connections)') }}</div>
                <button type="button" class="btn ghost btn-xs" data-modal-open="top-connections">{{ ___('Expand') }}</button>
            </div>
            @if(empty($metrics['top_connections']))
                <div class="muted">{{ ___('No data for selected range.') }}</div>
            @else
                <div class="table dash-table">
                    <table>
                        <thead>
                        <tr>
                            <th>{{ ___('Company') }}</th>
                            <th>{{ ___('Requests') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($metrics['top_connections'] as $row)
                            <tr>
                                <td>@include('partials.company_label', ['name' => $row['name'] ?? ''])</td>
                                <td>{{ $row['total'] }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Top companies (vehicle requests)') }}</div>
                <button type="button" class="btn ghost btn-xs" data-modal-open="top-vehicles">{{ ___('Expand') }}</button>
            </div>
            @if(empty($metrics['top_vehicle_requests']))
                <div class="muted">{{ ___('No data for selected range.') }}</div>
            @else
                <div class="table dash-table">
                    <table>
                        <thead>
                        <tr>
                            <th>{{ ___('Company') }}</th>
                            <th>{{ ___('Requests') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($metrics['top_vehicle_requests'] as $row)
                            <tr>
                                <td>@include('partials.company_label', ['name' => $row['name'] ?? ''])</td>
                                <td>{{ $row['total'] }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>

    <div style="height:12px;"></div>

    <div class="row">
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Pending SLA') }}</div>
                <button type="button" class="btn ghost btn-xs" data-modal-open="sla">{{ ___('Expand') }}</button>
            </div>
            <div class="row" style="gap:8px;">
                <div class="field">
                    <div class="muted small">{{ ___('Connections > 24h') }}</div>
                    <div class="metric-sm">{{ $metrics['sla']['connections_over_24h'] }}</div>
                </div>
                <div class="field">
                    <div class="muted small">{{ ___('Connections > 72h') }}</div>
                    <div class="metric-sm">{{ $metrics['sla']['connections_over_72h'] }}</div>
                </div>
                <div class="field">
                    <div class="muted small">{{ ___('Vehicle requests > 24h') }}</div>
                    <div class="metric-sm">{{ $metrics['sla']['vehicles_over_24h'] }}</div>
                </div>
                <div class="field">
                    <div class="muted small">{{ ___('Vehicle requests > 72h') }}</div>
                    <div class="metric-sm">{{ $metrics['sla']['vehicles_over_72h'] }}</div>
                </div>
            </div>
        </div>
    </div>

    <div style="height:12px;"></div>

    <div class="row">
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Recent connection requests') }}</div>
                <button type="button" class="btn ghost btn-xs" data-modal-open="recent-connections">{{ ___('Expand') }}</button>
            </div>
            @if($recentConnections->isEmpty())
                <div class="muted">{{ ___('No requests yet.') }}</div>
            @else
                <div class="table dash-table">
                    <table>
                        <thead>
                        <tr>
                            <th>{{ ___('Company') }}</th>
                            <th>{{ ___('Status') }}</th>
                            <th>{{ ___('Requested by') }}</th>
                            <th>{{ ___('Requested at') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($recentConnections as $row)
                            <tr>
                                <td>@include('partials.company_label', ['company' => $row->company, 'companyId' => $row->company_id])</td>
                                <td>{{ strtoupper($row->status) }}</td>
                                <td>{{ $row->requester?->full_name ?? '-' }}</td>
                                <td>{{ $row->requested_at?->format('Y-m-d H:i') ?? '-' }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
        <div class="card dash-mini" style="flex:1;">
            <div class="card-head">
                <div class="h">{{ ___('Recent vehicle requests') }}</div>
                <button type="button" class="btn ghost btn-xs" data-modal-open="recent-vehicles">{{ ___('Expand') }}</button>
            </div>
            @if($recentVehicleRequests->isEmpty())
                <div class="muted">{{ ___('No vehicle requests yet.') }}</div>
            @else
                <div class="table dash-table">
                    <table>
                        <thead>
                        <tr>
                            <th>{{ ___('Company') }}</th>
                            <th>{{ ___('Vehicle') }}</th>
                            <th>{{ ___('Status') }}</th>
                            <th>{{ ___('Requested at') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($recentVehicleRequests as $row)
                            <tr>
                                <td>@include('partials.company_label', ['company' => $row->company, 'companyId' => $row->company_id])</td>
                                <td>{{ $row->vehicle?->display_name ?? ('#' . $row->vehicle_id) }}</td>
                                <td>{{ strtoupper($row->status) }}</td>
                                <td>{{ $row->requested_at?->format('Y-m-d H:i') ?? '-' }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
</div>

<template id="tpl-top-connections">
    <div class="table">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Company') }}</th>
                <th>{{ ___('Requests') }}</th>
            </tr>
            </thead>
            <tbody>
            @foreach($metrics['top_connections'] as $row)
                <tr>
                    <td>@include('partials.company_label', ['name' => $row['name'] ?? ''])</td>
                    <td>{{ $row['total'] }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</template>

<template id="tpl-top-vehicles">
    <div class="table">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Company') }}</th>
                <th>{{ ___('Requests') }}</th>
            </tr>
            </thead>
            <tbody>
            @foreach($metrics['top_vehicle_requests'] as $row)
                <tr>
                    <td>@include('partials.company_label', ['name' => $row['name'] ?? ''])</td>
                    <td>{{ $row['total'] }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</template>

<template id="tpl-recent-connections">
    <div class="table">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Company') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Requested by') }}</th>
                <th>{{ ___('Requested at') }}</th>
            </tr>
            </thead>
            <tbody>
            @foreach($recentConnections as $row)
                <tr>
                    <td>@include('partials.company_label', ['company' => $row->company, 'companyId' => $row->company_id])</td>
                    <td>{{ strtoupper($row->status) }}</td>
                    <td>{{ $row->requester?->full_name ?? '-' }}</td>
                    <td>{{ $row->requested_at?->format('Y-m-d H:i') ?? '-' }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</template>

<template id="tpl-recent-vehicles">
    <div class="table">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Company') }}</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Requested at') }}</th>
            </tr>
            </thead>
            <tbody>
            @foreach($recentVehicleRequests as $row)
                <tr>
                    <td>@include('partials.company_label', ['company' => $row->company, 'companyId' => $row->company_id])</td>
                    <td>{{ $row->vehicle?->display_name ?? ('#' . $row->vehicle_id) }}</td>
                    <td>{{ strtoupper($row->status) }}</td>
                    <td>{{ $row->requested_at?->format('Y-m-d H:i') ?? '-' }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</template>

<template id="tpl-sla">
    <div class="row" style="gap:12px;">
        <div class="field">
            <div class="muted small">{{ ___('Connections > 24h') }}</div>
            <div class="metric">{{ $metrics['sla']['connections_over_24h'] }}</div>
        </div>
        <div class="field">
            <div class="muted small">{{ ___('Connections > 72h') }}</div>
            <div class="metric">{{ $metrics['sla']['connections_over_72h'] }}</div>
        </div>
        <div class="field">
            <div class="muted small">{{ ___('Vehicle requests > 24h') }}</div>
            <div class="metric">{{ $metrics['sla']['vehicles_over_24h'] }}</div>
        </div>
        <div class="field">
            <div class="muted small">{{ ___('Vehicle requests > 72h') }}</div>
            <div class="metric">{{ $metrics['sla']['vehicles_over_72h'] }}</div>
        </div>
    </div>
</template>

<div id="dashboardModal" class="dash-modal" aria-hidden="true">
    <div class="dash-modal-backdrop" data-modal-close></div>
    <div class="dash-modal-content">
        <div class="dash-modal-head">
            <div id="dashModalTitle" class="h"></div>
            <button type="button" class="btn ghost btn-xs" data-modal-close>{{ ___('Close') }}</button>
        </div>
        <div id="dashModalBody" class="dash-modal-body"></div>
    </div>
</div>

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js"></script>
    <script>
        (function(){
            const connectionData = @json($metrics['daily_connections']);
            const vehicleData = @json($metrics['daily_vehicle_requests']);

            const chartOptions = {
                connections: {
                    tooltip: { trigger: 'axis' },
                    grid: { left: 40, right: 16, top: 20, bottom: 30 },
                    xAxis: { type: 'category', data: connectionData.map(r => r.date) },
                    yAxis: { type: 'value' },
                    series: [
                        { name: 'Total', type: 'line', data: connectionData.map(r => r.total), smooth: true },
                        { name: 'Approved', type: 'line', data: connectionData.map(r => r.approved), smooth: true },
                        { name: 'Rejected', type: 'line', data: connectionData.map(r => r.rejected), smooth: true }
                    ]
                },
                vehicles: {
                    tooltip: { trigger: 'axis' },
                    grid: { left: 40, right: 16, top: 20, bottom: 30 },
                    xAxis: { type: 'category', data: vehicleData.map(r => r.date) },
                    yAxis: { type: 'value' },
                    series: [
                        { name: 'Total', type: 'bar', data: vehicleData.map(r => r.total) },
                        { name: 'Approved', type: 'bar', data: vehicleData.map(r => r.approved) },
                        { name: 'Rejected', type: 'bar', data: vehicleData.map(r => r.rejected) }
                    ]
                }
            };

            const initChart = (el, type) => {
                if (!el || !window.echarts) return null;
                const chart = echarts.init(el);
                chart.setOption(chartOptions[type]);
                requestAnimationFrame(() => chart.resize());
                return chart;
            };

            const connEl = document.getElementById('connectionsChart');
            const connChart = initChart(connEl, 'connections');

            const vehicleEl = document.getElementById('vehiclesChart');
            const vehicleChart = initChart(vehicleEl, 'vehicles');

            const modal = document.getElementById('dashboardModal');
            const modalTitle = document.getElementById('dashModalTitle');
            const modalBody = document.getElementById('dashModalBody');
            let modalChart = null;

            const openModal = (title, buildContent) => {
                modalTitle.textContent = title;
                modalBody.innerHTML = '';
                if (modalChart) {
                    modalChart.dispose();
                    modalChart = null;
                }
                modal.classList.add('open');
                modal.setAttribute('aria-hidden', 'false');
                buildContent();
                requestAnimationFrame(() => {
                    modalChart?.resize();
                });
            };

            const closeModal = () => {
                modal.classList.remove('open');
                modal.setAttribute('aria-hidden', 'true');
                if (modalChart) {
                    modalChart.dispose();
                    modalChart = null;
                }
                modalBody.innerHTML = '';
            };

            document.querySelectorAll('[data-modal-close]').forEach(btn => {
                btn.addEventListener('click', closeModal);
            });

            document.querySelectorAll('[data-modal-open]').forEach(btn => {
                btn.addEventListener('click', () => {
                    const key = btn.getAttribute('data-modal-open');
                    if (key === 'chart-connections') {
                        openModal('Daily connections', () => {
                            const chartEl = document.createElement('div');
                            chartEl.style.height = '460px';
                            modalBody.appendChild(chartEl);
                            modalChart = initChart(chartEl, 'connections');
                        });
                        return;
                    }
                    if (key === 'chart-vehicles') {
                        openModal('Daily vehicle requests', () => {
                            const chartEl = document.createElement('div');
                            chartEl.style.height = '460px';
                            modalBody.appendChild(chartEl);
                            modalChart = initChart(chartEl, 'vehicles');
                        });
                        return;
                    }

                    const map = {
                        'top-connections': 'Top companies (connections)',
                        'top-vehicles': 'Top companies (vehicle requests)',
                        'recent-connections': 'Recent connection requests',
                        'recent-vehicles': 'Recent vehicle requests',
                        'sla': 'Pending SLA'
                    };
                    const tpl = document.getElementById('tpl-' + key);
                    if (!tpl) return;
                    openModal(map[key] || 'Details', () => {
                        modalBody.innerHTML = tpl.innerHTML;
                    });
                });
            });

            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.classList.contains('open')) {
                    closeModal();
                }
            });

            window.addEventListener('resize', () => {
                connChart?.resize();
                vehicleChart?.resize();
                modalChart?.resize();
            });
        })();
    </script>
@endpush

@push('styles')
    <style>
        .dash-mini { padding: 10px; }
        .dash-mini .h { font-size: 14px; }
        .metric { font-size: 22px; font-weight: 800; }
        .metric-sm { font-size: 16px; font-weight: 700; }
        .dash-chart { height: 130px; }
        .dash-table { max-height: 150px; overflow: auto; }
        .card-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 6px; }
        .btn-xs { padding: 4px 8px; font-size: 12px; }
        .dash-modal { position: fixed; inset: 0; display: none; z-index: 999; }
        .dash-modal.open { display: flex; align-items: center; justify-content: center; }
        .dash-modal-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,0.55); }
        .dash-modal-content {
            position: relative;
            background: var(--card);
            border: 1px solid var(--border-strong);
            border-radius: 12px;
            padding: 14px;
            width: min(980px, 92vw);
            max-height: 86vh;
            overflow: auto;
            z-index: 1;
        }
        .dash-modal-body .table { max-height: none; }
        .dash-modal-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 8px; }
    </style>
@endpush
@endsection