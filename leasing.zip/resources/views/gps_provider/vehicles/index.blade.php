@extends('layouts.provider')

@section('title', ___('Vehicles'))
@section('page_title', ___('Vehicles'))
@section('page_subtitle')
    {{ $provider?->name ?? 'GPS Provider' }}
@endsection

@section('content')
@if($error)
    <div class="banner error">
        <span class="badge bad">{{ ___('Error') }}</span>
        <span style="margin-left:10px;">{{ $error }}</span>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <div class="h">{{ ___('Wialon units') }}</div>
        @if(empty($units))
            <div class="muted" style="margin-top:10px;">{{ ___('No units found.') }}</div>
        @else
            <div class="table" style="margin-top:10px;">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Unit') }}</th>
                        <th>{{ ___('Unit ID') }}</th>
                        <th>{{ ___('Last position') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($units as $unit)
                        @php
                            $unitId = (int) ($unit['id'] ?? 0);
                            $name = $unit['nm'] ?? $unit['name'] ?? ('#' . $unitId);
                            $pos = $positions[$unitId] ?? null;
                        @endphp
                        <tr>
                            <td>{{ $name }}</td>
                            <td>{{ $unitId }}</td>
                            <td>
                                @if($pos)
                                    <div class="muted small">{{ $pos['device_time'] ?? '-' }}</div>
                                    <div class="muted small">{{ $pos['latitude'] ?? '-' }}, {{ $pos['longitude'] ?? '-' }}</div>
                                @else
                                    <span class="muted">-</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>
@endsection
