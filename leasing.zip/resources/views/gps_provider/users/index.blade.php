@extends('layouts.provider')

@section('title', ___('Provider users'))
@section('page_title', ___('Provider users'))

@section('page_actions')
    <a class="btn primary" href="{{ route('gps_provider.users.create') }}">{{ ___('+ New user') }}</a>
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

<div class="wrap">
    <div class="card">
        @if($users->isEmpty())
            <div class="muted">{{ ___('No users yet.') }}</div>
        @else
            <div class="table">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Name') }}</th>
                        <th>{{ ___('Phone') }}</th>
                        <th>{{ ___('Role') }}</th>
                        <th>{{ ___('Status') }}</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($users as $u)
                        <tr>
                            <td>{{ $u->full_name }}</td>
                            <td>{{ $u->phone }}</td>
                            <td>{{ $u->role }}</td>
                            <td>{{ $u->is_active ? ___('Active') : ___('Inactive') }}</td>
                            <td style="white-space:nowrap;">
                                <a class="btn ghost" href="{{ route('gps_provider.users.edit', $u) }}">{{ ___('Edit') }}</a>
                                <form method="POST" action="{{ route('gps_provider.users.destroy', $u) }}" style="display:inline-block;" onsubmit="return confirm('{{ ___('Delete?') }}');">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div style="margin-top:10px;">{{ $users->links() }}</div>
        @endif
    </div>
</div>
@endsection
