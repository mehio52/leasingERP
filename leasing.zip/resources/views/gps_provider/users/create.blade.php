@extends('layouts.provider')

@section('title', ___('New provider user'))
@section('page_title', ___('New provider user'))

@section('content')
@if($errors->any())
    <div class="banner error">
        <div class="badge bad">{{ ___('Xeta') }}</div>
        <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <form method="POST" action="{{ route('gps_provider.users.store') }}">
            @csrf

            <div class="row">
                <div class="field">
                    <label>{{ ___('First name') }}</label>
                    <input name="first_name" value="{{ old('first_name') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Last name') }}</label>
                    <input name="last_name" value="{{ old('last_name') }}" required>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Phone') }}</label>
                    <input name="phone" value="{{ old('phone') }}" placeholder="+994xxxxxxxxx" required>
                </div>
                <div class="field">
                    <label>{{ ___('Email') }}</label>
                    <input name="email" value="{{ old('email') }}" placeholder="example@mail.com">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Password') }}</label>
                    <input type="password" name="password" required>
                </div>
                <div class="field">
                    <label>{{ ___('Confirm password') }}</label>
                    <input type="password" name="password_confirmation" required>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Role') }}</label>
                    <select name="role">
                        <option value="gps_provider_admin" @selected(old('role') === 'gps_provider_admin')>{{ ___('Admin') }}</option>
                        <option value="gps_provider_staff" @selected(old('role') === 'gps_provider_staff')>{{ ___('Staff') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Active') }}</label>
                    <select name="is_active">
                        <option value="1" @selected(old('is_active', '1') === '1')>{{ ___('Active') }}</option>
                        <option value="0" @selected(old('is_active') === '0')>{{ ___('Inactive') }}</option>
                    </select>
                </div>
            </div>

            <hr class="hr">

            <div class="h" style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
                <span>{{ ___('Permissions') }}</span>
                <button type="button" class="btn outline" onclick="toggleAll()">{{ ___('Select all / deselect all') }}</button>
            </div>

            @php $selectedPerms = old('permissions', []); @endphp

            @foreach($permissionGroups as $groupTitle => $perms)
                @php $hash = md5($groupTitle); @endphp
                <div class="permGroup">
                    <div class="permHead">
                        <strong>{{ $groupTitle }}</strong>
                        <button type="button" class="btn outline" onclick="toggleGroup('{{ $hash }}')">{{ ___('Select group / deselect') }}</button>
                    </div>
                    <div class="permBody">
                        <div class="permGrid">
                            @foreach($perms as $permKey => $permLabel)
                                <label class="permItem">
                                    <input class="perm perm-{{ $hash }}" type="checkbox" name="permissions[]" value="{{ $permKey }}"
                                           @checked(in_array($permKey, $selectedPerms, true))>
                                    <span>
                                        <div style="font-weight:700;">{{ $permLabel }}</div>
                                        <div class="help">{{ $permKey }}</div>
                                    </span>
                                </label>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endforeach

            <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
                <button class="btn primary" type="submit">{{ ___('Create') }}</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleGroup(hash){
    const items = document.querySelectorAll('.perm-' + hash);
    if(!items.length) return;
    let allChecked = true;
    items.forEach(i => { if(!i.checked) allChecked = false; });
    items.forEach(i => { i.checked = !allChecked; });
}

function toggleAll(){
    const items = document.querySelectorAll('.perm');
    if(!items.length) return;
    let allChecked = true;
    items.forEach(i => { if(!i.checked) allChecked = false; });
    items.forEach(i => { i.checked = !allChecked; });
}
</script>
@endsection
