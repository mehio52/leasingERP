@extends('layouts.provider')

@section('title', ___('GPS requests'))
@section('page_title', ___('GPS requests'))
@section('page_subtitle')
    @include('partials.provider_label', ['provider' => $provider, 'size' => 18])
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <div style="display:flex; gap:10px; align-items:center; justify-content:space-between; flex-wrap:wrap;">
            <div class="h">{{ ___('Connection requests') }}</div>
            <div style="display:flex; gap:8px;">
                @foreach(['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected', 'all' => 'All'] as $key => $label)
                    <a class="btn ghost {{ $status === $key ? 'primary' : '' }}" href="{{ route('gps_provider.requests.index', ['status' => $key]) }}">
                        {{ ___($label) }}
                    </a>
                @endforeach
            </div>
        </div>

        @if($connections->isEmpty())
            <div class="muted" style="margin-top:10px;">{{ ___('No requests found.') }}</div>
        @else
            <div class="table" style="margin-top:10px;">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Company') }}</th>
                        <th>{{ ___('Status') }}</th>
                        <th>{{ ___('Requested by') }}</th>
                        <th>{{ ___('Requested at') }}</th>
                        <th>{{ ___('Actions') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($connections as $row)
                        <tr>
                            <td>
                                <div style="font-weight:700;">@include('partials.company_label', ['company' => $row->company, 'companyId' => $row->company_id])</div>
                                <div class="muted small">Company ID: {{ $row->company_id }}</div>
                            </td>
                            <td>{{ strtoupper($row->status) }}</td>
                            <td>{{ $row->requester?->full_name ?? '-' }}</td>
                            <td>{{ $row->requested_at?->format('Y-m-d H:i') ?? '-' }}</td>
                            <td>
                                @if($row->status === 'pending' && auth()->user()?->hasPermission('gps_provider.requests.approve'))
                                    <form method="POST" action="{{ route('gps_provider.requests.approve', $row) }}" style="display:inline-block;">
                                        @csrf
                                        @method('PUT')
                                        <button class="btn primary" type="submit">{{ ___('Approve') }}</button>
                                    </form>
                                    <form method="POST" action="{{ route('gps_provider.requests.reject', $row) }}" style="display:inline-block;">
                                        @csrf
                                        @method('PUT')
                                        <button class="btn danger" type="submit">{{ ___('Reject') }}</button>
                                    </form>
                                @else
                                    <span class="muted">—</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div style="margin-top:10px;">{{ $connections->links() }}</div>
        @endif
    </div>
</div>
@endsection
