@extends('layouts.app')
@php
    $isRentacar = ($user?->company?->moduleCode() ?? 'leasing') === 'rentacar';
    $customerSingle = $isRentacar ? ___('Vehicle owner') : ___('Customer');
@endphp
@section('title', ___('Edit') . ' ' . $customerSingle)
@section('page_title', ___('Edit') . ' ' . $customerSingle)
@section('page_subtitle')
ID #{{ $customer->id }} - {{ $customer->first_name }} {{ $customer->last_name }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('customers.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
@if($errors->any())
        <div class="banner">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('customers.update', $customer) }}">
            @csrf
            @method('PUT')

            <div class="section-title">{{ ___('Personal information') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('First name') }}</label>
                    <input name="first_name" value="{{ old('first_name', $customer->first_name) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Last name') }}</label>
                    <input name="last_name" value="{{ old('last_name', $customer->last_name) }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Father\'s name (optional)') }}</label>
                    <input name="father_name" value="{{ old('father_name', $customer->father_name) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Date of birth (optional)') }}</label>
                    <input type="date" name="birth_date" value="{{ old('birth_date', optional($customer->birth_date)->format('Y-m-d')) }}">
                </div>
            </div>

            <div style="height:18px;"></div>
            <div class="section-title">{{ ___('Contact') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Phone') }}</label>
                    <input name="phone" value="{{ old('phone', $customer->phone) }}" placeholder="{{ ___('+994501234567') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Tax ID (VÖEN) (optional)') }}</label>
                    <input name="voen" value="{{ old('voen', $customer->voen) }}">
                </div>
            </div>

            <div style="margin-top:12px;">
                <label style="display:flex; gap:8px; align-items:center;">
                    <input type="checkbox" name="whatsapp_opt_in" value="1" @checked(old('whatsapp_opt_in', $customer->whatsapp_opt_in))>
                    <span>{{ ___('WhatsApp consent (opt-in)') }}</span>
                </label>
                <div class="muted small">{{ $isRentacar ? ___('Enables WhatsApp notifications and campaigns for this vehicle owner.') : ___('Enables WhatsApp notifications and campaigns for this customer.') }}</div>
            </div>

            <div style="height:18px;"></div>
            <div class="section-title">{{ ___('Documents') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('FIN code (optional)') }}</label>
                    <input name="fin_code" value="{{ old('fin_code', $customer->fin_code) }}">
                </div>
                <div class="field">
                    <label>{{ ___('ID card serial number (optional)') }}</label>
                    <input name="id_card_number" value="{{ old('id_card_number', $customer->id_card_number) }}" placeholder="{{ ___('e.g. AA1234567') }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Driver\'s license number (optional)') }}</label>
                    <input name="driver_license_number" value="{{ old('driver_license_number', $customer->driver_license_number) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Driver\'s license category (optional)') }}</label>
                    <input name="driver_license_category" value="{{ old('driver_license_category', $customer->driver_license_category) }}" placeholder="{{ ___('e.g. B') }}">
                </div>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
