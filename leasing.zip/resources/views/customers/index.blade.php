@extends('layouts.app')
@php
    $isRentacar = ($user?->company?->moduleCode() ?? 'leasing') === 'rentacar';
    $customerLabel = $isRentacar ? ___('Vehicle owners') : ___('Customers');
    $customerSingle = $isRentacar ? ___('Vehicle owner') : ___('Customer');
@endphp
@section('title', $customerLabel)
@section('page_title', $customerLabel)
@section('page_subtitle')
User: {{ $user->first_name }} {{ $user->last_name }}
@endsection
@section('page_actions')
    <a class="btn primary action-right" href="{{ route('customers.create') }}">+ {{ $customerSingle }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    <div class="card">
        <form class="row" method="GET" action="{{ route('customers.index') }}">
            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <input name="q" value="{{ $q }}" placeholder="{{ ___('Search: first name, last name, phone, email, Tax ID/FIN...') }}">
                <button class="btn" type="submit">{{ ___('Search') }}</button>
                @if($q !== '')
                    <a class="btn" href="{{ route('customers.index') }}">{{ ___('Reset') }}</a>
                @endif
            </div>
            <div class="muted">{{ ___('Total:') }} {{ $customers->total() }}</div>
        </form>

        <table style="margin-top:12px;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>{{ ___('Full name') }}</th>
                    <th>{{ ___('Phone') }}</th>
                    <th>{{ ___('Email') }}</th>
                    <th>{{ ___('Active') }}</th>
                    <th style="width:220px;">{{ ___('Actions') }}</th>
                </tr>
            </thead>
            <tbody>
            @forelse($customers as $c)
                <tr>
                    <td>{{ $c->id }}</td>
                    <td>{{ $c->first_name }} {{ $c->last_name }}</td>
                    <td>{{ $c->phone }}</td>
                    <td>{{ $c->email ?? '-' }}</td>
                    <td>
                        @if((int)$c->is_active === 1)
                            <span class="pill ok">{{ ___('Yes') }}</span>
                        @else
                            <span class="pill bad">{{ ___('No') }}</span>
                        @endif
                    </td>
                    <td>
                        <div class="actions">
                            <a class="btn" href="{{ route('customers.edit', $c) }}">{{ ___('Edit') }}</a>

                            <form method="POST" action="{{ route('customers.destroy', $c) }}" onsubmit="return confirm('{{ ___('Are you sure you want to delete?') }}');">
                                @csrf
                                @method('DELETE')
                                <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6" class="muted">{{ $isRentacar ? ___('No vehicle owners found.') : ___('No customers found.') }}</td>
                </tr>
            @endforelse
            </tbody>
        </table>

        <div style="margin-top:12px;">
            {{ $customers->links() }}
        </div>
    </div>
@endsection
