@php
    $layout = auth()->user()?->gpsProvider ? 'layouts.provider' : 'layouts.app';
@endphp

@extends($layout)

@section('title', ___('Ticket detalları'))
@section('page_title', $ticket->subject)
@section('page_subtitle')
    {{ ___('Kateqoriya') }}: {{ $categories[$ticket->category] ?? $ticket->category }} —
    {{ ___('Prioritet') }}: {{ $priorities[$ticket->priority] ?? $ticket->priority }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('tickets.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    <div class="card">
        <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center; justify-content:space-between;">
            <div>
                <div class="muted small">{{ ___('Status') }}</div>
                <div class="badge {{ $ticket->status === 'closed' ? 'ok' : 'warn' }}">
                    {{ $ticket->status === 'closed' ? ___('Bağlı') : ___('Açıq') }}
                </div>
            </div>
            <div class="muted small">
                {{ ___('Yaradıldı') }}: {{ optional($ticket->created_at)->format('Y-m-d H:i') }} |
                {{ ___('Yeniləndi') }}: {{ optional($ticket->updated_at)->format('Y-m-d H:i') }}
            </div>
        </div>
    </div>

    <div class="card">
        <div class="h" style="margin-bottom:8px;">{{ ___('Mesajlar') }}</div>
        <div style="display:grid; gap:10px;">
            @foreach($ticket->messages as $msg)
                <div style="border:1px solid var(--border); border-radius:10px; padding:10px;">
                    <div style="display:flex; gap:8px; align-items:center; justify-content:space-between; flex-wrap:wrap;">
                        @php
                            $msgUser = $msg->user;
                            $deptMap = [
                                'technical' => ___('Texniki dəstək komandası'),
                                'sales' => ___('Satış departamenti'),
                                'proposal' => ___('Təkliflərin qəbulu departamenti'),
                                'complaint' => ___('Şikayətlərin qəbulu departamenti'),
                                'other' => ___('Dəstək komandası'),
                            ];
                            $categoryLabel = $deptMap[$ticket->category] ?? ___('Dəstək komandası');
                            $companyName = $ticket->company?->name ?: ___('Şirkət');
                            $isSuperadmin = $msgUser?->isSuperAdmin() || ($msgUser?->role === 'superadmin');
                            $sameCompany = $msgUser && $ticket->company_id && ((int)$msgUser->company_id === (int)$ticket->company_id);
                            $label = (!$msgUser || $isSuperadmin || !$sameCompany) ? $categoryLabel : $companyName;
                        @endphp
                        <div style="font-weight:700;">{{ $label }}</div>
                        <div class="muted small">{{ optional($msg->created_at)->format('Y-m-d H:i') }}</div>
                    </div>
                    <div style="margin-top:6px; white-space:pre-wrap;">{{ $msg->body }}</div>
                </div>
            @endforeach
        </div>
    </div>

    @if($ticket->status !== 'closed')
        <div class="card">
            <form method="POST" action="{{ route('tickets.reply', $ticket) }}">
                @csrf
                <div class="field">
                    <label>{{ ___('Cavab') }}</label>
                    <textarea name="body" rows="4" required></textarea>
                </div>
                <div class="row" style="align-items:center;">
                    <label class="switch">
                        <input type="checkbox" name="close" value="1" @checked($ticket->status === 'closed')>
                        <div>
                            <div style="font-weight:700;">{{ ___('Cavabdan sonra bağla') }}</div>
                            <div class="muted small">{{ ___('İhtiyac yoxdursa, açıq saxlayın') }}</div>
                        </div>
                    </label>
                </div>
                <div class="actions">
                    <button class="btn primary" type="submit">{{ ___('Göndər') }}</button>
                </div>
            </form>
        </div>
    @endif
@endsection
