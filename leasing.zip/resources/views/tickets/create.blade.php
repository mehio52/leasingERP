@php
    $layout = auth()->user()?->gpsProvider ? 'layouts.provider' : 'layouts.app';
@endphp

@extends($layout)

@section('title', ___('Yeni ticket'))
@section('page_title', ___('Yeni ticket'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('tickets.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    <div class="card">
        <form method="POST" action="{{ route('tickets.store') }}">
            @csrf
            <div class="row">
                <div class="field">
                    <label>{{ ___('Mövzu') }}</label>
                    <input name="subject" value="{{ old('subject') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Kateqoriya') }}</label>
                    <select name="category" required>
                        @foreach($categories as $key => $label)
                            <option value="{{ $key }}" @selected(old('category')===$key)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Prioritet') }}</label>
                    <select name="priority" required>
                        @foreach($priorities as $key => $label)
                            <option value="{{ $key }}" @selected(old('priority')===$key)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="field">
                <label>{{ ___('Mesaj') }}</label>
                <textarea name="body" rows="5" required>{{ old('body') }}</textarea>
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Göndər') }}</button>
            </div>
        </form>
    </div>
@endsection
