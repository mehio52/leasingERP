@php
    $layout = auth()->user()?->gpsProvider ? 'layouts.provider' : 'layouts.app';
@endphp

@extends($layout)

@section('title', ___('Tickets'))
@section('page_title', ___('Dəstək biletləri'))
@section('page_actions')
    <a class="btn primary" href="{{ route('tickets.create') }}">+ {{ ___('Yeni ticket') }}</a>
@endsection

@section('content')
    <div class="card">
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Mövzu') }}</th>
                <th>{{ ___('Kateqoriya') }}</th>
                <th>{{ ___('Prioritet') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Yenilənmə') }}</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($tickets as $t)
                <tr>
                    <td>{{ $t->id }}</td>
                    <td>{{ $t->subject }}</td>
                    <td>{{ $categories[$t->category] ?? $t->category }}</td>
                    <td><span class="badge">{{ $priorities[$t->priority] ?? $t->priority }}</span></td>
                    <td>
                        <span class="badge {{ $t->status === 'closed' ? 'ok' : 'warn' }}">
                            {{ $t->status === 'closed' ? ___('Bağlı') : ___('Açıq') }}
                        </span>
                    </td>
                    <td class="small">{{ optional($t->updated_at)->format('Y-m-d H:i') }}</td>
                    <td><a class="btn ghost" href="{{ route('tickets.show', $t) }}">{{ ___('Aç') }}</a></td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="muted">{{ ___('Ticket yoxdur.') }}</td>
                </tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:12px;">{{ $tickets->links() }}</div>
    </div>
@endsection
