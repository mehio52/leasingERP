@extends('layouts.app')

@section('title', ___('Control panel'))
@section('page_title', ___('Control panel'))
@section('page_subtitle', $company?->name ?? ___('Company not found'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.index') }}">{{ ___('Cars') }}</a>
    <a class="btn ghost" href="{{ route('company.gps') }}">{{ ___('Fleet map') }}</a>
@endsection

@push('styles')
<style>
    .chart-card{ position:relative; overflow:hidden; }
    .chart-body{ position:relative; min-height:220px; }
    .chart-empty{
        position:absolute; inset:0; display:flex; align-items:center; justify-content:center;
        color:#8a8a8a; font-size:13px; pointer-events:none;
    }
    .chart-box{ width:100%; height:240px; }
</style>
@endpush

@section('content')
@php
    $statusLabels = [
        'available' => ___('Available'),
        'rented' => ___('Rented'),
        'maintenance' => ___('Maintenance'),
    ];
    $statusBadge = [
        'available' => 'ok',
        'rented' => 'warn',
        'maintenance' => 'bad',
    ];
@endphp
<div class="wrap">

    @if(!$company)
        <div class="card banner error">
            <div class="badge bad">{{ ___('Problem') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('This user is not affiliated with any company.') }}
            </div>
        </div>
    @endif

    @if($company && ($isSuspended || !$isActive))
        <div class="card banner error">
            <div class="badge bad">{{ ___('Company blocked / deactivated') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('Blocking history') }}: {{ optional($company->suspended_at)->format('Y-m-d H:i') ?? '-' }}
                {{ ___('Reason') }}: {{ $company->suspend_reason ?? '-' }}
            </div>
        </div>
    @endif

    @if($company && $readOnly)
        <div class="card banner warn">
            <div class="badge warn">{{ ___('Trial / Subscription expired.') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('The system is in read-only mode. A block is opened with a new contract or active subscription.') }}
            </div>
        </div>
    @endif

    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:12px;">
        <div class="card">
            <div class="muted small">{{ ___('Total cars') }}</div>
            <div class="h">{{ $vehicleCounts['total'] ?? 0 }}</div>
        </div>
        <div class="card">
            <div class="muted small">{{ ___('Available') }}</div>
            <div class="h">{{ $vehicleCounts['available'] ?? 0 }}</div>
        </div>
        <div class="card">
            <div class="muted small">{{ ___('Rented') }}</div>
            <div class="h">{{ $vehicleCounts['rented'] ?? 0 }}</div>
        </div>
        <div class="card">
            <div class="muted small">{{ ___('Maintenance') }}</div>
            <div class="h">{{ $vehicleCounts['maintenance'] ?? 0 }}</div>
        </div>
        <div class="card">
            <div class="muted small">{{ ___('Returns in next days') }} ({{ $returnWindowDays }})</div>
            <div class="h">{{ $dueSoon?->count() ?? 0 }}</div>
        </div>
        <div class="card">
            <div class="muted small">{{ ___('Overdue returns') }}</div>
            <div class="h">{{ $overdueReturns?->count() ?? 0 }}</div>
        </div>
    </div>

    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:12px; margin-top:12px;">
        <div class="card chart-card">
            <div class="h">{{ ___('Most rented cars') }}</div>
            <div class="muted small">{{ ___('Top vehicles by rentals') }}</div>
            <div class="chart-body">
                <div class="chart-empty">{{ ___('No information') }}</div>
                <div id="topVehiclesChart" class="chart-box"></div>
            </div>
        </div>
        <div class="card chart-card">
            <div class="h">{{ ___('Most rented add-ons') }}</div>
            <div class="muted small">{{ ___('Top company add-ons') }}</div>
            <div class="chart-body">
                <div class="chart-empty">{{ ___('No information') }}</div>
                <div id="topAddonsChart" class="chart-box"></div>
            </div>
        </div>
    </div>

    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px; margin-top:12px;">
        <div class="card">
            <div class="muted small">{{ ___('Monthly revenue') }}</div>
            <div class="h">{{ number_format((float)($totalRevenueMonth ?? 0), 2) }}</div>
        </div>
        <div class="card">
            <div class="muted small">{{ ___('Monthly expenses') }}</div>
            <div class="h">{{ number_format((float)($totalExpenseMonth ?? 0), 2) }}</div>
        </div>
        <div class="card">
            <div class="muted small">{{ ___('Monthly profit') }}</div>
            <div class="h">{{ number_format((float)($totalProfitMonth ?? 0), 2) }}</div>
        </div>
    </div>

    <div class="card chart-card" style="margin-top:12px;">
        <div class="h">{{ ___('Vehicle expenses vs revenue') }}</div>
        <div class="muted small">{{ ___('Expense, revenue and profit by vehicle') }}</div>
        <div class="chart-body">
            <div class="chart-empty">{{ ___('No information') }}</div>
            <div id="vehicleProfitChart" class="chart-box"></div>
        </div>
    </div>

    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:12px; margin-top:12px;">
        <div class="card">
            <div class="h">{{ ___('Rented cars') }}</div>
            <div class="muted small">{{ ___('Active rentals') }}</div>
            <table style="margin-top:10px;">
                <thead>
                <tr>
                    <th>{{ ___('Car') }}</th>
                    <th>{{ ___('Due') }}</th>
                    <th>{{ ___('Source') }}</th>
                </tr>
                </thead>
                <tbody>
                @forelse($rentedCars ?? [] as $v)
                    <tr>
                        <td>{{ $v->brand }} {{ $v->model }} ({{ $v->plate_number ?? '-' }})</td>
                        <td>
                            {{ $v->rent_due_at?->format('Y-m-d H:i') ?? '-' }}
                            @if(!empty($v->rent_remaining))
                                <div class="muted small">{{ $v->rent_remaining }}</div>
                            @endif
                        </td>
                        <td>{{ $v->rent_source ?? '-' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="3" class="muted">{{ ___('No active rentals.') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="card">
            <div class="h">{{ ___('Upcoming returns') }}</div>
            <div class="muted small">{{ ___('Next') }} {{ $returnWindowDays }} {{ ___('days') }}</div>
            <table style="margin-top:10px;">
                <thead>
                <tr>
                    <th>{{ ___('Car') }}</th>
                    <th>{{ ___('Due') }}</th>
                    <th>{{ ___('Status') }}</th>
                </tr>
                </thead>
                <tbody>
                @forelse($dueSoon as $v)
                    <tr>
                        <td>{{ $v->brand }} {{ $v->model }} ({{ $v->plate_number ?? '-' }})</td>
                        <td>
                            {{ $v->rent_due_at?->format('Y-m-d H:i') ?? '-' }}
                            @if(!empty($v->rent_remaining))
                                <div class="muted small">{{ $v->rent_remaining }}</div>
                            @endif
                        </td>
                        <td>
                            <span class="badge {{ $statusBadge[$v->status] ?? 'bad' }}">
                                {{ $statusLabels[$v->status] ?? $v->status }}
                            </span>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="3" class="muted">{{ ___('No upcoming returns.') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="card">
            <div class="h">{{ ___('Overdue returns') }}</div>
            <div class="muted small">{{ ___('Past due vehicles') }}</div>
            <table style="margin-top:10px;">
                <thead>
                <tr>
                    <th>{{ ___('Car') }}</th>
                    <th>{{ ___('Due') }}</th>
                    <th>{{ ___('Status') }}</th>
                </tr>
                </thead>
                <tbody>
                @forelse($overdueReturns as $v)
                    <tr>
                        <td>{{ $v->brand }} {{ $v->model }} ({{ $v->plate_number ?? '-' }})</td>
                        <td>
                            {{ $v->rent_due_at?->format('Y-m-d H:i') ?? '-' }}
                            @if(!empty($v->rent_remaining))
                                <div class="muted small">{{ $v->rent_remaining }}</div>
                            @endif
                        </td>
                        <td>
                            <span class="badge {{ $statusBadge[$v->status] ?? 'bad' }}">
                                {{ $statusLabels[$v->status] ?? $v->status }}
                            </span>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="3" class="muted">{{ ___('No overdue returns.') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="card" style="margin-top:12px;">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
            <div>
                <div class="h">{{ ___('Calendar') }}</div>
                <div class="muted small">{{ ___('Reservations, active and closed rentals') }}</div>
            </div>
            <div style="display:flex; gap:8px; align-items:center;">
                <button class="btn" type="button" id="calPrev">&larr;</button>
                <div class="h" id="calTitle" style="min-width:160px; text-align:center;">-</div>
                <button class="btn" type="button" id="calNext">&rarr;</button>
            </div>
        </div>

        <div id="rentalCalendar"
             data-events='@json($rentalCalendarEvents ?? [])'
             style="margin-top:10px; display:grid; grid-template-columns: repeat(7, 1fr); gap:6px;">
        </div>
        <div class="muted small" style="margin-top:8px;">
            <span style="display:inline-block; width:10px; height:10px; background:#ffb347; border-radius:2px; margin-right:6px;"></span>{{ ___('Active') }}
            <span style="display:inline-block; width:10px; height:10px; background:#9ad39a; border-radius:2px; margin:0 6px 0 14px;"></span>{{ ___('Closed') }}
        </div>
    </div>
</div>

<script>
(function () {
    const cal = document.getElementById('rentalCalendar');
    if (!cal) return;
    const events = JSON.parse(cal.getAttribute('data-events') || '[]');
    let current = new Date();

    function fmtTitle(d){
        return d.toLocaleString('default', { month: 'long', year: 'numeric' });
    }

    function toDate(str){
        if (!str) return null;
        const parts = str.split('-').map(Number);
        return new Date(parts[0], parts[1]-1, parts[2]);
    }

    function inRange(day, start, end){
        if (!start) return false;
        const d = new Date(day.getFullYear(), day.getMonth(), day.getDate());
        const s = new Date(start.getFullYear(), start.getMonth(), start.getDate());
        const e = end ? new Date(end.getFullYear(), end.getMonth(), end.getDate()) : s;
        return d >= s && d <= e;
    }

    function render(){
        const year = current.getFullYear();
        const month = current.getMonth();
        const first = new Date(year, month, 1);
        const last = new Date(year, month + 1, 0);
        const startWeekday = (first.getDay() + 6) % 7; // Monday=0

        const title = document.getElementById('calTitle');
        if (title) title.textContent = fmtTitle(current);

        cal.innerHTML = '';
        const weekLabels = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
        weekLabels.forEach((w) => {
            const h = document.createElement('div');
            h.textContent = w;
            h.style.fontWeight = '600';
            h.style.opacity = '0.6';
            cal.appendChild(h);
        });

        for (let i = 0; i < startWeekday; i++) {
            const cell = document.createElement('div');
            cal.appendChild(cell);
        }

        for (let day = 1; day <= last.getDate(); day++) {
            const cellDate = new Date(year, month, day);
            const cell = document.createElement('div');
            cell.style.border = '1px solid #eee';
            cell.style.borderRadius = '6px';
            cell.style.padding = '6px';
            cell.style.minHeight = '70px';
            cell.style.display = 'flex';
            cell.style.flexDirection = 'column';
            cell.style.gap = '4px';

            const label = document.createElement('div');
            label.textContent = day.toString();
            label.style.fontWeight = '600';
            label.style.fontSize = '12px';
            cell.appendChild(label);

            events.forEach((ev) => {
                const s = toDate(ev.start);
                const e = toDate(ev.end);
                if (!inRange(cellDate, s, e)) return;

                const badge = document.createElement('div');
                badge.textContent = ev.vehicle;
                badge.style.fontSize = '11px';
                badge.style.padding = '2px 4px';
                badge.style.borderRadius = '4px';
                badge.style.whiteSpace = 'nowrap';
                badge.style.overflow = 'hidden';
                badge.style.textOverflow = 'ellipsis';
                badge.style.background = ev.status === 'active' ? '#ffb347' : '#9ad39a';
                badge.title = ev.vehicle + ' #' + ev.id;
                cell.appendChild(badge);
            });

            cal.appendChild(cell);
        }
    }

    document.getElementById('calPrev')?.addEventListener('click', () => {
        current = new Date(current.getFullYear(), current.getMonth() - 1, 1);
        render();
    });
    document.getElementById('calNext')?.addEventListener('click', () => {
        current = new Date(current.getFullYear(), current.getMonth() + 1, 1);
        render();
    });

    render();
})();
</script>
<script>
(function () {
    if (typeof echarts === 'undefined') return;

    const vehicleData = @json($topRentedVehicles ?? []);
    const addonData = @json($topRentedAddons ?? []);
    const profitData = @json($vehicleProfitStats ?? []);

    function renderBar(el, data, color) {
        if (!el) return;
        const wrap = el.closest('.chart-body');
        const empty = wrap ? wrap.querySelector('.chart-empty') : null;
        const hasData = Array.isArray(data) && data.length > 0;
        if (empty) empty.style.display = hasData ? 'none' : 'flex';

        const labels = data.map(d => d.label);
        const values = data.map(d => d.value);

        const chart = echarts.init(el);
        chart.setOption({
            grid: { left: 140, right: 16, top: 10, bottom: 10, containLabel: true },
            tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
            xAxis: {
                type: 'value',
                axisLabel: { color: '#9aa0a6' },
                splitLine: { lineStyle: { color: 'rgba(255,255,255,0.06)' } },
            },
            yAxis: {
                type: 'category',
                data: labels,
                axisLabel: { color: '#cbd5e1' },
                axisTick: { show: false },
                axisLine: { show: false },
            },
            series: [{
                type: 'bar',
                data: values,
                barWidth: 12,
                itemStyle: { color },
                label: { show: true, position: 'right', color: '#cbd5e1' },
            }],
        }, true);

        window.addEventListener('resize', () => chart.resize());
    }

    renderBar(document.getElementById('topVehiclesChart'), vehicleData, '#7cc4ff');
    renderBar(document.getElementById('topAddonsChart'), addonData, '#ffb95e');

    (function renderProfitChart(){
        const el = document.getElementById('vehicleProfitChart');
        if (!el) return;
        const wrap = el.closest('.chart-body');
        const empty = wrap ? wrap.querySelector('.chart-empty') : null;
        const hasData = Array.isArray(profitData) && profitData.length > 0;
        if (empty) empty.style.display = hasData ? 'none' : 'flex';
        if (!hasData) return;

        const labels = profitData.map(d => d.label);
        const revenue = profitData.map(d => d.revenue);
        const expense = profitData.map(d => d.expense);
        const profit = profitData.map(d => d.profit);

        const chart = echarts.init(el);
        chart.setOption({
            grid: { left: 140, right: 16, top: 20, bottom: 10, containLabel: true },
            tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
            legend: { textStyle: { color: '#cbd5e1' } },
            xAxis: {
                type: 'value',
                axisLabel: { color: '#9aa0a6' },
                splitLine: { lineStyle: { color: 'rgba(255,255,255,0.06)' } },
            },
            yAxis: {
                type: 'category',
                data: labels,
                axisLabel: { color: '#cbd5e1' },
                axisTick: { show: false },
                axisLine: { show: false },
            },
            series: [
                { name: @json(___('Revenue')), type: 'bar', data: revenue, itemStyle: { color: '#86efac' }, barWidth: 12 },
                { name: @json(___('Expense')), type: 'bar', data: expense, itemStyle: { color: '#fca5a5' }, barWidth: 12 },
                { name: @json(___('Profit')), type: 'bar', data: profit, itemStyle: { color: '#60a5fa' }, barWidth: 12 },
            ],
        }, true);

        window.addEventListener('resize', () => chart.resize());
    })();
})();
</script>
@endsection
