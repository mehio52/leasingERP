@extends('layouts.app')

@section('title', ___('Notification Logs'))
@section('page_title', ___('Notification Logs'))
@section('page_subtitle', ___('Sent messages'))

@section('content')
<div class="wrap">
    <div class="card slab" style="display:flex; justify-content:space-between; align-items:center;">
        <div>
            <div class="h">{{ ___('Sent messages') }}</div>
            <div class="muted small">{{ ___('Latest notifications for the company') }}</div>
        </div>
        <a class="btn ghost" href="{{ route('company.notifications.edit') }}">{{ ___('Settings') }}</a>
    </div>

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Date') }}</th>
                <th>{{ ___('Phone') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Reason') }}</th>
                <th>{{ ___('Message') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($logs as $log)
                <tr>
                    <td>{{ $log->sent_at?->format('Y-m-d H:i') ?? $log->created_at->format('Y-m-d H:i') }}</td>
                    <td>{{ $log->phone ?? '-' }}</td>
                    <td><span class="badge">{{ $log->status }}</span></td>
                    <td class="small">{{ $log->reason ?? '-' }}</td>
                    <td class="small" style="max-width:320px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">{{ Str::limit($log->message, 120) }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="muted">{{ ___('No logs found.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:10px;">
            {{ $logs->links() }}
        </div>
    </div>
</div>
@endsection