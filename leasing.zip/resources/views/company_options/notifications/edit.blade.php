@extends('layouts.app')

@section('title', ___('Notification Settings'))
@section('page_title', ___('Notification Settings'))
@section('page_subtitle', ___('WhatsApp API'))

@section('content')
<div class="wrap">
    <div class="card">
        <div class="h" style="margin-bottom:8px;">{{ ___('WhatsApp Notifications') }}</div>
        <div class="muted small" style="margin-bottom:10px;">
            {{ ___('When enabled, enter the API details to send WhatsApp messages.') }}
        </div>
        <div style="margin-bottom:12px; display:flex; gap:8px; align-items:center;">
            <a class="btn ghost" href="{{ route('company.notifications.logs') }}">{{ ___('Logs') }}</a>
            @if(Route::has('company.whatsapp_campaigns.index'))
                <a class="btn ghost" href="{{ route('company.whatsapp_campaigns.index') }}">{{ ___('Kampaniyalar') }}</a>
            @endif
        </div>
        @php
            $isRentacar = ($option->company?->moduleCode() ?? 'leasing') === 'rentacar';
            $isTaxi = $isTaxi ?? (($option->company?->moduleCode() ?? 'leasing') === 'taxipark');
        @endphp
        @if(!$isRentacar && !$isTaxi)
            <div class="muted small" style="margin-bottom:12px; padding:10px; border:1px dashed #d9d9d9; border-radius:6px; display:grid; gap:10px;">
            <div>
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Notification fields') }}</div>
                <div style="display:grid; gap:4px;">
                    <div><code>is_active</code> — {{ ___('Turns WhatsApp notifications on or off.') }}</div>
                    <div><code>wp_api_url</code> — {{ ___('Endpoint URL of your WhatsApp API provider.') }}</div>
                    <div><code>wp_api_key</code> — {{ ___('Public/API key used for authentication.') }}</div>
                    <div><code>wp_api_secret</code> — {{ ___('Secret/token used for authentication.') }}</div>
                    <div><code>sender_label</code> — {{ ___('Name or label shown as sender in WhatsApp messages.') }}</div>
                </div>
            </div>
            <div>
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Message keys and triggers') }}</div>
                <div style="display:grid; gap:4px;">
                    <div><code>template_due_soon</code> — {{ ___('Sent when payment due date is approaching.') }}</div>
                    <div><code>template_overdue</code> — {{ ___('Sent when payment is overdue.') }}</div>
                    <div><code>template_penalty_applied</code> — {{ ___('Sent when a penalty is applied to the account.') }}</div>
                </div>
            </div>
            <div>
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Available placeholders') }}</div>
                <div style="display:grid; gap:4px;">
                    <div><code>{customer_name}</code> — {{ ___('Customer full name.') }}</div>
                    <div><code>{due_date}</code> — {{ ___('Upcoming or expected payment date.') }}</div>
                    <div><code>{amount}</code> — {{ ___('Upcoming payment amount.') }}</div>
                    <div><code>{penalty_preview}</code> — {{ ___('Preview of penalty that may apply if unpaid.') }}</div>
                    <div><code>{days_overdue}</code> — {{ ___('How many days the payment is overdue.') }}</div>
                    <div><code>{penalty_amount}</code> — {{ ___('Penalty amount that has been applied.') }}</div>
                    <div><code>{total_due}</code> — {{ ___('Total amount currently due (including penalty).') }}</div>
                    <div><code>{penalty_type}</code> — {{ ___('Penalty type (fixed or percentage).') }}</div>
                    <div><code>{penalty_value}</code> — {{ ___('Penalty value (number for the type above).') }}</div>
                    <div><code>{penalty_frequency}</code> — {{ ___('How often the penalty is applied (daily/once).') }}</div>
                    <div><code>{apply_on}</code> — {{ ___('What the penalty is applied to (principal/total/etc.).') }}</div>
                </div>
            </div>
            </div>
        @endif
        <form method="POST" action="{{ route('company.notifications.update') }}" class="grid" style="grid-template-columns: repeat(auto-fit,minmax(240px,1fr)); gap:12px;">
            @csrf
            @php
                $scheduleSettings = $option->settings['schedule'] ?? [];
                $scheduleInterval = old('schedule_interval_minutes', $scheduleSettings['interval_minutes'] ?? 60);
                $scheduleRanges = old('schedule_time_ranges', implode("\n", $scheduleSettings['allowed_time_ranges'] ?? []));
                $geofenceSettings = $option->settings['geofence'] ?? [];
                $geofenceAdminPanel = old('geofence_admin_panel', $geofenceSettings['admin_panel'] ?? false);
                $geofenceAdminWhatsApp = old('geofence_admin_whatsapp', $geofenceSettings['admin_whatsapp'] ?? false);
                $geofenceCustomerEnterWhatsApp = old('geofence_customer_enter_whatsapp', $geofenceSettings['customer_enter_whatsapp'] ?? false);
                $geofenceCustomerReminderWhatsApp = old('geofence_customer_reminder_whatsapp', $geofenceSettings['customer_reminder_whatsapp'] ?? false);
                $geofenceReminderInterval = old('geofence_customer_reminder_interval_minutes', $geofenceSettings['customer_reminder_interval_minutes'] ?? 60);
                $geofenceTplAdminExit = old('geofence_template_admin_exit', $geofenceSettings['template_admin_exit'] ?? '');
                $geofenceTplCustomerEnter = old('geofence_template_customer_enter', $geofenceSettings['template_customer_enter'] ?? '');
                $geofenceTplCustomerReminder = old('geofence_template_customer_reminder', $geofenceSettings['template_customer_reminder'] ?? '');
                $authorizationSettings = $option->settings['authorization'] ?? [];
                $authorizationAdminPanel = old('authorization_admin_panel', $authorizationSettings['admin_panel'] ?? false);
                $authorizationAdminWhatsApp = old('authorization_admin_whatsapp', $authorizationSettings['admin_whatsapp'] ?? false);
                $authorizationDaysBefore = old('authorization_days_before', $authorizationSettings['days_before'] ?? 7);
                $authorizationTplAdminExpire = old('authorization_template_admin_expire', $authorizationSettings['template_admin_expire'] ?? '');
                $taxiSettings = $option->settings['taxi'] ?? [];
                $taxiPayrollAdminPanel = old('taxi_payroll_admin_panel', $taxiSettings['payroll_admin_panel'] ?? false);
                $taxiPayrollAdminWhatsApp = old('taxi_payroll_admin_whatsapp', $taxiSettings['payroll_admin_whatsapp'] ?? false);
                $taxiPayrollDaysBefore = old('taxi_payroll_days_before', $taxiSettings['payroll_days_before'] ?? 0);
                $taxiPayrollTplAdmin = old('taxi_payroll_template_admin', $taxiSettings['payroll_template_admin'] ?? '');
                $taxiAssignAdminPanel = old('taxi_assignment_admin_panel', $taxiSettings['assignment_admin_panel'] ?? false);
                $taxiAssignAdminWhatsApp = old('taxi_assignment_admin_whatsapp', $taxiSettings['assignment_admin_whatsapp'] ?? false);
                $taxiAssignTplAdmin = old('taxi_assignment_template_admin', $taxiSettings['assignment_template_admin'] ?? '');
                $taxiServiceAdminPanel = old('taxi_service_admin_panel', $taxiSettings['service_admin_panel'] ?? false);
                $taxiServiceAdminWhatsApp = old('taxi_service_admin_whatsapp', $taxiSettings['service_admin_whatsapp'] ?? false);
                $taxiServiceDaysBefore = old('taxi_service_days_before', $taxiSettings['service_days_before'] ?? 0);
                $taxiServiceTplAdmin = old('taxi_service_template_admin', $taxiSettings['service_template_admin'] ?? '');
            @endphp
            <div style="display:flex; align-items:center; gap:8px;">
                <input type="hidden" name="is_active" value="0">
                <input type="checkbox" name="is_active" value="1" @checked($option->is_active)>
                <span class="muted small">{{ ___('Enable') }}</span>
            </div>
            <div>
                <label class="muted small">{{ ___('API URL') }}</label>
                <input class="input" name="wp_api_url" value="{{ old('wp_api_url', $option->wp_api_url) }}">
            </div>
            <div>
                <label class="muted small">{{ ___('API Secret') }}</label>
                <input class="input" name="wp_api_key" value="{{ old('wp_api_key', $option->wp_api_key) }}">
            </div>
            <div>
                <label class="muted small">{{ ___('API Key') }}</label>
                <input class="input" name="wp_api_secret" value="{{ old('wp_api_secret', $option->wp_api_secret) }}">
            </div>
            <div>
                <label class="muted small">{{ ___('Sender label') }}</label>
                <input class="input" name="sender_label" value="{{ old('sender_label', $option->sender_label) }}">
            </div>

            @if(!$isRentacar && !$isTaxi)
                <div class="span-12" style="grid-column: span 12;">
                    <div style="display:grid; gap:8px;">
                        <div style="font-weight:600;">{{ ___('Bildiriş planı') }}</div>
                        <div style="display:grid; gap:10px; grid-template-columns: repeat(auto-fit,minmax(240px,1fr));">
                            <div>
                                <label class="muted small">{{ ___('İnterval (dəqiqə)') }}</label>
                                <input class="input" type="number" min="5" name="schedule_interval_minutes" value="{{ $scheduleInterval }}">
                                <div class="muted small">{{ ___('Bu intervaldan sonra yeni bildiriş göndərilməlidir. Standart 60 dəqiqədir.') }}</div>
                            </div>
                            <div>
                                <label class="muted small">{{ ___('İcazə verilən saat intervalları') }}</label>
                                <textarea class="input" rows="3" name="schedule_time_ranges" placeholder="09:00-12:00, 14:00-18:00">{{ $scheduleRanges }}</textarea>
                                <div class="muted small">{{ ___('HH:MM-HH:MM formatında aralıqları vergül və ya yeni sətrə ayırın. Boş buraxsaq, bütün gün göndərilir.') }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @if(!$isRentacar && !$isTaxi)
                <div class="span-12" style="grid-column: span 12;">
                    <label class="muted small">{{ ___('Notification - Payment due date is approaching') }}</label>
                    <textarea class="input" rows="3" name="template_due_soon">{{ old('template_due_soon', $option->template_due_soon) }}</textarea>
                    <div class="muted small">{{ ___('Available keywords: {customer_name}, {due_date}, {amount}, {penalty_preview}') }}</div>
                </div>
                <div class="span-12" style="grid-column: span 12;">
                    <label class="muted small">{{ ___('Notification - Overdue') }}</label>
                    <textarea class="input" rows="3" name="template_overdue">{{ old('template_overdue', $option->template_overdue) }}</textarea>
                    <div class="muted small">{{ ___('Available keywords: {customer_name}, {days_overdue}, {penalty_amount}, {total_due}') }}</div>
                </div>
                <div class="span-12" style="grid-column: span 12;">
                    <label class="muted small">{{ ___('Notification - Penalty applied') }}</label>
                    <textarea class="input" rows="3" name="template_penalty_applied">{{ old('template_penalty_applied', $option->template_penalty_applied) }}</textarea>
                    <div class="muted small">{{ ___('Keywords: {customer_name}, {penalty_type}, {penalty_value}, {penalty_frequency}, {apply_on}') }}</div>
                </div>
            @endif

            @if($isTaxi)
            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Taxi payroll notifications') }}</div>
                <div class="muted small" style="margin-bottom:10px;">{{ ___('Notify admins about salary periods and summaries.') }}</div>
                <div style="display:grid; gap:10px; grid-template-columns: repeat(auto-fit,minmax(240px,1fr));">
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="taxi_payroll_admin_panel" value="0">
                        <input type="checkbox" name="taxi_payroll_admin_panel" value="1" @checked($taxiPayrollAdminPanel)>
                        {{ ___('Send admin panel notification') }}
                    </label>
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="taxi_payroll_admin_whatsapp" value="0">
                        <input type="checkbox" name="taxi_payroll_admin_whatsapp" value="1" @checked($taxiPayrollAdminWhatsApp)>
                        {{ ___('Send admin WhatsApp notification') }}
                    </label>
                </div>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Notify before (days)') }}</label>
                <input class="input" type="number" min="0" max="60" name="taxi_payroll_days_before" value="{{ $taxiPayrollDaysBefore }}">
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Template - Payroll summary (admin)') }}</label>
                <textarea class="input" rows="3" name="taxi_payroll_template_admin">{{ $taxiPayrollTplAdmin }}</textarea>
                <div class="muted small">{{ ___('Placeholders: {month}, {drivers}, {trips}, {revenue}, {salary_total}') }}</div>
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Taxi assignment notifications') }}</div>
                <div class="muted small" style="margin-bottom:10px;">{{ ___('Notify admins when a vehicle is assigned/returned.') }}</div>
                <div style="display:grid; gap:10px; grid-template-columns: repeat(auto-fit,minmax(240px,1fr));">
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="taxi_assignment_admin_panel" value="0">
                        <input type="checkbox" name="taxi_assignment_admin_panel" value="1" @checked($taxiAssignAdminPanel)>
                        {{ ___('Send admin panel notification') }}
                    </label>
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="taxi_assignment_admin_whatsapp" value="0">
                        <input type="checkbox" name="taxi_assignment_admin_whatsapp" value="1" @checked($taxiAssignAdminWhatsApp)>
                        {{ ___('Send admin WhatsApp notification') }}
                    </label>
                </div>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Template - Assignment (admin)') }}</label>
                <textarea class="input" rows="3" name="taxi_assignment_template_admin">{{ $taxiAssignTplAdmin }}</textarea>
                <div class="muted small">{{ ___('Placeholders: {vehicle}, {plate}, {driver}, {assigned_at}, {returned_at}') }}</div>
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Taxi service notifications') }}</div>
                <div class="muted small" style="margin-bottom:10px;">{{ ___('Notify admins before a vehicle service date.') }}</div>
                <div style="display:grid; gap:10px; grid-template-columns: repeat(auto-fit,minmax(240px,1fr));">
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="taxi_service_admin_panel" value="0">
                        <input type="checkbox" name="taxi_service_admin_panel" value="1" @checked($taxiServiceAdminPanel)>
                        {{ ___('Send admin panel notification') }}
                    </label>
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="taxi_service_admin_whatsapp" value="0">
                        <input type="checkbox" name="taxi_service_admin_whatsapp" value="1" @checked($taxiServiceAdminWhatsApp)>
                        {{ ___('Send admin WhatsApp notification') }}
                    </label>
                </div>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Notify before service (days)') }}</label>
                <input class="input" type="number" min="0" max="365" name="taxi_service_days_before" value="{{ $taxiServiceDaysBefore }}">
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Template - Service reminder (admin)') }}</label>
                <textarea class="input" rows="3" name="taxi_service_template_admin">{{ $taxiServiceTplAdmin }}</textarea>
                <div class="muted small">{{ ___('Placeholders: {vehicle}, {plate}, {service_date}') }}</div>
            </div>
            @endif

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Geofence notifications') }}</div>
                <div class="muted small" style="margin-bottom:10px;">
                    {{ ___('Admin and customer alerts for vehicles leaving/entering the alarm area.') }}
                </div>
                <div style="display:grid; gap:10px; grid-template-columns: repeat(auto-fit,minmax(240px,1fr));">
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="geofence_admin_panel" value="0">
                        <input type="checkbox" name="geofence_admin_panel" value="1" @checked($geofenceAdminPanel)>
                        {{ ___('Send admin panel notification on exit') }}
                    </label>
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="geofence_admin_whatsapp" value="0">
                        <input type="checkbox" name="geofence_admin_whatsapp" value="1" @checked($geofenceAdminWhatsApp)>
                        {{ ___('Send admin WhatsApp notification on exit') }}
                    </label>
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="geofence_customer_enter_whatsapp" value="0">
                        <input type="checkbox" name="geofence_customer_enter_whatsapp" value="1" @checked($geofenceCustomerEnterWhatsApp)>
                        {{ ___('Send customer WhatsApp when vehicle returns (enter)') }}
                    </label>
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="geofence_customer_reminder_whatsapp" value="0">
                        <input type="checkbox" name="geofence_customer_reminder_whatsapp" value="1" @checked($geofenceCustomerReminderWhatsApp)>
                        {{ ___('Send customer WhatsApp reminders while outside') }}
                    </label>
                </div>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Reminder interval (minutes)') }}</label>
                <input class="input" type="number" min="5" name="geofence_customer_reminder_interval_minutes" value="{{ $geofenceReminderInterval }}">
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Template - Admin exit alert') }}</label>
                <textarea class="input" rows="3" name="geofence_template_admin_exit">{{ $geofenceTplAdminExit }}</textarea>
                <div class="muted small">{{ ___('Placeholders: {vehicle}, {plate}, {company}, {lat}, {lng}, {radius}') }}</div>
            </div>
            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Template - Customer return (enter)') }}</label>
                <textarea class="input" rows="3" name="geofence_template_customer_enter">{{ $geofenceTplCustomerEnter }}</textarea>
                <div class="muted small">{{ ___('Placeholders: {vehicle}, {plate}, {company}') }}</div>
            </div>
            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Template - Customer reminder (outside)') }}</label>
                <textarea class="input" rows="3" name="geofence_template_customer_reminder">{{ $geofenceTplCustomerReminder }}</textarea>
                <div class="muted small">{{ ___('Placeholders: {vehicle}, {plate}, {company}, {lat}, {lng}, {radius}') }}</div>
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div style="font-weight:600; margin-bottom:6px;">{{ ___('Authorization expiry notifications') }}</div>
                <div class="muted small" style="margin-bottom:10px;">
                    {{ ___('Notify admins when a vehicle authorization is about to expire.') }}
                </div>
                <div style="display:grid; gap:10px; grid-template-columns: repeat(auto-fit,minmax(240px,1fr));">
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="authorization_admin_panel" value="0">
                        <input type="checkbox" name="authorization_admin_panel" value="1" @checked($authorizationAdminPanel)>
                        {{ ___('Send admin panel notification') }}
                    </label>
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="authorization_admin_whatsapp" value="0">
                        <input type="checkbox" name="authorization_admin_whatsapp" value="1" @checked($authorizationAdminWhatsApp)>
                        {{ ___('Send admin WhatsApp notification') }}
                    </label>
                </div>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Notify when remaining days') }}</label>
                <input class="input" type="number" min="1" max="365" name="authorization_days_before" value="{{ $authorizationDaysBefore }}">
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Template - Admin authorization expiry') }}</label>
                <textarea class="input" rows="3" name="authorization_template_admin_expire">{{ $authorizationTplAdminExpire }}</textarea>
                <div class="muted small">{{ ___('Placeholders: {person}, {vehicle}, {plate}, {days}, {end_date}') }}</div>
            </div>

            <div class="span-12" style="grid-column: span 12; display:flex; justify-content:flex-end; gap:10px;">
                <a class="btn ghost" href="{{ route('dashboard') }}">{{ ___('Back') }}</a>
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
