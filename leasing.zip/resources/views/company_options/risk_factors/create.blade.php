@extends('layouts.app')

@section('title', $mode === 'edit' ? ___('Edit factor') : ___('New factor'))
@section('page_title', $mode === 'edit' ? ___('Edit factor') : ___('New factor'))
@section('page_subtitle', ___('Company Options'))

@section('content')
<div class="wrap">
    <div class="card">
        <div class="h" style="margin-bottom:6px;">{{ $mode === 'edit' ? ___('Edit factor') : ___('New factor') }}</div>
        <div class="muted small" style="margin-bottom:12px;">
            {{ ___('Key is the technical name, label is the title shown to the creditor. Choose the type and method, fill in the values using the inputs; there is no need to write JSON.') }}
        </div>
        <form method="POST" action="{{ $mode === 'edit' ? route('company_options.risk_factors.update', $item) : route('company_options.risk_factors.store') }}" class="risk-grid">
            @csrf
            @if($mode === 'edit')
                @method('PUT')
            @endif
            <div>
                <label class="muted small">{{ ___('Key') }}</label>
                <input class="input" name="key" value="{{ old('key', $item->key) }}" required>
            </div>
            <div>
                <label class="muted small">{{ ___('Label') }}</label>
                <input class="input" name="label" value="{{ old('label', $item->label) }}" required>
            </div>
            <div>
                <label class="muted small">{{ ___('Type') }}</label>
                <select class="input" name="type">
                    @foreach(['number','boolean','select','text'] as $t)
                        <option value="{{ $t }}" @selected(old('type', $item->type ?? 'number') === $t)>{{ $t }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="muted small">{{ ___('Calculation method') }}</label>
                <select class="input" name="method">
                    @foreach(['bands','linear','boolean','select_map'] as $m)
                        <option value="{{ $m }}" @selected(old('method', $item->config['method'] ?? 'bands') === $m)>{{ $m }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="muted small">{{ ___('Sort') }}</label>
                <input class="input" type="number" name="sort_order" value="{{ old('sort_order', $item->sort_order) }}">
            </div>
            <div style="display:flex; align-items:center; gap:8px; margin-top:24px;">
                <input type="hidden" name="is_active" value="0">
                <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $item->is_active))>
                <span class="muted small">{{ ___('Active') }}</span>
            </div>

            <div class="risk-wide">
                <div class="card" style="padding:10px; overflow:hidden;">
                    <div class="h" style="margin-bottom:6px;">{{ ___('Bands (points by interval)') }}</div>
                    <div id="bands-rows" class="risk-subgrid"></div>
                    <button type="button" class="btn ghost" id="add-band" style="margin-top:8px;">{{ ___('+ Add band') }}</button>
                </div>
            </div>

            <div class="risk-wide">
                <div class="card" style="padding:10px; overflow:hidden;">
                    <div class="h" style="margin-bottom:6px;">{{ ___('Linear') }}</div>
                    <div class="risk-subgrid">
                        <input class="input" type="number" step="0.01" name="linear_unit" placeholder="{{ ___('Unit (e.g. 100)') }}" value="{{ old('linear_unit', $item->config['unit'] ?? '') }}">
                        <input class="input" type="number" step="0.01" name="linear_points_per_unit" placeholder="{{ ___('Points per unit') }}" value="{{ old('linear_points_per_unit', $item->config['points_per_unit'] ?? '') }}">
                        <input class="input" type="number" step="0.01" name="linear_max_points" placeholder="{{ ___('Max points (optional)') }}" value="{{ old('linear_max_points', $item->config['max_points'] ?? '') }}">
                    </div>
                </div>
            </div>

            <div class="risk-wide">
                <div class="card" style="padding:10px; overflow:hidden;">
                    <div class="h" style="margin-bottom:6px;">{{ ___('Boolean') }}</div>
                    <div class="risk-subgrid">
                        <input class="input" type="number" step="0.01" name="boolean_true_points" placeholder="{{ ___('true → points') }}" value="{{ old('boolean_true_points', $item->config['true_points'] ?? '') }}">
                        <input class="input" type="number" step="0.01" name="boolean_false_points" placeholder="{{ ___('false → points (optional)') }}" value="{{ old('boolean_false_points', $item->config['false_points'] ?? '') }}">
                    </div>
                </div>
            </div>

            <div class="risk-wide">
                <div class="card" style="padding:10px; overflow:hidden;">
                    <div class="h" style="margin-bottom:6px;">{{ ___('Options for Select') }}</div>
                    <div id="select-options" class="risk-subgrid"></div>
                    <button type="button" class="btn ghost" id="add-option" style="margin-top:8px;">{{ ___('+ Add option') }}</button>
                </div>
            </div>

            <div class="risk-wide">
                <div class="card" style="padding:10px; overflow:hidden;">
                    <div class="h" style="margin-bottom:6px;">{{ ___('Select map (points by value)') }}</div>
                    <div id="select-map" class="risk-subgrid"></div>
                    <button type="button" class="btn ghost" id="add-map" style="margin-top:8px;">{{ ___('+ Map row') }}</button>
                </div>
            </div>

            <div class="risk-wide" style="display:flex; gap:10px; justify-content:flex-end;">
                <a class="btn ghost" href="{{ route('company_options.risk_factors.index') }}">{{ ___('Back') }}</a>
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection

@php
    // Aynı mantık — sadece Blade parser'ı rahatlatmak için değişkenlere aldık
    $initialBands = old('bands', $item->config['penalties'] ?? []);
    $initialOptions = old('select_options', $item->options ?? []);

    $initialMapRaw = old('select_map');
    if ($initialMapRaw === null) {
        $map = (isset($item->config['map']) && is_array($item->config['map'])) ? $item->config['map'] : [];
        $initialMapRaw = collect($map)->map(function ($p, $k) {
            return ['value' => $k, 'label' => '', 'points' => $p];
        })->values()->toArray();
    }
@endphp

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', () => {
    const bandsWrap = document.getElementById('bands-rows');
    const addBand = document.getElementById('add-band');
    const optWrap = document.getElementById('select-options');
    const addOpt = document.getElementById('add-option');
    const mapWrap = document.getElementById('select-map');
    const addMap = document.getElementById('add-map');

    function bandRow(op='lte', value='', points='') {
        const idx = bandsWrap.children.length;
        const div = document.createElement('div');
        div.innerHTML = `
            <select class="input" name="bands[${idx}][op]">
                <option value="lte" ${op==='lte'?'selected':''}>&le;</option>
                <option value="lt" ${op==='lt'?'selected':''}>&lt;</option>
                <option value="gte" ${op==='gte'?'selected':''}>&ge;</option>
                <option value="gt" ${op==='gt'?'selected':''}>&gt;</option>
                <option value="eq" ${op==='eq'?'selected':''}>=</option>
            </select>
            <input class="input" type="number" step="0.01" name="bands[${idx}][value]" placeholder="{{ ___('Value') }}" value="${value}">
            <input class="input" type="number" step="0.01" name="bands[${idx}][points]" placeholder="{{ ___('Points') }}" value="${points}">
        `;
        bandsWrap.appendChild(div);
    }

    function optionRow(val='', label='') {
        const idx = optWrap.children.length;
        const div = document.createElement('div');
        div.innerHTML = `
            <input class="input" type="text" name="select_options[${idx}][value]" placeholder="{{ ___('Value') }}" value="${val}">
            <input class="input" type="text" name="select_options[${idx}][label]" placeholder="{{ ___('Label') }}" value="${label}">
        `;
        optWrap.appendChild(div);
    }

    function mapRow(val='', label='', points='') {
        const idx = mapWrap.children.length;
        const div = document.createElement('div');
        div.innerHTML = `
            <input class="input" type="text" name="select_map[${idx}][value]" placeholder="{{ ___('Value') }}" value="${val}">
            <input class="input" type="text" name="select_map[${idx}][label]" placeholder="{{ ___('Label') }}" value="${label}">
            <input class="input" type="number" step="0.01" name="select_map[${idx}][points]" placeholder="{{ ___('Points') }}" value="${points}">
        `;
        mapWrap.appendChild(div);
    }

    addBand?.addEventListener('click', () => bandRow());
    addOpt?.addEventListener('click', () => optionRow());
    addMap?.addEventListener('click', () => mapRow());

    const initialBands   = @json($initialBands);
    const initialOptions = @json($initialOptions);
    const initialMapRaw  = @json($initialMapRaw);

    if (Array.isArray(initialBands) && initialBands.length) {
        initialBands.forEach(row => {
            const op = Object.keys(row).find(k => ['lte','lt','gte','gt','eq'].includes(k)) || 'lte';
            bandRow(op, row[op] ?? '', row.points ?? '');
        });
    }
    if (Array.isArray(initialOptions) && initialOptions.length) {
        initialOptions.forEach(r => optionRow(r.value ?? '', r.label ?? ''));
    }
    if (Array.isArray(initialMapRaw) && initialMapRaw.length) {
        initialMapRaw.forEach(r => mapRow(r.value ?? '', r.label ?? '', r.points ?? ''));
    }

    // fallback rows if empty
    if (bandsWrap.childElementCount === 0) bandRow();
    if (optWrap.childElementCount === 0) optionRow();
    if (mapWrap.childElementCount === 0) mapRow();
});
</script>
@endpush
