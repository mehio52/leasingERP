@extends('layouts.app')

@section('title', ___('Risk Factors'))
@section('page_title', ___('Risk Factors'))
@section('page_subtitle', ___('Company Options'))

@section('content')
<div class="wrap">
    <div class="card slab" style="display:flex; justify-content:space-between; align-items:center;">
        <div>
            <div class="h">{{ ___('Factors') }}</div>
            <div class="muted small">{{ ___('List of company risk factors') }}</div>
        </div>
        <a class="btn primary" href="{{ route('company_options.risk_factors.create') }}">{{ ___('+ New factor') }}</a>
    </div>

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Label') }}</th>
                <th>{{ ___('Key') }}</th>
                <th>{{ ___('Type') }}</th>
                <th>{{ ___('Active') }}</th>
                <th>{{ ___('Sort') }}</th>
                <th>{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($items as $item)
                <tr>
                    <td>{{ $item->label }}</td>
                    <td>{{ $item->key }}</td>
                    <td>{{ $item->type }}</td>
                    <td>
                        <span class="badge">{{ $item->is_active ? ___('Active') : ___('Inactive') }}</span>
                    </td>
                    <td>{{ $item->sort_order }}</td>
                    <td style="display:flex; gap:6px;">
                        <a class="btn ghost" href="{{ route('company_options.risk_factors.edit', $item) }}">{{ ___('Edit') }}</a>
                        <form method="POST" action="{{ route('company_options.risk_factors.toggle', $item) }}">
                            @csrf
                            @method('PATCH')
                            <button class="btn ghost" type="submit">{{ $item->is_active ? ___('Disable') : ___('Enable') }}</button>
                        </form>
                        <form method="POST" action="{{ route('company_options.risk_factors.destroy', $item) }}" onsubmit="return confirm('{{ ___('Delete?') }}');">
                            @csrf
                            @method('DELETE')
                            <button class="btn ghost danger" type="submit">{{ ___('Delete') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">{{ ___('No factors found.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection