@extends('layouts.app')

@section('title', ___('Company Options'))
@section('page_title', ___('Company Options'))
@section('page_subtitle')
Company ID: {{ $options->company_id }} - User: {{ $user->first_name }} {{ $user->last_name }}
@endsection

@section('content')
@if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Xeta') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @php
        $days = [
            'mon' => 'B.e (Mon)',
            'tue' => 'Ç.a (Tue)',
            'wed' => 'Ç (Wed)',
            'thu' => 'C.a (Thu)',
            'fri' => 'C (Fri)',
            'sat' => 'Ş (Sat)',
            'sun' => 'B (Sun)',
        ];

        $timeOptions = [];
        for ($h=0; $h<24; $h++) {
            foreach ([0, 30] as $m) {
                $timeOptions[] = sprintf('%02d:%02d', $h, $m);
            }
        }

        $working = old('working_hours', $options->working_hours ?? []);
        $social  = old('social_links', $options->social_links ?? []);
        $settingsAssoc = $options->settings ?? [];
        $settingsOldK = old('settings_k');
        $settingsOldV = old('settings_v');
        $paymentGateways = is_array($options->payment_gateways) ? $options->payment_gateways : [];
        $gatewayValue = function (string $provider, string $field) use ($paymentGateways) {
            $oldKey = "payment_gateways.$provider.$field";
            return old($oldKey, data_get($paymentGateways, "$provider.$field", ''));
        };
        $logoUrl = $options->logo_path ? \Illuminate\Support\Facades\Storage::disk('public')->url($options->logo_path) : null;
        $coverUrl = $options->cover_image_path ? \Illuminate\Support\Facades\Storage::disk('public')->url($options->cover_image_path) : null;
        $gpsProviders = $gpsProviders ?? collect();
        $gpsConnection = $gpsConnection ?? null;
        $gpsSelectedId = old('gps_provider_id', $gpsConnection?->gps_provider_id);
        $gpsStatus = $gpsConnection?->status;
        $gpsProviderName = $gpsConnection?->provider?->name;
        $host = request()->getSchemeAndHttpHost();
        if ($logoUrl && str_starts_with($logoUrl, 'http')) {
            $logoUrl = $host . (parse_url($logoUrl, PHP_URL_PATH) ?? '');
        }
        if ($coverUrl && str_starts_with($coverUrl, 'http')) {
            $coverUrl = $host . (parse_url($coverUrl, PHP_URL_PATH) ?? '');
        }
        if (request()->isSecure()) {
            if ($logoUrl && str_starts_with($logoUrl, 'http://')) $logoUrl = preg_replace('#^http://#', 'https://', $logoUrl);
            if ($coverUrl && str_starts_with($coverUrl, 'http://')) $coverUrl = preg_replace('#^http://#', 'https://', $coverUrl);
        }
        $resolveMediaUrl = function ($path) use ($host) {
            if (!$path) return null;
            $url = (str_starts_with($path, 'http') || str_starts_with($path, '/'))
                ? $path
                : \Illuminate\Support\Facades\Storage::disk('public')->url($path);

            if (str_starts_with($url, 'http')) {
                $url = $host . (parse_url($url, PHP_URL_PATH) ?? '');
            }
            if (request()->isSecure() && str_starts_with($url, 'http://')) {
                $url = preg_replace('#^http://#', 'https://', $url);
            }
            return $url;
        };
    @endphp

    <form class="company-options" method="POST" action="{{ route('company.options.update') }}" enctype="multipart/form-data">
        @csrf

        <details class="card company-accordion" open>
            <summary class="company-accordion-summary">{{ ___('Branding') }}</summary>
            <div class="company-accordion-body">
            <div class="row">
                <div class="field">
                    <label>{{ ___('Display name') }}</label>
                    <input name="display_name" value="{{ old('display_name', $options->display_name) }}" placeholder="{{ ___('Example: Carma Leasing') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Logo (image)') }}</label>
                    <input type="file" name="logo" accept="image/*">
                    @if($logoUrl)
                        <div class="muted">{{ ___('Current:') }}</div>
                        <div style="margin-top:6px;">
                            <img src="{{ $logoUrl }}" alt="logo" style="max-height:80px; max-width:200px; border:1px solid #ddd; border-radius:8px; background:#fff; padding:4px;">
                        </div>
                    @endif
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Cover image (image)') }}</label>
                    <input type="file" name="cover_image" accept="image/*">
                    @if($coverUrl)
                        <div class="muted">{{ ___('Current:') }}</div>
                        <div style="margin-top:6px;">
                            <img src="{{ $coverUrl }}" alt="cover" style="max-height:120px; max-width:240px; border:1px solid #ddd; border-radius:8px; background:#fff; padding:4px;">
                        </div>
                    @endif
                </div>
                <div class="field">
                    <label>{{ ___('Country') }}</label>
                    <input name="country" value="{{ old('country', $options->country) }}" placeholder="{{ ___('Azerbaijan') }}">
                </div>
            </div>
            </div>
        </details>

        <details class="card company-accordion">
            <summary class="company-accordion-summary">{{ ___('Payment gateways') }}</summary>
            <div class="company-accordion-body">
            <div class="muted" style="margin-bottom:10px;">{{ ___('Each company can connect its own merchant account and specify the API keys/secrets here.') }}</div>

            <details class="gateway-accordion gateway-section" open>
                <summary class="gateway-accordion-summary">
                    <span>{{ ___('Epoint (AZ)') }}</span>
                </summary>
                <div class="gateway-accordion-body">
                    <div class="gateway-section-head">
                        <div class="muted small">{{ ___('Merchant endpoints') }}</div>
                        <button type="button"
                                class="gateway-info-button"
                                data-target="gateway-endpoints-epoint"
                                aria-controls="gateway-endpoints-epoint"
                                aria-expanded="false"
                                title="{{ ___('View the endpoints your merchant account must call.') }}"
                                style="border:none; background:#e2e8f0; color:#0f172a; font-weight:600; border-radius:999px; width:24px; height:24px; display:inline-flex; align-items:center; justify-content:center; cursor:pointer; padding:0;">
                            i
                        </button>
                    </div>
                    <div class="row">
                        <div class="field">
                            <label>{{ ___('Public key (merchant ID)') }}</label>
                            <input name="payment_gateways[epoint][public_key]" value="{{ $gatewayValue('epoint', 'public_key') }}" placeholder="i000000001">
                        </div>
                        <div class="field">
                            <label>{{ ___('Private key') }}</label>
                            <input name="payment_gateways[epoint][private_key]" value="{{ $gatewayValue('epoint', 'private_key') }}" placeholder="{{ ___('secret') }}">
                        </div>
                    </div>
                    <div class="field">
                        <label>{{ ___('Base URL') }}</label>
                        <input name="payment_gateways[epoint][base_url]" value="{{ $gatewayValue('epoint', 'base_url') }}" placeholder="https://epoint.az/api/1">
                        <div class="muted">{{ ___('Leave empty to use the default URL unless you have a sandbox account.') }}</div>
                    </div>
                    <div class="gateway-endpoints-panel" id="gateway-endpoints-epoint" hidden>
                        <div style="font-weight:700; margin-bottom:6px;">{{ ___('Epoint endpoints') }}</div>
                        <div style="display:flex; flex-direction:column; gap:4px; font-size:13px;">
                            <div><strong>{{ ___('Success URL') }}:</strong> <code>{{ route('epoint.success') }}</code></div>
                            <div><strong>{{ ___('Error URL') }}:</strong> <code>{{ route('epoint.error') }}</code></div>
                            <div><strong>{{ ___('Result URL') }}:</strong> <code>{{ route('epoint.result') }}</code></div>
                        </div>
                        <div class="muted small" style="margin-top:6px;">{{ ___('Use these values when configuring the merchant callback/webhook settings.') }}</div>
                    </div>
                </div>
            </details>

            <details class="gateway-accordion gateway-section">
                <summary class="gateway-accordion-summary">
                    <span>{{ ___('Stripe (US/global)') }}</span>
                </summary>
                <div class="gateway-accordion-body">
                    <div class="gateway-section-head">
                        <div class="muted small">{{ ___('Merchant endpoints') }}</div>
                        <button type="button"
                                class="gateway-info-button"
                                data-target="gateway-endpoints-stripe"
                                aria-controls="gateway-endpoints-stripe"
                                aria-expanded="false"
                                title="{{ ___('View the endpoint Stripe will call for webhooks.') }}"
                                style="border:none; background:#e2e8f0; color:#0f172a; font-weight:600; border-radius:999px; width:24px; height:24px; display:inline-flex; align-items:center; justify-content:center; cursor:pointer; padding:0;">
                            i
                        </button>
                    </div>
                    <div class="row">
                        <div class="field">
                            <label>{{ ___('Publishable key') }}</label>
                            <input name="payment_gateways[stripe][public_key]" value="{{ $gatewayValue('stripe', 'public_key') }}" placeholder="pk_live_...">
                        </div>
                        <div class="field">
                            <label>{{ ___('Secret key') }}</label>
                            <input name="payment_gateways[stripe][secret]" value="{{ $gatewayValue('stripe', 'secret') }}" placeholder="sk_live_...">
                        </div>
                    </div>
                    <div class="field">
                        <label>{{ ___('Webhook secret') }}</label>
                        <input name="payment_gateways[stripe][webhook_secret]" value="{{ $gatewayValue('stripe', 'webhook_secret') }}" placeholder="whsec_...">
                    </div>
                    <div class="gateway-endpoints-panel" id="gateway-endpoints-stripe" hidden>
                        <div style="font-weight:700; margin-bottom:6px;">{{ ___('Stripe endpoint') }}</div>
                        <div style="display:flex; flex-direction:column; gap:4px; font-size:13px;">
                            <div><strong>{{ ___('Webhook URL') }}:</strong> <code>{{ route('stripe.webhook') }}</code></div>
                        </div>
                        <div class="muted small" style="margin-top:6px;">{{ ___('Send this URL to Stripe when you configure events.') }}</div>
                    </div>
                </div>
            </details>

            <details class="gateway-accordion gateway-section">
                <summary class="gateway-accordion-summary">
                    <span>{{ ___('Iyzico (Turkey)') }}</span>
                </summary>
                <div class="gateway-accordion-body">
                    <div class="gateway-section-head">
                        <div class="muted small">{{ ___('Merchant endpoints') }}</div>
                        <button type="button"
                                class="gateway-info-button"
                                data-target="gateway-endpoints-iyzico"
                                aria-controls="gateway-endpoints-iyzico"
                                aria-expanded="false"
                                title="{{ ___('View the URLs Iyzico will call back to.') }}"
                                style="border:none; background:#e2e8f0; color:#0f172a; font-weight:600; border-radius:999px; width:24px; height:24px; display:inline-flex; align-items:center; justify-content:center; cursor:pointer; padding:0;">
                            i
                        </button>
                    </div>
                    <div class="row">
                        <div class="field">
                            <label>{{ ___('API key') }}</label>
                            <input name="payment_gateways[iyzico][api_key]" value="{{ $gatewayValue('iyzico', 'api_key') }}" placeholder="sandbox-...">
                        </div>
                        <div class="field">
                            <label>{{ ___('Secret key') }}</label>
                            <input name="payment_gateways[iyzico][secret_key]" value="{{ $gatewayValue('iyzico', 'secret_key') }}" placeholder="sandbox-...">
                        </div>
                    </div>
                    <div class="field">
                        <label>{{ ___('Base URL') }}</label>
                        <input name="payment_gateways[iyzico][base_url]" value="{{ $gatewayValue('iyzico', 'base_url') }}" placeholder="https://api.iyzipay.com">
                    </div>
                    <div class="gateway-endpoints-panel" id="gateway-endpoints-iyzico" hidden>
                        <div style="font-weight:700; margin-bottom:6px;">{{ ___('Iyzico endpoints') }}</div>
                        <div style="display:flex; flex-direction:column; gap:4px; font-size:13px;">
                            <div><strong>{{ ___('Callback URL') }}:</strong> <code>{{ route('iyzico.callback') }}</code></div>
                            <div><strong>{{ ___('Return URL') }}:</strong> <code>{{ route('iyzico.redirect') }}</code></div>
                        </div>
                        <div class="muted small" style="margin-top:6px;">{{ ___('Use these URLs when configuring Iyzico callbacks.') }}</div>
                    </div>
                </div>
            </details>
            </div>
        </details>

        <details class="card company-accordion">
            <summary class="company-accordion-summary">{{ ___('GPS provider') }}</summary>
            <div class="company-accordion-body">
                <div class="muted" style="margin-bottom:10px;">
                    {{ ___('Select the GPS provider for this company. The provider will approve the request and manage credentials.') }}
                </div>
                @if($gpsStatus)
                    <div class="banner" style="margin-bottom:10px;">
                        <span class="badge {{ $gpsStatus === 'approved' ? 'ok' : ($gpsStatus === 'rejected' ? 'bad' : 'warn') }}">
                            {{ strtoupper($gpsStatus) }}
                        </span>
                        @if($gpsConnection?->provider)
                            <span class="muted" style="margin-left:8px;">
                                @include('partials.provider_label', ['provider' => $gpsConnection->provider, 'size' => 16])
                            </span>
                        @elseif($gpsProviderName)
                            <span class="muted" style="margin-left:8px;">{{ $gpsProviderName }}</span>
                        @endif
                    </div>
                @endif
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Provider') }}</label>
                        <select name="gps_provider_id" id="gpsProviderSelect" data-placeholder="{{ ___('Select provider') }}">
                            <option value="">{{ ___('No provider selected') }}</option>
                            @foreach($gpsProviders as $provider)
                                @php
                                    $providerLogoUrl = $resolveMediaUrl(data_get($provider->settings, 'logo_path'));
                                    $providerInitial = strtoupper(substr($provider->name ?? 'G', 0, 1));
                                @endphp
                                <option value="{{ $provider->id }}"
                                        @selected((string) $gpsSelectedId === (string) $provider->id)
                                        data-initial="{{ $providerInitial }}"
                                        @if($providerLogoUrl) data-logo="{{ $providerLogoUrl }}" @endif>
                                    {{ $provider->name }}
                                </option>
                            @endforeach
                        </select>
                        @if($gpsProviders->isEmpty())
                            <div class="muted small">{{ ___('No active GPS providers yet.') }}</div>
                        @endif
                    </div>
                </div>

            </div>
        </details>

        <details class="card company-accordion">
            <summary class="company-accordion-summary">{{ ___('Contact') }}</summary>
            <div class="company-accordion-body">
            <div class="row">
                <div class="field">
                    <label>{{ ___('Contact email') }}</label>
                    <input name="contact_email" value="{{ old('contact_email', $options->contact_email) }}" placeholder="{{ ___('info@...') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Contact phone') }}</label>
                    <input name="contact_phone" value="{{ old('contact_phone', $options->contact_phone) }}" placeholder="{{ ___('+994...') }}">
                </div>
            </div>
            <div style="height:12px;"></div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('WhatsApp phone') }}</label>
                    <input name="whatsapp_phone" value="{{ old('whatsapp_phone', $options->whatsapp_phone) }}" placeholder="{{ ___('+994...') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Address') }}</label>
                    <input name="address" value="{{ old('address', $options->address) }}" placeholder="{{ ___('Bakı, ...') }}">
                </div>
            </div>
            <div style="height:12px;"></div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('City') }}</label>
                    <input name="city" value="{{ old('city', $options->city) }}" placeholder="{{ ___('Baku') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Map URL') }}</label>
                    <input name="map_url" value="{{ old('map_url', $options->map_url) }}" placeholder="{{ ___('https://maps.google.com/...') }}">
                </div>
            </div>
            <div style="height:12px;"></div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Latitude') }}</label>
                    <input name="latitude" value="{{ old('latitude', $options->latitude) }}" placeholder="{{ ___('40.4093') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Longitude') }}</label>
                    <input name="longitude" value="{{ old('longitude', $options->longitude) }}" placeholder="{{ ___('49.8671') }}">
                </div>
            </div>
            </div>
        </details>

        <details class="card company-accordion">
            <summary class="company-accordion-summary">{{ ___('Localization') }}</summary>
            <div class="company-accordion-body">
            <div class="row">
                <div class="field">
                    <label>{{ ___('Timezone') }}</label>
                    <input name="timezone" value="{{ old('timezone', $options->timezone) }}" placeholder="{{ ___('Asia/Baku') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Locale') }}</label>
                    <select name="locale">
                        @foreach(['az'=>'AZ', 'en'=>'EN', 'ru'=>'RU', 'tr'=>'TR'] as $k=>$v)
                            <option value="{{ $k }}" @selected(old('locale', $options->locale) === $k)>{{ $v }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div style="height:12px;"></div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Currency') }}</label>
                    <input name="currency" value="{{ old('currency', $options->currency) }}" placeholder="{{ ___('AZN') }}">
                </div>
                <div class="field"></div>
            </div>
            </div>
        </details>

        <details class="card company-accordion">
            <summary class="company-accordion-summary">{{ ___('SEO') }}</summary>
            <div class="company-accordion-body">
            <div class="row">
                <div class="field">
                    <label>{{ ___('SEO title') }}</label>
                    <input name="seo_title" value="{{ old('seo_title', $options->seo_title) }}">
                </div>
                <div class="field">
                    <label>{{ ___('SEO canonical URL') }}</label>
                    <input name="seo_canonical_url" value="{{ old('seo_canonical_url', $options->seo_canonical_url) }}">
                </div>
            </div>
            <div style="height:12px;"></div>
            <div class="field">
                <label>{{ ___('SEO description') }}</label>
                <input name="seo_description" value="{{ old('seo_description', $options->seo_description) }}">
            </div>
            <div style="height:12px;"></div>
            <div class="field">
                <label>{{ ___('SEO keywords') }}</label>
                <input name="seo_keywords" value="{{ old('seo_keywords', $options->seo_keywords) }}">
            </div>
            <div style="height:12px;"></div>
            <div class="field inline">
                <input style="width:auto;" type="checkbox" name="seo_indexable" value="1" @checked(old('seo_indexable', (int)$options->seo_indexable) === 1)>
                <label style="margin:0;">{{ ___('Indexable (search engines)') }}</label>
            </div>
            </div>
        </details>
        <details class="card company-accordion">
            <summary class="company-accordion-summary">{{ ___('Social links') }}</summary>
            <div class="company-accordion-body">
            <div class="muted" style="margin-bottom:10px;">{{ ___('Press “+” → select a platform → paste the link. Add as many as you want.') }}</div>

            <div id="socialRows" style="display:grid; gap:10px;">
                @php $social = is_array($social) ? $social : []; @endphp

                @foreach($social as $i => $item)
                    @php
                        $type = $item['type'] ?? '';
                        $url  = $item['url'] ?? '';
                    @endphp
                    <div class="social-row">
                        <select name="social_links[{{ $i }}][type]">
                            <option value="">{{ ___('Select...') }}</option>
                            <option value="facebook" @selected($type==='facebook')>Facebook</option>
                            <option value="instagram" @selected($type==='instagram')>Instagram</option>
                            <option value="tiktok" @selected($type==='tiktok')>TikTok</option>
                            <option value="youtube" @selected($type==='youtube')>YouTube</option>
                            <option value="linkedin" @selected($type==='linkedin')>LinkedIn</option>
                            <option value="telegram" @selected($type==='telegram')>Telegram</option>
                            <option value="whatsapp" @selected($type==='whatsapp')>WhatsApp</option>
                            <option value="x" @selected($type==='x')>X (Twitter)</option>
                            <option value="website" @selected($type==='website')>Website</option>
                        </select>
                        <input name="social_links[{{ $i }}][url]" value="{{ $url }}" placeholder="https://...">
                        <button type="button" class="btn danger social-remove">{{ ___('Delete') }}</button>
                    </div>
                @endforeach
            </div>

            <div class="actions" style="justify-content:flex-start;">
                <button type="button" class="btn" id="socialAdd">{{ ___('+ Add') }}</button>
            </div>
            </div>
        </details>

        <details class="card company-accordion">
            <summary class="company-accordion-summary">{{ ___('Settings (key/value)') }}</summary>
            <div class="company-accordion-body">
            <div class="muted" style="margin-bottom:10px;">{{ ___('Save any parameter as key/value. Increase with “+”.') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Monthly collection target') }}</label>
                    <input name="collection_target_monthly" value="{{ old('collection_target_monthly', data_get($settingsAssoc, 'collection_target_monthly', '')) }}" placeholder="{{ ___('Example: 25000') }}">
                    <div class="muted">{{ ___('Used in leasing dashboard collection performance.') }}</div>
                </div>
                <div class="field"></div>
            </div>
            <div style="height:12px;"></div>

            <div id="settingsRows" style="display:grid; gap:14px;">
                @php
                    if (is_array($settingsOldK) && is_array($settingsOldV)) {
                        $rows = [];
                        foreach ($settingsOldK as $idx => $k) {
                            if ($k === 'collection_target_monthly') continue;
                            $rows[] = ['k' => $k, 'v' => $settingsOldV[$idx] ?? ''];
                        }
                    } else {
                        $rows = [];
                        if (is_array($settingsAssoc)) {
                            foreach ($settingsAssoc as $k => $v) {
                                if ($k === 'collection_target_monthly') continue;
                                $rows[] = ['k' => $k, 'v' => is_scalar($v) ? (string)$v : json_encode($v, JSON_UNESCAPED_UNICODE)];
                            }
                        }
                    }
                @endphp

                @foreach($rows as $i => $row)
                    <div class="settings-row">
                        <input name="settings_k[{{ $i }}]" value="{{ $row['k'] ?? '' }}" placeholder="{{ ___('key (Example: order.read_only)') }}">
                        <input name="settings_v[{{ $i }}]" value="{{ $row['v'] ?? '' }}" placeholder="{{ ___('value (Example: 1)') }}">
                        <button type="button" class="btn danger settings-remove">{{ ___('Sil') }}</button>
                    </div>
                @endforeach
            </div>

            <div class="actions" style="justify-content:flex-start;">
                <button type="button" class="btn" id="settingsAdd">{{ ___('+ Add') }}</button>
            </div>


            </div>
        </details>
        <details class="card calc company-accordion">
            <summary class="company-accordion-summary">{{ ___('Calculator ranges') }}</summary>
            <div class="company-accordion-body">
            <div class="row">
                <div class="field">
                    <label>{{ ___('Interest min (%)') }}</label>
                    <input name="calc_interest_min" value="{{ old('calc_interest_min', $options->calc_interest_min) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Interest max (%)') }}</label>
                    <input name="calc_interest_max" value="{{ old('calc_interest_max', $options->calc_interest_max) }}">
                </div>
            </div>
            <div style="height:12px;"></div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Term min (months)') }}</label>
                    <input name="calc_term_min_months" value="{{ old('calc_term_min_months', $options->calc_term_min_months) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Term max (months)') }}</label>
                    <input name="calc_term_max_months" value="{{ old('calc_term_max_months', $options->calc_term_max_months) }}">
                </div>
            </div>
            <div style="height:12px;"></div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Amount min') }}</label>
                    <input name="calc_amount_min" value="{{ old('calc_amount_min', $options->calc_amount_min) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Amount max') }}</label>
                    <input name="calc_amount_max" value="{{ old('calc_amount_max', $options->calc_amount_max) }}">
                </div>
            </div>
            </div>
        </details>

        <details class="card working-hours company-accordion">
            <summary class="company-accordion-summary">{{ ___('Working hours') }}</summary>
            <div class="company-accordion-body">
            <div class="muted" style="margin-bottom:10px;">{{ ___('Günlər standartdır. “Closed” seç, ya da saatları seç.') }}</div>

            <div style="display:grid; gap:10px;">
                @foreach($days as $dk => $dlabel)
                    @php
                        $row = $working[$dk] ?? [];
                        $closed = (bool)($row['closed'] ?? false);
                        $from = $row['from'] ?? '09:00';
                        $to   = $row['to']   ?? '18:00';
                    @endphp

                    <div class="work-row">
                        <div class="muted" style="font-weight:700;">{{ $dlabel }}</div>

                        <label class="field inline" style="margin:0;">
                            <input type="checkbox"
                                   name="working_hours[{{ $dk }}][closed]"
                                   value="1"
                                   class="wh-closed"
                                   data-day="{{ $dk }}"
                                   @checked($closed)>
                            <span class="muted" style="white-space:nowrap;">{{ ___('Closed') }}</span>
                        </label>

                        <select name="working_hours[{{ $dk }}][from]" class="wh-from" data-day="{{ $dk }}" @disabled($closed)>
                            @foreach($timeOptions as $t)
                                <option value="{{ $t }}" @selected($from === $t)>{{ $t }}</option>
                            @endforeach
                        </select>

                        <select name="working_hours[{{ $dk }}][to]" class="wh-to" data-day="{{ $dk }}" @disabled($closed)>
                            @foreach($timeOptions as $t)
                                <option value="{{ $t }}" @selected($to === $t)>{{ $t }}</option>
                            @endforeach
                        </select>
                    </div>
                @endforeach
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
            </div>
        </details>



    </form>
</div>

<script>
(function(){
    // Working hours: closed -> disable selects
    document.querySelectorAll('.wh-closed').forEach(cb => {
        cb.addEventListener('change', () => {
            const day = cb.dataset.day;
            const from = document.querySelector('.wh-from[data-day="'+day+'"]');
            const to   = document.querySelector('.wh-to[data-day="'+day+'"]');
            if (!from || !to) return;
            const disabled = cb.checked;
            from.disabled = disabled;
            to.disabled = disabled;
        });
    });

    // Social links add/remove
    const socialRows = document.getElementById('socialRows');
    const socialAdd  = document.getElementById('socialAdd');

    function nextSocialIndex(){
        return socialRows.querySelectorAll('.social-row').length;
    }

    function socialRowHtml(i){
        return `
            <div class="social-row">
            <select name="social_links[${i}][type]">
                <option value="">{{ ___('Seç...') }}</option>
                <option value="facebook">Facebook</option>
                <option value="instagram">Instagram</option>
                <option value="tiktok">TikTok</option>
                <option value="youtube">YouTube</option>
                <option value="linkedin">LinkedIn</option>
                <option value="telegram">Telegram</option>
                <option value="whatsapp">WhatsApp</option>
                <option value="x">X (Twitter)</option>
                <option value="website">Website</option>
            </select>
            <input name="social_links[${i}][url]" value="" placeholder="{{ ___('https://...') }}">
            <button type="button" class="btn danger social-remove">{{ ___('Sil') }}</button>
        </div>`;
    }

    socialAdd?.addEventListener('click', () => {
        const i = nextSocialIndex();
        socialRows.insertAdjacentHTML('beforeend', socialRowHtml(i));
    });

    socialRows?.addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('social-remove')) {
            e.target.closest('.social-row')?.remove();
        }
    });

    // Settings add/remove
    const settingsRows = document.getElementById('settingsRows');
    const settingsAdd  = document.getElementById('settingsAdd');

    function nextSettingsIndex(){
        return settingsRows.querySelectorAll('.settings-row').length;
    }

    function settingsRowHtml(i){
        return `
                    <div class="settings-row">
            <input name="settings_k[${i}]" value="" placeholder="{{ ___('key (Example: order.read_only)') }}">
            <input name="settings_v[${i}]" value="" placeholder="{{ ___('value (Example: 1)') }}">
            <button type="button" class="btn danger settings-remove">{{ ___('Delete') }}</button>
        </div>`;
    }

    settingsAdd?.addEventListener('click', () => {
        const i = nextSettingsIndex();
        settingsRows.insertAdjacentHTML('beforeend', settingsRowHtml(i));
    });

    settingsRows?.addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('settings-remove')) {
            e.target.closest('.settings-row')?.remove();
        }
    });

    const companyAccordions = document.querySelectorAll('.company-accordion');
    companyAccordions.forEach(item => {
        item.addEventListener('toggle', () => {
            if (!item.open) return;
            companyAccordions.forEach(other => {
                if (other !== item) other.open = false;
            });
        });
    });

    const gatewayAccordions = document.querySelectorAll('.gateway-accordion');
    gatewayAccordions.forEach(item => {
        item.addEventListener('toggle', () => {
            if (!item.open) return;
            gatewayAccordions.forEach(other => {
                if (other !== item) other.open = false;
            });
        });
    });

    const gatewayButtons = document.querySelectorAll('.gateway-info-button');
    const gatewayPanels = document.querySelectorAll('.gateway-endpoints-panel');

    gatewayButtons.forEach(button => {
        const targetId = button.dataset.target;
        if (!targetId) return;
        const panel = document.getElementById(targetId);
        if (!panel) return;
        button.addEventListener('click', (event) => {
            event.stopPropagation();
            const isOpen = !panel.hasAttribute('hidden');
            gatewayPanels.forEach(p => p.hidden = true);
            gatewayButtons.forEach(b => b.setAttribute('aria-expanded', 'false'));
            if (!isOpen) {
                panel.hidden = false;
                button.setAttribute('aria-expanded', 'true');
            }
        });
    });

    document.addEventListener('click', (event) => {
        if (event.target.closest('.gateway-section')) return;
        gatewayPanels.forEach(p => p.hidden = true);
        gatewayButtons.forEach(b => b.setAttribute('aria-expanded', 'false'));
    });
})();
</script>

@push('styles')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.default.min.css">
    <style>
        .provider-option {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .provider-option .provider-logo {
            width: 22px;
            height: 22px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid var(--border);
            background: var(--surface);
        }
        .provider-option .provider-initial {
            width: 22px;
            height: 22px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 700;
            color: var(--text);
            background: var(--bg-soft);
            border: 1px solid var(--border);
        }
        .ts-wrapper { width: 100%; }
        .ts-control {
            background: var(--bg-soft);
            border-color: var(--border);
            color: var(--text);
            min-height: 42px;
            padding: 6px 8px;
            border-radius: 10px;
        }
        .ts-control input { color: var(--text); }
        .ts-control .item {
            background: var(--surface);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .ts-dropdown {
            background: var(--bg-soft);
            border-color: var(--border);
            color: var(--text);
        }
        .ts-dropdown .active { background: var(--surface); }
        .ts-dropdown .option { color: var(--text); }
    </style>
@endpush

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
    <script>
        (function(){
            const el = document.getElementById('gpsProviderSelect');
            if (!el || typeof TomSelect === 'undefined') return;
            const placeholder = el.dataset.placeholder || 'Select provider';
            new TomSelect(el, {
                create: false,
                persist: false,
                allowEmptyOption: true,
                placeholder: placeholder,
                render: {
                    option: function(data, escape) {
                        const label = escape(data.text || '');
                        const logo = data.logo;
                        const initial = escape(data.initial || (data.text || '').charAt(0).toUpperCase());
                        const media = logo
                            ? '<img class="provider-logo" src="' + escape(logo) + '" alt="">'
                            : '<span class="provider-initial">' + initial + '</span>';
                        return '<div class="provider-option">' + media + '<span>' + label + '</span></div>';
                    },
                    item: function(data, escape) {
                        const label = escape(data.text || '');
                        const logo = data.logo;
                        const initial = escape(data.initial || (data.text || '').charAt(0).toUpperCase());
                        const media = logo
                            ? '<img class="provider-logo" src="' + escape(logo) + '" alt="">'
                            : '<span class="provider-initial">' + initial + '</span>';
                        return '<div class="provider-option">' + media + '<span>' + label + '</span></div>';
                    }
                }
            });
        })();
    </script>
@endpush
@endsection
