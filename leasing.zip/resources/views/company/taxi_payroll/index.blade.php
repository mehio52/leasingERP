@extends('layouts.app')
@section('title', ___('Taxi payroll'))
@section('page_title', ___('Taxi payroll'))
@section('page_subtitle', ___('Monthly payroll overview'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('dashboard') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    <div class="card" style="margin-bottom:12px;">
        <form method="GET" action="{{ route('company.taxi_payroll.index') }}">
            <div class="row">
                <div class="field">
                    <label>{{ ___('Month') }}</label>
                    <input type="month" name="month" value="{{ $month }}">
                </div>
                <div class="field" style="display:flex; align-items:flex-end;">
                    <button class="btn" type="submit">{{ ___('Apply') }}</button>
                </div>
            </div>
        </form>
    </div>

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Driver') }}</th>
                <th>{{ ___('Trips') }}</th>
                <th>{{ ___('Revenue') }}</th>
                <th>{{ ___('Salary') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($stats as $s)
                <tr>
                    <td>{{ $s['driver']->first_name }} {{ $s['driver']->last_name }}</td>
                    <td>{{ $s['trips'] }}</td>
                    <td>{{ number_format($s['revenue'], 2) }}</td>
                    <td>{{ number_format($s['salary'], 2) }}</td>
                </tr>
            @empty
                <tr><td colspan="4" class="muted">{{ ___('No data for selected month.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endsection
