﻿@extends('layouts.app')

@section('title', ___('Payroll'))
@section('page_title', ___('Payroll'))
@section('page_subtitle', ___('Salary and commission summary'))
@section('page_actions')
    <a class="btn ghost" href="{{ url()->previous() }}">{{ ___('Back') }}</a>
@endsection

@section('content')
<div class="card">
    <form method="GET" action="{{ route('company.payroll.index') }}" class="row" style="gap:10px; align-items:end;">
        <div>
            <label class="muted small">{{ ___('Beginning') }}</label>
            <input class="input" type="date" name="from" value="{{ $from->toDateString() }}">
        </div>
        <div>
            <label class="muted small">{{ ___('Finishing') }}</label>
            <input class="input" type="date" name="to" value="{{ $to->toDateString() }}">
        </div>
        <div>
            <button class="btn primary" type="submit">{{ ___('Apply') }}</button>
        </div>
    </form>
</div>

<div class="card">
    <div class="h">{{ ___('Employees') }}</div>
    <table class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th>{{ ___('Full name') }}</th>
            <th>{{ ___('Role') }}</th>
            <th>{{ ___('Base salary') }}</th>
            <th>{{ ___('Commission') }}</th>
            <th>{{ ___('Total') }}</th>
        </tr>
        </thead>
        <tbody>
        @forelse($employees as $emp)
            @php $p = $payouts[$emp->id] ?? null; @endphp
            <tr>
                <td>{{ $emp->id }}</td>
                <td>{{ $emp->full_name }}</td>
                <td>{{ $emp->role }}</td>
                <td>{{ number_format($p['base_salary'] ?? 0,2) }} {{ $p['currency'] ?? 'AZN' }}</td>
                <td>{{ number_format($p['commission'] ?? 0,2) }} {{ $p['currency'] ?? 'AZN' }}</td>
                <td><strong>{{ number_format($p['total'] ?? 0,2) }} {{ $p['currency'] ?? 'AZN' }}</strong></td>
            </tr>
        @empty
            <tr><td colspan="6" class="muted">{{ ___('No information') }}</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
@endsection
