@extends('layouts.app')
@section('title', ___('Add driver'))
@section('page_title', ___('Add driver'))
@section('page_subtitle', ___('Taxi driver profile'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.taxi_drivers.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_drivers.store') }}" enctype="multipart/form-data">
            @csrf
            @include('company.taxi_drivers.partials.form', ['driver' => null])
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Create driver') }}</button>
            </div>
        </form>
    </div>
@endsection
