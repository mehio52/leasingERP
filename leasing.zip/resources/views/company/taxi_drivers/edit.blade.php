@extends('layouts.app')
@section('title', ___('Edit driver'))
@section('page_title', ___('Edit driver'))
@section('page_subtitle', ___('Taxi driver profile'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.taxi_drivers.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_drivers.update', $driver) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            @include('company.taxi_drivers.partials.form', ['driver' => $driver])
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save changes') }}</button>
            </div>
        </form>
    </div>
@endsection
