@extends('layouts.app')
@section('title', ___('Taxi drivers'))
@section('page_title', ___('Taxi drivers'))
@section('page_subtitle', ___('Manage taxi drivers'))
@section('page_actions')
    <a class="btn" href="{{ route('company.taxi_drivers.create') }}">{{ ___('Add driver') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif

    <div class="card" style="margin-bottom:12px;">
        <form method="GET" action="{{ route('company.taxi_drivers.index') }}">
            <div class="row">
                <div class="field" style="flex:2;">
                    <label>{{ ___('Search') }}</label>
                    <input name="q" value="{{ $q ?? '' }}" placeholder="{{ ___('Name, phone, email') }}">
                </div>
                <div class="field" style="display:flex; align-items:flex-end;">
                    <button class="btn" type="submit">{{ ___('Search') }}</button>
                </div>
            </div>
        </form>
    </div>

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Driver') }}</th>
                <th>{{ ___('Phone') }}</th>
                <th>{{ ___('Salary') }}</th>
                <th>{{ ___('Status') }}</th>
                <th style="width:180px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($drivers as $d)
                <tr>
                    <td>{{ $d->id }}</td>
                    <td>{{ $d->first_name }} {{ $d->last_name }}</td>
                    <td>{{ $d->phone ?? '-' }}</td>
                    <td>{{ $d->salary_type ? $d->salary_type . ' / ' . ($d->salary_value ?? '') : '-' }}</td>
                    <td>{{ $d->status ?? 'active' }}</td>
                    <td style="display:flex; gap:8px;">
                        <a class="btn" href="{{ route('company.taxi_drivers.edit', $d) }}">{{ ___('Edit') }}</a>
                        <form method="POST" action="{{ route('company.taxi_drivers.destroy', $d) }}" onsubmit="return confirm(@json(___('Delete this driver?')));">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">{{ ___('No drivers yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:12px;">{{ $drivers->links() }}</div>
    </div>
@endsection
