@php
    $drv = $driver ?? null;
    $meta = old('salary_meta_k') ? array_combine(old('salary_meta_k', []), old('salary_meta_v', [])) : ($drv->salary_meta ?? []);
    $metaKeys = array_keys($meta);
    $metaVals = array_values($meta);
    $rows = max(3, count($metaKeys));
@endphp

<div class="row">
    <div class="field">
        <label>{{ ___('First name') }}</label>
        <input name="first_name" value="{{ old('first_name', $drv->first_name ?? '') }}" required>
    </div>
    <div class="field">
        <label>{{ ___('Last name') }}</label>
        <input name="last_name" value="{{ old('last_name', $drv->last_name ?? '') }}" required>
    </div>
    <div class="field">
        <label>{{ ___('Phone') }}</label>
        <input name="phone" value="{{ old('phone', $drv->phone ?? '') }}">
    </div>
    <div class="field">
        <label>{{ ___('Email') }}</label>
        <input name="email" value="{{ old('email', $drv->email ?? '') }}">
    </div>
</div>

<div class="row">
    <div class="field" style="flex:2;">
        <label>{{ ___('Address') }}</label>
        <input name="address" value="{{ old('address', $drv->address ?? '') }}">
    </div>
    <div class="field">
        <label>{{ ___('Status') }}</label>
        <select name="status">
            <option value="active" @selected(old('status', $drv->status ?? 'active') === 'active')>{{ ___('Active') }}</option>
            <option value="inactive" @selected(old('status', $drv->status ?? '') === 'inactive')>{{ ___('Inactive') }}</option>
        </select>
    </div>
</div>

<div class="card" style="margin-top:12px;">
    <div class="h">{{ ___('Salary') }}</div>
    <div class="row">
        <div class="field">
            <label>{{ ___('Salary type') }}</label>
            <select name="salary_type">
                <option value="">-</option>
                @foreach($salaryTypes as $key => $label)
                    <option value="{{ $key }}" @selected(old('salary_type', $drv->salary_type ?? '') === $key)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="field">
            <label>{{ ___('Value') }}</label>
            <input type="number" step="0.01" min="0" name="salary_value" value="{{ old('salary_value', $drv->salary_value ?? '') }}">
        </div>
        <div class="field">
            <label>{{ ___('Currency') }}</label>
            <input name="salary_currency" value="{{ old('salary_currency', $drv->salary_currency ?? 'AZN') }}">
        </div>
    </div>
    <div class="h" style="margin-top:10px;">{{ ___('Salary meta') }}</div>
    <div class="muted small" style="margin-bottom:8px;">{{ ___('Use key/value for custom rules (e.g. percent, thresholds).') }}</div>
    @for($i = 0; $i < $rows; $i++)
        <div class="row" style="margin-bottom:6px;">
            <div class="field">
                <input name="salary_meta_k[]" placeholder="key" value="{{ old('salary_meta_k.' . $i, $metaKeys[$i] ?? '') }}">
            </div>
            <div class="field">
                <input name="salary_meta_v[]" placeholder="value" value="{{ old('salary_meta_v.' . $i, $metaVals[$i] ?? '') }}">
            </div>
        </div>
    @endfor
</div>

<div class="card" style="margin-top:12px;">
    <div class="h">{{ ___('Documents') }}</div>
    <div class="row">
        <div class="field">
            <label>{{ ___('Certificate number') }}</label>
            <input name="certificate_no" value="{{ old('certificate_no', $drv->certificate_no ?? '') }}">
        </div>
        <div class="field">
            <label>{{ ___('Certificate image') }}</label>
            <input type="file" name="certificate_image" accept="image/*">
            @if(!empty($drv?->certificate_image))
                <div class="muted small">{{ $drv->certificate_image }}</div>
            @endif
        </div>
    </div>
    <div class="row">
        <div class="field">
            <label>{{ ___('ID card number') }}</label>
            <input name="id_card_no" value="{{ old('id_card_no', $drv->id_card_no ?? '') }}">
        </div>
        <div class="field">
            <label>{{ ___('ID card image') }}</label>
            <input type="file" name="id_card_image" accept="image/*">
            @if(!empty($drv?->id_card_image))
                <div class="muted small">{{ $drv->id_card_image }}</div>
            @endif
        </div>
    </div>
    <div class="row">
        <div class="field">
            <label>{{ ___('Driver license number') }}</label>
            <input name="driver_license_no" value="{{ old('driver_license_no', $drv->driver_license_no ?? '') }}">
        </div>
        <div class="field">
            <label>{{ ___('Driver license image') }}</label>
            <input type="file" name="driver_license_image" accept="image/*">
            @if(!empty($drv?->driver_license_image))
                <div class="muted small">{{ $drv->driver_license_image }}</div>
            @endif
        </div>
    </div>
</div>

<div class="field" style="margin-top:12px;">
    <label>{{ ___('Notes') }}</label>
    <textarea name="notes" rows="3">{{ old('notes', $drv->notes ?? '') }}</textarea>
</div>
