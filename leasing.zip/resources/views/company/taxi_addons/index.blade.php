@extends('layouts.app')
@section('title', ___('Taxi add-ons'))
@section('page_title', ___('Taxi add-ons'))
@section('page_subtitle', ___('Create and manage taxi add-ons'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('dashboard') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_addons.store') }}">
            @csrf
            <div class="row">
                <div class="field">
                    <label>{{ ___('Name') }}</label>
                    <input name="name" value="{{ old('name') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Price (AZN)') }}</label>
                    <input type="number" step="0.01" min="0" name="price" value="{{ old('price', 0) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Billing type') }}</label>
                    <select name="billing_type">
                        <option value="per_trip" @selected(old('billing_type', 'per_trip') === 'per_trip')>{{ ___('Per trip') }}</option>
                        <option value="per_day" @selected(old('billing_type') === 'per_day')>{{ ___('Per day') }}</option>
                        <option value="per_month" @selected(old('billing_type') === 'per_month')>{{ ___('Per month') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Quantity') }}</label>
                    <input type="number" min="0" name="quantity" value="{{ old('quantity', 0) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Sort order') }}</label>
                    <input type="number" min="0" name="sort_order" value="{{ old('sort_order', 0) }}">
                </div>
                <div class="field" style="display:flex; align-items:flex-end;">
                    <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', true))>
                        {{ ___('Active') }}
                    </label>
                </div>
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Add add-on') }}</button>
            </div>
        </form>
    </div>

    <div class="card" style="margin-top:12px;">
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Name') }}</th>
                <th>{{ ___('Price') }}</th>
                <th>{{ ___('Billing') }}</th>
                <th>{{ ___('Quantity') }}</th>
                <th>{{ ___('Active') }}</th>
                <th>{{ ___('Order') }}</th>
                <th style="width:180px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($addons as $a)
                <tr>
                    <td>{{ $a->id }}</td>
                    <td>
                        <input class="input" name="name" form="addon-form-{{ $a->id }}" value="{{ old('name', $a->name) }}">
                    </td>
                    <td>
                        <input class="input" type="number" step="0.01" min="0" name="price" form="addon-form-{{ $a->id }}" value="{{ old('price', $a->price) }}">
                    </td>
                    <td>
                        <select name="billing_type" form="addon-form-{{ $a->id }}">
                            <option value="per_trip" @selected(($a->billing_type ?? 'per_trip') === 'per_trip')>{{ ___('Per trip') }}</option>
                            <option value="per_day" @selected($a->billing_type === 'per_day')>{{ ___('Per day') }}</option>
                            <option value="per_month" @selected($a->billing_type === 'per_month')>{{ ___('Per month') }}</option>
                        </select>
                    </td>
                    <td>
                        <input class="input" type="number" min="0" name="quantity" form="addon-form-{{ $a->id }}" value="{{ old('quantity', $a->quantity) }}">
                    </td>
                    <td>
                        <input type="hidden" name="is_active" value="0" form="addon-form-{{ $a->id }}">
                        <input type="checkbox" name="is_active" value="1" form="addon-form-{{ $a->id }}" @checked($a->is_active)>
                    </td>
                    <td>
                        <input class="input" type="number" min="0" name="sort_order" form="addon-form-{{ $a->id }}" value="{{ old('sort_order', $a->sort_order) }}">
                    </td>
                    <td style="display:flex; gap:8px;">
                        <form id="addon-form-{{ $a->id }}" method="POST" action="{{ route('company.taxi_addons.update', $a) }}">
                            @csrf
                            @method('PUT')
                            <button class="btn" type="submit">{{ ___('Save') }}</button>
                        </form>
                        <form method="POST" action="{{ route('company.taxi_addons.destroy', $a) }}" onsubmit="return confirm(@json(___('Delete this add-on?')));">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="8" class="muted">{{ ___('No add-ons yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endsection
