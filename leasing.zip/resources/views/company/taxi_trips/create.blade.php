@extends('layouts.app')
@section('title', ___('Add trip'))
@section('page_title', ___('Add trip'))
@section('page_subtitle', ___('Taxi trip record'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.taxi_trips.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_trips.store') }}">
            @csrf
            <div class="row">
                <div class="field">
                    <label>{{ ___('Driver') }}</label>
                    <select name="driver_id" required>
                        <option value="">-</option>
                        @foreach($drivers as $d)
                            <option value="{{ $d->id }}" @selected(old('driver_id') == $d->id)>{{ $d->first_name }} {{ $d->last_name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Vehicle') }}</label>
                    <select name="vehicle_id" required>
                        <option value="">-</option>
                        @foreach($vehicles as $v)
                            <option value="{{ $v->id }}" @selected(old('vehicle_id') == $v->id)>{{ $v->display_name ?? ($v->brand . ' ' . $v->model) }} ({{ $v->plate_number ?? '-' }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Start at') }}</label>
                    <input type="datetime-local" name="start_at" value="{{ old('start_at') }}">
                </div>
                <div class="field">
                    <label>{{ ___('End at') }}</label>
                    <input type="datetime-local" name="end_at" value="{{ old('end_at') }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Distance (km)') }}</label>
                    <input type="number" step="0.01" min="0" name="distance_km" value="{{ old('distance_km') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Fare') }}</label>
                    <input type="number" step="0.01" min="0" name="fare" value="{{ old('fare') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Tip') }}</label>
                    <input type="number" step="0.01" min="0" name="tip" value="{{ old('tip') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Discount') }}</label>
                    <input type="number" step="0.01" min="0" name="discount" value="{{ old('discount') }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Payment method') }}</label>
                    <input name="payment_method" value="{{ old('payment_method') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Status') }}</label>
                    <input name="status" value="{{ old('status', 'completed') }}">
                </div>
            </div>
            <div class="field">
                <label>{{ ___('Notes') }}</label>
                <textarea name="notes" rows="3">{{ old('notes') }}</textarea>
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Create trip') }}</button>
            </div>
        </form>
    </div>
@endsection
