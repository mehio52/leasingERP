@extends('layouts.app')
@section('title', ___('Taxi trips'))
@section('page_title', ___('Taxi trips'))
@section('page_subtitle', ___('Trip records and revenue'))
@section('page_actions')
    <a class="btn" href="{{ route('company.taxi_trips.create') }}">{{ ___('Add trip') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif

    <div class="card" style="margin-bottom:12px;">
        <form method="GET" action="{{ route('company.taxi_trips.index') }}">
            <div class="row">
                <div class="field" style="flex:2;">
                    <label>{{ ___('Search') }}</label>
                    <input name="q" value="{{ $q ?? '' }}" placeholder="{{ ___('Driver name') }}">
                </div>
                <div class="field" style="display:flex; align-items:flex-end;">
                    <button class="btn" type="submit">{{ ___('Search') }}</button>
                </div>
            </div>
        </form>
    </div>

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Driver') }}</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Start') }}</th>
                <th>{{ ___('Distance') }}</th>
                <th>{{ ___('Total') }}</th>
                <th style="width:180px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($trips as $t)
                <tr>
                    <td>{{ $t->id }}</td>
                    <td>{{ $t->driver?->first_name }} {{ $t->driver?->last_name }}</td>
                    <td>{{ $t->vehicle?->display_name ?? $t->vehicle?->plate_number ?? '-' }}</td>
                    <td>{{ $t->start_at?->format('Y-m-d H:i') ?? '-' }}</td>
                    <td>{{ $t->distance_km ?? '-' }}</td>
                    <td>{{ $t->total ?? 0 }}</td>
                    <td style="display:flex; gap:8px;">
                        <a class="btn" href="{{ route('company.taxi_trips.edit', $t) }}">{{ ___('Edit') }}</a>
                        <form method="POST" action="{{ route('company.taxi_trips.destroy', $t) }}" onsubmit="return confirm(@json(___('Delete this trip?')));">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">{{ ___('No trips yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:12px;">{{ $trips->links() }}</div>
    </div>
@endsection
