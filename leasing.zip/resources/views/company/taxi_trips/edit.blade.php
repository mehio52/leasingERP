@extends('layouts.app')
@section('title', ___('Edit trip'))
@section('page_title', ___('Edit trip'))
@section('page_subtitle', ___('Taxi trip record'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.taxi_trips.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_trips.update', $trip) }}">
            @csrf
            @method('PUT')
            <div class="row">
                <div class="field">
                    <label>{{ ___('Driver') }}</label>
                    <select name="driver_id" required>
                        @foreach($drivers as $d)
                            <option value="{{ $d->id }}" @selected(old('driver_id', $trip->driver_id) == $d->id)>{{ $d->first_name }} {{ $d->last_name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Vehicle') }}</label>
                    <select name="vehicle_id" required>
                        @foreach($vehicles as $v)
                            <option value="{{ $v->id }}" @selected(old('vehicle_id', $trip->vehicle_id) == $v->id)>{{ $v->display_name ?? ($v->brand . ' ' . $v->model) }} ({{ $v->plate_number ?? '-' }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Start at') }}</label>
                    <input type="datetime-local" name="start_at" value="{{ old('start_at', $trip->start_at ? $trip->start_at->format('Y-m-d\TH:i') : '') }}">
                </div>
                <div class="field">
                    <label>{{ ___('End at') }}</label>
                    <input type="datetime-local" name="end_at" value="{{ old('end_at', $trip->end_at ? $trip->end_at->format('Y-m-d\TH:i') : '') }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Distance (km)') }}</label>
                    <input type="number" step="0.01" min="0" name="distance_km" value="{{ old('distance_km', $trip->distance_km) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Fare') }}</label>
                    <input type="number" step="0.01" min="0" name="fare" value="{{ old('fare', $trip->fare) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Tip') }}</label>
                    <input type="number" step="0.01" min="0" name="tip" value="{{ old('tip', $trip->tip) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Discount') }}</label>
                    <input type="number" step="0.01" min="0" name="discount" value="{{ old('discount', $trip->discount) }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Payment method') }}</label>
                    <input name="payment_method" value="{{ old('payment_method', $trip->payment_method) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Status') }}</label>
                    <input name="status" value="{{ old('status', $trip->status) }}">
                </div>
            </div>
            <div class="field">
                <label>{{ ___('Notes') }}</label>
                <textarea name="notes" rows="3">{{ old('notes', $trip->notes) }}</textarea>
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save changes') }}</button>
            </div>
        </form>
    </div>
@endsection
