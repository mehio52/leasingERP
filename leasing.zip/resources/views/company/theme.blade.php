@extends('layouts.app')

@section('title', ___('Public Theme'))
@section('page_title', ___('Public Theme'))
@section('page_subtitle')
    {{ $company->name }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ url()->previous() }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card" style="margin-bottom:14px;">
        <div style="font-weight:700; margin-bottom:6px;">{{ ___('Public URL') }}</div>
        @if($company->public_enabled)
            @php
                $publicUrl = route('public.theme', ['companySlug' => $company->slug]);
            @endphp
            <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                <a href="{{ $publicUrl }}" target="_blank" class="btn ghost">{{ $publicUrl }}</a>
                <span class="muted small">{{ ___('Public site is enabled') }}</span>
            </div>
        @else
            <div class="muted small">{{ ___('Public site is disabled. Enable below to activate the URL.') }}</div>
        @endif
    </div>

    <div class="card">
        <form method="POST" action="{{ route('company.theme.update') }}">
            @csrf
            @method('PUT')

            <div class="switch" style="margin-bottom:16px;">
                <input type="checkbox" name="public_enabled" value="1" @checked(old('public_enabled', $company->public_enabled) == 1)>
                <div>
                    <div style="font-weight:700;">{{ ___('Enable public site') }}</div>
                    <div class="muted small">{{ ___('If disabled, public URL will return 404') }}</div>
                </div>
            </div>

            @php
                $selectedThemeCode = old('public_theme', $company->public_theme ?? $defaultTheme);
                $moduleLabel = $company->isRentacarModule() ? ___('Rent a car') : ___('Leasing');
                $vehicleLabel = $company->isRentacarModule() ? ___('cars') : ___('vehicles');
            @endphp
            <div class="field">
                <label>{{ ___('Theme') }}</label>
                <input type="hidden" name="public_theme" id="public_theme_input" value="{{ $selectedThemeCode }}">
                <div class="theme-grid">
                    @foreach($themes as $theme)
                        @php $isSelected = $selectedThemeCode === $theme['code']; @endphp
                        <div class="theme-card @if($isSelected) selected @endif" data-theme-code="{{ $theme['code'] }}">
                            <div class="theme-preview">
                                @if(!empty($theme['preview']))
                                    <img src="{{ $theme['preview'] }}" alt="{{ $theme['name'] }} preview">
                                @else
                                    <div class="theme-placeholder">{{ ___('Preview unavailable') }}</div>
                                @endif
                            </div>
                            <div class="theme-info">
                                <div class="theme-title">{{ $theme['name'] }}</div>
                                <div class="theme-subtitle">
                                    <span>{{ $theme['version'] ?: '—' }}</span>
                                    @if(!empty($theme['plans']))
                                        <span>· {{ $theme['plans'] }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="muted small" style="margin-top:6px;">
                {{ ___('Showing only :module themes.', ['module' => $moduleLabel]) }}
            </div>

            <style>
                .theme-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                    gap: 10px;
                    margin-top: 10px;
                    align-items: stretch;
                }
                .theme-card {
                    border: 1px solid var(--border);
                    border-radius: 10px;
                    overflow: hidden;
                    display: flex;
                    flex-direction: column;
                    background: var(--bg, #fff);
                    transition: box-shadow 0.2s, border-color 0.2s, transform 0.2s;
                    cursor: pointer;
                }
                .theme-card.selected {
                    border-color: var(--primary);
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                    transform: translateY(-2px);
                }
                .theme-preview {
                    min-height: 90px;
                    max-height: 90px;
                    background: var(--border);
                    position: relative;
                }
                .theme-preview img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    display: block;
                }
                .theme-card .theme-preview::after {
                    content: '';
                    position: absolute;
                    inset: 0;
                    border-radius: 10px 10px 0 0;
                    box-shadow: inset 0 0 0 1px rgba(0,0,0,0.08);
                }
                .theme-placeholder {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    height: 100%;
                    padding: 10px;
                    font-size: 13px;
                    color: var(--text-muted);
                    text-align: center;
                }
                .theme-info {
                    padding: 12px;
                }
                .theme-title {
                    font-weight: 600;
                }
                .theme-subtitle {
                    font-size: 13px;
                    color: var(--text-muted);
                    margin-top: 4px;
                }
                @media (max-width: 640px) {
                    .theme-grid {
                        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                    }
                    .theme-card.selected {
                        transform: translateY(0);
                    }
                }
            </style>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    const cards = document.querySelectorAll('.theme-card');
                    const hidden = document.getElementById('public_theme_input');
                    if (!hidden) return;
                    cards.forEach(function (card) {
                        card.addEventListener('click', function () {
                            hidden.value = card.dataset.themeCode;
                            cards.forEach(function (c) { c.classList.remove('selected'); });
                            card.classList.add('selected');
                        });
                    });
                });
            </script>

            <div class="muted small" style="margin-top:8px;">
                {{ ___('Place your theme under resources/themes/{code} with theme-info.txt, views/, assets/.') }}
            </div>

            <div style="height:12px;"></div>

            <div class="switch" style="margin-bottom:12px;">
                <input type="checkbox" name="show_calculator" value="1" @checked(old('show_calculator', $showCalculator) == 1)>
                <div>
                    <div style="font-weight:700;">{{ ___('Show credit calculator block') }}</div>
                    <div class="muted small">{{ ___('If unchecked, calculator will be hidden in the public theme.') }}</div>
                </div>
            </div>
            <div class="switch" style="margin-bottom:12px;">
                <input type="checkbox" name="show_public_vehicles" value="1" @checked(old('show_public_vehicles', $company->public_settings['show_public_vehicles'] ?? true) == 1)>
                <div>
                    <div style="font-weight:700;">{{ ___('Show :term section', ['term' => ucfirst($vehicleLabel)]) }}</div>
                    <div class="muted small">{{ ___('Hide or show :term list on public site.', ['term' => $vehicleLabel]) }}</div>
                </div>
            </div>
            <div class="switch" style="margin-bottom:12px;">
                <input type="checkbox" name="show_blog_link" value="1" @checked(old('show_blog_link', $company->public_settings['show_blog_link'] ?? true) == 1)>
                <div>
                    <div style="font-weight:700;">{{ ___('Show blog link') }}</div>
                    <div class="muted small">{{ ___('Toggle visibility of blog link/section on public site.') }}</div>
                </div>
            </div>
            <div class="switch" style="margin-bottom:12px;">
                <input type="checkbox" name="show_pages_footer" value="1" @checked(old('show_pages_footer', $company->public_settings['show_pages_footer'] ?? true) == 1)>
                <div>
                    <div style="font-weight:700;">{{ ___('Show custom pages in footer') }}</div>
                    <div class="muted small">{{ ___('Hide or show created pages links in footer.') }}</div>
                </div>
            </div>
            <div class="switch" style="margin-bottom:12px;">
                <input type="checkbox" name="show_test_drive" value="1" @checked(old('show_test_drive', $company->public_settings['show_test_drive'] ?? true) == 1)>
                <div>
                    <div style="font-weight:700;">{{ ___('Show test drive form') }}</div>
                    <div class="muted small">{{ ___('Hide or show test drive request block.') }}</div>
                </div>
            </div>

            <div class="field">
                <label>{{ ___(':term to display on public site', ['term' => ucfirst($vehicleLabel)]) }}</label>
                <select name="public_vehicle_ids[]" multiple size="6">
                    @foreach($vehicles as $v)
                        @php $label = "#{$v->id} - {$v->brand} {$v->model}"; @endphp
                        <option value="{{ $v->id }}" @selected(in_array($v->id, (array)($company->public_settings['public_vehicle_ids'] ?? [])))>
                            {{ $label }}
                        </option>
                    @endforeach
                </select>
                <div class="muted small">{{ ___('Select which :term appear on the public page.', ['term' => $vehicleLabel]) }}</div>
            </div>

            <div style="height:12px;"></div>

            @php
                $localeOptions = ['en'=>'English','az'=>'Azerbaijani','ru'=>'Russian','tr'=>'Turkish'];
                $selectedLocales = old('theme_locales', $themeLocales);
                $defaultLocale = old('theme_default_locale', $themeDefaultLocale);
                $themeStyles = $company->public_settings['theme_styles'] ?? [];
            @endphp
            <div class="row">
                <div class="field">
                    <label>{{ ___('Available languages') }}</label>
                    <select name="theme_locales[]" multiple size="4">
                        @foreach($localeOptions as $code=>$label)
                            <option value="{{ $code }}" @selected(in_array($code, (array)$selectedLocales))>{{ $label }}</option>
                        @endforeach
                    </select>
                    <div class="muted small">{{ ___('Select languages to show in the public site switcher') }}</div>
                </div>
                <div class="field">
                    <label>{{ ___('Default language') }}</label>
                    <select name="theme_default_locale">
                        @foreach($localeOptions as $code=>$label)
                            <option value="{{ $code }}" @selected($defaultLocale === $code)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div style="height:12px;"></div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Background color') }}</label>
                    <input type="color" name="bg_color" value="{{ old('bg_color', $themeStyles['background_color'] ?? '#f8fafc') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Text color') }}</label>
                    <input type="color" name="text_color" value="{{ old('text_color', $themeStyles['text_color'] ?? '#0f172a') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Heading color') }}</label>
                    <input type="color" name="heading_color" value="{{ old('heading_color', $themeStyles['heading_color'] ?? '#0f172a') }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Link color') }}</label>
                    <input type="color" name="link_color" value="{{ old('link_color', $themeStyles['link_color'] ?? '#0f172a') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Card background') }}</label>
                    <input type="color" name="card_bg_color" value="{{ old('card_bg_color', $themeStyles['card_bg_color'] ?? '#ffffff') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Base font size') }}</label>
                    <input type="text" name="font_size" value="{{ old('font_size', $themeStyles['font_size'] ?? '16px') }}" placeholder="16px">
                    <div class="muted small">{{ ___('Use CSS unit, e.g. 15px or 1rem') }}</div>
                </div>
            </div>

            <div class="actions" style="margin-top:16px;">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>
@endsection
