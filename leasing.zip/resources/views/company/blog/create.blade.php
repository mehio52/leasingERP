@extends('layouts.app')

@section('title', ___('New blog post'))
@section('page_title', ___('New blog post'))
@section('page_subtitle')
    {{ $company->name }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.blog.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.blog.store') }}">
            @csrf
            <div class="field">
                <label>{{ ___('Title') }}</label>
                <input name="title" value="{{ old('title') }}" required>
            </div>
            <div class="field">
                <label>{{ ___('Slug (optional)') }}</label>
                <input name="slug" value="{{ old('slug') }}" placeholder="{{ ___('auto from title') }}">
            </div>
            <div class="field">
                <label>{{ ___('Excerpt (optional)') }}</label>
                <textarea name="excerpt" rows="2">{{ old('excerpt') }}</textarea>
            </div>
            <div class="field">
                <label>{{ ___('Content') }}</label>
                <textarea name="content" rows="8">{{ old('content') }}</textarea>
            </div>
            <div class="field">
                <label>{{ ___('Status') }}</label>
                <select name="status">
                    <option value="published" @selected(old('status')==='published')>{{ ___('Published') }}</option>
                    <option value="draft" @selected(old('status')==='draft')>{{ ___('Draft') }}</option>
                </select>
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>
@endsection
