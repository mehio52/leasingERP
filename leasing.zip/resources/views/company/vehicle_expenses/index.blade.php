@extends('layouts.app')

@section('title', ___('Vehicle expenses'))
@section('page_title', ___('Vehicle expenses'))
@section('page_subtitle', ___('Track maintenance and operating costs'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.index') }}">{{ ___('Cars') }}</a>
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

@if($errors->any())
    <div class="banner error">
        <span class="badge bad">{{ ___('Error') }}</span>
        <ul style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <div class="h">{{ ___('Add expense') }}</div>
        <form method="POST" action="{{ route('company.vehicle_expenses.store') }}" class="row">
            @csrf
            <div class="field">
                <label>{{ ___('Vehicle') }}</label>
                <select name="vehicle_id" required>
                    <option value="">{{ ___('Select') }}</option>
                    @foreach($vehicles as $v)
                        <option value="{{ $v->id }}" @selected(old('vehicle_id') == $v->id)>
                            {{ $v->display_name }} {{ $v->plate_number ? '(' . $v->plate_number . ')' : '' }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Category') }}</label>
                <select name="category" required>
                    @foreach($categories as $key => $label)
                        <option value="{{ $key }}" @selected(old('category', 'other') === $key)>{{ $label }}</option>
                    @endforeach
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Amount') }}</label>
                <input name="amount" type="number" step="0.01" min="0" value="{{ old('amount') }}" placeholder="0" required>
            </div>
            <div class="field">
                <label>{{ ___('Expense date') }}</label>
                <input name="expense_date" type="date" value="{{ old('expense_date') }}">
            </div>
            <div class="field">
                <label>{{ ___('Vendor / Master') }}</label>
                <input name="vendor" value="{{ old('vendor') }}" placeholder="{{ ___('Optional') }}">
            </div>
            <div class="field" style="grid-column: span 2;">
                <label>{{ ___('Problem / Title') }}</label>
                <input name="title" value="{{ old('title') }}" placeholder="{{ ___('Example: Oil change, brake issue...') }}">
            </div>
            <div class="field" style="grid-column: span 2;">
                <label>{{ ___('Details') }}</label>
                <textarea name="details" rows="3" placeholder="{{ ___('Notes about the issue or work done') }}">{{ old('details') }}</textarea>
            </div>
            <div class="actions" style="grid-column: span 2;">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

    <div class="card" style="margin-top:12px;">
        <div class="h">{{ ___('Expenses report') }}</div>
        <form method="GET" class="row" style="margin-bottom:10px;">
            <div class="field">
                <label>{{ ___('Vehicle') }}</label>
                <select name="vehicle_id">
                    <option value="">{{ ___('All') }}</option>
                    @foreach($vehicles as $v)
                        <option value="{{ $v->id }}" @selected(($filters['vehicle_id'] ?? '') == $v->id)>
                            {{ $v->display_name }} {{ $v->plate_number ? '(' . $v->plate_number . ')' : '' }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Category') }}</label>
                <select name="category">
                    <option value="">{{ ___('All') }}</option>
                    @foreach($categories as $key => $label)
                        <option value="{{ $key }}" @selected(($filters['category'] ?? '') === $key)>{{ $label }}</option>
                    @endforeach
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Date from') }}</label>
                <input type="date" name="date_from" value="{{ $filters['date_from'] ?? '' }}">
            </div>
            <div class="field">
                <label>{{ ___('Date to') }}</label>
                <input type="date" name="date_to" value="{{ $filters['date_to'] ?? '' }}">
            </div>
            <div class="actions" style="grid-column: span 2;">
                <button class="btn" type="submit">{{ ___('Filter') }}</button>
                <a class="btn ghost" href="{{ route('company.vehicle_expenses.index') }}">{{ ___('Reset') }}</a>
            </div>
        </form>

        <div class="muted small" style="margin-bottom:6px;">
            {{ ___('Total amount') }}: <strong>{{ number_format((float)$totalAmount, 2) }}</strong>
        </div>

        <table>
            <thead>
            <tr>
                <th>{{ ___('Date') }}</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Category') }}</th>
                <th>{{ ___('Problem') }}</th>
                <th>{{ ___('Vendor') }}</th>
                <th>{{ ___('Amount') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($expenses as $e)
                <tr>
                    <td>{{ $e->expense_date?->format('Y-m-d') ?? '-' }}</td>
                    <td>{{ $e->vehicle?->display_name ?? '-' }}</td>
                    <td>{{ $categories[$e->category] ?? $e->category }}</td>
                    <td>
                        <div>{{ $e->title ?? '-' }}</div>
                        @if($e->details)
                            <div class="muted small">{{ $e->details }}</div>
                        @endif
                    </td>
                    <td>{{ $e->vendor ?? '-' }}</td>
                    <td>{{ number_format((float)$e->amount, 2) }}</td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">{{ ___('No expenses found.') }}</td></tr>
            @endforelse
            </tbody>
        </table>

        {{ $expenses->links() }}
    </div>
</div>
@endsection
