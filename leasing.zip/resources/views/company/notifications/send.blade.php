@extends('layouts.app')

@section('title', ___('Send notification'))
@section('page_title', ___('Send notification'))
@section('page_subtitle')
    {{ auth()->user()->isSuperAdmin() ? 'Superadmin' : (auth()->user()->company?->name ?? '') }}
@endsection

@section('page_actions')
    <a class="btn ghost" href="{{ url()->previous() }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @php
        $action = auth()->user()->isSuperAdmin()
            ? route('superadmin.notifications.store')
            : route('company.notifications.store');
    @endphp
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ $action }}">
            @csrf
            <div class="field">
                <label>{{ ___('Scope') }}</label>
                <select name="scope" id="scopeSelect" required>
                    @foreach($scopes as $k => $label)
                        <option value="{{ $k }}">{{ $label }}</option>
                    @endforeach
                </select>
            </div>

            @if(isset($companies) && $companies->count())
            <div class="field" id="companyWrap">
                <label>{{ ___('Target company') }}</label>
                <select name="company_id">
                    <option value="">{{ ___('Select company (optional)') }}</option>
                    @foreach($companies as $c)
                        <option value="{{ $c->id }}">{{ $c->name }} (#{{ $c->id }})</option>
                    @endforeach
                </select>
            </div>
            @endif

            <div class="field" id="targetUserWrap" style="display:none;">
                <label>{{ ___('Target user') }}</label>
                <select name="target_user_id">
                    <option value="">{{ ___('Select user') }}</option>
                    @foreach($companyUsers as $u)
                        <option value="{{ $u->id }}">{{ $u->full_name }} ({{ $u->email ?? $u->phone }})</option>
                    @endforeach
                </select>
            </div>

            <div class="field" id="targetRoleWrap" style="display:none;">
                <label>{{ ___('Target role') }}</label>
                <select name="target_role">
                    <option value="owner">Owner</option>
                    <option value="superadmin">Superadmin</option>
                </select>
            </div>

            <div class="field">
                <label>{{ ___('Title') }}</label>
                <input name="title" value="{{ old('title') }}" required>
            </div>

            <div class="field">
                <label>{{ ___('Body') }}</label>
                <textarea name="body" rows="3">{{ old('body') }}</textarea>
            </div>

            @if(auth()->user()->isSuperAdmin())
                <div class="actions" style="display:flex; gap:12px; align-items:center; justify-content:flex-end; flex-wrap:wrap;">
                    <label style="display:flex; align-items:center; gap:8px; margin:0;">
                        <input type="hidden" name="send_whatsapp" value="0">
                        <input type="checkbox" name="send_whatsapp" value="1" @checked(old('send_whatsapp'))>
                        <span class="muted small">{{ ___('Send via WhatsApp') }}</span>
                    </label>
                    <button class="btn primary" type="submit">{{ ___('Send') }}</button>
                </div>
            @else
                <div class="actions">
                    <button class="btn primary" type="submit">{{ ___('Send') }}</button>
                </div>
            @endif
        </form>
    </div>
@endsection

@push('scripts')
<script>
    (function(){
        const scope = document.getElementById('scopeSelect');
        const userWrap = document.getElementById('targetUserWrap');
        const roleWrap = document.getElementById('targetRoleWrap');
        function toggle(){
            const val = scope.value;
            userWrap.style.display = val === 'user' ? 'block' : 'none';
            roleWrap.style.display = val === 'role' ? 'block' : 'none';
        }
        scope?.addEventListener('change', toggle);
        toggle();
    })();
</script>
@endpush
