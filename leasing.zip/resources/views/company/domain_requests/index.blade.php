@extends('layouts.app')

@section('title', ___('Custom domain'))
@section('page_title', ___('Custom domain'))
@section('page_subtitle')
    {{ $company->name }}
@endsection

@section('page_actions')
    <a class="btn ghost" href="{{ url()->previous() }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="h">{{ ___('Current domain') }}</div>
        <div class="muted">{{ $company->domain ?: ___('Not set') }}</div>
    </div>

    <div class="card">
        <div class="h">{{ ___('Request a custom domain') }}</div>
        <div class="muted" style="margin-bottom:10px;">{{ ___('Enter the domain you want to use for your public theme (example: example.com).') }}</div>

        <form method="POST" action="{{ route('company.domain_requests.store') }}" class="row">
            @csrf
            <div class="field">
                <label>{{ ___('Requested domain') }}</label>
                <input name="requested_domain" value="{{ old('requested_domain') }}" placeholder="example.com" required>
            </div>
            <div class="field" style="align-self:flex-end;">
                <button class="btn primary action-right" type="submit">{{ ___('Submit request') }}</button>
            </div>
        </form>

        <div class="muted small" style="margin-top:10px;">
            {{ ___('Admin will review the request and contact you if needed.') }}
        </div>
    </div>

    <div class="card">
        <div class="h">{{ ___('Request history') }}</div>
        <table>
            <thead>
                <tr>
                    <th>{{ ___('Domain') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Routing') }}</th>
                    <th>{{ ___('Requested at') }}</th>
                    <th>{{ ___('Admin note') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($requests as $req)
                    <tr>
                        <td>{{ $req->requested_domain }}</td>
                        <td>{{ ucfirst($req->status) }}</td>
                        <td>
                            @if($req->is_active)
                                <span class="badge ok">{{ ___('Active') }}</span>
                            @else
                                <span class="badge">{{ ___('Inactive') }}</span>
                            @endif
                        </td>
                        <td>{{ $req->created_at?->format('Y-m-d H:i') }}</td>
                        <td>{{ $req->admin_note ?: '-' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="muted">{{ ___('No requests yet.') }}</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection
