@extends('layouts.app')

@section('title', ___('Pages'))
@section('page_title', ___('Pages'))
@section('page_subtitle')
    {{ $company->name }}
@endsection
@section('page_actions')
    <a class="btn primary action-right" href="{{ route('company.pages.create') }}">{{ ___('New page') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif

    <div class="card">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>{{ ___('Title') }}</th>
                    <th>{{ ___('Slug / URL') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Published at') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach($pages as $p)
                    <tr>
                        <td>{{ $p->id }}</td>
                        <td>{{ $p->title }}</td>
                        <td>{{ $p->slug }}</td>
                        <td>{{ $p->status }}</td>
                        <td>{{ $p->published_at }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        {{ $pages->links() }}
    </div>
@endsection
