@extends('layouts.app')

@section('title', ___('Test drives'))
@section('page_title', ___('Test drives'))
@section('page_subtitle')
    {{ $company->name }}
@endsection

@section('content')
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif

    <div class="card" style="margin-bottom:16px;">
        <div style="font-weight:700; margin-bottom:8px;">{{ ___('Calendar overview') }}</div>
        @if($calendarStats->isEmpty())
            <div class="muted">{{ ___('No requests yet.') }}</div>
        @else
            <div style="display:flex; flex-wrap:wrap; gap:10px;">
                @foreach($calendarStats as $item)
                    <div style="border:1px solid #e2e8f0; border-radius:8px; padding:8px 12px; background:#f8fafc;">
                        <div style="font-weight:700;">{{ $item['day'] }}</div>
                        <div class="muted small">{{ ___('Total') }}: {{ $item['total'] }}</div>
                        <div class="muted small">{{ ___('Confirmed') }}: {{ $item['confirmed'] }}</div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>

    <div class="card">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>{{ ___('Name') }}</th>
                    <th>{{ ___('Vehicle') }}</th>
                    <th>{{ ___('Contact') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Scheduled for') }}</th>
                    <th>{{ ___('Note') }}</th>
                    <th>{{ ___('Actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach($testDrives as $td)
                    <tr>
                        <td>{{ $td->id }}</td>
                        <td>{{ $td->name }}</td>
                        <td>{{ $td->vehicle?->display_name ?? '—' }}</td>
                        <td>
                            <div>{{ $td->phone }}</div>
                            <div>{{ $td->email }}</div>
                        </td>
                        <td>{{ $td->status }}</td>
                        <td>{{ $td->scheduled_for }}</td>
                        <td>{{ $td->note }}</td>
                        <td>
                            <form method="POST" action="{{ route('company.test_drives.update', $td) }}" style="display:grid; gap:6px; min-width:200px;">
                                @csrf
                                @method('PUT')
                                <select name="status">
                                    @foreach(['pending','confirmed','cancelled','done'] as $st)
                                        <option value="{{ $st }}" @selected($td->status === $st)>{{ ucfirst($st) }}</option>
                                    @endforeach
                                </select>
                                <input type="datetime-local" name="scheduled_for" value="{{ $td->scheduled_for ? $td->scheduled_for->format('Y-m-d\\TH:i') : '' }}">
                                <textarea name="note" rows="2" placeholder="{{ ___('Internal note') }}">{{ $td->note }}</textarea>
                                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        {{ $testDrives->links() }}
    </div>
@endsection
