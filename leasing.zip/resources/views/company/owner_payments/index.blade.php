@extends('layouts.app')

@section('title', ___('Owner payments'))
@section('page_title', ___('Owner payments'))
@section('page_subtitle', ___('Rent a car owners payments report'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.index') }}">{{ ___('Cars') }}</a>
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

@if($errors->any())
    <div class="banner error">
        <span class="badge bad">{{ ___('Error') }}</span>
        <ul style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <div class="h">{{ ___('Add owner payment') }}</div>
        <form method="POST" action="{{ route('company.owner_payments.store') }}" class="row">
            @csrf
            <div class="field">
                <label>{{ ___('Vehicle') }}</label>
                <select name="vehicle_id" required>
                    <option value="">{{ ___('Select') }}</option>
                    @foreach($ownerVehicles as $v)
                        <option value="{{ $v->id }}" @selected(old('vehicle_id') == $v->id)>
                            {{ $v->display_name }} {{ $v->plate_number ? '(' . $v->plate_number . ')' : '' }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Payment type') }}</label>
                <select name="payment_type">
                    <option value="">{{ ___('Select') }}</option>
                    <option value="daily" @selected(old('payment_type') === 'daily')>{{ ___('Daily') }}</option>
                    <option value="weekly" @selected(old('payment_type') === 'weekly')>{{ ___('Weekly') }}</option>
                    <option value="monthly" @selected(old('payment_type') === 'monthly')>{{ ___('Monthly') }}</option>
                    <option value="per_rental" @selected(old('payment_type') === 'per_rental')>{{ ___('Per rental') }}</option>
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Amount') }}</label>
                <input name="amount" value="{{ old('amount') }}" placeholder="0" required>
            </div>
            <div class="field">
                <label>{{ ___('Paid at') }}</label>
                <input type="datetime-local" name="paid_at" value="{{ old('paid_at') }}">
            </div>
            <div class="field">
                <label>{{ ___('Period start') }}</label>
                <input type="date" name="period_start" value="{{ old('period_start') }}">
            </div>
            <div class="field">
                <label>{{ ___('Period end') }}</label>
                <input type="date" name="period_end" value="{{ old('period_end') }}">
            </div>
            <div class="field" style="grid-column: span 2;">
                <label>{{ ___('Note') }}</label>
                <input name="note" value="{{ old('note') }}" placeholder="{{ ___('Optional') }}">
            </div>
            <div class="actions" style="grid-column: span 2;">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

    <div class="card" style="margin-top:12px;">
        <div class="h">{{ ___('Report') }}</div>
        <form method="GET" class="row" style="margin-bottom:10px;">
            <div class="field">
                <label>{{ ___('Vehicle') }}</label>
                <select name="vehicle_id">
                    <option value="">{{ ___('All') }}</option>
                    @foreach($ownerVehicles as $v)
                        <option value="{{ $v->id }}" @selected(($filters['vehicle_id'] ?? '') == $v->id)>
                            {{ $v->display_name }} {{ $v->plate_number ? '(' . $v->plate_number . ')' : '' }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Owner') }}</label>
                <select name="owner_customer_id">
                    <option value="">{{ ___('All') }}</option>
                    @foreach($owners as $o)
                        <option value="{{ $o->id }}" @selected(($filters['owner_customer_id'] ?? '') == $o->id)>
                            {{ $o->full_name }} {{ $o->phone ? '(' . $o->phone . ')' : '' }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="field">
                <label>{{ ___('Date from') }}</label>
                <input type="date" name="date_from" value="{{ $filters['date_from'] ?? '' }}">
            </div>
            <div class="field">
                <label>{{ ___('Date to') }}</label>
                <input type="date" name="date_to" value="{{ $filters['date_to'] ?? '' }}">
            </div>
            <div class="actions" style="grid-column: span 2;">
                <button class="btn" type="submit">{{ ___('Filter') }}</button>
                <a class="btn ghost" href="{{ route('company.owner_payments.index') }}">{{ ___('Reset') }}</a>
            </div>
        </form>

        <div class="muted small" style="margin-bottom:6px;">
            {{ ___('Total amount') }}: <strong>{{ number_format((float)$totalAmount, 2) }}</strong>
        </div>

        <table>
            <thead>
            <tr>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Owner') }}</th>
                <th>{{ ___('Payment type') }}</th>
                <th>{{ ___('Amount') }}</th>
                <th>{{ ___('Paid at') }}</th>
                <th>{{ ___('Period') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($payments as $p)
                <tr>
                    <td>{{ $p->vehicle?->display_name ?? '-' }}</td>
                    <td>{{ $p->owner?->full_name ?? '-' }}</td>
                    <td>{{ $p->payment_type ?? '-' }}</td>
                    <td>{{ number_format((float)$p->amount, 2) }}</td>
                    <td>{{ $p->paid_at?->format('Y-m-d H:i') ?? '-' }}</td>
                    <td>
                        @if($p->period_start || $p->period_end)
                            {{ $p->period_start?->format('Y-m-d') ?? '-' }} - {{ $p->period_end?->format('Y-m-d') ?? '-' }}
                        @else
                            -
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">{{ ___('No payments yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>

        {{ $payments->links() }}
    </div>
</div>
@endsection
