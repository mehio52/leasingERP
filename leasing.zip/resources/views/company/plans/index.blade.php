@extends('layouts.app')

@section('title', ___('Plans'))
@section('page_title', ___('Plans'))
@section('page_subtitle', ___('Subscription overview'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.addons.index') }}">{{ ___('add_ons') }}</a>
@endsection

@push('styles')
<style>
    .plan-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;align-items:stretch;}
    .plan-card{border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;background:linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01));position:relative;overflow:hidden;display:flex;flex-direction:column;gap:10px;}
    .plan-card .plan-head{display:flex;align-items:center;justify-content:space-between;gap:8px;}
    .plan-card .plan-name{font-weight:800;font-size:18px;}
    .plan-card .plan-code{font-size:12px;text-transform:uppercase;}
    .plan-card .price-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;}
    .plan-card .pill{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:6px 10px;font-size:12px;background:rgba(255,255,255,0.06);}
    .plan-card .feature-list{list-style:none;padding:0;margin:6px 0 0;display:flex;flex-direction:column;gap:6px;}
    .plan-card .feature-list li{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:6px 0;border-bottom:1px dashed rgba(255,255,255,0.04);}
    .plan-card .feature-list li:last-child{border-bottom:0;}
    .plan-card .feature-list .label{display:flex;align-items:center;gap:8px;}
    .plan-card .dot{width:8px;height:8px;border-radius:50%;background:#7dd3fc;display:inline-block;}
    .plan-card .feature-list .disabled .dot{background:#475569;}
    .plan-card .feature-list .disabled .label{opacity:.65;text-decoration:line-through;}
    .plan-card.active{border-color:#f5c542;background:linear-gradient(145deg,rgba(245,197,66,0.18),rgba(245,197,66,0.05));box-shadow:0 10px 38px rgba(245,197,66,0.16);}
    .plan-pill{display:inline-flex;align-items:center;gap:8px;color:#f5c542;background:rgba(245,197,66,0.12);border:1px solid rgba(245,197,66,0.4);border-radius:999px;padding:8px 12px;font-weight:800;letter-spacing:0.3px;}
    .plan-pill svg{width:18px;height:18px;color:inherit;}
    .plan-hero{display:flex;flex-direction:column;gap:10px;}
    .section-title{font-weight:700;margin-bottom:4px;}
</style>
@endpush

@php
    $crownIcon = '<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M4.5 8.2l3.9 2.6 2.6-5.2 2.6 5.2 3.9-2.6 1.8 8.3H2.7l1.8-8.3z"/><path d="M4 18.5h16v2H4z"/></svg>';
    $currentPlanName = $currentSubscription?->plan_name_snapshot
        ?? $currentSubscription?->plan?->name
        ?? ($currentPlanCode ? strtoupper($currentPlanCode) : null);
@endphp

@section('content')
<div class="wrap">
    @if(request('status') === 'success')
        <div class="banner success">{{ ___('Payment successful. Your plan will be activated shortly.') }}</div>
    @elseif(request('status') === 'error')
        <div class="banner error">{{ ___('Payment failed. Please try again.') }}</div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <div class="card">
        <div class="plan-hero">
            <div class="plan-pill">
                {!! $crownIcon !!}
                <span>{{ $currentPlanName ?? ___('No active subscription') }}</span>
            </div>
            <div class="muted small" style="display:flex;gap:12px;flex-wrap:wrap;">
                <span>{{ ___('Status') }}: <strong>{{ $currentSubscription?->status ?? ___('unknown') }}</strong></span>
                <span>{{ ___('Trial ends at') }}: {{ optional($currentSubscription?->trial_ends_at ?? $company->trial_ends_at)->format('Y-m-d') ?? '—' }}</span>
                <span>{{ ___('Subscription ends at') }}: {{ optional($currentSubscription?->ends_at ?? $company->subscription_ends_at)->format('Y-m-d') ?? '—' }}</span>
            </div>
        </div>
    </div>

    <div class="plan-grid">
        @forelse($plans as $plan)
            @php
                $isCurrent = $plan->code === $currentPlanCode;
                $features = is_array($plan->features) ? $plan->features : [];
                $enabledFeatures = array_filter($features, fn($v) => (bool) $v);
                $limits = is_array($plan->limits) ? $plan->limits : [];
                $hasFeatures = count($enabledFeatures) > 0;
            @endphp
            <div class="plan-card {{ $isCurrent ? 'active' : '' }}">
                <div class="plan-head">
                    <div>
                        <div class="plan-name">{{ $plan->name }}</div>
                        <div class="muted small plan-code">{{ strtoupper($plan->code) }}</div>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <span class="pill">{{ ___('Trial days') }}: {{ $plan->trial_days ?? 0 }}</span>
                        @if($isCurrent)
                            <span class="plan-pill" style="padding:6px 10px;">{!! $crownIcon !!} <span>{{ ___('Current plan') }}</span></span>
                        @endif
                    </div>
                </div>

                <div class="price-row">
                    <div>
                        <div class="muted small">{{ ___('Monthly price') }}</div>
                        <div style="font-weight:800;">{{ number_format((float)$plan->price_monthly, 2) }} {{ $plan->currency }}</div>
                    </div>
                    <div>
                        <div class="muted small">{{ ___('Yearly price') }}</div>
                        <div style="font-weight:800;">{{ number_format((float)$plan->price_yearly, 2) }} {{ $plan->currency }}</div>
                    </div>
                </div>

                @if($gatewayEnabled ?? false)
                    <div style="display:flex; gap:8px; margin-top:auto;">
                        <form method="POST" action="{{ route('company.plans.checkout') }}" style="flex:1;">
                            @csrf
                            <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                            <input type="hidden" name="billing_period" value="monthly">
                            <button class="btn primary" type="submit" style="width:100%;" @disabled($isCurrent || (float)$plan->price_monthly <= 0)>{{ ___('Buy monthly') }}</button>
                        </form>
                        <form method="POST" action="{{ route('company.plans.checkout') }}" style="flex:1;">
                            @csrf
                            <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                            <input type="hidden" name="billing_period" value="yearly">
                            <button class="btn" type="submit" style="width:100%;" @disabled($isCurrent || (float)$plan->price_yearly <= 0)>{{ ___('Buy yearly') }}</button>
                        </form>
                    </div>
                @else
                    <div class="muted small" style="margin-top:10px;">{{ ___('Payment gateway is not configured.') }}</div>
                @endif

                <div>
                    <div class="section-title">{{ ___('Features') }}</div>
                    @if(!$hasFeatures)
                        <div class="muted small">{{ ___('All modules are available on this plan.') }}</div>
                    @else
                        <ul class="feature-list">
                            @foreach($enabledFeatures as $key => $enabled)
                                <li>
                                    <div class="label">
                                        <span class="dot"></span>
                                        <span>{{ \Illuminate\Support\Str::headline((string) $key) }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </div>

                <div>
                    <div class="section-title">{{ ___('Limits') }}</div>
                    @if(count($limits) === 0)
                        <div class="muted small">{{ ___('No limits defined (treated as unlimited).') }}</div>
                    @else
                        <ul class="feature-list">
                            @foreach($limits as $key => $value)
                                <li>
                                    <div class="label">
                                        <span class="dot"></span>
                                        <span>{{ \Illuminate\Support\Str::headline((string) $key) }}</span>
                                    </div>
                                    <span class="muted small">{{ $value === null ? ___('Unlimited') : $value }}</span>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </div>
            </div>
        @empty
            <div class="card">
                <div class="h">{{ ___('No plan available.') }}</div>
                <div class="muted small">{{ ___('Please ask the superadmin to create at least one plan.') }}</div>
            </div>
        @endforelse
    </div>
</div>
@endsection
