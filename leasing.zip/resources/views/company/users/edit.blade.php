@extends('layouts.app')

@section('title', ___('Edit Employee'))
@section('page_title', ___('Edit Employee'))
@section('page_subtitle')
    {{ $user->first_name ?? '' }} {{ $user->last_name ?? '' }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.users.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
@if($errors->any())
        <div class="banner error">
            <span class="badge bad">{{ ___('Error') }}</span>
            <ul style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $e) <li>{{ $e }}</li> @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.users.update', $user) }}">
            @csrf
            @method('PUT')

            <div class="grid">
                <div class="col6 field">
                    <label class="muted">{{ ___('First name') }}</label>
                    <input class="input" name="first_name" value="{{ old('first_name', $user->first_name) }}" required>
                </div>

                <div class="col6 field">
                    <label class="muted">{{ ___('Last name') }}</label>
                    <input class="input" name="last_name" value="{{ old('last_name', $user->last_name) }}" required>
                </div>

                <div class="col6 field">
                    <label class="muted">{{ ___('Phone') }}</label>
                    <input class="input" name="phone" value="{{ old('phone', $user->phone) }}" placeholder="+994501234567" required>
                    <div class="help">{{ ___('Format: +994XXXXXXXXX') }}</div>
                </div>

                <div class="col6 field">
                    <label class="muted">{{ ___('Email (optional)') }}</label>
                    <input class="input" name="email" value="{{ old('email', $user->email) }}">
                </div>

                <div class="col6 field">
                    <label class="muted">{{ ___('Role (optional, free text)') }}</label>
                    <input class="input" name="role" value="{{ old('role', $user->role) }}" placeholder="{{ ___('e.g. sales lead') }}">
                </div>

                <div class="col6 field" style="display:flex; align-items:end;">
                    <label class="check">
                        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $user->is_active))>
                        <span>{{ ___('Active') }}</span>
                    </label>
                </div>

                <div class="col6 field">
                    <label class="muted">{{ ___('New password (leave empty = no change)') }}</label>
                    <input class="input" type="password" name="password">
                </div>

                <div class="col6 field">
                    <label class="muted">{{ ___('Confirm password') }}</label>
                    <input class="input" type="password" name="password_confirmation">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="grid">
                <div class="col4 field">
                    <label class="muted">{{ ___('Base salary') }}</label>
                    <input class="input" type="number" step="0.01" min="0" name="base_salary" value="{{ old('base_salary', $user->base_salary) }}" placeholder="0">
                </div>
                <div class="col4 field">
                    <label class="muted">{{ ___('Salary currency') }}</label>
                    <input class="input" name="salary_currency" value="{{ old('salary_currency', $user->salary_currency ?? 'AZN') }}">
                </div>
                <div class="col4 field">
                    <label class="muted">{{ ___('Payout period') }}</label>
                    @php $pp = old('payout_period', $user->payout_period); @endphp
                    <select class="input" name="payout_period">
                        <option value="">{{ ___('Select') }}</option>
                        <option value="monthly" @selected($pp==='monthly')>{{ ___('Monthly') }}</option>
                        <option value="weekly" @selected($pp==='weekly')>{{ ___('Weekly') }}</option>
                        <option value="per_sale" @selected($pp==='per_sale')>{{ ___('Per sale') }}</option>
                    </select>
                </div>
            </div>

            <div class="grid">
                <div class="col6 field">
                    <label class="muted">{{ ___('Commission type') }}</label>
                    @php $ct = old('commission_type', $user->commission_type); @endphp
                    <select class="input" name="commission_type">
                        <option value="">{{ ___('None') }}</option>
                        <option value="percent_per_vehicle" @selected($ct==='percent_per_vehicle')>{{ ___('Percent per vehicle') }}</option>
                        <option value="fixed_per_vehicle" @selected($ct==='fixed_per_vehicle')>{{ ___('Fixed per vehicle') }}</option>
                    </select>
                </div>
                <div class="col6 field">
                    <label class="muted">{{ ___('Commission rate') }}</label>
                    <input class="input" type="number" step="0.01" min="0" name="commission_rate" value="{{ old('commission_rate', $user->commission_rate) }}" placeholder="0">
                    <div class="help">{{ ___('Percent or fixed amount based on type') }}</div>
                </div>
            </div>

            <div class="field">
                <label class="muted">{{ ___('Salary notes') }}</label>
                <textarea class="input" name="salary_notes" rows="2">{{ old('salary_notes', $user->salary_notes) }}</textarea>
            </div>

            <div class="field">
                <label class="muted">{{ ___('Reset password (temporary)') }}</label>
                <form method="POST" action="{{ route('company.users.reset_password', $user) }}">
                    @csrf
                    <button class="btn warn" type="submit">{{ ___('Generate temp password') }}</button>
                </form>
                @if(session('status'))
                    <div class="banner success" style="margin-top:8px;">{{ session('status') }}</div>
                @endif
            </div>

            <hr class="hr">

            <div class="h" style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
                <span>{{ ___('Permissions') }}</span>
                <button type="button" class="btn outline" onclick="toggleAll()">{{ ___('Select all / deselect all') }}</button>
            </div>

            @php $selectedPerms = old('permissions', $user->permissions ?? []); @endphp

            @foreach($permissionGroups as $groupTitle => $perms)
                @php $hash = md5($groupTitle); @endphp
                <div class="permGroup">
                    <div class="permHead">
                        <strong>{{ $groupTitle }}</strong>
                        <button type="button" class="btn outline" onclick="toggleGroup('{{ $hash }}')">{{ ___('Select group / deselect') }}</button>
                    </div>
                    <div class="permBody">
                        <div class="permGrid">
                            @foreach($perms as $permKey => $permLabel)
                                <label class="permItem">
                                    <input class="perm perm-{{ $hash }}" type="checkbox" name="permissions[]" value="{{ $permKey }}"
                                           @checked(in_array($permKey, $selectedPerms, true))>
                                    <span>
                                        <div style="font-weight:700;">{{ $permLabel }}</div>
                                        <div class="help">{{ $permKey }}</div>
                                    </span>
                                </label>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endforeach

            <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

</div>

<script>
function toggleGroup(hash){
    const items = document.querySelectorAll('.perm-' + hash);
    if(!items.length) return;
    let allChecked = true;
    items.forEach(i => { if(!i.checked) allChecked = false; });
    items.forEach(i => { i.checked = !allChecked; });
}
function toggleAll(){
    const items = document.querySelectorAll('.perm');
    if(!items.length) return;
    let allChecked = true;
    items.forEach(i => { if(!i.checked) allChecked = false; });
    items.forEach(i => { i.checked = !allChecked; });
}
</script>
@endsection
