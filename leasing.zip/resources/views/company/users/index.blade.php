@extends('layouts.app')

@section('title', ___('Employees'))
@section('page_title', ___('Employees'))
@section('page_subtitle', ___('Owner and staff list'))
@section('page_actions')
    <a class="btn primary action-right" href="{{ route('company.users.create') }}">{{ ___('+ Create employee') }}</a>
    <a class="btn ghost" href="{{ url()->previous() }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('success'))
        <div class="banner">
            <span class="badge ok">{{ ___('OK') }}</span>
            <span style="margin-left:10px;">{{ session('success') }}</span>
        </div>
    @endif

    @if(session('error'))
        <div class="banner error">
            <span class="badge bad">{{ ___('Error') }}</span>
            <span style="margin-left:10px;">{{ session('error') }}</span>
        </div>
    @endif

    <div class="card">
        <div class="h">{{ ___('List') }}</div>

        <table class="table">
            <thead>
            <tr>
                <th style="width:70px;">#</th>
                <th>{{ ___('Full name') }}</th>
                <th>{{ ___('Phone') }}</th>
                <th>{{ ___('Email') }}</th>
                <th>{{ ___('Role') }}</th>
                <th style="width:90px;">{{ ___('Active') }}</th>
                <th style="width:320px; text-align:right;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($users as $u)
                <tr>
                    <td>{{ $u->id }}</td>
                    <td>{{ $u->full_name }}</td>
                    <td>{{ $u->phone }}</td>
                    <td>{{ $u->email }}</td>
                    <td><span class="badge">{{ $u->role }}</span></td>
                    <td>
                        @if($u->is_active)
                            <span class="badge ok">{{ ___('yes') }}</span>
                        @else
                            <span class="badge bad">{{ ___('no') }}</span>
                        @endif
                    </td>
                    <td>
                        <div class="actions" style="justify-content:flex-end; gap:6px; flex-wrap:wrap;">
                            @if(!($u->is_owner || $u->role === 'owner'))
                                <form method="POST" action="{{ route('impersonate.start', $u) }}">
                                    @csrf
                                    <button class="btn ghost" type="submit">{{ ___('Login as user') }}</button>
                                </form>
                                <a class="btn outline" href="{{ route('company.users.edit', $u) }}">{{ ___('Edit') }}</a>
                                <form method="POST" action="{{ route('company.users.destroy', $u) }}"
                                      onsubmit="return confirm('{{ ___('Are you sure you want to delete?') }}')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                                </form>
                            @else
                                <span class="muted">-</span>
                            @endif
                        </div>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">{{ ___('No one found.') }}</td></tr>
            @endforelse
            </tbody>
        </table>

        @if($users->hasPages())
            <div class="pager">
                <div class="muted">{{ ___('Page') }} {{ $users->currentPage() }} / {{ $users->lastPage() }}</div>
                <div style="display:flex; gap:10px;">
                    <a class="pill {{ $users->onFirstPage() ? 'disabled' : '' }}" href="{{ $users->previousPageUrl() ?? '#' }}">{{ ___('Previous') }}</a>
                    <a class="pill {{ $users->hasMorePages() ? '' : 'disabled' }}" href="{{ $users->nextPageUrl() ?? '#' }}">{{ ___('Next') }}</a>
                </div>
            </div>
        @endif
    </div>
@endsection
