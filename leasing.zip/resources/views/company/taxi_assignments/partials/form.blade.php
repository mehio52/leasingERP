@php
    $assignment = $assignment ?? null;
    $issues = old('issues_k') ? array_combine(old('issues_k', []), old('issues_v', [])) : ($assignment->issues ?? []);
    $issueKeys = array_keys($issues);
    $issueVals = array_values($issues);
    $issueRows = max(3, count($issueKeys));
    $attrs = old('attrs_k') ? array_combine(old('attrs_k', []), old('attrs_v', [])) : ($assignment->attributes ?? []);
    $attrKeys = array_keys($attrs);
    $attrVals = array_values($attrs);
    $attrRows = max(3, count($attrKeys));
    $addonMap = $assignment->addons ?? [];
    $oldIds = old('addons_id');
    if (is_array($oldIds)) {
        $addonMap = [];
        $oldQtys = old('addons_qty', []);
        foreach ($oldIds as $oid) {
            $oid = (int) $oid;
            if ($oid <= 0) continue;
            $addonMap[$oid] = (int) ($oldQtys[$oid] ?? 1);
        }
    }
@endphp

<div class="row">
    <div class="field">
        <label>{{ ___('Vehicle') }}</label>
        <select name="vehicle_id" required>
            <option value="">-</option>
            @foreach($vehicles as $v)
                <option value="{{ $v->id }}" @selected(old('vehicle_id', $assignment->vehicle_id ?? '') == $v->id)>{{ $v->display_name ?? ($v->brand . ' ' . $v->model) }} ({{ $v->plate_number ?? '-' }})</option>
            @endforeach
        </select>
    </div>
    <div class="field">
        <label>{{ ___('Driver') }}</label>
        <select name="driver_id" required>
            <option value="">-</option>
            @foreach($drivers as $d)
                <option value="{{ $d->id }}" @selected(old('driver_id', $assignment->driver_id ?? '') == $d->id)>{{ $d->first_name }} {{ $d->last_name }}</option>
            @endforeach
        </select>
    </div>
    <div class="field">
        <label>{{ ___('Assigned at') }}</label>
        <input type="date" name="assigned_at" value="{{ old('assigned_at', optional($assignment->assigned_at)->format('Y-m-d')) }}">
    </div>
    <div class="field">
        <label>{{ ___('Returned at') }}</label>
        <input type="date" name="returned_at" value="{{ old('returned_at', optional($assignment->returned_at)->format('Y-m-d')) }}">
    </div>
</div>

<div class="field">
    <label>{{ ___('Notes') }}</label>
    <textarea name="notes" rows="2">{{ old('notes', $assignment->notes ?? '') }}</textarea>
</div>

<div class="card" style="margin-top:12px;">
    <div class="h">{{ ___('Issues (key/value)') }}</div>
    @for($i = 0; $i < $issueRows; $i++)
        <div class="row" style="margin-bottom:6px;">
            <div class="field">
                <input name="issues_k[]" placeholder="key" value="{{ old('issues_k.' . $i, $issueKeys[$i] ?? '') }}">
            </div>
            <div class="field">
                <input name="issues_v[]" placeholder="value" value="{{ old('issues_v.' . $i, $issueVals[$i] ?? '') }}">
            </div>
        </div>
    @endfor
</div>

<div class="card" style="margin-top:12px;">
    <div class="h">{{ ___('Taxi attributes for this vehicle (key/value)') }}</div>
    @for($i = 0; $i < $attrRows; $i++)
        <div class="row" style="margin-bottom:6px;">
            <div class="field">
                <input name="attrs_k[]" placeholder="key" value="{{ old('attrs_k.' . $i, $attrKeys[$i] ?? '') }}">
            </div>
            <div class="field">
                <input name="attrs_v[]" placeholder="value" value="{{ old('attrs_v.' . $i, $attrVals[$i] ?? '') }}">
            </div>
        </div>
    @endfor
</div>

<div class="card" style="margin-top:12px;">
    <div class="h">{{ ___('Add-ons') }}</div>
    @forelse($addons as $a)
        <div class="row" style="align-items:center;">
            <div class="field" style="display:flex; align-items:center; gap:8px;">
                <input type="checkbox" name="addons_id[]" value="{{ $a->id }}" @checked(array_key_exists($a->id, $addonMap))>
                <div>{{ $a->name }} ({{ $a->price }} {{ $a->billing_type }})</div>
            </div>
            <div class="field" style="max-width:120px;">
                <input type="number" min="1" name="addons_qty[{{ $a->id }}]" value="{{ old('addons_qty.' . $a->id, $addonMap[$a->id] ?? 1) }}">
            </div>
        </div>
    @empty
        <div class="muted">{{ ___('No add-ons available.') }}</div>
    @endforelse
</div>
