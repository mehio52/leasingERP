@extends('layouts.app')
@section('title', ___('Edit assignment'))
@section('page_title', ___('Edit assignment'))
@section('page_subtitle', ___('Vehicle to driver assignment'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.taxi_assignments.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_assignments.update', $assignment) }}">
            @csrf
            @method('PUT')
            @include('company.taxi_assignments.partials.form', ['assignment' => $assignment])
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save changes') }}</button>
            </div>
        </form>
    </div>
@endsection
