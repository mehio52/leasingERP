@extends('layouts.app')
@section('title', ___('Taxi assignments'))
@section('page_title', ___('Taxi assignments'))
@section('page_subtitle', ___('Vehicle to driver assignments'))
@section('page_actions')
    <a class="btn" href="{{ route('company.taxi_assignments.create') }}">{{ ___('New assignment') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Driver') }}</th>
                <th>{{ ___('Assigned') }}</th>
                <th>{{ ___('Returned') }}</th>
                <th style="width:180px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($assignments as $a)
                <tr>
                    <td>{{ $a->id }}</td>
                    <td>{{ $a->vehicle?->display_name ?? $a->vehicle?->plate_number ?? '-' }}</td>
                    <td>{{ $a->driver?->first_name }} {{ $a->driver?->last_name }}</td>
                    <td>{{ $a->assigned_at?->format('Y-m-d') ?? '-' }}</td>
                    <td>{{ $a->returned_at?->format('Y-m-d') ?? '-' }}</td>
                    <td style="display:flex; gap:8px;">
                        <a class="btn" href="{{ route('company.taxi_assignments.edit', $a) }}">{{ ___('Edit') }}</a>
                        <form method="POST" action="{{ route('company.taxi_assignments.destroy', $a) }}" onsubmit="return confirm(@json(___('Delete this assignment?')));">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">{{ ___('No assignments yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:12px;">{{ $assignments->links() }}</div>
    </div>
@endsection
