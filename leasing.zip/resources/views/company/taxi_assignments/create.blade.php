@extends('layouts.app')
@section('title', ___('New assignment'))
@section('page_title', ___('New assignment'))
@section('page_subtitle', ___('Assign vehicle to driver'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.taxi_assignments.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_assignments.store') }}">
            @csrf
            @include('company.taxi_assignments.partials.form', ['assignment' => null])
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Create assignment') }}</button>
            </div>
        </form>
    </div>
@endsection
