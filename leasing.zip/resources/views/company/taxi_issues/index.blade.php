@extends('layouts.app')
@section('title', ___('Vehicle issues'))
@section('page_title', ___('Vehicle issues'))
@section('page_subtitle', ___('Taxi vehicle problems log'))
@section('page_actions')
    <a class="btn" href="{{ route('company.taxi_issues.create') }}">{{ ___('Report issue') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Driver') }}</th>
                <th>{{ ___('Title') }}</th>
                <th>{{ ___('Severity') }}</th>
                <th>{{ ___('Status') }}</th>
                <th style="width:180px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($issues as $i)
                <tr>
                    <td>{{ $i->id }}</td>
                    <td>{{ $i->vehicle?->display_name ?? $i->vehicle?->plate_number ?? '-' }}</td>
                    <td>{{ $i->driver?->first_name }} {{ $i->driver?->last_name }}</td>
                    <td>{{ $i->title }}</td>
                    <td>{{ $i->severity ?? '-' }}</td>
                    <td>{{ $i->status ?? '-' }}</td>
                    <td style="display:flex; gap:8px;">
                        <a class="btn" href="{{ route('company.taxi_issues.edit', $i) }}">{{ ___('Edit') }}</a>
                        <form method="POST" action="{{ route('company.taxi_issues.destroy', $i) }}" onsubmit="return confirm(@json(___('Delete this issue?')));">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">{{ ___('No issues yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:12px;">{{ $issues->links() }}</div>
    </div>
@endsection
