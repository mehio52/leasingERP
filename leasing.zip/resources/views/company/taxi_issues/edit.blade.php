@extends('layouts.app')
@section('title', ___('Edit issue'))
@section('page_title', ___('Edit issue'))
@section('page_subtitle', ___('Taxi vehicle issue'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.taxi_issues.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.taxi_issues.update', $issue) }}">
            @csrf
            @method('PUT')
            <div class="row">
                <div class="field">
                    <label>{{ ___('Vehicle') }}</label>
                    <select name="vehicle_id" required>
                        @foreach($vehicles as $v)
                            <option value="{{ $v->id }}" @selected(old('vehicle_id', $issue->vehicle_id) == $v->id)>{{ $v->display_name ?? ($v->brand . ' ' . $v->model) }} ({{ $v->plate_number ?? '-' }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Driver') }}</label>
                    <select name="driver_id">
                        <option value="">-</option>
                        @foreach($drivers as $d)
                            <option value="{{ $d->id }}" @selected(old('driver_id', $issue->driver_id) == $d->id)>{{ $d->first_name }} {{ $d->last_name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Reported at') }}</label>
                    <input type="date" name="reported_at" value="{{ old('reported_at', optional($issue->reported_at)->format('Y-m-d')) }}">
                </div>
            </div>
            <div class="row">
                <div class="field" style="flex:2;">
                    <label>{{ ___('Title') }}</label>
                    <input name="title" value="{{ old('title', $issue->title) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Severity') }}</label>
                    <select name="severity">
                        <option value="low" @selected(old('severity', $issue->severity) === 'low')>{{ ___('Low') }}</option>
                        <option value="normal" @selected(old('severity', $issue->severity ?? 'normal') === 'normal')>{{ ___('Normal') }}</option>
                        <option value="high" @selected(old('severity', $issue->severity) === 'high')>{{ ___('High') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Status') }}</label>
                    <select name="status">
                        <option value="open" @selected(old('status', $issue->status ?? 'open') === 'open')>{{ ___('Open') }}</option>
                        <option value="in_progress" @selected(old('status', $issue->status) === 'in_progress')>{{ ___('In progress') }}</option>
                        <option value="closed" @selected(old('status', $issue->status) === 'closed')>{{ ___('Closed') }}</option>
                    </select>
                </div>
            </div>
            <div class="field">
                <label>{{ ___('Details') }}</label>
                <textarea name="details" rows="3">{{ old('details', $issue->details) }}</textarea>
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save changes') }}</button>
            </div>
        </form>
    </div>
@endsection
