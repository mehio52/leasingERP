@extends('layouts.app')

@section('title', ___('Document Templates'))

@section('content')
<div class="page-block">
    <h1>{{ ___('Document Automation Templates') }}</h1>

    @if(session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
    @endif

    <section class="card">
        <h2>{{ ___('Upload new template') }}</h2>
        <form action="{{ route('company.document_templates.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="field">
                    <label>{{ ___('Name') }}</label>
                    <input name="name" value="{{ old('name') }}" required>
                </div>
            </div>
            <p class="hint small">
                {{ ___('Keywords are managed automatically; you only need to pick the contract type and upload the document. The table below lists all available placeholders that the system can fill.') }}
            </p>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Description') }}</label>
                    <textarea name="description">{{ old('description') }}</textarea>
                </div>
                <div class="field">
                    <label>{{ ___('File (txt, docx, pdf)') }}</label>
                    <input type="file" name="file" required>
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Contract type') }}</label>
                    <select name="contract_type" required>
                        <option value="two" @selected(old('contract_type','two')==='two')>{{ ___('2-sided (company & buyer)') }}</option>
                        <option value="three" @selected(old('contract_type')==='three')>{{ ___('3-sided (seller included)') }}</option>
                    </select>
                </div>
            </div>
            <button class="btn primary" type="submit">{{ ___('Upload template') }}</button>
        </form>
    </section>

    <section class="card mt-4">
        <h2>{{ ___('Available keyword groups') }}</h2>
        <p class="muted">{{ ___('Use these keywords inside your document template to pull data automatically. Missing metadata can be provided through the BHPH account form.') }}</p>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{{ ___('Group') }}</th>
                        <th>{{ ___('Keywords') }}</th>
                        <th>{{ ___('Source / notes') }}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{{ ___('Müşteri (customer_*)') }}</td>
                        <td>
                            customer_name,
                            customer_address,
                            customer_id_card_number,
                            customer_fin,
                            customer_date_of_issue_of_identity_card,
                            customer_name_of_the_authority_issuing_the_identity_card,
                            customer_bank_details
                        </td>
                        <td>{{ ___('Customer record; missing address/bank data can be filled via the document metadata modal.') }}</td>
                    </tr>
                    <tr>
                        <td>{{ ___('Şirket (company_*)') }}</td>
                        <td>
                            company_name,
                            company_address,
                            company_bank_details
                        </td>
                        <td>{{ ___('Company model tied to the account.') }}</td>
                    </tr>
                    <tr>
                        <td>{{ ___('Satıcı / 3. taraf') }}</td>
                        <td>
                            seller_fullname,
                            seller_id_card_number,
                            seller_fin,
                            seller_date_of_issue_of_identity_card,
                            seller_name_of_the_authority_issuing_the_identity_card,
                            3rd_party_seller_fullname
                        </td>
                        <td>{{ ___('Contract data plus document metadata (seller info/3rd party).') }}</td>
                    </tr>
                    <tr>
                        <td>{{ ___('Kontrat') }}</td>
                        <td>
                            contract_date,
                            contract_id
                        </td>
                        <td>{{ ___('Contract model fields.') }}</td>
                    </tr>
                    <tr>
                        <td>{{ ___('Araç (vehicle_*)') }}</td>
                        <td>
                            vehicle_price_integer,
                            vehicle_price_text,
                            vehicle_fullname,
                            vehicle_year_of_release,
                            vehicle_specifications,
                            vehicle_type,
                            vehicle_color
                        </td>
                        <td>{{ ___('Vehicle model + specs JSON from the account.') }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

    <section class="card mt-4">
        <h2>{{ ___('Available templates') }}</h2>

        @if($templates->isEmpty())
            <div class="muted">{{ ___('No templates uploaded.') }}</div>
        @else
            <table class="table">
                <thead>
                    <tr>
                        <th>{{ ___('Name') }}</th>
                <th>{{ ___('Keywords') }}</th>
                <th>{{ ___('Uploaded at') }}</th>
                        <th>{{ ___('Contract type') }}</th>
                <th>{{ ___('Actions') }}</th>
            </tr>
                </thead>
                <tbody>
                    @foreach($templates as $template)
                        <tr>
                            <td>{{ $template->name }}</td>
                            <td>{{ implode(', ', $template->keywords ?? []) }}</td>
                            <td>{{ $template->created_at->toDateTimeString() }}</td>
                            <td>
                                {{ $template->contract_type === 'three'
                                    ? ___('3-sided (seller included)')
                                    : ___('2-sided (company & buyer)') }}
                            </td>
                            <td>
                                <div class="row multi">
                                    <select id="doc-account-{{ $template->id }}">
                                        <option value="">{{ ___('Select account') }}</option>
                                        @foreach($accounts as $account)
                                            <option value="{{ $account->id }}">
                                                #{{ $account->id }} — {{ $account->customer?->full_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <button type="button"
                                        class="btn primary doc-preview-btn"
                                        data-template-id="{{ $template->id }}"
                                        data-preview-base="{{ route('company.document_templates.preview', [$template, '__ACCOUNT__']) }}">
                                        {{ ___('Preview') }}
                                    </button>
                                </div>
                                <form method="POST" action="{{ route('company.document_templates.destroy', $template) }}" style="margin-top:8px;">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn ghost small" type="submit" onclick="return confirm('{{ ___('Are you sure you want to delete this template?') }}');">
                                        {{ ___('Delete template') }}
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </section>
</div>

@push('scripts')
<script>
    (function () {
        const selectAccountMessage = @json(___('Select an account first.'));
        document.querySelectorAll('.doc-preview-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const templateId = btn.dataset.templateId;
                const select = document.getElementById('doc-account-' + templateId);
                if (!select || !select.value) {
                    alert(selectAccountMessage);
                    return;
                }
                const url = btn.dataset.previewBase.replace('__ACCOUNT__', select.value);
                window.open(url, '_blank');
            });
        });
    })();
</script>
@endpush
@endsection
