@extends('layouts.app')

@section('title', ___('Document preview'))

@section('content')
<div class="page-block">
    <h1>{{ ___('Preview:') }} {{ $template->name }}</h1>
    <p>{{ ___('Account') }} #{{ $account->id }} — {{ $account->customer?->full_name }}</p>

    @if(!empty($missing))
        <div class="alert alert-warning">
            {{ ___('Missing keyword values:') }} {{ implode(', ', $missing) }}
        </div>
    @endif

    <section class="card">
        <h2>{{ ___('Rendered content') }}</h2>
        <pre style="white-space: pre-wrap;">{{ $content }}</pre>
    </section>
</div>
@endsection
