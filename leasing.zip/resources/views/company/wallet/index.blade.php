@extends('layouts.app')

@section('title', ___('Wallet'))
@section('page_title', ___('Wallet'))
@section('page_subtitle', ___('Customer card payments'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('dashboard') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
<div class="wrap">
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif
    @if(request('card') === 'success')
        <div class="banner success">{{ ___('Card registration completed.') }}</div>
    @elseif(request('card') === 'error')
        <div class="banner error">{{ ___('Card registration failed.') }}</div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="h">{{ ___('Balance summary') }}</div>
        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px; margin-top:10px;">
            <div class="card" style="padding:12px;">
                <div class="muted small">{{ ___('Total received (card)') }}</div>
                <div style="font-weight:800;">{{ number_format($totalReceived, 2) }} AZN</div>
            </div>
            <div class="card" style="padding:12px;">
                <div class="muted small">{{ ___('Paid out') }}</div>
                <div style="font-weight:800;">{{ number_format($paidOut, 2) }} AZN</div>
            </div>
            <div class="card" style="padding:12px;">
                <div class="muted small">{{ ___('Pending payouts') }}</div>
                <div style="font-weight:800;">{{ number_format($pendingOut, 2) }} AZN</div>
            </div>
            <div class="card" style="padding:12px;">
                <div class="muted small">{{ ___('Available') }}</div>
                <div style="font-weight:800;">{{ number_format($available, 2) }} AZN</div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="h">{{ ___('Payout card') }}</div>
        @if(!$epointEnabled)
            <div class="muted small">{{ ___('Payment gateway is not configured.') }}</div>
        @elseif($payoutCard)
            <div class="muted small" style="margin-top:8px;">
                {{ ___('Active card') }}: <strong>{{ $payoutCard->card_mask ?? '****' }}</strong>
            </div>
        @else
            <div class="muted small" style="margin-top:8px;">{{ ___('No card registered yet.') }}</div>
            <form method="POST" action="{{ route('company.wallet.card') }}" style="margin-top:10px;">
                @csrf
                <button class="btn primary" type="submit">{{ ___('Register payout card') }}</button>
            </form>
        @endif
    </div>

    <div class="card">
        <div class="h">{{ ___('Request payout') }}</div>
        @if(!$epointEnabled)
            <div class="muted small">{{ ___('Payment gateway is not configured.') }}</div>
        @elseif(!$payoutCard)
            <div class="muted small">{{ ___('Register a payout card first.') }}</div>
        @else
            <form method="POST" action="{{ route('company.wallet.payout') }}" class="grid" style="margin-top:10px;">
                @csrf
                <div class="field">
                    <label>{{ ___('Amount (AZN)') }}</label>
                    <input class="input" type="number" step="0.01" min="1" max="{{ number_format($available,2,'.','') }}" name="amount" value="{{ old('amount', number_format($available,2,'.','')) }}">
                    <div class="muted small">{{ ___('Available') }}: {{ number_format($available, 2) }} AZN</div>
                </div>
                <div style="display:flex; justify-content:flex-end;">
                    <button class="btn primary" type="submit">{{ ___('Request payout') }}</button>
                </div>
            </form>
        @endif
    </div>

    <div class="card">
        <div class="h">{{ ___('Payout history') }}</div>
        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th>{{ ___('Amount') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Order ID') }}</th>
                <th>{{ ___('Created') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($payouts as $payout)
                <tr>
                    <td>{{ $payout->id }}</td>
                    <td>{{ number_format((float) $payout->amount, 2) }} {{ $payout->currency ?? 'AZN' }}</td>
                    <td>
                        @if($payout->status === 'success')
                            <span class="badge ok">{{ ___('Success') }}</span>
                        @elseif($payout->status === 'failed')
                            <span class="badge bad">{{ ___('Failed') }}</span>
                        @else
                            <span class="badge">{{ ___('Pending') }}</span>
                        @endif
                    </td>
                    <td style="max-width:220px; word-break:break-all;">{{ $payout->order_id }}</td>
                    <td>{{ optional($payout->created_at)->format('Y-m-d H:i') }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="muted">{{ ___('No information') }}</td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
