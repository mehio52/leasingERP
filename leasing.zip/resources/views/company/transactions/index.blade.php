@extends('layouts.app')

@section('title', ___('Transactions'))
@section('page_title', ___('Transactions'))
@section('page_subtitle', ___('Customer payments only'))

@section('content')
<div class="wrap">
    <div class="card">
        <form method="GET" action="{{ route('company.transactions.index') }}" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px; align-items:end;">
            <div>
                <label class="muted small">{{ ___('Search') }}</label>
                <input class="input" type="text" name="q" value="{{ $q }}" placeholder="{{ ___('Order ID / transaction / message') }}">
            </div>
            <div>
                <label class="muted small">{{ ___('Status') }}</label>
                <select class="input" name="status">
                    <option value="">{{ ___('All') }}</option>
                    <option value="pending" @selected($status === 'pending')>{{ ___('Pending') }}</option>
                    <option value="success" @selected($status === 'success')>{{ ___('Success') }}</option>
                    <option value="failed" @selected($status === 'failed')>{{ ___('Failed') }}</option>
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <button class="btn ghost" type="button" onclick="window.location='{{ route('company.transactions.index') }}'">{{ ___('Reset') }}</button>
                <button class="btn primary" type="submit">{{ ___('Apply') }}</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="h">{{ ___('Payment logs') }}</div>
        <table class="table">
            <thead>
                <tr>
                    <th>{{ ___('Date') }}</th>
                    <th>{{ ___('Customer') }}</th>
                    <th>{{ ___('Contract') }}</th>
                    <th>{{ ___('Gateway') }}</th>
                    <th>{{ ___('Amount') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Order ID') }}</th>
                    <th>{{ ___('Message') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($transactions as $tx)
                    @php
                        $meta = is_array($tx->meta) ? $tx->meta : [];
                        $accountId = $meta['bhph_account_id'] ?? null;
                        $account = $accountId ? ($accounts[$accountId] ?? null) : null;
                        $customerName = $account?->customer?->full_name ?? '--';
                        $contractNo = $account?->contract?->contract_no ?? ($meta['contract_no'] ?? '--');
                        $paidAt = $tx->processed_at ?? $tx->created_at;
                    @endphp
                    <tr>
                        <td>{{ optional($paidAt)->format('Y-m-d H:i') }}</td>
                        <td>{{ $customerName }}</td>
                        <td>{{ $contractNo }}</td>
                        <td>{{ $tx->gateway ?? 'epoint' }}</td>
                        <td>{{ number_format((float) $tx->amount, 2) }} {{ $tx->currency ?? 'AZN' }}</td>
                        <td>
                            @if($tx->status === 'success')
                                <span class="badge ok">{{ ___('Success') }}</span>
                            @elseif($tx->status === 'failed')
                                <span class="badge bad">{{ ___('Failed') }}</span>
                            @else
                                <span class="badge">{{ ___('Pending') }}</span>
                            @endif
                        </td>
                        <td>
                            <div style="max-width:200px; word-break:break-all;">{{ $tx->order_id }}</div>
                        </td>
                        <td>
                            <div class="muted small" style="max-width:220px; word-break:break-all;">
                                {{ $tx->message ?? '--' }}
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="muted">{{ ___('No information') }}</td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        @if($transactions->hasPages())
            <div class="pager">
                <div class="muted">{{ ___('Page') }} {{ $transactions->currentPage() }} / {{ $transactions->lastPage() }}</div>
                <div style="display:flex; gap:10px;">
                    <a class="pill {{ $transactions->onFirstPage() ? 'disabled' : '' }}" href="{{ $transactions->previousPageUrl() ?? '#' }}">{{ ___('Previous') }}</a>
                    <a class="pill {{ $transactions->hasMorePages() ? '' : 'disabled' }}" href="{{ $transactions->nextPageUrl() ?? '#' }}">{{ ___('Next') }}</a>
                </div>
            </div>
        @endif
    </div>
</div>
@endsection
