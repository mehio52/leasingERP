@extends('layouts.guest')

@section('title', ___('Blog'))

@push('styles')
<style>
    :root {
        --primary: #2563eb;
        --primary-dark: #1e40af;
        --text: #0f172a;
        --text-light: #475569;
        --text-lighter: #94a3b8;
        --bg: #f8fafc;
        --bg-light: #ffffff;
        --border: #e2e8f0;
    }

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        color: var(--text);
        background: var(--bg);
        line-height: 1.6;
    }

    .wrap {
        max-width: 1100px;
        margin: 0 auto;
        padding: 0 24px 48px;
    }

    .top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 0;
        border-bottom: 1px solid var(--border);
    }

    .brand {
        font-size: 20px;
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .nav {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }

    .nav-link {
        color: var(--text);
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 6px;
    }

    .nav-link:hover {
        color: var(--primary);
        background: rgba(37, 99, 235, 0.08);
    }

    .btn {
        padding: 8px 16px;
        border: 1px solid var(--border);
        background: transparent;
        color: var(--text);
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        font-size: 14px;
        text-decoration: none;
    }

    .btn.primary {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
    }

    .btn.primary:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
    }

    .hero {
        padding: 40px 0 20px;
        text-align: center;
    }

    .hero h1 {
        margin: 0 0 10px;
        font-size: 36px;
    }

    .hero p {
        margin: 0;
        color: var(--text-light);
    }

    .blog-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 24px;
        margin-top: 28px;
    }

    .blog-card {
        background: var(--bg-light);
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 10px;
        min-height: 220px;
    }

    .blog-card h3 {
        margin: 0;
        font-size: 18px;
    }

    .blog-card h3 a {
        color: var(--text);
        text-decoration: none;
    }

    .blog-card h3 a:hover {
        color: var(--primary);
    }

    .meta {
        font-size: 12px;
        color: var(--text-lighter);
    }

    .excerpt {
        color: var(--text-light);
        font-size: 14px;
        flex: 1;
    }

    .blog-link {
        color: var(--primary);
        text-decoration: none;
        font-weight: 700;
        font-size: 14px;
    }

    .empty {
        text-align: center;
        color: var(--text-light);
        padding: 40px 0;
    }

    .pager {
        display: flex;
        justify-content: space-between;
        margin-top: 32px;
    }

    .pager a {
        color: var(--primary);
        text-decoration: none;
        font-weight: 600;
    }

    @media (max-width: 720px) {
        .top {
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }
    }
</style>
@endpush

@section('content')
<div class="wrap">
    <div class="top">
        <div class="brand">dYs- Lizinq SaaS</div>
        <div class="nav">
            <a class="nav-link" href="{{ route('home') }}">{{ ___('Home') }}</a>
            <a class="nav-link" href="{{ route('public.blog.index') }}">{{ ___('Blogs') }}</a>
            <a class="btn" href="{{ route('login') }}">{{ ___('Login') }}</a>
            <a class="btn primary" href="{{ route('company.register.form') }}">{{ ___('Register') }}</a>
        </div>
    </div>

    <div class="hero">
        <h1>{{ ___('Platform Blog') }}</h1>
        <p>{{ ___('Updates, guides, and insights from the Lizinq team.') }}</p>
    </div>

    <div class="blog-grid">
        @forelse($posts as $post)
            @php
                $raw = $post->excerpt ?: ($post->content ?? '');
                $plain = strip_tags($raw);
                $plain = preg_replace('/\{[^}]+\}/', '', $plain);
                $excerpt = \Illuminate\Support\Str::limit(trim($plain), 160);
                $date = $post->published_at ?? $post->created_at;
            @endphp
            <article class="blog-card">
                <div class="meta">{{ $date?->format('Y-m-d') }}</div>
                <h3><a href="{{ route('public.blog.show', $post->slug) }}">{{ $post->title }}</a></h3>
                <div class="excerpt">{{ $excerpt }}</div>
                <a class="blog-link" href="{{ route('public.blog.show', $post->slug) }}">{{ ___('Read more') }}</a>
            </article>
        @empty
            <div class="empty">{{ ___('No posts yet.') }}</div>
        @endforelse
    </div>

    @if($posts->hasPages())
        <div class="pager">
            <div>
                @if($posts->previousPageUrl())
                    <a href="{{ $posts->previousPageUrl() }}">{{ ___('Newer posts') }}</a>
                @endif
            </div>
            <div>
                @if($posts->nextPageUrl())
                    <a href="{{ $posts->nextPageUrl() }}">{{ ___('Older posts') }}</a>
                @endif
            </div>
        </div>
    @endif
</div>
@endsection
