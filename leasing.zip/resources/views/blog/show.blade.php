@extends('layouts.guest')

@php
    $raw = $post->excerpt ?: ($post->content ?? '');
    $plain = strip_tags($raw);
    $plain = preg_replace('/\{[^}]+\}/', '', $plain);
    $metaDescription = \Illuminate\Support\Str::limit(trim($plain), 160);
    $date = $post->published_at ?? $post->created_at;
@endphp

@section('title', $post->title)

@push('head')
    @if($metaDescription)
        <meta name="description" content="{{ $metaDescription }}">
    @endif
@endpush

@push('styles')
<style>
    :root {
        --primary: #2563eb;
        --primary-dark: #1e40af;
        --text: #0f172a;
        --text-light: #475569;
        --text-lighter: #94a3b8;
        --bg: #f8fafc;
        --bg-light: #ffffff;
        --border: #e2e8f0;
    }

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        color: var(--text);
        background: var(--bg);
        line-height: 1.6;
    }

    .wrap {
        max-width: 900px;
        margin: 0 auto;
        padding: 0 24px 48px;
    }

    .top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 0;
        border-bottom: 1px solid var(--border);
    }

    .brand {
        font-size: 20px;
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .nav {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }

    .nav-link {
        color: var(--text);
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 6px;
    }

    .nav-link:hover {
        color: var(--primary);
        background: rgba(37, 99, 235, 0.08);
    }

    .btn {
        padding: 8px 16px;
        border: 1px solid var(--border);
        background: transparent;
        color: var(--text);
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        font-size: 14px;
        text-decoration: none;
    }

    .btn.primary {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
    }

    .btn.primary:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
    }

    .article {
        margin-top: 32px;
        background: var(--bg-light);
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 28px;
    }

    .article h1 {
        margin-top: 0;
        font-size: 32px;
    }

    .meta {
        font-size: 12px;
        color: var(--text-lighter);
        margin-bottom: 12px;
    }

    .lead {
        font-weight: 600;
        color: var(--text-light);
    }

    .content {
        margin-top: 18px;
    }

    .content img {
        max-width: 100%;
        height: auto;
    }

    .content a {
        color: var(--primary);
    }

    .back {
        display: inline-block;
        margin-top: 12px;
        color: var(--primary);
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
    }

    @media (max-width: 720px) {
        .top {
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }

        .article {
            padding: 20px;
        }
    }
</style>
@endpush

@section('content')
<div class="wrap">
    <div class="top">
        <div class="brand">dYs- Lizinq SaaS</div>
        <div class="nav">
            <a class="nav-link" href="{{ route('home') }}">{{ ___('Home') }}</a>
            <a class="nav-link" href="{{ route('public.blog.index') }}">{{ ___('Blogs') }}</a>
            <a class="btn" href="{{ route('login') }}">{{ ___('Login') }}</a>
            <a class="btn primary" href="{{ route('company.register.form') }}">{{ ___('Register') }}</a>
        </div>
    </div>

    <div class="article">
        <a class="back" href="{{ route('public.blog.index') }}">{{ ___('Back to blog') }}</a>
        <h1>{{ $post->title }}</h1>
        <div class="meta">{{ $date?->format('Y-m-d') }}</div>
        @if($post->excerpt)
            <p class="lead">{{ $post->excerpt }}</p>
        @endif
        <div class="content">{!! $post->rendered_content !!}</div>
    </div>
</div>
@endsection
