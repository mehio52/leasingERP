@extends('layouts.app')

@section('title', 'Access denied')
@section('page_title', '403 - Access denied')
@section('page_subtitle', ___('You do not have permission to view this page.'))
@section('page_actions')
    <a class="btn ghost" href="{{ url()->previous() }}">{{ ___('Back') }}</a>
    <a class="btn primary" href="{{ route('dashboard') }}">{{ ___('Dashboard') }}</a>
@endsection

@push('styles')
<style>
    .error-hero{
        background: linear-gradient(135deg, rgba(59,130,246,.15), rgba(16,185,129,.15));
        border:1px solid var(--border);
        border-radius:16px;
        padding:32px;
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:20px;
        align-items:center;
    }
    .error-hero h1{margin:0;font-size:32px;}
    .error-hero p{margin:6px 0 0;}
    @media(max-width:900px){ .error-hero{grid-template-columns:1fr;} }
</style>
@endpush

@section('content')
<div class="wrap">
    <div class="error-hero">
        <div>
            <div class="badge bad">403</div>
            <h1>{{ ___('Permission required') }}</h1>
            <p class="muted">{{ ___('Contact your company owner to grant access for this action.') }}</p>
            <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
                <a class="btn primary" href="{{ route('dashboard') }}">{{ ___('Go to dashboard') }}</a>
                <a class="btn ghost" href="{{ url()->previous() }}">{{ ___('Back') }}</a>
                @auth
                    <a class="btn warn" href="{{ route('company.plans.index') }}">{{ ___('Upgrade plan') }}</a>
                @endauth
            </div>
        </div>
        <div style="text-align:right;">
            <div style="font-size:14px; color:var(--muted);">{{ now()->format('Y-m-d H:i') }}</div>
            <div style="font-size:64px; font-weight:800;">{{ $exception->getStatusCode() ?? 403 }}</div>
            <div class="muted">{{ $exception->getMessage() ?: ___('No permission for this resource') }}</div>
        </div>
    </div>
</div>
@endsection
