@extends('layouts.app')

@section('title', ___('Control panel'))
@section('page_title', ___('Control panel'))
@section('page_subtitle', $company?->name ?? ___('Company not found'))

@push('styles')
<style>
    .chart-card{ position:relative; overflow:hidden; cursor:pointer; }
    .chart-body{ position:relative; min-height:220px; }
    .charts-layout{
        display:grid;
        grid-template-columns: 1fr minmax(260px, 320px);
        gap:12px;
        align-items:start;
    }
    .charts-main{
        display:grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap:12px;
    }
    .side-placeholder{
        min-height:220px;
        display:flex;
        flex-direction:column;
        gap:8px;
        justify-content:center;
    }
    @media (max-width:1200px){
        .charts-layout{ grid-template-columns:1fr; }
    }
    .chart-empty{
        position:absolute; inset:0;
        display:flex; align-items:center; justify-content:center;
        background: linear-gradient(135deg, rgba(255,255,255,0.02), rgba(255,255,255,0.00));
        border: 1px dashed rgba(255,255,255,0.08);
        border-radius: 12px;
        font-weight:700;
        color:#94a3b8;
        pointer-events:none;
        padding:14px;
        text-align:center;
    }
    .chart-box{ width:100%; height:240px; }
    /* Payment calendar */
    .pay-calendar { display:flex; flex-direction:column; gap:10px; }
    .pay-cal-controls { display:flex; gap:8px; align-items:center; }
    .pay-cal-controls .btn { padding:8px 10px; }
    .pay-cal-days { display:grid; gap:8px; }
    .pay-day { border:1px solid var(--border); border-radius:12px; padding:10px 12px; background:var(--surface); }
    .pay-day h4 { margin:0 0 6px; font-size:14px; }
    .pay-items { display:grid; gap:6px; }
    .pay-item { display:flex; flex-wrap:wrap; gap:8px; align-items:center; padding:8px 10px; border-radius:10px; border:1px solid var(--border); background:rgba(255,255,255,0.02); }
    .pay-item .badge { margin-left:auto; }
    .badge-paid { background: rgba(34,197,94,0.15); color:#22c55e; }
    .badge-overdue { background: rgba(239,68,68,0.15); color:#ef4444; }
    .badge-pending { background: rgba(234,179,8,0.15); color:#eab308; }
    .cal-grid { display:grid; grid-template-columns: repeat(7, minmax(64px,1fr)); gap:6px; }
    .cal-day { border:1px solid var(--border); border-radius:8px; padding:6px; min-height:60px; background:var(--surface); display:flex; flex-direction:column; gap:4px; cursor:pointer; position:relative; font-size:12px; }
    .cal-day.off { opacity:0.35; }
    .cal-day .num { font-weight:700; }
    .cal-day .dot { width:8px; height:8px; border-radius:50%; }
    .cal-day .dots { display:flex; gap:4px; flex-wrap:wrap; align-items:center; }
    .cal-day .popover { position:absolute; left:6px; right:6px; top:calc(100% + 4px); z-index:5; background:var(--card); border:1px solid var(--border); border-radius:10px; padding:8px; box-shadow:0 8px 20px rgba(0,0,0,0.35); display:none; }
    .cal-day .popover .cal-entry { margin:4px 0 0; }
    .cal-day.active .popover { display:block; }
    .cal-paid { background: rgba(34,197,94,0.15); border-color: rgba(34,197,94,0.35); }
    .cal-overdue { background: rgba(239,68,68,0.15); border-color: rgba(239,68,68,0.35); }
    .cal-pending { background: rgba(234,179,8,0.15); border-color: rgba(234,179,8,0.35); }
    .cal-empty { grid-column:1 / -1; text-align:center; color:var(--muted); padding:10px 0; }
    .cal-summary { display:flex; gap:10px; flex-wrap:wrap; font-weight:700; margin-top:6px; font-size:12px; }
    .cal-summary .muted { font-weight:400; }
    .cal-entry { display:flex; gap:6px; flex-wrap:wrap; align-items:center; padding:6px 8px; border:1px solid var(--border); border-radius:10px; margin-top:6px; background:rgba(255,255,255,0.02); font-size:12px; }
</style>
@endpush

@section('content')
<div class="wrap">

    @if(!$company)
        <div class="card banner error">
            <div class="badge bad">{{ ___('Problem') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('This user is not affiliated with any company.') }} <code>users.company_id</code> {{ ___('and check the relation.') }}
            </div>
        </div>
    @endif

    @if($company && ($isSuspended || !$isActive))
        <div class="card banner error">
            <div class="badge bad">{{ ___('Company blocked / deactivated') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('Blocking history') }}: {{ optional($company->suspended_at)->format('Y-m-d H:i') }} —
                {{ ___('Reason') }}: {{ $company->suspend_reason ?? '-' }}
            </div>
        </div>
    @endif

    @if($company && $readOnly)
        <div class="card banner warn">
            <div class="badge warn">{{ ___('Trial / Subscription expired.') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('The system is in read-only mode. A block is opened with a new contract or active subscription.') }}
            </div>
        </div>
    @endif

    @php
        $canPayments = $user?->hasPermission('payments.view') ?? false;
        $canBhph = $user?->hasPermission('bhph.view') ?? false;
        $canVehicles = $user?->hasPermission('vehicles.view') ?? false;
        $canCustomers = $user?->hasPermission('customers.view') ?? false;
        $canSettings = $user?->hasPermission('settings.edit') ?? false;
        $canAnyDashboard = $canPayments || $canBhph || $canVehicles || $canCustomers || $canSettings;
    @endphp

    @if($company && !$canAnyDashboard)
        <div class="card banner warn">
            <div class="badge warn">{{ ___('Access limited') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('Your role does not have permission to view dashboard data.') }}
            </div>
        </div>
    @endif

    {{-- Filters --}}
    <div class="card">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:14px; flex-wrap:wrap;">
            <div>
                <div class="h" style="margin-bottom:4px;">{{ ___('Report filters') }}</div>
                <div class="muted small">{{ ___('Narrow by date range and account status.') }}</div>
            </div>

            <form method="GET" action="{{ route('dashboard') }}"
                  style="display:grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap:12px; align-items:end; flex:1; max-width:820px;">
                <div>
                    <label class="muted small">{{ ___('Beginning') }}</label>
                    <input class="input" type="date" name="start_date" value="{{ $filters['start_date'] ?? '' }}">
                </div>
                <div>
                    <label class="muted small">{{ ___('Finishing') }}</label>
                    <input class="input" type="date" name="end_date" value="{{ $filters['end_date'] ?? '' }}">
                </div>
                <div>
                    <label class="muted small">{{ ___('Account status') }}</label>
                    <select class="input" name="account_status">
                        <option value="all" @selected(($filters['account_status'] ?? 'all') === 'all')>{{ ___('All') }}</option>
                        <option value="active" @selected(($filters['account_status'] ?? '') === 'active')>{{ ___('Active') }}</option>
                        <option value="overdue" @selected(($filters['account_status'] ?? '') === 'overdue')>{{ ___('Late') }}</option>
                        <option value="legal" @selected(($filters['account_status'] ?? '') === 'legal')>{{ ___('Legal') }}</option>
                        <option value="inactive" @selected(($filters['account_status'] ?? '') === 'inactive')>{{ ___('Deactive') }}</option>
                    </select>
                </div>
                <div style="display:flex; gap:8px; justify-content:flex-end;">
                    @if($canAnyDashboard)
                        <a class="btn ghost" target="_blank" href="{{ route('dashboard.export_pdf', ['start_date' => $filters['start_date'] ?? null, 'end_date' => $filters['end_date'] ?? null, 'account_status' => $filters['account_status'] ?? null]) }}">{{ ___('Export PDF') }}</a>
                    @endif
                    <button class="btn ghost" type="button" onclick="window.location='{{ route('dashboard') }}'">{{ ___('Reset') }}</button>
                    <button class="btn primary" type="submit">{{ ___('Apply') }}</button>
                </div>
            </form>
        </div>
    </div>

    {{-- Charts + right --}}
    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:12px; margin-top:12px;">
        @if($canPayments || $canBhph || $canVehicles || $canCustomers)
            <div class="card">
                <div class="h">{{ ___('Aylıq Göstəricilər') }}</div>
                @if($canPayments)
                    <div class="kv"><span class="muted">{{ ___('Bu Ay Alınan Ödənişlər') }}</span><span><b>{{ number_format((float)($creditDashboard['monthly']['payments'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</b></span></div>
                @endif
                @if($canBhph)
                    <div class="kv"><span class="muted">{{ ___('Gecikmiş Hesablar') }}</span><span>{{ (int) ($creditDashboard['monthly']['overdue_accounts'] ?? 0) }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('Ümumi Gecikmiş Aylıq Ödəniş') }}</span><span>{{ number_format((float)($creditDashboard['monthly']['overdue_amount'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                @endif
                @if($canPayments)
                    <div class="kv"><span class="muted">{{ ___('Bu Ay Alınan Faiz') }}</span><span>{{ number_format((float)($creditDashboard['monthly']['interest'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                @endif
                @if($canCustomers)
                    <div class="kv"><span class="muted">{{ ___('Ümumi Müştəri Sayı') }}</span><span>{{ (int) ($creditDashboard['monthly']['customers'] ?? 0) }}</span></div>
                @endif
                @if($canVehicles)
                    <div class="kv"><span class="muted">{{ ___('Satılan Avtomobillər') }}</span><span>{{ (int) ($creditDashboard['monthly']['sold_vehicles'] ?? 0) }}</span></div>
                @endif
            </div>
        @endif
        @if($canBhph || $canVehicles)
            <div class="card">
                <div class="h">{{ ___('Ümumi Göstəricilər') }}</div>
                @if($canBhph)
                    <div class="kv"><span class="muted">{{ ___('İndiyə kimi alınan ilkin Ödəniş') }}</span><span><b>{{ number_format((float)($creditDashboard['overall']['down_payment'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</b></span></div>
                    <div class="kv"><span class="muted">{{ ___('Alınan ümumi faiz') }}</span><span>{{ number_format((float)($creditDashboard['overall']['paid_interest'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('Qalan əsas borc') }}</span><span>{{ number_format((float)($creditDashboard['overall']['remaining_principal'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('Qalan əsas + faiz (cəmi)') }}</span><span>{{ number_format((float)($creditDashboard['overall']['remaining_total'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('Qalan faizlərin cəmi') }}</span><span>{{ number_format((float)($creditDashboard['overall']['remaining_interest'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                @endif
                @if($canVehicles)
                    <div class="kv"><span class="muted">{{ ___('Əldə olan maşınların ümumi qiyməti') }}</span><span>{{ number_format((float)($creditDashboard['overall']['inventory_value'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                @endif
                @if($canBhph)
                    <div class="kv"><span class="muted">{{ ___('Ödənilən ümumi əsas məbləğ') }}</span><span>{{ number_format((float)($creditDashboard['overall']['paid_principal'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('Ödənilən ümumi məbləğ') }}</span><span>{{ number_format((float)($creditDashboard['overall']['paid_total'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                @endif
            </div>
        @endif
    </div>

    @if($canBhph || $canPayments)
        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:12px; margin-top:12px;">
            @if($canBhph)
                <div class="card">
                    <div class="h">{{ ___('Aging buckets + PAR') }}</div>
                    <div class="kv"><span class="muted">{{ ___('0-30 gün') }}</span><span>{{ number_format((float)($creditReports['aging']['bucket_0_30'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('31-60 gün') }}</span><span>{{ number_format((float)($creditReports['aging']['bucket_31_60'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('61-90 gün') }}</span><span>{{ number_format((float)($creditReports['aging']['bucket_61_90'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('90+ gün') }}</span><span>{{ number_format((float)($creditReports['aging']['bucket_90_plus'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('PAR (overdue principal / outstanding)') }}</span><span><b>{{ number_format((float)($creditReports['par']['ratio'] ?? 0), 2) }}%</b></span></div>
                </div>
            @endif
            @if($canPayments)
                <div class="card">
                    <div class="h">{{ ___('Tahsilat performansı (target vs actual)') }}</div>
                    <div class="kv"><span class="muted">{{ ___('Hedef') }}</span><span>{{ number_format((float)($creditReports['collection']['target'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('Gerçekleşen') }}</span><span><b>{{ number_format((float)($creditReports['collection']['actual'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</b></span></div>
                    <div class="kv"><span class="muted">{{ ___('Performans') }}</span><span>{{ number_format((float)($creditReports['collection']['performance'] ?? 0), 2) }}%</span></div>
                    <div class="kv"><span class="muted">{{ ___('Fark (Hedef - Gerçekleşen)') }}</span><span>{{ number_format((float)($creditReports['collection']['gap'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    @if(empty($creditReports['collection']['target']))
                        <div class="muted small">{{ ___('Hedef təyin edilməyib (company options > settings).') }}</div>
                    @endif
                </div>
                <div class="card">
                    <div class="h">{{ ___('Accrued vs collected faiz') }}</div>
                    <div class="kv"><span class="muted">{{ ___('Accrued faiz') }}</span><span>{{ number_format((float)($creditReports['interest']['accrued'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                    <div class="kv"><span class="muted">{{ ___('Collected faiz') }}</span><span><b>{{ number_format((float)($creditReports['interest']['collected'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</b></span></div>
                    <div class="kv"><span class="muted">{{ ___('Fark (accrued - collected)') }}</span><span>{{ number_format((float)($creditReports['interest']['gap'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
                </div>
            @endif
        </div>
    @endif

    <div class="charts-layout">
        <div class="charts-main">
            @if($canSettings)
                <div class="card">
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; flex-wrap:wrap;">
                        <div>
                            <div class="h">{{ ___('Taxes') }}</div>
                            <div class="muted small">{{ ___('YTD tax + last report') }}</div>
                        </div>
                        <a class="btn ghost" href="{{ route('company.taxes.index') }}">{{ ___('Open taxes') }}</a>
                    </div>
                    <div style="margin-top:8px; display:flex; gap:12px; flex-wrap:wrap;">
                        <div class="kv">
                            <span class="muted">{{ ___('Tax YTD') }}</span>
                            <span><b>{{ number_format((float)($taxTotalYear ?? 0),2) }} {{ $currencyCode ?? 'AZN' }}</b></span>
                        </div>
                        <div class="kv">
                            <span class="muted">{{ ___('Last rate') }}</span>
                            <span>{{ $lastTax?->tax_rate ? number_format((float)$lastTax->tax_rate,3).'%' : '—' }}</span>
                        </div>
                        <div class="kv">
                            <span class="muted">{{ ___('Last tax') }}</span>
                            <span>{{ $lastTax?->tax_amount ? number_format((float)$lastTax->tax_amount,2).' '.($currencyCode ?? 'AZN') : '—' }}</span>
                        </div>
                    </div>
                </div>
            @endif

            @if($canPayments)
                <div class="card chart-card" data-chart="paymentsChart">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <div class="h">{{ ___('Payment dynamics') }}</div>
                        <span class="badge">{{ ___('Click for larger view') }}</span>
                    </div>
                    <div class="chart-body">
                        <div class="chart-empty">{{ ___('No information') }}</div>
                        <div id="paymentsChart" class="chart-box"></div>
                    </div>
                </div>

                <div class="card chart-card" data-chart="penaltyChart">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <div class="h">{{ ___('Fine payments') }}</div>
                        <span class="badge">{{ ___('Click for larger view') }}</span>
                    </div>
                    <div class="chart-body">
                        <div class="chart-empty">{{ ___('No information') }}</div>
                        <div id="penaltyChart" class="chart-box"></div>
                    </div>
                </div>
            @endif

            @if($canVehicles)
                <div class="card chart-card" data-chart="vehicleStatusChart">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <div class="h">{{ ___('Vehicle status') }}</div>
                        <span class="badge">{{ ___('Click for larger view') }}</span>
                    </div>
                    <div class="chart-body">
                        <div class="chart-empty">{{ ___('No information') }}</div>
                        <div id="vehicleStatusChart" class="chart-box"></div>
                    </div>
                </div>

                <div class="card chart-card" data-chart="vehicleValueChart">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <div class="h">{{ ___('Warehouse cost') }}</div>
                        <span class="badge">{{ ___('Click for larger view') }}</span>
                    </div>
                    <div class="chart-body">
                        <div class="chart-empty">{{ ___('No information') }}</div>
                        <div id="vehicleValueChart" class="chart-box"></div>
                    </div>
                </div>

                <div class="card chart-card" data-chart="vehicleProfitChart">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <div class="h">{{ ___('Sales revenue/profit') }}</div>
                        <span class="badge">{{ ___('Click for larger view') }}</span>
                    </div>
                    <div class="chart-body">
                        <div class="chart-empty">{{ ___('No information') }}</div>
                        <div id="vehicleProfitChart" class="chart-box"></div>
                    </div>
                </div>
            @endif

        </div>

        @if($canBhph)
            <div class="card side-placeholder">
                <div class="h">{{ ___('Upcoming/overdue payments') }}</div>
                <div class="muted small">{{ ___('This section is intended for recent and overdue accounts.') }}</div>
            </div>
        @endif
        {{-- Forecast + Tax summary --}}
        @if($canPayments || $canSettings)
            <div class="card">
                <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap;">
                    <div class="h">{{ ___('Forecast') }}</div>
                    <div class="muted small">{{ ___('Advanced reports (analytics)') }}</div>
                </div>
                @if($canPayments)
                    @if($hasAnalytics)
                        @if(isset($forecastTurnover) && $forecastTurnover->isNotEmpty())
                            <table>
                                <thead>
                                <tr>
                                    <th>{{ ___('Period') }}</th>
                                    <th class="right">{{ ___('Turnover') }}</th>
                                    <th class="small">{{ ___('Range') }}</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($forecastTurnover as $f)
                                    @php
                                        $lo = $f->meta['yhat_lower'] ?? null;
                                        $hi = $f->meta['yhat_upper'] ?? null;
                                    @endphp
                                    <tr>
                                        <td>{{ optional($f->forecast_date)->format('Y-m') }}</td>
                                        <td class="right">{{ number_format((float)$f->value,2) }} {{ $currencyCode ?? 'AZN' }}</td>
                                        <td class="small">
                                            @if($lo !== null && $hi !== null)
                                                {{ number_format((float)$lo,2) }} — {{ number_format((float)$hi,2) }}
                                            @else
                                                —
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        @else
                            <div class="muted">{{ ___('No information') }}</div>
                        @endif
                    @else
                        <div class="muted">{{ ___('Upgrade to view analytics') }}</div>
                        <a class="btn primary" href="{{ route('company.plans.index') }}" style="margin-top:8px;">{{ ___('Open plans') }}</a>
                    @endif
                @else
                    <div class="muted">{{ ___('No permission to view payments analytics.') }}</div>
                @endif
                @if($canSettings)
                    <div style="margin-top:8px;">
                        <span class="badge">{{ ___('Tax YTD') }}: {{ number_format((float)($taxTotalYear ?? 0),2) }} {{ $currencyCode ?? 'AZN' }}</span>
                        @if($lastTax)
                            <span class="badge ghost">{{ ___('Last tax') }}: {{ number_format((float)$lastTax->tax_amount,2) }} {{ $currencyCode ?? 'AZN' }}</span>
                        @endif
                        <a class="btn ghost" href="{{ route('company.taxes.index') }}" style="float:right;">{{ ___('Open taxes') }}</a>
                    </div>
                @endif
            </div>
        @endif
    </div>

    @if($canBhph)
        {{-- Payment calendar --}}
        <div class="card">
            <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                <div>
                    <div class="h">{{ ___('Payment calendar') }}</div>
                    <div class="muted small">{{ ___('Browse payments by month until the last recorded date.') }}</div>
                </div>
                <div class="pay-cal-controls">
                    <button class="btn ghost" type="button" id="calPrev">‹</button>
                    <select class="input" id="calMonth"></select>
                    <button class="btn ghost" type="button" id="calNext">›</button>
                </div>
            </div>
            <div class="pay-calendar">
                <div id="calSummary" class="muted small"></div>
                <div id="calGrid" class="cal-grid"></div>
            </div>
        </div>
    @endif

    @if($canPayments || $canBhph)
        {{-- Last payments + overdue --}}
        <div class="grid" style="grid-template-columns: repeat(auto-fit,minmax(320px,1fr)); gap:12px; margin-top:12px;">
            @if($canPayments)
                <div class="card">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
                        <div class="h">{{ ___('Recent payments') }}</div>
                        <div class="muted small">{{ ___('Last 6 notes') }}</div>
                    </div>
                    <table>
                        <thead>
                        <tr>
                            <th>{{ ___('History') }}</th>
                            <th class="right">{{ ___('Amount') }}</th>
                            <th class="right">{{ ___('Penalty') }}</th>
                            <th class="small">{{ ___('Reference') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($recentPayments as $p)
                            <tr>
                                <td>{{ optional($p->paid_date ?? $p->created_at)->format('Y-m-d') }}</td>
                                <td class="right">{{ number_format((float)$p->amount,2) }}</td>
                                <td class="right">{{ number_format((float)($p->penalty_amount ?? 0),2) }}</td>
                                <td class="small">{{ $p->reference ?? '-' }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="4" class="muted">{{ ___('No payment.') }}</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            @endif

            @if($canBhph)
                <div class="card">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
                        <div class="h">{{ ___('Overdue accounts') }}</div>
                        <div class="muted small">{{ ___('Top 5') }}</div>
                    </div>
                    <table>
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>{{ ___('Customer') }}</th>
                            <th>{{ ___('Status') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($topOverdue as $acc)
                            <tr>
                                <td>{{ $acc->id }}</td>
                                <td>{{ $acc->customer?->first_name }} {{ $acc->customer?->last_name }}</td>
                                <td><span class="badge">{{ $acc->status }}</span></td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="muted">{{ ___('No overdue bills.') }}</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    @endif

</div>

{{-- Chart modal --}}
<div id="chartModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:2000; align-items:center; justify-content:center; padding:16px;">
    <div style="background:#0f1115; border-radius:16px; padding:18px; width:min(1100px, 100%); max-height:90vh; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,.35); position:relative;">
        <button id="chartModalClose" class="btn ghost" style="position:absolute; top:10px; right:10px;">{{ ___('Close') }}</button>
        <div class="h" id="chartModalTitle" style="margin-bottom:8px;">{{ ___('Graphic') }}</div>
        <div id="chartModalCanvas" style="width:100%; height:320px;"></div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof echarts === 'undefined') {
        console.error(@json(___('ECharts is not loaded. You must have echarts.min.js inside layouts.app.')));
        return;
    }

    const daily = @json($daily ?? []);
    const vehicleCounts = @json($vehicleCounts ?? ['available'=>0,'leasing'=>0,'sold'=>0]);
    const vehicleValues = @json($vehicleValues ?? ['purchase_total'=>0,'sale_total'=>0]);
    const soldValues = @json($soldValues ?? ['purchase_total'=>0,'sale_total'=>0,'profit'=>0]);
    const amortTimeline = @json($amortTimeline ?? []);
    const timelineStart = @json($timelineStart ?? null);
    const timelineEnd = @json($timelineEnd ?? null);
    const taxTotalYear = @json($taxTotalYear ?? 0);
    const lastTax = @json($lastTax ?? null);
    const currencyCode = @json($currencyCode ?? 'AZN');

    const els = {
        payments: document.getElementById('paymentsChart'),
        penalty:  document.getElementById('penaltyChart'),
        status:   document.getElementById('vehicleStatusChart'),
        value:    document.getElementById('vehicleValueChart'),
        profit:   document.getElementById('vehicleProfitChart'),
    };

    const labels = daily.map(d => d.date);
    const totals = daily.map(d => Number(d.total || 0));
    const penalties = daily.map(d => Number(d.penalty || 0));

    const palette = {
        teal: '#22d3ee',
        green: '#22c55e',
        orange: '#f97316',
        blue: '#3b82f6',
        cyan: '#06b6d4',
        indigo: '#818cf8'
    };

    function toggleEmpty(el, hasData) {
        // Always render the chart; we only use hasData to decide if the overlay should appear.
        const wrap = el?.closest?.('.chart-body');
        const empty = wrap ? wrap.querySelector('.chart-empty') : null;
        if (empty) empty.style.display = 'none';
        el.style.display = 'block';
        return true;
    }

    function initChart(el, optionFn, hasDataFn) {
        if (!el) return null;

        toggleEmpty(el, !!hasDataFn());

        // Guard: elementin ölçüsü hələ 0-dırsa, 2-3 frame sonra yenə yoxla
        let tries = 0;
        function tryInit() {
            const rect = el.getBoundingClientRect();
            if ((rect.width === 0 || rect.height === 0) && tries < 6) {
                tries++;
                requestAnimationFrame(tryInit);
                return;
            }
            const chart = echarts.init(el);
            chart.setOption(optionFn(), true);
            chart.resize();
            chart.__optionFn = optionFn; // debug/refresh üçün
            return chart;
        }
        return tryInit() || null;
    }

    const chartStore = {}; // key -> chart instance
    function store(key, inst){ if (inst) chartStore[key] = inst; return inst; }

    // 1) Payments (line)
    store('payments', initChart(els.payments, () => ({
        tooltip: { trigger: 'axis' },
        grid: { left: 50, right: 20, top: 20, bottom: 30 },
        xAxis: { type: 'category', data: labels, boundaryGap: false, axisLine: { lineStyle: { color: '#64748b' } } },
        yAxis: { type: 'value', axisLine: { lineStyle: { color: '#64748b' } }, splitLine: { lineStyle: { color: 'rgba(100,116,139,.2)' } } },
        series: [{
            name: @json(___('Payment')) + ' (' + currencyCode + ')',
            type: 'line',
            smooth: true,
            symbolSize: 6,
            lineStyle: { width: 3, color: palette.teal },
            areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                {offset:0,color:'rgba(34,211,238,.45)'},
                {offset:1,color:'rgba(34,211,238,.08)'}
            ])},
            data: totals
        }]
    }), () => labels.length > 0));

    // 2) Penalties (bar)
    store('penalty', initChart(els.penalty, () => ({
        tooltip: { trigger: 'axis' },
        legend: { bottom: 0 },
        grid: { left: 50, right: 20, top: 20, bottom: 50 },
        xAxis: { type: 'category', data: labels, axisLine: { lineStyle: { color: '#64748b' } } },
        yAxis: { type: 'value', axisLine: { lineStyle: { color: '#64748b' } }, splitLine: { lineStyle: { color: 'rgba(100,116,139,.2)' } } },
        series: [
            {
                name: @json(___('Penalty')),
                type: 'bar',
                data: penalties,
                itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                    {offset:0,color:'rgba(249,115,22,.9)'},
                    {offset:1,color:'rgba(249,115,22,.4)'}
                ])},
                barWidth: 16
            },
            {
                name: @json(___('Total')),
                type: 'bar',
                data: totals,
                itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                    {offset:0,color:'rgba(34,197,94,.9)'},
                    {offset:1,color:'rgba(34,197,94,.4)'}
                ])},
                barWidth: 16
            }
        ]
    }), () => labels.length > 0));

    // 3) Vehicle status (pie)
    store('status', initChart(els.status, () => ({
        tooltip: { trigger: 'item' },
        legend: { bottom: 0 },
        series: [{
            type: 'pie',
            radius: ['50%','70%'],
            itemStyle: { borderRadius: 10, borderColor: '#0f172a', borderWidth: 2 },
            label: { show: false },
            data: [
                { value: Number(vehicleCounts.available ?? 0), name: @json(___('Available')), itemStyle:{color:palette.green} },
                { value: Number(vehicleCounts.leasing ?? 0), name: @json(___('On lease')), itemStyle:{color:palette.blue} },
                { value: Number(vehicleCounts.sold ?? 0), name: @json(___('Sold')), itemStyle:{color:palette.orange} },
            ]
        }]
    }), () => {
        const vals = [vehicleCounts.available, vehicleCounts.leasing, vehicleCounts.sold].map(v => Number(v||0));
        return vals.some(v => v > 0);
    }));

    // 4) Stock value (bar)
    store('value', initChart(els.value, () => ({
        tooltip: { trigger: 'axis' },
        legend: { bottom: 0 },
        grid: { left: 50, right: 20, top: 20, bottom: 50 },
        xAxis: { type: 'category', data: [@json(___('Warehouse'))], axisLine: { lineStyle: { color: '#64748b' } } },
        yAxis: { type: 'value', axisLine: { lineStyle: { color: '#64748b' } }, splitLine: { lineStyle: { color: 'rgba(100,116,139,.2)' } } },
        series: [
            {
                name: @json(___('Purchase total')),
                type: 'bar',
                data: [Number(vehicleValues.purchase_total ?? 0)],
                itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                    {offset:0,color:'rgba(6,182,212,.9)'},
                    {offset:1,color:'rgba(6,182,212,.35)'}
                ])},
                barWidth: 30
            },
            {
                name: @json(___('Sales total')),
                type: 'bar',
                data: [Number(vehicleValues.sale_total ?? 0)],
                itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                    {offset:0,color:'rgba(34,197,94,.9)'},
                    {offset:1,color:'rgba(34,197,94,.35)'}
                ])},
                barWidth: 30
            }
        ]
    }), () => (Number(vehicleValues.purchase_total||0) > 0 || Number(vehicleValues.sale_total||0) > 0)));

    // 5) Sold revenue / profit (bar)
    store('profit', initChart(els.profit, () => ({
        tooltip: { trigger: 'axis' },
        legend: { bottom: 0 },
        grid: { left: 50, right: 20, top: 20, bottom: 50 },
        xAxis: { type: 'category', data: [@json(___('Sold'))], axisLine: { lineStyle: { color: '#64748b' } } },
        yAxis: { type: 'value', axisLine: { lineStyle: { color: '#64748b' } }, splitLine: { lineStyle: { color: 'rgba(100,116,139,.2)' } } },
        series: [
            {
                name: @json(___('Purchase total')),
                type: 'bar',
                data: [Number(soldValues.purchase_total ?? 0)],
                itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                    {offset:0,color:'rgba(6,182,212,.9)'},
                    {offset:1,color:'rgba(6,182,212,.4)'}
                ])},
                barWidth: 28
            },
            {
                name: @json(___('Sales total')),
                type: 'bar',
                data: [Number(soldValues.sale_total ?? 0)],
                itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                    {offset:0,color:'rgba(129,140,248,.9)'},
                    {offset:1,color:'rgba(129,140,248,.4)'}
                ])},
                barWidth: 28
            },
            {
                name: @json(___('Profit')),
                type: 'bar',
                data: [Number(soldValues.profit ?? 0)],
                itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
                    {offset:0,color:'rgba(249,115,22,.9)'},
                    {offset:1,color:'rgba(249,115,22,.4)'}
                ])},
                barWidth: 28
            }
        ]
    }), () => {
        // göstər, hətta 0 olsa belə (əgər məlumat mövcuddursa)
        return soldValues !== null && soldValues !== undefined;
    }));

    // Modal (wide view)
    const modal = document.getElementById('chartModal');
    const modalCanvas = document.getElementById('chartModalCanvas');
    const modalTitle = document.getElementById('chartModalTitle');
    const closeBtn = document.getElementById('chartModalClose');
    let modalChart = null;

    const map = {
        paymentsChart: { key:'payments', title: @json(___('Paymnet dynamics')) },
        penaltyChart: { key:'penalty', title: @json(___('Fine payments')) },
        vehicleStatusChart: { key:'status', title: @json(___('Vehicle status')) },
        vehicleValueChart: { key:'value', title: @json(___('Warehouse cost')) },
        vehicleProfitChart: { key:'profit', title: @json(___('Sales revenue/profit')) },
    };

    function openModalByCardId(cardId){
        const cfg = map[cardId];
        if (!cfg) return;

        const inst = chartStore[cfg.key];
        if (!inst) return;

        if (modalChart) { modalChart.dispose(); modalChart = null; }
        modalCanvas.innerHTML = '';
        modal.style.display = 'flex';
        modalTitle.textContent = cfg.title;

        modalChart = echarts.init(modalCanvas);
        // chart option-u olduğu kimi götürürük
        modalChart.setOption(inst.getOption(), true);
        setTimeout(() => {
            if (modalChart) modalChart.resize();
        }, 60);
    }

    document.querySelectorAll('.chart-card').forEach(card => {
        card.addEventListener('click', () => openModalByCardId(card.getAttribute('data-chart')));
    });

    closeBtn?.addEventListener('click', () => {
        modal.style.display = 'none';
        if (modalChart) { modalChart.dispose(); modalChart = null; }
    });

    modal?.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
            if (modalChart) { modalChart.dispose(); modalChart = null; }
        }
    });

    window.addEventListener('resize', () => {
        Object.values(chartStore).forEach(ch => ch?.resize?.());
        modalChart?.resize?.();
    });

    // Payment calendar
    (function(){
        const monthSelect = document.getElementById('calMonth');
        const grid = document.getElementById('calGrid');
        const summaryEl = document.getElementById('calSummary');
        const prevBtn = document.getElementById('calPrev');
        const nextBtn = document.getElementById('calNext');
        if(!monthSelect || !grid) return;

        if(!timelineStart || !timelineEnd || amortTimeline.length === 0){
            grid.innerHTML = `<div class="cal-empty">${@json(___('No payment.'))}</div>`;
            return;
        }

        const parseDate = (s) => {
            const d = new Date(s + 'T00:00:00');
            return isNaN(d.getTime()) ? null : d;
        };
        const start = parseDate(timelineStart);
        const end = parseDate(timelineEnd);
        if(!start || !end) {
            grid.innerHTML = `<div class="cal-empty">${@json(___('No payment.'))}</div>`;
            return;
        }

        const months = [];
        const cursor = new Date(start);
        cursor.setDate(1);
        const limit = new Date(end);
        limit.setDate(1);
        while(cursor <= limit){
            const y = cursor.getFullYear();
            const m = cursor.getMonth(); // 0-based
            months.push({ key: `${y}-${String(m+1).padStart(2,'0')}`, label: `${y}-${String(m+1).padStart(2,'0')}` });
            cursor.setMonth(cursor.getMonth()+1);
        }

        months.forEach(m => {
            const opt = document.createElement('option');
            opt.value = m.key;
            opt.textContent = m.label;
            monthSelect.appendChild(opt);
        });
        monthSelect.value = months.at(-1)?.key ?? '';

        function renderMonth(key){
            if(!key){ grid.innerHTML = ''; return; }
            const [yStr,mStr] = key.split('-');
            const y = Number(yStr), m = Number(mStr);
            const filtered = amortTimeline.filter(p => p.date && p.date.startsWith(`${yStr}-${mStr}`));
            const grouped = {};
            filtered.forEach(p => {
                const day = p.date;
                if(!grouped[day]) grouped[day] = [];
                grouped[day].push(p);
            });

            const firstDay = new Date(`${key}-01T00:00:00`);
            const daysInMonth = new Date(y, m, 0).getDate();
            const startWeekday = firstDay.getDay(); // 0=Sun

            grid.innerHTML = '';
            // empty leading cells
            for(let i=0;i<startWeekday;i++){
                const cell = document.createElement('div');
                cell.className = 'cal-day off';
                grid.appendChild(cell);
            }

            let monthTotal = 0;
            for(let d=1; d<=daysInMonth; d++){
                const dayStr = `${key}-${String(d).padStart(2,'0')}`;
                const items = grouped[dayStr] || [];
                let statusDot = 'badge-pending';
                if(items.some(i => (i.status||'').toLowerCase() === 'overdue')) statusDot = 'badge-overdue';
                else if(items.every(i => (i.status||'').toLowerCase() === 'paid')) statusDot = 'badge-paid';

                const cell = document.createElement('div');
                cell.className = 'cal-day';
                if(statusDot === 'badge-paid') cell.classList.add('cal-paid');
                else if(statusDot === 'badge-overdue') cell.classList.add('cal-overdue');
                else cell.classList.add('cal-pending');
                const num = document.createElement('div');
                num.className = 'num';
                num.textContent = d;
                cell.appendChild(num);

                const dots = document.createElement('div');
                dots.className = 'dots';
                if(items.length > 0){
                    const dot = document.createElement('span');
                    dot.className = `dot ${statusDot}`;
                    dots.appendChild(dot);
                    const count = document.createElement('span');
                    count.className = 'muted small';
                    count.textContent = `${items.length}x`;
                    dots.appendChild(count);
                } else {
                    const dot = document.createElement('span');
                    dot.className = 'dot';
                    dot.style.background = 'var(--border)';
                    dots.appendChild(dot);
                }
                cell.appendChild(dots);

                cell.addEventListener('click', (e) => {
                    e.stopPropagation();
                    // close other popovers
                    document.querySelectorAll('.cal-day.active').forEach(c => {
                        if(c !== cell){ c.classList.remove('active'); c.querySelector('.popover')?.remove(); }
                    });
                    const existing = cell.querySelector('.popover');
                    if(existing){
                        existing.remove();
                        cell.classList.remove('active');
                        return;
                    }
                    const pop = showDetails(dayStr, items);
                    if(pop){
                        cell.appendChild(pop);
                        cell.classList.add('active');
                    }
                });
                grid.appendChild(cell);

                items.forEach(p => monthTotal += Number(p.amount || 0));
            }

            summaryEl.textContent = `${key}: ${filtered.length} ${@json(___('record(s)'))}, ${monthTotal.toFixed(2)} ${currencyCode}`;
        }

        function showDetails(dayStr, items){
            if(!items || items.length === 0){
                return;
            }
            let sumAmount=0, sumPrincipal=0, sumInterest=0, sumPenalty=0;
            const rows = items.map(p => {
                sumAmount += Number(p.amount||0);
                sumPrincipal += Number(p.principal||0);
                sumInterest += Number(p.interest||0);
                sumPenalty += Number(p.penalty||0);
                const status = (p.status||'').toLowerCase();
                let badgeClass = 'badge';
                if(status === 'paid') badgeClass += ' badge-paid';
                else if(status === 'overdue') badgeClass += ' badge-overdue';
                else badgeClass += ' badge-pending';
                const who = p.customer ? p.customer : `#${p.account_id ?? ''}`;
                return `
                    <div class="cal-entry">
                        <span style="font-weight:700;">${who}</span>
                        <span class="muted small">${@json(___('Status'))}: ${p.status || ''}</span>
                        <span class="${badgeClass}">${p.status || ''}</span>
                        <span style="margin-left:auto; font-weight:700;">${Number(p.amount||0).toFixed(2)} ${currencyCode}</span>
                    </div>
                `;
            }).join('');

            const pop = document.createElement('div');
            pop.className = 'popover';
            pop.innerHTML = `
                <h4 style="margin:0 0 6px;">${dayStr}</h4>
                <div class="cal-summary">
                    <span>${@json(___('Total'))}: ${sumAmount.toFixed(2)} ${currencyCode}</span>
                    <span class="muted">${@json(___('Principal'))}: ${sumPrincipal.toFixed(2)}</span>
                    <span class="muted">${@json(___('Interest'))}: ${sumInterest.toFixed(2)}</span>
                    <span class="muted">${@json(___('Penalty'))}: ${sumPenalty.toFixed(2)}</span>
                </div>
                <div>${rows}</div>
            `;
            return pop;
        }

        monthSelect.addEventListener('change', () => renderMonth(monthSelect.value));
        prevBtn?.addEventListener('click', () => {
            const idx = months.findIndex(m => m.key === monthSelect.value);
            if(idx > 0){
                monthSelect.value = months[idx-1].key;
                renderMonth(monthSelect.value);
            }
        });
        nextBtn?.addEventListener('click', () => {
            const idx = months.findIndex(m => m.key === monthSelect.value);
            if(idx >=0 && idx < months.length-1){
                monthSelect.value = months[idx+1].key;
                renderMonth(monthSelect.value);
            }
        });

        renderMonth(monthSelect.value);
    })();
});
</script>
@endpush
