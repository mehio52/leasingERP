@extends('layouts.app')

@section('title', ___('Payment Settings'))
@section('page_title', ___('Payment Settings'))
@section('page_subtitle')
Company ID: {{ $options->company_id }} - User: {{ $user->first_name }} {{ $user->last_name }}
@endsection

@section('content')
@if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @php
        $settingsAssoc = $options->settings ?? [];
        $settingsOldK = old('settings_k');
        $settingsOldV = old('settings_v');

        if (is_array($settingsOldK) && is_array($settingsOldV)) {
            $rows = [];
            foreach ($settingsOldK as $idx => $k) {
                $rows[] = ['k' => $k, 'v' => $settingsOldV[$idx] ?? ''];
            }
        } else {
            $rows = [];
            if (is_array($settingsAssoc)) {
                foreach ($settingsAssoc as $k => $v) {
                    $rows[] = ['k' => $k, 'v' => is_scalar($v) ? (string)$v : json_encode($v, JSON_UNESCAPED_UNICODE)];
                }
            }
        }
    @endphp

    <form class="grid" method="POST" action="{{ route('company.payment_options.update') }}">
        @csrf

        <div class="card">
            <div class="h">{{ ___('Permissions') }}</div>

            <div class="row">
                <div class="switch">
                    <input type="checkbox" name="allow_payment_gateway" value="1"
                           @checked(old('allow_payment_gateway', (int)$options->allow_payment_gateway) === 1)>
                    <div>
                        <div style="font-weight:700;">{{ ___('Allow payment gateway') }}</div>
                        <div class="muted">{{ ___('For card / online payment integration.') }}</div>
                    </div>
                </div>

                <div class="switch">
                    <input type="checkbox" name="allow_advance_payment" value="1"
                           @checked(old('allow_advance_payment', (int)$options->allow_advance_payment) === 1)>
                    <div>
                        <div style="font-weight:700;">{{ ___('Allow advance payment') }}</div>
                        <div class="muted">{{ ___('Payment made before the due date.') }}</div>
                    </div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="switch">
                    <input type="checkbox" name="allow_partial_payment" id="allowPartial" value="1"
                           @checked(old('allow_partial_payment', (int)$options->allow_partial_payment) === 1)>
                    <div>
                        <div style="font-weight:700;">{{ ___('Allow partial payment') }}</div>
                        <div class="muted">{{ ___('Accept payment even if the full amount is not paid.') }}</div>
                    </div>
                </div>

                <div class="switch">
                    <input type="checkbox" name="allow_overpayment" id="allowOver" value="1"
                           @checked(old('allow_overpayment', (int)$options->allow_overpayment) === 1)>
                    <div>
                        <div style="font-weight:700;">{{ ___('Allow overpayment') }}</div>
                        <div class="muted">{{ ___('Defines behavior if the customer overpays.') }}</div>
                    </div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="switch">
                    <input type="checkbox" name="allow_principal_only_payment" value="1"
                           @checked(old('allow_principal_only_payment', (int)$options->allow_principal_only_payment) === 1)>
                    <div>
                        <div style="font-weight:700;">{{ ___('Allow principal-only payment') }}</div>
                        <div class="muted">{{ ___('Allow closing only the principal, without interest.') }}</div>
                    </div>
                </div>

                <div class="field">
                    <label>{{ ___('Minimum partial payment (AZN)') }}</label>
                    <input name="min_partial_payment_amount" id="minPartial"
                           value="{{ old('min_partial_payment_amount', $options->min_partial_payment_amount) }}"
                           placeholder="{{ ___('can be left empty') }}">
                    <div class="muted">{{ ___('Not applied if partial payment is disabled.') }}</div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Minimum overpayment amount (AZN)') }}</label>
                    <input name="min_overpayment_amount" id="minOver"
                           value="{{ old('min_overpayment_amount', $options->min_overpayment_amount) }}"
                           placeholder="{{ ___('can be left empty') }}">
                    <div class="muted">{{ ___('Not applied if overpayment is disabled.') }}</div>
                </div>

                <div class="field">
                    <label>{{ ___('Overpayment behavior') }}</label>
                    <select name="overpayment_behavior" id="overBehavior">
                        <option value="keep_as_credit" @selected(old('overpayment_behavior', $options->overpayment_behavior) === 'keep_as_credit')>{{ ___('Keep as credit') }}</option>
                        <option value="reduce_principal" @selected(old('overpayment_behavior', $options->overpayment_behavior) === 'reduce_principal')>{{ ___('Reduce principal') }}</option>
                        <option value="apply_next_installments" @selected(old('overpayment_behavior', $options->overpayment_behavior) === 'apply_next_installments')>{{ ___('Apply to next installments') }}</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Gateway provider') }}</div>
            <div class="field">
                <label>{{ ___('Preferred provider') }}</label>
                <select name="payment_gateway_provider">
                    <option value="auto" @selected(old('payment_gateway_provider', $options->payment_gateway_provider ?? 'auto') === 'auto')>{{ ___('Auto (by company defaults)') }}</option>
                    <option value="epoint" @selected(old('payment_gateway_provider', $options->payment_gateway_provider ?? 'auto') === 'epoint')>{{ ___('Epoint') }}</option>
                    <option value="iyzico" @selected(old('payment_gateway_provider', $options->payment_gateway_provider ?? 'auto') === 'iyzico')>{{ ___('Iyzico') }}</option>
                    <option value="stripe" @selected(old('payment_gateway_provider', $options->payment_gateway_provider ?? 'auto') === 'stripe')>{{ ___('Stripe') }}</option>
                </select>
                <div class="muted">{{ ___('Auto chooses the provider by the company country/locale and available credentials.') }}</div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Payment application rules') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Where should the payment be applied?') }}</label>
                    <select name="apply_to">
                        <option value="oldest_due_first" @selected(old('apply_to', $options->apply_to) === 'oldest_due_first')>{{ ___('Start with the oldest due') }}</option>
                        <option value="current_due_only" @selected(old('apply_to', $options->apply_to) === 'current_due_only')>{{ ___('Apply only to the current due') }}</option>
                        <option value="newest_first" @selected(old('apply_to', $options->apply_to) === 'newest_first')>{{ ___('Start with the newest due') }}</option>
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('Allocation order') }}</label>
                    <select name="allocation_order">
                        <option value="interest_then_principal" @selected(old('allocation_order', $options->allocation_order) === 'interest_then_principal')>{{ ___('Interest first, then principal') }}</option>
                        <option value="principal_then_interest" @selected(old('allocation_order', $options->allocation_order) === 'principal_then_interest')>{{ ___('Principal first, then interest') }}</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Note') }}</div>
            <div class="field">
                <label>{{ ___('Internal note') }}</label>
                <textarea name="notes" rows="4" placeholder="{{ ___('Internal note...') }}">{{ old('notes', $options->notes) }}</textarea>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Parameters (key/value)') }}</div>
            <div class="muted" style="margin-bottom:10px;">{{ ___('Any additional parameter as key/value. Increase with “+”.') }}</div>

            <div id="settingsRows" style="display:grid; gap:10px;">
                @foreach($rows as $i => $row)
                    <div class="settings-row" style="display:grid; grid-template-columns: 260px 1fr 90px; gap:10px; align-items:center;">
                        <input name="settings_k[{{ $i }}]" value="{{ $row['k'] ?? '' }}" placeholder="{{ ___('key (e.g. payment.strict_mode)') }}">
                        <input name="settings_v[{{ $i }}]" value="{{ $row['v'] ?? '' }}" placeholder="{{ ___('value (e.g. 1)') }}">
                        <button type="button" class="btn danger settings-remove">{{ ___('Delete') }}</button>
                    </div>
                @endforeach
            </div>

            <div class="actions" style="justify-content:flex-start;">
                <button type="button" class="btn" id="settingsAdd">{{ ___('+ Add') }}</button>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </div>

    </form>
</div>

<script>
(function(){
    const allowPartial = document.getElementById('allowPartial');
    const minPartial   = document.getElementById('minPartial');

    const allowOver    = document.getElementById('allowOver');
    const minOver      = document.getElementById('minOver');
    const overBehavior = document.getElementById('overBehavior');

    function syncUI(){
        const p = !!allowPartial?.checked;
        if (minPartial) minPartial.disabled = !p;

        const o = !!allowOver?.checked;
        if (minOver) minOver.disabled = !o;
        if (overBehavior) overBehavior.disabled = !o;

        if (!p && minPartial) minPartial.value = '';
        if (!o) {
            if (minOver) minOver.value = '';
        }
    }

    allowPartial?.addEventListener('change', syncUI);
    allowOver?.addEventListener('change', syncUI);
    syncUI();

    // settings add/remove
    const settingsRows = document.getElementById('settingsRows');
    const settingsAdd  = document.getElementById('settingsAdd');

    function nextSettingsIndex(){
        return settingsRows.querySelectorAll('.settings-row').length;
    }

    function settingsRowHtml(i){
        return `
        <div class="settings-row" style="display:grid; grid-template-columns: 260px 1fr 90px; gap:10px; align-items:center;">
            <input name="settings_k[${i}]" value="" placeholder="{{ ___('key (e.g. payment.strict_mode)') }}">
            <input name="settings_v[${i}]" value="" placeholder="{{ ___('value (e.g. 1)') }}">
            <button type="button" class="btn danger settings-remove">{{ ___('Delete') }}</button>
        </div>`;
    }

    settingsAdd?.addEventListener('click', () => {
        const i = nextSettingsIndex();
        settingsRows.insertAdjacentHTML('beforeend', settingsRowHtml(i));
    });

    settingsRows?.addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('settings-remove')) {
            e.target.closest('.settings-row')?.remove();
        }
    });
})();
</script>
@endsection
