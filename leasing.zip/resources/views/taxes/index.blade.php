@extends('layouts.app')

@section('title', ___('Taxes'))
@section('page_title', ___('Taxes'))
@section('page_subtitle', ___('Calculate and log company taxes'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('dashboard') }}">{{ ___('Back to dashboard') }}</a>
@overwrite

@section('content')
@if(session('status'))
    <div class="banner"><span class="badge ok">{{ session('status') }}</span></div>
@endif
@if($errors->any())
    <div class="banner error">
        <div class="badge bad">{{ ___('Error') }}</div>
        <ul style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $e) <li>{{ $e }}</li> @endforeach
        </ul>
    </div>
@endif

<div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:12px;">
    <div class="card">
        <div class="h">{{ ___('New tax report') }}</div>
        <form method="POST" action="{{ route('company.taxes.store') }}" class="grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:10px;">
            @csrf
            <div class="field">
                <label class="muted small">{{ ___('Period start') }}</label>
                <input class="input" type="date" name="period_start" value="{{ old('period_start') }}">
            </div>
            <div class="field">
                <label class="muted small">{{ ___('Period end') }}</label>
                <input class="input" type="date" name="period_end" value="{{ old('period_end') }}">
            </div>
            <div class="field">
                <label class="muted small">{{ ___('Gross revenue') }}</label>
                <input class="input" type="number" step="0.01" min="0" name="gross_revenue" value="{{ old('gross_revenue', 0) }}" required>
            </div>
            <div class="field">
                <label class="muted small">{{ ___('Deductible expenses') }}</label>
                <input class="input" type="number" step="0.01" min="0" name="deductible_expenses" value="{{ old('deductible_expenses', 0) }}" required>
            </div>
            <div class="field">
                <label class="muted small">{{ ___('Tax rate (%)') }}</label>
                <input class="input" type="number" step="0.001" min="0" max="100" name="tax_rate" value="{{ old('tax_rate', 14) }}" required>
            </div>
            <div class="field" style="grid-column: 1 / -1;">
                <label class="muted small">{{ ___('Note (optional)') }}</label>
                <input class="input" name="note" value="{{ old('note') }}" placeholder="{{ ___('Reason, law article, etc.') }}">
            </div>
            <div style="grid-column: 1 / -1; display:flex; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="h">{{ ___('Tax history (latest)') }}</div>
        <div class="muted small" style="margin-bottom:6px;">{{ ___('Last 12 records') }}</div>
        <table>
            <thead>
            <tr>
                <th>{{ ___('Period') }}</th>
                <th class="right">{{ ___('Taxable') }}</th>
                <th class="right">{{ ___('Tax') }}</th>
                <th>{{ ___('Rate') }}</th>
                <th>{{ ___('Note') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($reports as $r)
                <tr>
                    <td>
                        {{ optional($r->period_start)->format('Y-m-d') ?? '—' }}
                        – {{ optional($r->period_end)->format('Y-m-d') ?? '—' }}
                    </td>
                    <td class="right">{{ number_format((float)$r->taxable_income,2) }}</td>
                    <td class="right">{{ number_format((float)$r->tax_amount,2) }}</td>
                    <td>{{ number_format((float)$r->tax_rate,3) }}%</td>
                    <td class="small">{{ $r->note ?? '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="muted">{{ ___('No tax reports yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:10px;">
            {{ $reports->links() }}
        </div>
    </div>
</div>
</div>
@endsection
