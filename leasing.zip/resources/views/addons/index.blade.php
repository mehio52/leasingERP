@extends('layouts.app')

@section('title', ___('add_ons'))
@section('page_title', ___('add_ons'))
@section('page_subtitle', ___('enable_gps_or_notifications_without_upgrading_plan'))

@section('content')
<div class="wrap">
    <div class="card slab" style="display:flex; align-items:center; justify-content:space-between;">
        <div>
            <div class="h">{{ ___('Add-ons') }}</div>
            <div class="muted small">{{ ___('Enable GPS or notifications without upgrading the whole plan.') }}</div>
        </div>
        <div style="display:flex; gap:8px;">
            <a class="btn ghost" href="{{ route('company.notifications.edit') }}">{{ ___('Notification settings') }}</a>
            <a class="btn ghost" href="{{ route('company.gps') }}">{{ ___('Fleet map') }}</a>
        </div>
    </div>

    @if (session('status'))
        <div class="card" style="border-left:4px solid #16a34a;">{{ session('status') }}</div>
    @endif
    @if(request('status') === 'success')
        <div class="card" style="border-left:4px solid #16a34a;">{{ ___('Payment successful. Add-on will activate shortly.') }}</div>
    @elseif(request('status') === 'error')
        <div class="card" style="border-left:4px solid #dc2626;">{{ ___('Payment failed. Please try again.') }}</div>
    @endif
    @if ($errors->any())
        <div class="card" style="border-left:4px solid #dc2626;">
            <ul style="margin:0; padding-left:18px;">
                @foreach ($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:12px;">
        @foreach($addons as $addon)
            @php
                $activeAddon = $active->firstWhere('addon_id', $addon->id);
                $isActive = $activeAddon && (!$activeAddon->ends_at || $activeAddon->ends_at->isFuture());
            @endphp
            <div class="card" style="display:flex; flex-direction:column; gap:8px;">
                <div style="font-weight:700;">{{ $addon->name }}</div>
                <div class="muted small">{{ $addon->description }}</div>
                <div class="muted">
                    {{ number_format((float)($addon->price_monthly ?? 0),2) }} {{ $addon->currency ?? 'AZN' }} / {{ ___('month') }}
                </div>
                <div class="muted">
                    {{ number_format((float)($addon->price_yearly ?? 0),2) }} {{ $addon->currency ?? 'AZN' }} / {{ ___('year') }}
                </div>
                <div style="display:flex; gap:8px; align-items:center;">
                    <span class="badge {{ $isActive ? 'ok' : '' }}">{{ $isActive ? ___('Active') : ___('Inactive') }}</span>
                </div>
                <div style="margin-top:auto; display:flex; gap:8px;">
                    @if(!$isActive)
                        @if($gatewayEnabled ?? false)
                            <form method="POST" action="{{ route('company.addons.store') }}" style="flex:1;">
                                @csrf
                                <input type="hidden" name="addon_code" value="{{ $addon->code }}">
                                <input type="hidden" name="billing_period" value="monthly">
                                <button class="btn primary" type="submit" style="width:100%;" @disabled((float)($addon->price_monthly ?? 0) <= 0)>{{ ___('Buy monthly') }}</button>
                            </form>
                            <form method="POST" action="{{ route('company.addons.store') }}" style="flex:1;">
                                @csrf
                                <input type="hidden" name="addon_code" value="{{ $addon->code }}">
                                <input type="hidden" name="billing_period" value="yearly">
                                <button class="btn" type="submit" style="width:100%;" @disabled((float)($addon->price_yearly ?? 0) <= 0)>{{ ___('Buy yearly') }}</button>
                            </form>
                        @else
                            <div class="muted small">{{ ___('Payment gateway is not configured.') }}</div>
                        @endif
                    @else
                        <form method="POST" action="{{ route('company.addons.destroy', $activeAddon) }}" style="flex:1;" onsubmit="return confirm('{{ ___('Disable this add-on?') }}');">
                            @csrf
                            @method('DELETE')
                            <button class="btn ghost" type="submit" style="width:100%;">{{ ___('Deactivate') }}</button>
                        </form>
                    @endif
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
