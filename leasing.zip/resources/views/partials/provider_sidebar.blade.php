@php
    $user = auth()->user();
    $provider = $user?->gpsProvider;
    $saasLogo = config('app.saas_logo');
    if (!$saasLogo) {
        try {
            $saasLogo = \App\Models\SystemSetting::query()->value('saas_logo');
        } catch (\Throwable $e) {
            $saasLogo = null;
        }
    }
    if ($saasLogo) {
        if (str_starts_with($saasLogo, '/')) {
            $saasLogo = url($saasLogo);
        }
        if (request()->isSecure() && str_starts_with($saasLogo, 'http://')) {
            $saasLogo = preg_replace('#^http://#', 'https://', $saasLogo);
        }
    }
    $providerLogoPath = $provider?->settings['logo_path'] ?? null;
    $providerLogoUrl = null;
    if ($providerLogoPath) {
        if (str_starts_with($providerLogoPath, 'http')) {
            $providerLogoUrl = $providerLogoPath;
        } elseif (str_starts_with($providerLogoPath, '/')) {
            $publicPath = public_path(ltrim($providerLogoPath, '/'));
            if (file_exists($publicPath)) {
                $providerLogoUrl = url($providerLogoPath);
            }
        } elseif (\Illuminate\Support\Facades\Storage::disk('public')->exists($providerLogoPath)) {
            $providerLogoUrl = \Illuminate\Support\Facades\Storage::disk('public')->url($providerLogoPath);
        }

        if ($providerLogoUrl && request()->isSecure() && str_starts_with($providerLogoUrl, 'http://')) {
            $providerLogoUrl = preg_replace('#^http://#', 'https://', $providerLogoUrl);
        }
    }
    $navItems = [
        ['label' => ___('Dashboard'), 'route' => 'gps_provider.dashboard', 'icon' => 'dashboard'],
        ['label' => ___('Connection requests'), 'route' => 'gps_provider.requests.index', 'icon' => 'bell', 'perm' => 'gps_provider.requests.view'],
        ['label' => ___('Vehicle requests'), 'route' => 'gps_provider.vehicle_requests.index', 'icon' => 'car', 'perm' => 'gps_provider.vehicle_requests.view'],
        ['label' => ___('Companies'), 'route' => 'gps_provider.companies.index', 'icon' => 'company', 'perm' => 'gps_provider.companies.view'],
        ['label' => ___('Vehicles'), 'route' => 'gps_provider.vehicles.index', 'icon' => 'car', 'perm' => 'gps_provider.vehicles.view'],
        ['label' => ___('Tickets'), 'route' => 'tickets.index', 'icon' => 'ticket'],
        ['label' => ___('Provider users'), 'route' => 'gps_provider.users.index', 'icon' => 'team', 'perm' => 'gps_provider.users.manage'],
        ['label' => ___('Provider settings'), 'route' => 'gps_provider.settings.edit', 'icon' => 'settings', 'perm' => 'gps_provider.settings.edit'],
    ];

    $getIcon = function (string $key) {
        $icons = require resource_path('views/partials/nav_groups.php');
        $iconMap = $icons['navGetIcon'] ?? null;
        if (is_callable($iconMap)) {
            return $iconMap($key);
        }
        return '';
    };
@endphp

<aside class="sidebar">
    <div class="sidebar-scroll">
        <div class="sidebar-head">
            <div class="brand-wrap">
                <div class="brand-icon">
                    @if($saasLogo)
                        <img src="{{ $saasLogo }}" alt="logo" style="width:28px; height:28px; object-fit:contain; display:block;">
                    @else
                        GPS
                    @endif
                </div>
                <div class="brand-text">
                    <div class="brand">{{ $provider?->name ?? 'GPS Provider' }}</div>
                    <div class="muted">{{ ___('Provider panel') }}</div>
                </div>
            </div>
            <button type="button" class="sidebar-toggle" aria-label="{{ ___('Toggle sidebar') }}">
                <span class="toggle-chev"></span>
            </button>
        </div>

        <div class="user">
            <div style="font-weight:700;">{{ $user?->first_name }} {{ $user?->last_name }}</div>
            <div class="muted">{{ $user?->role ?? ___('Guest') }}</div>
        </div>

        <nav>
            @foreach($navItems as $item)
                @php
                    if (!empty($item['perm']) && !$user?->hasPermission($item['perm'])) {
                        continue;
                    }
                    $active = request()->routeIs($item['route']);
                @endphp
                <a class="nav-link {{ $active ? 'active' : '' }}"
                   href="{{ route($item['route']) }}">
                    <span class="nav-icon">{!! $getIcon($item['icon'] ?? 'list') !!}</span>
                    <span class="nav-label">{{ $item['label'] }}</span>
                </a>
            @endforeach
        </nav>

        <div class="logout">
            <a class="btn ghost" href="{{ route('home') }}">
                <span class="nav-icon">{!! $getIcon('home') !!}</span>
                <span class="nav-label">{{ ___('Landing') }}</span>
            </a>
        </div>
    </div>
</aside>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function(){
    const toggle = document.querySelector('.sidebar-toggle');
    const body = document.body;
    const storeKey = 'sidebar-collapsed';

    try {
        if (localStorage.getItem(storeKey) === '1') {
            body.classList.add('sidebar-collapsed');
        }
    } catch (e) {}

    if (toggle) {
        toggle.addEventListener('click', function () {
            if (window.matchMedia && window.matchMedia('(max-width: 1080px)').matches) {
                body.classList.remove('sidebar-open');
                return;
            }
            body.classList.toggle('sidebar-collapsed');
            const collapsed = body.classList.contains('sidebar-collapsed');
            try { localStorage.setItem(storeKey, collapsed ? '1' : '0'); } catch (e) {}
        });
    }
});
</script>
@endpush
