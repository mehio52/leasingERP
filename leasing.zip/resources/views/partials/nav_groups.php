<?php

use Illuminate\Support\Facades\Auth;

/** @var \App\Models\User|null $navUser */

$navUser = Auth::user();
$navCompany = $navUser?->company;
$navModule = $navCompany?->moduleCode() ?? 'leasing';
$navIsRentacar = $navModule === 'rentacar';
$navIsTaxipark = $navModule === 'taxipark';
$navSubscriptionService = app(\App\Services\SubscriptionService::class);
$navFeaturesAreOpen = $navCompany ? $navSubscriptionService->featuresAreUnlimited($navCompany) : true;
$navVehicleLabel = ($navIsRentacar || $navIsTaxipark) ? ___('Cars') : ___('Vehicles');
$navCustomerLabel = $navIsRentacar ? ___('Vehicle owners') : ($navIsTaxipark ? ___('Drivers') : ___('Customers'));
$navAssetGroupLabel = $navIsRentacar ? ___('Vehicle owners & fleet') : ($navIsTaxipark ? ___('Drivers & fleet') : ___('Customers & assets'));
$navBrandLabel = $navIsRentacar ? ___('Rent a car SaaS') : ($navIsTaxipark ? ___('Taxi park SaaS') : ___('Leasing SaaS'));

// Consistent icon style (outline icons): stroke-linecap/join added
$navIcons = [
    // Core
    'dashboard' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h7v7H4z"/><path d="M13 4h7v5h-7z"/><path d="M13 11h7v9h-7z"/><path d="M4 13h7v7H4z"/></svg>',
    'company'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 21h16"/><path d="M4 7h16"/><path d="M9 3h6v4H9z"/><path d="M6 7v14"/><path d="M18 7v14"/><path d="M10 12h4"/><path d="M10 16h4"/></svg>',
    'credit'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/><path d="M8 15h3"/></svg>',
    'wallet'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V9a2 2 0 012-2z"/><path d="M18 11h3v4h-3a2 2 0 01-2-2v0a2 2 0 012-2z"/><path d="M4 7V5a2 2 0 012-2h10"/></svg>',
    'users'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
    'team'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 12a4 4 0 100-8 4 4 0 000 8z"/><path d="M6 21v-2a4 4 0 014-4h4a4 4 0 014 4v2"/><path d="M4 10.5a2.5 2.5 0 115 0A2.5 2.5 0 014 10.5z"/><path d="M3 21v-2.2c0-1.3.84-2.4 2.07-2.7"/></svg>',
    'car'       => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 16l1.5-6h11L19 16"/><path d="M6.5 10L8 6h8l1.5 4"/><circle cx="7" cy="17" r="1.2"/><circle cx="17" cy="17" r="1.2"/><path d="M5 16h14"/></svg>',
    'bank'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10h18"/><path d="M4 10v8"/><path d="M9 10v8"/><path d="M15 10v8"/><path d="M20 10v8"/><path d="M2 18h20"/><path d="M12 4l9 5H3z"/></svg>',
    'doc'       => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l5 5v11a2 2 0 01-2 2H7a2 2 0 01-2-2V5a2 2 0 012-2z"/><path d="M14 3v5h5"/></svg>',
    'home'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10l9-7 9 7"/><path d="M5 12v8a1 1 0 001 1h4v-6h4v6h4a1 1 0 001-1v-8"/></svg>',
    'bell'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0112 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 21a2 2 0 004 0"/></svg>',

    // Semantic additions
    'percent'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M19 5L5 19"/><circle cx="7" cy="7" r="2"/><circle cx="17" cy="17" r="2"/></svg>',
    'risk'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 4v5c0 4.4-3.1 8.4-8 9-4.9-.6-8-4.6-8-9V7z"/><path d="M12 8v5"/><circle cx="12" cy="15" r="1.2"/></svg>',
    'settings'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16"/><circle cx="8" cy="6" r="1.6"/><path d="M4 12h16"/><circle cx="14" cy="12" r="1.6"/><path d="M4 18h16"/><circle cx="10" cy="18" r="1.6"/></svg>',
    'history'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 109-9"/><path d="M3 4v5h5"/><path d="M12 7v6l3 2"/></svg>',
    'package'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v10l9 5 9-5V8"/><path d="M12 13v10"/></svg>',
    'layers'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l9 5-9 5-9-5 9-5z"/><path d="M3 12l9 5 9-5"/><path d="M3 17l9 5 9-5"/></svg>',
    'chat'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a4 4 0 01-4 4H8l-5 3V7a4 4 0 014-4h10a4 4 0 014 4z"/></svg>',
    'palette'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 100 18h3a2 2 0 002-2 2 2 0 00-2-2h-1a1.5 1.5 0 010-3h1a4 4 0 000-8H12z"/><circle cx="7.5" cy="10.5" r="1"/><circle cx="9.5" cy="7.5" r="1"/><circle cx="14.5" cy="7.5" r="1"/><circle cx="16.5" cy="10.5" r="1"/></svg>',
    'map'       => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l-6 3V6l6-3 6 3 6-3v15l-6 3-6-3z"/><path d="M9 3v15"/><path d="M15 6v15"/></svg>',
    'ticket'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9a2 2 0 012-2h14a2 2 0 012 2v2a2 2 0 010 4v2a2 2 0 01-2 2H5a2 2 0 01-2-2v-2a2 2 0 010-4z"/><path d="M12 7v10"/></svg>',

    // Penalty
    'penalty'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 4v5c0 4.4-3.1 8.4-8 9-4.9-.6-8-4.6-8-9V7z"/><path d="M12 8v5"/><circle cx="12" cy="15" r="1.2"/></svg>',

    // Fallback
    'list'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6h11"/><path d="M9 12h11"/><path d="M9 18h11"/><path d="M4 6h.01"/><path d="M4 12h.01"/><path d="M4 18h.01"/></svg>',

    // Crown (fill icon kept)
    'crown'     => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.5 8.2l3.9 2.6 2.6-5.2 2.6 5.2 3.9-2.6 1.8 8.3H2.7l1.8-8.3z"/><path d="M4 18.5h16v2H4z"/></svg>',
];

$navGroups = [
    [
        'label' => ___('Main'),
        'icon' => 'dashboard',
        'modules' => ['leasing','rentacar','taxipark'],
        'items' => [
            ['label' => ___('Dashboard'), 'route' => 'dashboard', 'icon' => 'dashboard'],
            ['label' => ___('Rentals'), 'route' => 'rentals.index', 'icon' => 'car', 'modules' => ['rentacar'], 'perm' => 'rentals.view', 'feature' => 'vehicles'],
            ['label' => ___('Taxi trips'), 'route' => 'company.taxi_trips.index', 'icon' => 'car', 'modules' => ['taxipark'], 'perm' => 'taxi.trips.view', 'feature' => 'taxi'],
        ],
    ],
    [
        'label' => ___('Company'),
        'icon' => 'company',
        'modules' => ['leasing','rentacar','taxipark'],
        'items' => [
            ['label' => ___('Company Options'), 'route' => 'company.options.edit', 'icon' => 'settings', 'perm' => 'settings.edit', 'feature' => 'settings'],
            ['label' => ___('Taxes'), 'route' => 'company.taxes.index', 'icon' => 'percent', 'perm' => 'settings.edit'],
            ['label' => ___('Custom domain'), 'route' => 'company.domain_requests.index', 'icon' => 'home', 'ownerOnly' => true, 'feature' => 'custom_domain'],

            ['label' => ___('Employees'), 'route' => 'company.users.index', 'active' => 'company.users.*', 'icon' => 'team', 'perm' => 'users.manage', 'feature' => 'users'],
            ['label' => ___('Owner payments'), 'route' => 'company.owner_payments.index', 'icon' => 'wallet', 'perm' => 'owner_payments.view', 'modules' => ['rentacar']],
            ['label' => ___('Rental add-ons'), 'route' => 'company.rental_addons.index', 'icon' => 'package', 'perm' => 'settings.edit', 'modules' => ['rentacar']],
            ['label' => ___('Taxi add-ons'), 'route' => 'company.taxi_addons.index', 'icon' => 'package', 'perm' => 'taxi.addons.manage', 'modules' => ['taxipark'], 'feature' => 'taxi'],
        ],
    ],
    [
        'label' => ___('Notifications'),
        'icon' => 'bell',
        'modules' => ['leasing','rentacar','taxipark'],
        'items' => [
            ['label' => ___('Notification settings'), 'route' => 'company.notifications.edit', 'icon' => 'settings', 'perm' => 'notify.edit', 'feature' => 'notifications'],
            ['label' => ___('Notification logs'), 'route' => 'company.notifications.logs', 'icon' => 'history', 'perm' => 'notify.logs', 'feature' => 'notifications'],
            ['label' => ___('Chat'), 'route' => 'company.chat.index', 'icon' => 'chat'],
            ['label' => ___('Send notification'), 'route' => 'company.notifications.form', 'icon' => 'bell', 'perm' => 'notify.send'],
        ],
    ],
    [
        'label' => ___('Public site / Theme'),
        'icon' => 'home',
        'modules' => ['leasing','rentacar','taxipark'],
        'items' => [
            ['label' => ___('Theme options'), 'route' => 'company.theme.edit', 'icon' => 'palette', 'perm' => 'public.theme', 'feature' => 'public_theme'],
            ['label' => ___('Blog posts'), 'route' => 'company.blog.index', 'icon' => 'doc', 'perm' => 'public.blog', 'feature' => 'public_theme'],
            ['label' => ___('Pages'), 'route' => 'company.pages.index', 'icon' => 'doc', 'perm' => 'public.pages', 'feature' => 'public_theme'],
            ['label' => ___('Test drives'), 'route' => 'company.test_drives.index', 'icon' => 'car', 'perm' => 'public.test_drives', 'feature' => 'public_theme'],
        ],
    ],
    [
        'label' => ___('Risk'),
        'icon' => 'risk',
        'modules' => ['leasing'],
        'items' => [
            ['label' => ___('Risk analysis'), 'route' => 'risk_assessments.create', 'icon' => 'risk', 'perm' => 'risk.create', 'feature' => 'risk'],
            ['label' => ___('Risk factors'), 'route' => 'company_options.risk_factors.index', 'icon' => 'risk', 'perm' => 'risk.view', 'feature' => 'risk'],
        ],
    ],
    [
        'label' => ___('Credit'),
        'icon' => 'credit',
        'modules' => ['leasing'],
        'items' => [
            ['label' => ___('Credit settings'), 'route' => 'company.leasing_options.edit', 'icon' => 'credit', 'perm' => 'settings.edit', 'feature' => 'settings'],
            ['label' => ___('Penalty settings'), 'route' => 'company.penalty_options.edit', 'icon' => 'penalty', 'perm' => 'settings.edit', 'feature' => 'payments'],
            ['label' => ___('Penalties'), 'route' => 'penalties.index', 'icon' => 'penalty', 'perm' => 'payments.view', 'feature' => 'payments'],
            ['label' => ___('Payment settings'), 'route' => 'company.payment_options.edit', 'icon' => 'wallet', 'perm' => 'settings.edit', 'feature' => 'payments'],
            ['label' => ___('Wallet'), 'route' => 'company.wallet.index', 'icon' => 'wallet', 'perm' => 'payments.view', 'feature' => 'payments'],
            ['label' => ___('Transactions'), 'route' => 'company.transactions.index', 'active' => 'company.transactions.*', 'icon' => 'history', 'perm' => 'payments.view|settings.edit', 'feature' => 'payments'],
            ['label' => ___('BHPH Accounts'), 'route' => 'bhph_accounts.index', 'active' => 'bhph_accounts.*', 'icon' => 'bank', 'perm' => 'bhph.view', 'feature' => 'bhph'],
        ],
    ],
    [
        'label' => $navAssetGroupLabel,
        'icon' => 'users',
        'modules' => ['leasing','rentacar','taxipark'],
        'items' => [
            ['label' => $navCustomerLabel, 'route' => 'customers.index', 'active' => 'customers.*', 'icon' => 'users', 'perm' => 'customers.view', 'feature' => 'customers'],
            ['label' => $navVehicleLabel, 'route' => 'vehicles.index', 'active' => 'vehicles.*', 'icon' => 'car', 'perm' => 'vehicles.view', 'feature' => 'vehicles'],
            ['label' => ___('Vehicle expenses'), 'route' => 'company.vehicle_expenses.index', 'active' => 'company.vehicle_expenses.*', 'icon' => 'wallet', 'perm' => 'vehicles.view', 'modules' => ['rentacar'], 'feature' => 'vehicles'],
            ['label' => ___('Vehicle authorizations'), 'route' => 'vehicles.authorizations.all', 'active' => 'vehicles.authorizations.*', 'icon' => 'doc', 'perm' => 'vehicles.view', 'feature' => 'vehicles'],
        ],
    ],
    [
        'label' => ___('Taxi park'),
        'icon' => 'car',
        'modules' => ['taxipark'],
        'items' => [
            ['label' => ___('Drivers'), 'route' => 'company.taxi_drivers.index', 'active' => 'company.taxi_drivers.*', 'icon' => 'team', 'perm' => 'taxi.drivers.view', 'feature' => 'taxi'],
            ['label' => ___('Assignments'), 'route' => 'company.taxi_assignments.index', 'active' => 'company.taxi_assignments.*', 'icon' => 'layers', 'perm' => 'taxi.assignments.view', 'feature' => 'taxi'],
            ['label' => ___('Vehicle issues'), 'route' => 'company.taxi_issues.index', 'active' => 'company.taxi_issues.*', 'icon' => 'penalty', 'perm' => 'taxi.issues.view', 'feature' => 'taxi'],
            ['label' => ___('Trips'), 'route' => 'company.taxi_trips.index', 'active' => 'company.taxi_trips.*', 'icon' => 'car', 'perm' => 'taxi.trips.view', 'feature' => 'taxi'],
            ['label' => ___('Payroll'), 'route' => 'company.taxi_payroll.index', 'active' => 'company.taxi_payroll.*', 'icon' => 'wallet', 'perm' => 'taxi.payroll.view', 'feature' => 'taxi'],
        ],
    ],
    [
        'label' => ___('Documentation'),
        'icon' => 'doc',
        'modules' => ['leasing','rentacar','taxipark'],
        'items' => [
            ['label' => ___('GPS təlimatı (Traccar)'), 'route' => 'vehicles.gps_setup', 'active' => 'vehicles.gps_setup', 'icon' => 'map', 'feature' => 'vehicles'],
            ['label' => ___('Tickets'), 'route' => 'tickets.index', 'active' => 'tickets.*', 'icon' => 'ticket'],
            ['label' => ___('Document templates'), 'route' => 'company.document_templates.index', 'active' => 'company.document_templates.*', 'icon' => 'doc', 'perm' => 'settings.edit', 'feature' => 'document_automation'],
        ],
    ],
];

$navGroups = array_values(array_filter($navGroups, function ($g) use ($navModule) {
    $mods = $g['modules'] ?? ['leasing','rentacar','taxipark'];
    return in_array($navModule, $mods, true);
}));

if (($navUser?->role ?? null) === 'superadmin') {
    $navGroups = [[
        'label' => ___('Superadmin'),
        'icon' => 'dashboard',
        'items' => [
            ['label' => ___('Overview'), 'route' => 'superadmin.dashboard', 'active' => 'superadmin.dashboard', 'icon' => 'dashboard'],
            ['label' => ___('Companies'), 'route' => 'superadmin.companies.index', 'active' => 'superadmin.companies.*', 'icon' => 'company'],
            ['label' => ___('Plans'), 'route' => 'superadmin.plans.index', 'active' => 'superadmin.plans.*', 'icon' => 'layers'],
            ['label' => ___('Addons'), 'route' => 'superadmin.addons.index', 'active' => 'superadmin.addons.*', 'icon' => 'package'],
            ['label' => ___('Platform blog'), 'route' => 'superadmin.blogs.index', 'active' => 'superadmin.blogs.*', 'icon' => 'doc'],
            ['label' => ___('Epoint transactions'), 'route' => 'superadmin.epoint.index', 'active' => 'superadmin.epoint.*', 'icon' => 'wallet'],
            ['label' => ___('GPS providers'), 'route' => 'superadmin.gps_providers.index', 'active' => 'superadmin.gps_providers.*', 'icon' => 'map'],
                ['label' => ___('Settings'), 'route' => 'superadmin.settings.edit', 'active' => 'superadmin.settings.*', 'icon' => 'settings'],
                ['label' => ___('Domain requests'), 'route' => 'superadmin.domain_requests.index', 'active' => 'superadmin.domain_requests.*', 'icon' => 'home'],
                ['label' => ___('Notifications'), 'route' => 'superadmin.notifications.form', 'active' => 'superadmin.notifications.*', 'icon' => 'bell'],
            ['label' => ___('GPS map (all)'), 'route' => 'superadmin.gps', 'active' => 'superadmin.gps', 'icon' => 'map'],
            ['label' => ___('Tickets'), 'route' => 'superadmin.tickets.index', 'active' => 'superadmin.tickets.*', 'icon' => 'ticket'],
        ],
    ]];
}

$navGetIcon = function($key) use ($navIcons) {
    return $navIcons[$key] ?? ($navIcons['list'] ?? '');
};

$navIsSuperAdmin = function() use ($navUser): bool {
    if (!$navUser) return false;
    if (!method_exists($navUser, 'isSuperAdmin')) return false;
    return (bool) $navUser->isSuperAdmin();
};

$navHasPermission = function(string $perm) use ($navUser, $navIsSuperAdmin): bool {
    if (!$navUser) return false;
    if ($navIsSuperAdmin()) return true;
    if (!method_exists($navUser, 'hasPermission')) return false;
    return (bool) $navUser->hasPermission($perm);
};

$navFilterItems = function($group) use ($navUser, $navCompany, $navIsSuperAdmin, $navHasPermission, $navModule, $navSubscriptionService, $navFeaturesAreOpen) {
    return collect($group['items'] ?? [])->filter(function($it) use ($navUser, $navCompany, $navIsSuperAdmin, $navHasPermission, $navModule, $navSubscriptionService, $navFeaturesAreOpen){
        if(!\Illuminate\Support\Facades\Route::has($it['route'])) return false;
        $mods = $it['modules'] ?? $it['module'] ?? null;
        if ($mods) {
            $mods = is_array($mods) ? $mods : [$mods];
            if (!in_array($navModule, $mods, true)) return false;
        }
        if (!empty($it['feature']) && !$navIsSuperAdmin() && !$navFeaturesAreOpen && $navCompany) {
            $required = (array) $it['feature'];
            $hasFeature = false;
            foreach ($required as $chunk) {
                foreach (preg_split('/\\|/', (string) $chunk) as $featureKey) {
                    $featureKey = trim($featureKey);
                    if ($featureKey === '') continue;
                    if ($navSubscriptionService->hasFeature($navCompany, $featureKey)) {
                        $hasFeature = true;
                        break 2;
                    }
                }
            }
            if (!$hasFeature) return false;
        }
        if(($it['ownerOnly'] ?? false) && !($navUser?->is_owner || $navUser?->role === 'owner' || $navIsSuperAdmin())) return false;
        if(!empty($it['perm']) && !($navIsSuperAdmin() || $navUser?->is_owner || $navUser?->role === 'owner' || $navHasPermission($it['perm']))) return false;
        return true;
    })->values();
};

return compact(
    'navUser',
    'navCompany',
    'navModule',
    'navBrandLabel',
    'navGroups',
    'navGetIcon',
    'navFilterItems'
);

