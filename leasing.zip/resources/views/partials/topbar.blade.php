@php
    $nav = require resource_path('views/partials/nav_groups.php');
    extract($nav, EXTR_SKIP);

    $user = $navUser;
    $company = $navCompany;
    $groups = $navGroups;
    $filterNavItems = $navFilterItems;

    $logo = $company?->logo_path ?: $company?->options?->logo_path;
    $logoUrl = null;
    if ($logo) {
        $logoUrl = (str_starts_with($logo, 'http') || str_starts_with($logo, '/'))
            ? $logo
            : \Illuminate\Support\Facades\Storage::disk('public')->url($logo);

        // Qarışıq domenləri düzəlt: mövcud hostun sxem+host-u ilə əvəzlə
        if (str_starts_with($logoUrl, 'http')) {
            $parts = parse_url($logoUrl);
            $path = $parts['path'] ?? '';
            $logoUrl = request()->getSchemeAndHttpHost() . $path;
        }
        if (request()->isSecure() && str_starts_with($logoUrl, 'http://')) {
            $logoUrl = preg_replace('#^http://#', 'https://', $logoUrl);
        }
    }
    $initial = strtoupper(substr($company?->name ?? $user?->first_name ?? 'U', 0, 1));

    $currentGroup = null;
    $currentItems = collect();
    foreach ($groups as $group) {
        $items = $filterNavItems($group);
        if ($items->isEmpty()) continue;
        foreach ($items as $it) {
            if (request()->routeIs($it['active'] ?? $it['route'])) {
                $currentGroup = $group;
                $currentItems = $items;
                break 2;
            }
        }
    }
@endphp

<header class="topbar">
    <div class="topbar-left">
        <button class="mobile-nav-btn" id="mobileSidebarToggle" type="button" data-sidebar-inline="1"
                onclick="if (!window.matchMedia || window.matchMedia('(max-width: 1080px)').matches) { document.body.classList.toggle('sidebar-open'); }"
                aria-label="{{ ___('Open menu') }}">
            <span></span><span></span><span></span>
        </button>
        <div class="topbar-titles">
            <div class="page-title">@yield('page_title', ___('panel'))</div>
            @if(trim($__env->yieldContent('page_subtitle')))
                <div class="page-subtitle">@yield('page_subtitle')</div>
            @elseif($user)
                <div class="page-subtitle">{{ $user->first_name }} {{ $user->last_name }} - {{ $user->role }}</div>
            @endif
        </div>
    </div>

    <div class="top-actions">
        <div class="lang-switch">
            @php
                $langs = ['en' => 'EN', 'az' => 'AZ', 'tr' => 'TR', 'ru' => 'RU'];
                $current = app()->getLocale();
            @endphp
            <select class="input" onchange="if(this.value) window.location=this.value;">
                @foreach($langs as $code => $label)
                    <option value="{{ route('locale.switch', $code) }}" @selected($current === $code)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <button class="theme-toggle" data-theme-toggle title="{{ ___('toggle theme') }}">{{ ___('toggle') }}</button>

        @yield('page_actions')

        <div class="notif-wrap" style="position:relative; margin-right:12px;">
            <button class="btn ghost" id="notifBell" type="button" aria-label="{{ ___('Notifications') }}">
                🔔 <span id="notifCount" class="badge" style="display:none;">0</span>
            </button>
            <div id="notifPanel" class="card" style="position:absolute; right:0; top:110%; width:320px; max-height:400px; overflow-y:auto; display:none; z-index:30;">
                <div style="font-weight:700; margin-bottom:6px;">{{ ___('Notifications') }}</div>
                <div id="notifList" style="display:flex; flex-direction:column; gap:8px;"></div>
            </div>
        </div>

        <div class="avatar-menu" data-menu>
            <button class="avatar-btn" data-menu-button type="button">
                @if($logoUrl)
                    <img src="{{ $logoUrl }}" alt="{{ ___('Logo') }}">
                @else
                    <span class="avatar-initial">{{ $initial }}</span>
                @endif
                <div style="text-align:left;">
                    <div style="font-weight:700;">{{ $company?->name ?? ___('No company assigned') }}</div>
                    <div class="muted" style="font-size:12px;">{{ $user?->first_name }} {{ $user?->last_name }}</div>
                </div>
            </button>
            <div class="menu" data-menu-panel>
                <div class="menu-item" style="cursor:default; flex-direction:column; align-items:flex-start;">
                    <div style="font-weight:700;">{{ $user?->first_name }} {{ $user?->last_name }}</div>
                    <span class="muted">{{ ___('Role:') }} {{ $user?->role ?? '-' }}</span>
                    <span class="muted">{{ ___('Company ID:') }} {{ $company?->id ?? ___('N/A') }}</span>
                </div>
                @if(session()->has('impersonator_id'))
                    <form method="POST" action="{{ route('impersonate.stop') }}" class="menu-item" style="padding:0;">
                        @csrf
                        <button class="btn warn" type="submit" style="width:100%; justify-content:center;">{{ ___('Stop impersonation') }}</button>
                    </form>
                @endif
                <div class="menu-item" style="justify-content:space-between;">
                    <span>{{ ___('theme') }}</span>
                    <button class="theme-toggle" data-theme-toggle type="button">{{ ___('toggle') }}</button>
                </div>
                <form method="POST" action="{{ route('auth.logout') }}" class="menu-item" style="padding:0;">
                    @csrf
                    <button class="btn danger" type="submit" style="width:100%; justify-content:center;">{{ ___('logout') }}</button>
                </form>
            </div>
        </div>
    </div>
</header>

@if(!request()->routeIs('dashboard'))
    <div class="subtopbar">
        <div class="subtopbar-inner">
            @if($currentGroup && $currentItems->isNotEmpty())
                <div class="subtopbar-nav">
                    <div class="subtopbar-title">{{ $currentGroup['label'] }}</div>
                    <div class="subtopbar-links">
                        @foreach($currentItems as $item)
                            @php
                                $disabled = $item['disabled'] ?? false;
                                $active = request()->routeIs($item['active'] ?? $item['route']);
                            @endphp
                            <a class="subtopbar-link {{ $active ? 'active' : '' }} {{ $disabled ? 'muted' : '' }}"
                               href="{{ $disabled ? '#' : route($item['route']) }}"
                               @if($disabled) onclick="return false;" @endif
                            >
                                {{ $item['label'] }}
                            </a>
                        @endforeach
                    </div>
                </div>
            @endif
        </div>
    </div>
@endif
