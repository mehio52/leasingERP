@php
    $size = $size ?? 22;
    $name = $name ?? $provider?->name ?? ___('GPS Provider');
    $logoPath = $logoPath ?? data_get($provider?->settings, 'logo_path');
    $logoUrl = $logoUrl ?? null;
    if (!$logoUrl && $logoPath) {
        if (str_starts_with($logoPath, 'http')) {
            $logoUrl = $logoPath;
        } elseif (str_starts_with($logoPath, '/')) {
            $publicPath = public_path(ltrim($logoPath, '/'));
            if (file_exists($publicPath)) {
                $logoUrl = url($logoPath);
            }
        } elseif (\Illuminate\Support\Facades\Storage::disk('public')->exists($logoPath)) {
            $logoUrl = \Illuminate\Support\Facades\Storage::disk('public')->url($logoPath);
        }

        if ($logoUrl && request()->isSecure() && str_starts_with($logoUrl, 'http://')) {
            $logoUrl = preg_replace('#^http://#', 'https://', $logoUrl);
        }
    }
    $initial = strtoupper(substr((string) $name, 0, 1));
@endphp

<span class="name-with-logo {{ $class ?? '' }}" style="display:inline-flex; align-items:center; gap:8px;">
    @if($logoUrl)
        <img src="{{ $logoUrl }}" alt="logo" style="width:{{ $size }}px; height:{{ $size }}px; border-radius:50%; object-fit:cover; border:1px solid var(--border); background:var(--surface);">
    @else
        <span style="width:{{ $size }}px; height:{{ $size }}px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; font-size:11px; font-weight:700; color:var(--text); background:var(--bg-soft); border:1px solid var(--border);">
            {{ $initial }}
        </span>
    @endif
    <span>{{ $name }}</span>
</span>
