@php
    $saasLogo = config('app.saas_logo');
    $nav = require resource_path('views/partials/nav_groups.php');
    extract($nav, EXTR_SKIP);

    $user = $navUser;
    $company = $navCompany;
    $module = $navModule;
    $brandLabel = $navBrandLabel;
    $groups = $navGroups;
    $getIcon = $navGetIcon;
    $filterNavItems = $navFilterItems;

    $subscriptionService = app(\App\Services\SubscriptionService::class);
    $currentSubscription = $company ? $subscriptionService->current($company) : null;

    $currentPlanLabel = $currentSubscription?->plan_name_snapshot
        ?? $currentSubscription?->plan?->name
        ?? ($company?->plan_code ? strtoupper($company->plan_code) : null);

    $featuresAreOpen = $company ? $subscriptionService->featuresAreUnlimited($company) : true;

    $currentPlanPrice = null;
    if($currentSubscription?->price_snapshot){
        $currentPlanPrice = (float) $currentSubscription->price_snapshot;
    } elseif($currentSubscription?->plan?->price_monthly) {
        $currentPlanPrice = (float) $currentSubscription->plan->price_monthly;
    } elseif($currentSubscription?->plan?->price_yearly) {
        $currentPlanPrice = (float) $currentSubscription->plan->price_yearly;
    } elseif($currentPlanLabel) {
        $lookupPlan = \App\Models\Plan::where('name', $currentPlanLabel)
            ->orWhere('code', strtolower($currentPlanLabel))
            ->first();
        if($lookupPlan?->price_monthly){
            $currentPlanPrice = (float) $lookupPlan->price_monthly;
        } elseif($lookupPlan?->price_yearly){
            $currentPlanPrice = (float) $lookupPlan->price_yearly;
        }
    }

    if (($user?->role ?? null) === 'superadmin') {
        $currentPlanLabel = null;
        $currentPlanPrice = null;
        $featuresAreOpen = true;
    }

@endphp


<aside class="sidebar">
    <div class="sidebar-scroll">
    <div class="sidebar-head">
        <div class="brand-wrap">
            @if($saasLogo)
                <div class="brand-icon" style="background:transparent; padding:0;">
                    <img src="{{ $saasLogo }}" alt="Logo" style="display:block; width:32px; height:32px; object-fit:contain;">
                </div>
            @else
                <div class="brand-icon">L</div>
            @endif
            <div class="brand-text">
                <div class="brand">{{ $brandLabel }}</div>
                <div class="muted">{{ ___('Admin panel') }}</div>
            </div>
        </div>
        <button type="button" class="sidebar-toggle" aria-label="{{ ___('Toggle sidebar') }}">
            <span class="toggle-chev"></span>
        </button>
    </div>

    <div class="user">
        <div style="font-weight:700;">{{ $user?->first_name }} {{ $user?->last_name }}</div>
        <div class="muted">{{ $user?->role ?? ___('Guest') }}</div>
        @if($user?->company_id)
            <div class="muted">Company #{{ $user->company_id }}</div>
        @endif
        @if($currentPlanLabel)
            <a href="{{ route('company.plans.index') }}" style="margin-top:6px; display:inline-flex; align-items:center; gap:6px; color:#f5c542; background:rgba(245,197,66,0.12); border:1px solid rgba(245,197,66,0.35); padding:6px 10px; border-radius:999px;">
                <span style="display:inline-flex; width:16px; height:16px; color:inherit;">{!! $getIcon('crown') !!}</span>
                <span style="font-weight:800;">{{ $currentPlanLabel }}</span>
            </a>
        @endif
    </div>

    <nav>
        @foreach($groups as $idx => $group)
            @php
                $groupId = 'grp_'.$idx;

                $items = $filterNavItems($group);

                if($items->isEmpty()) continue;

                $hasActive = false;
                foreach($items as $it){
                    if(request()->routeIs($it['active'] ?? $it['route'])) { $hasActive = true; break; }
                }
            @endphp

            <div class="nav-group {{ $hasActive ? 'open' : '' }}" data-group="{{ $groupId }}">
                <button type="button" class="nav-group-header" aria-expanded="{{ $hasActive ? 'true' : 'false' }}">
                    <span class="nav-icon">{!! $getIcon($group['icon']) !!}</span>
                    <span class="nav-label">{{ $group['label'] }}</span>
                    <span class="nav-chevron"></span>
                </button>

                <div class="nav-group-items">
                    @foreach($items as $item)
                        @php
                            $disabled = $item['disabled'] ?? false;
                            $active = request()->routeIs($item['active'] ?? $item['route']);
                        @endphp

                        <a class="nav-link {{ $active ? 'active' : '' }} {{ $disabled ? 'muted' : '' }}"
                           href="{{ $disabled ? '#' : route($item['route']) }}"
                           @if($disabled) onclick="return false;" @endif
                        >
                            <span class="nav-icon">{!! $getIcon($item['icon'] ?? 'list') !!}</span>
                            <span class="nav-label">{{ $item['label'] }}</span>

                        </a>
                    @endforeach
                </div>
            </div>
        @endforeach
    </nav>

    <div class="logout">
        <a class="btn ghost" href="{{ route('home') }}">
            <span class="nav-icon">{!! $getIcon('home') !!}</span>
            <span class="nav-label">{{ ___('Landing') }}</span>
        </a>
    </div>
    </div>
</aside>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function(){
    const toggle = document.querySelector('.sidebar-toggle');
    const body = document.body;
    const storeKey = 'sidebar-collapsed';

    try {
        if (localStorage.getItem(storeKey) === '1') {
            body.classList.add('sidebar-collapsed');
        }
    } catch (e) {}

    if (toggle) {
        toggle.addEventListener('click', function () {
            if (window.matchMedia && window.matchMedia('(max-width: 1080px)').matches) {
                body.classList.remove('sidebar-open');
                return;
            }
            body.classList.toggle('sidebar-collapsed');
            const collapsed = body.classList.contains('sidebar-collapsed');
            try { localStorage.setItem(storeKey, collapsed ? '1' : '0'); } catch (e) {}
        });
    }

    // nav group toggle
    document.querySelectorAll('.nav-group').forEach(group => {
        const header = group.querySelector('.nav-group-header');
        const gid = group.getAttribute('data-group');
        const saved = localStorage.getItem('nav-group-' + gid);

        if (saved === 'open') group.classList.add('open');
        if (saved === 'closed') group.classList.remove('open');

        if (header) {
            header.addEventListener('click', function () {
                group.classList.toggle('open');
                const isOpen = group.classList.contains('open');
                header.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
                try { localStorage.setItem('nav-group-' + gid, isOpen ? 'open' : 'closed'); } catch (e) {}
            });
        }
    });
});
</script>
@endpush
