@php
    $user = auth()->user();
    $provider = $user?->gpsProvider;
    $providerLogoPath = $provider?->settings['logo_path'] ?? null;
    $providerLogoUrl = null;
    if ($providerLogoPath) {
        if (str_starts_with($providerLogoPath, 'http')) {
            $providerLogoUrl = $providerLogoPath;
        } elseif (str_starts_with($providerLogoPath, '/')) {
            $publicPath = public_path(ltrim($providerLogoPath, '/'));
            if (file_exists($publicPath)) {
                $providerLogoUrl = url($providerLogoPath);
            }
        } elseif (\Illuminate\Support\Facades\Storage::disk('public')->exists($providerLogoPath)) {
            $providerLogoUrl = \Illuminate\Support\Facades\Storage::disk('public')->url($providerLogoPath);
        }

        if ($providerLogoUrl && request()->isSecure() && str_starts_with($providerLogoUrl, 'http://')) {
            $providerLogoUrl = preg_replace('#^http://#', 'https://', $providerLogoUrl);
        }
    }
@endphp

<header class="topbar">
    <div class="topbar-left">
        <button class="mobile-nav-btn" id="mobileSidebarToggle" type="button" data-sidebar-inline="1"
                onclick="if (!window.matchMedia || window.matchMedia('(max-width: 1080px)').matches) { document.body.classList.toggle('sidebar-open'); }"
                aria-label="{{ ___('Open menu') }}">
            <span></span><span></span><span></span>
        </button>
        <div class="topbar-titles">
            <div class="page-title">@yield('page_title', ___('provider'))</div>
            @if(trim($__env->yieldContent('page_subtitle')))
                <div class="page-subtitle">@yield('page_subtitle')</div>
            @else
                <div class="page-subtitle">
                    @include('partials.provider_label', ['provider' => $provider, 'size' => 16])
                </div>
            @endif
        </div>
    </div>

    <div class="top-actions">
        <div class="lang-switch">
            @php
                $langs = ['en' => 'EN', 'az' => 'AZ', 'tr' => 'TR', 'ru' => 'RU'];
                $current = app()->getLocale();
            @endphp
            <select class="input" onchange="if(this.value) window.location=this.value;">
                @foreach($langs as $code => $label)
                    <option value="{{ route('locale.switch', $code) }}" @selected($current === $code)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <button class="theme-toggle" data-theme-toggle title="{{ ___('toggle theme') }}">{{ ___('toggle') }}</button>

        @yield('page_actions')

        <div class="avatar-menu" data-menu>
            <button class="avatar-btn" data-menu-button type="button">
                @if($providerLogoUrl)
                    <img src="{{ $providerLogoUrl }}" alt="logo">
                @else
                    <span class="avatar-initial">{{ strtoupper(substr($provider?->name ?? $user?->first_name ?? 'G', 0, 1)) }}</span>
                @endif
                <div style="text-align:left;">
                    <div style="font-weight:700;">{{ $provider?->name ?? 'GPS Provider' }}</div>
                    <div class="muted" style="font-size:12px;">{{ $user?->first_name }} {{ $user?->last_name }}</div>
                </div>
            </button>
            <div class="menu" data-menu-panel>
                <div class="menu-item" style="cursor:default; flex-direction:column; align-items:flex-start;">
                    <div style="font-weight:700;">{{ $user?->first_name }} {{ $user?->last_name }}</div>
                    <span class="muted">{{ ___('Role:') }} {{ $user?->role ?? '-' }}</span>
                </div>
                <div class="menu-item" style="justify-content:space-between;">
                    <span>{{ ___('theme') }}</span>
                    <button class="theme-toggle" data-theme-toggle type="button">{{ ___('toggle') }}</button>
                </div>
                <form method="POST" action="{{ route('auth.logout') }}" class="menu-item" style="padding:0;">
                    @csrf
                    <button class="btn danger" type="submit" style="width:100%; justify-content:center;">{{ ___('logout') }}</button>
                </form>
            </div>
        </div>
    </div>
</header>
