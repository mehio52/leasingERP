<footer class="footer">
    Leasing SaaS - {{ now()->format('Y') }}
</footer>
