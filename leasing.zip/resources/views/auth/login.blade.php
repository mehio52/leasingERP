@extends('layouts.guest')

@extends('layouts.auth')
@php
    $errors = $errors ?? session('errors') ?? new \Illuminate\Support\ViewErrorBag;
    $bg = 'linear-gradient(135deg, #0f172a 0%, #111827 50%, #1f2937 100%)';
@endphp
@section('title', ___('Login'))
@section('content')
<div style="min-height:100vh; display:flex; align-items:center; justify-content:center; background:{{$bg}}; font-family:Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color:#e5e7eb; padding:20px;">
    <div style="width:100%; max-width:980px; display:grid; grid-template-columns:1.1fr 0.9fr; gap:18px;">
        <div style="background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:16px; padding:22px;">
            <div style="font-size:15px; letter-spacing:2px; color:#9ca3af; text-transform:uppercase;">Leasing ERP</div>
            <div style="font-size:28px; font-weight:800; margin:8px 0 10px;">{{ ___('Giriş paneli') }}</div>
            <div style="color:#cbd5e1; font-size:15px; line-height:1.5;">Avtomobillərin izlənməsi, müqavilələr və ödənişlər üçün vahid panel. Hesabınız yoxdursa, şirkətinizi qeydiyyatdan keçirin.</div>
            <ul style="margin:14px 0 0; padding-left:18px; color:#a5b4fc; font-size:14px; line-height:1.5;">
                <li>GPS inteqrasiya (Traccar)</li>
                <li>Müqavilə və BHPH idarəetməsi</li>
                <li>Risk, bildiriş və chat modulları</li>
            </ul>
        </div>
        <div style="background:#0b1220; border:1px solid rgba(255,255,255,0.08); border-radius:16px; padding:22px; box-shadow:0 20px 40px rgba(0,0,0,0.35);">
            <div style="font-weight:700; font-size:18px; margin-bottom:12px;">{{ ___('Hesabınıza daxil olun') }}</div>

            @if ($errors->any())
                <div style="background:#fee2e2; color:#991b1b; padding:10px 12px; border-radius:10px; margin-bottom:12px;">
                    <ul style="margin:0; padding-left:18px;">
                        @foreach ($errors->all() as $e)
                            <li>{{ $e }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @if(session('status'))
                <div style="background:#dcfce7; color:#14532d; padding:10px 12px; border-radius:10px; margin-bottom:12px;">
                    {{ session('status') }}
                </div>
            @endif

            <form method="POST" action="{{ route('auth.login') }}" style="display:flex; flex-direction:column; gap:12px;">
                @csrf
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Telefon') }}</label>
                    <input name="phone" value="{{ old('phone') }}" placeholder="+994501234567" class="js-phone" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Şifrə') }}</label>
                    <input type="password" name="password" placeholder="••••••••" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                </div>
                <button type="submit" style="padding:12px; border-radius:10px; border:none; background:linear-gradient(135deg,#2563eb,#4f46e5); color:white; font-weight:700; cursor:pointer;">{{ ___('Daxil ol') }}</button>
            </form>

            <div style="margin-top:16px; padding-top:12px; border-top:1px solid #1f2a44;">
                <form method="POST" action="{{ route('auth.forgot') }}" style="display:flex; flex-direction:column; gap:8px;">
                    @csrf
                    <label style="color:#cbd5e1; font-size:14px;">{{ ___('Şifrəni unutmusunuz? Telefonu yazın, owner təsdiqləsin:') }}</label>
                    <div style="display:flex; gap:8px;">
                        <input name="phone" value="{{ old('phone_forgot') }}" placeholder="+994501234567" class="js-phone" style="flex:1; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                        <button type="submit" style="padding:12px 14px; border-radius:10px; border:1px solid #4b5563; background:transparent; color:#e5e7eb; cursor:pointer;">{{ ___('Göndər') }}</button>
                    </div>
                </form>
            </div>

            <div style="margin-top:16px; text-align:center; color:#9ca3af;">
                {{ ___('Şirkətiniz yoxdur?') }}
                <a href="{{ route('company.register.form') }}" style="color:#a5b4fc; font-weight:700;">{{ ___('Şirkəti qeydiyyatdan keçir') }}</a>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    (function(){
        document.querySelectorAll('.js-phone').forEach(inp => {
            inp.addEventListener('input', () => {
                let v = inp.value.replace(/[^0-9+]/g, '');
                if(!v.startsWith('+994')) {
                    if(v.startsWith('994')) v = '+' + v;
                    else if(v.startsWith('0')) v = '+994' + v.substring(1);
                }
                if(v.length > 16) v = v.substring(0,16);
                inp.value = v;
            });
        });
    })();
</script>
@endpush
