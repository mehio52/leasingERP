@section('title', ___('Company registration'))

@extends('layouts.auth')
@php
    $errors = $errors ?? session('errors') ?? new \Illuminate\Support\ViewErrorBag;
    $bg = 'linear-gradient(135deg, #0f172a 0%, #0b1220 50%, #131a2e 100%)';
@endphp
@section('title', ___('Company registration'))
@section('content')
<div style="min-height:100vh; display:flex; align-items:center; justify-content:center; background:{{$bg}}; font-family:Inter, system-ui, -apple-system, BlinkMacSystemFont, \'Segoe UI\', sans-serif; color:#e5e7eb; padding:20px;">
    <div style="width:100%; max-width:1040px; display:grid; grid-template-columns:1fr 1fr; gap:18px;">
        <div style="background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:16px; padding:22px;">
            <div style="font-size:14px; letter-spacing:2px; color:#9ca3af; text-transform:uppercase;">Leasing ERP</div>
            <div style="font-size:28px; font-weight:800; margin:8px 0 10px;">{{ ___('Şirkət qeydiyyatı') }}</div>
            <div style="color:#cbd5e1; font-size:15px; line-height:1.5;">Yeni leasing şirkəti yaradın, sahib (owner) hesabı daxil edin və dərhal trial planı ilə başlayın.</div>
            <ul style="margin:14px 0 0; padding-left:18px; color:#a5b4fc; font-size:14px; line-height:1.5;">
                <li>GPS və müqavilə modulları</li>
                <li>BHPH, risk, bildiriş sistemi</li>
                <li>Public sayt və tema seçimi</li>
            </ul>
            <div style="margin-top:16px; color:#9ca3af; font-size:14px;">
                {{ ___('Artıq hesabınız var?') }}
                <a href="{{ route('login') }}" style="color:#a5b4fc; font-weight:700;">{{ ___('Giriş et') }}</a>
            </div>
        </div>
        <div style="background:#0b1220; border:1px solid rgba(255,255,255,0.08); border-radius:16px; padding:22px; box-shadow:0 20px 40px rgba(0,0,0,0.35);">
            <div style="font-weight:700; font-size:18px; margin-bottom:12px;">{{ ___('Şirkət məlumatları') }}</div>

            @if ($errors->any())
                <div style="background:#fee2e2; color:#991b1b; padding:10px 12px; border-radius:10px; margin-bottom:12px;">
                    <ul style="margin:0; padding-left:18px;">
                        @foreach ($errors->all() as $e)
                            <li>{{ $e }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('company.register') }}" style="display:flex; flex-direction:column; gap:12px;">
                @csrf
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Şirkətin adı') }}</label>
                    <input name="company_name" value="{{ old('company_name') }}" placeholder="Example Leasing" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Şirkət telefonu') }}</label>
                    <input name="company_phone" value="{{ old('company_phone') }}" placeholder="+994501234567" class="js-phone" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Module') }}</label>
                    <select name="module" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                        <option value="leasing" @selected(old('module', 'leasing') === 'leasing')>{{ ___('Leasing') }}</option>
                        <option value="rentacar" @selected(old('module') === 'rentacar')>{{ ___('Rent a car') }}</option>
                        <option value="taxipark" @selected(old('module') === 'taxipark')>{{ ___('Taxi park') }}</option>
                    </select>
                </div>

                <div style="font-weight:700; margin-top:8px;">{{ ___('Owner məlumatları') }}</div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Ad') }}</label>
                        <input name="owner_first_name" value="{{ old('owner_first_name') }}" placeholder="Ad" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Soyad') }}</label>
                        <input name="owner_last_name" value="{{ old('owner_last_name') }}" placeholder="Soyad" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                    </div>
                </div>
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Owner telefonu') }}</label>
                    <input name="owner_phone" value="{{ old('owner_phone') }}" placeholder="+994501234567" class="js-phone" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Şifrə') }}</label>
                    <input type="password" name="password" placeholder="•••••••" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:6px; color:#cbd5e1; font-size:14px;">{{ ___('Şifrə təsdiq') }}</label>
                    <input type="password" name="password_confirmation" placeholder="•••••••" style="width:100%; padding:12px; border-radius:10px; border:1px solid #1f2a44; background:#0e1627; color:#e5e7eb;">
                </div>

                <button type="submit" style="padding:12px; border-radius:10px; border:none; background:linear-gradient(135deg,#2563eb,#4f46e5); color:white; font-weight:700; cursor:pointer;">{{ ___('Qeydiyyatı tamamla') }}</button>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    (function(){
        document.querySelectorAll('.js-phone').forEach(inp => {
            inp.addEventListener('input', () => {
                let v = inp.value.replace(/[^0-9+]/g, '');
                if(!v.startsWith('+994')) {
                    if(v.startsWith('994')) v = '+' + v;
                    else if(v.startsWith('0')) v = '+994' + v.substring(1);
                }
                if(v.length > 16) v = v.substring(0,16);
                inp.value = v;
            });
        });
    })();
</script>
@endpush
