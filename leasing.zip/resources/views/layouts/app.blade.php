<!doctype html>
<html lang="az">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Leasing Panel')</title>
    @php
        $panelCssPath = public_path('css/panel.css');
        $panelCssVer = file_exists($panelCssPath) ? filemtime($panelCssPath) : time();
        $panelJsPath = public_path('js/panel.js');
        $panelJsVer = file_exists($panelJsPath) ? filemtime($panelJsPath) : time();
    @endphp
    <link rel="stylesheet" href="{{ asset('css/panel.css') }}?v={{ $panelCssVer }}">
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/pusher-js@8.4.0/dist/web/pusher.min.js"></script>
    <script src="https://unpkg.com/laravel-echo@1.15.0/dist/echo.iife.js"></script>
    <script>
        window.ReverbConfig = {
            key: "{{ env('REVERB_APP_KEY', '') }}",
            host: "{{ env('REVERB_HOST', request()->getHost()) }}",
            port: Number("{{ env('REVERB_PORT', 8080) }}"),
            scheme: "{{ env('REVERB_SCHEME', 'http') }}",
            user_id: {{ auth()->id() ?? 'null' }},
            company_id: {{ auth()->user()->company_id ?? 'null' }},
            is_superadmin: {{ auth()->user()?->isSuperAdmin() ? 'true' : 'false' }},
            is_owner: {{ (auth()->user()?->is_owner || auth()->user()?->role === 'owner') ? 'true' : 'false' }},
        };
    </script>
    @stack('styles')
</head>
<body data-theme="dark">
<div class="app-shell">
    @include('partials.sidebar')
    <div id="sidebarOverlay" class="sidebar-overlay"></div>

    <div class="main">
        @include('partials.topbar')

        @if(session()->has('impersonator_id') && auth()->check())
            <div style="padding:10px 16px; background:var(--warning-bg,#332600); color:var(--warning-text,#ffecb5); display:flex; align-items:center; gap:10px; justify-content:space-between;">
                <div>
                    <strong>{{ ___('Impersonating') }}:</strong>
                    <span>{{ auth()->user()->full_name }} ({{ auth()->user()->email ?? auth()->user()->phone }})</span>
                </div>
                <form method="POST" action="{{ route('impersonate.stop') }}">
                    @csrf
                    <button class="btn warn" type="submit">{{ ___('Stop impersonation') }}</button>
                </form>
            </div>
        @endif

        <main class="page">
            <div class="page-inner">
                @yield('content')
            </div>
        </main>

        @include('partials.footer')
    </div>
</div>
<script src="{{ asset('js/panel.js') }}?v={{ $panelJsVer }}" defer></script>
@stack('scripts')
</body>
</html>
