<!doctype html>
<html lang="az">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'GPS Provider Panel')</title>
    @php
        $panelCssPath = public_path('css/panel.css');
        $panelCssVer = file_exists($panelCssPath) ? filemtime($panelCssPath) : time();
        $panelJsPath = public_path('js/panel.js');
        $panelJsVer = file_exists($panelJsPath) ? filemtime($panelJsPath) : time();
    @endphp
    <link rel="stylesheet" href="{{ asset('css/panel.css') }}?v={{ $panelCssVer }}">
    <script>
        window.ReverbConfig = {
            key: "{{ env('REVERB_APP_KEY', '') }}",
            host: "{{ env('REVERB_HOST', request()->getHost()) }}",
            port: Number("{{ env('REVERB_PORT', 8080) }}"),
            scheme: "{{ env('REVERB_SCHEME', 'http') }}",
            user_id: {{ auth()->id() ?? 'null' }},
            company_id: null,
            is_superadmin: {{ auth()->user()?->isSuperAdmin() ? 'true' : 'false' }},
            is_owner: false,
        };
    </script>
    @stack('styles')
</head>
<body data-theme="dark">
<div class="app-shell">
    @include('partials.provider_sidebar')
    <div id="sidebarOverlay" class="sidebar-overlay"></div>

    <div class="main">
        @include('partials.provider_topbar')

        <main class="page">
            <div class="page-inner">
                @yield('content')
            </div>
        </main>

        @include('partials.footer')
    </div>
</div>
<script src="{{ asset('js/panel.js') }}?v={{ $panelJsVer }}" defer></script>
@stack('scripts')
</body>
</html>
