<!doctype html>
<html lang="az">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Auth')</title>
    <link rel="stylesheet" href="{{ asset('css/panel.css') }}">
    @stack('styles')
</head>
<body style="margin:0; padding:0;">
@yield('content')
@stack('scripts')
</body>
</html>
