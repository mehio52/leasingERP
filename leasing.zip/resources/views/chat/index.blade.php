@extends('layouts.app')

@section('title', ___('Chat'))
@section('page_title', ___('Chat'))
@section('content')
<div class="card" style="display:flex; gap:12px; min-height:400px;">
    <div style="width:240px; border-right:1px solid #2c2c40; padding-right:12px;">
        <div style="font-weight:700; margin-bottom:8px;">{{ ___('Rooms') }}</div>
        <ul style="list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:6px;">
            @foreach($rooms as $room)
                <li>
                    <button class="btn ghost chat-room-btn" data-room-id="{{ $room->id }}" style="width:100%; justify-content:flex-start;">
                        {{ $room->name ?? 'Chat #'.$room->id }}
                    </button>
                </li>
            @endforeach
        </ul>
        @if(auth()->user()->is_owner || auth()->user()->role === 'owner' || auth()->user()->isSuperAdmin())
            <form id="newRoomForm" style="margin-top:12px;">
                @csrf
                <input class="input" name="name" placeholder="{{ ___('Group name') }}">
                <button class="btn primary" type="submit" style="margin-top:6px;">{{ ___('Create group') }}</button>
            </form>
        @endif
    </div>
    <div style="flex:1; display:flex; flex-direction:column;">
        <div id="chatMessages" style="flex:1; overflow-y:auto; border:1px solid #2c2c40; border-radius:10px; padding:12px; background:#0d1025;">
            @foreach($messages as $m)
                <div data-msg-id="{{ $m->id }}" style="margin-bottom:8px;">
                    <div style="font-weight:700;">{{ $m->user?->full_name ?? 'User' }} <span class="muted small">{{ $m->created_at }}</span></div>
                    <div>{{ $m->message }}</div>
                </div>
            @endforeach
        </div>
        <form id="chatForm" style="margin-top:10px; display:flex; gap:8px;">
            @csrf
            <input type="hidden" id="activeRoomId" value="{{ $activeRoom?->id }}">
            <input class="input" id="chatMessageInput" name="message" placeholder="{{ ___('Type message') }}" style="flex:1;">
            <button class="btn primary" type="submit">{{ ___('Send') }}</button>
        </form>
    </div>
</div>
@push('scripts')
<script>
    const chatState = {
        roomId: document.getElementById('activeRoomId')?.value || null
    };
    window.addMessage = function addMessage(m){
        const box = document.getElementById('chatMessages');
        if(!box) return;
        const div = document.createElement('div');
        div.dataset.msgId = m.id;
        div.style.marginBottom = '8px';
        div.innerHTML = `<div style="font-weight:700;">${m.user_name || m.user?.full_name || 'User'} <span class="muted small">${m.created_at}</span></div><div>${m.message}</div>`;
        box.appendChild(div);
        box.scrollTop = box.scrollHeight;
    }
    document.querySelectorAll('.chat-room-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const roomId = btn.dataset.roomId;
            chatState.roomId = roomId;
            document.getElementById('activeRoomId').value = roomId;
            const res = await fetch(`/company/chat/rooms/${roomId}/messages`);
            if(res.ok){
                const json = await res.json();
                const box = document.getElementById('chatMessages');
                box.innerHTML = '';
                json.forEach(addMessage);
            }
        });
    });
    document.getElementById('chatForm')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const roomId = chatState.roomId;
        if(!roomId) return;
        const input = document.getElementById('chatMessageInput');
        const msg = input.value.trim();
        if(!msg) return;
        const res = await fetch(`/company/chat/rooms/${roomId}/messages`, {
            method:'POST',
            headers:{'X-CSRF-TOKEN': document.querySelector('meta[name=\"csrf-token\"]').content},
            body: new URLSearchParams({message: msg})
        });
        if(res.ok){
            input.value = '';
        }
    });
    document.getElementById('newRoomForm')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const form = e.target;
        const fd = new FormData(form);
        const res = await fetch('/company/chat/rooms', {method:'POST', headers:{'X-CSRF-TOKEN': document.querySelector('meta[name=\"csrf-token\"]').content}, body: fd});
        if(res.ok){
            alert('Grup yaradıldı');
            location.reload();
        }
    });
</script>
@endpush
@endsection
