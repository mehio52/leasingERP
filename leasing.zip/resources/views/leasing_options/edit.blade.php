@extends('layouts.app')

@section('title', ___('Leasing Settings'))
@section('page_title', ___('Leasing Settings'))
@section('page_subtitle')
Company ID: {{ $options->company_id }} - User: {{ $user->first_name }} {{ $user->last_name }}
@endsection

@section('content')
@if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @php
        $settingsAssoc = $options->settings ?? [];
        $settingsOldK = old('settings_k');
        $settingsOldV = old('settings_v');

        if (is_array($settingsOldK) && is_array($settingsOldV)) {
            $rows = [];
            foreach ($settingsOldK as $idx => $k) {
                $rows[] = ['k' => $k, 'v' => $settingsOldV[$idx] ?? ''];
            }
        } else {
            $rows = [];
            if (is_array($settingsAssoc)) {
                foreach ($settingsAssoc as $k => $v) {
                    $rows[] = ['k' => $k, 'v' => is_scalar($v) ? (string)$v : json_encode($v, JSON_UNESCAPED_UNICODE)];
                }
            }
        }
    @endphp

    <form class="grid" method="POST" action="{{ route('company.leasing_options.update') }}">
        @csrf

        <div class="card">
            <div class="h">{{ ___('Core rules') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Amortization method') }}</label>
                    <select name="amortization_method">
                        <option value="annuity" @selected(old('amortization_method', $options->amortization_method) === 'annuity')>{{ ___('Annuity') }}</option>
                        <option value="reducing_balance" @selected(old('amortization_method', $options->amortization_method) === 'reducing_balance')>{{ ___('Reducing balance') }}</option>
                        <option value="flat" @selected(old('amortization_method', $options->amortization_method) === 'flat')>{{ ___('Flat') }}</option>
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('Payment frequency') }}</label>
                    <select name="payment_frequency">
                        <option value="monthly" @selected(old('payment_frequency', $options->payment_frequency) === 'monthly')>{{ ___('Monthly') }}</option>
                        <option value="weekly" @selected(old('payment_frequency', $options->payment_frequency) === 'weekly')>{{ ___('Weekly') }}</option>
                        <option value="biweekly" @selected(old('payment_frequency', $options->payment_frequency) === 'biweekly')>{{ ___('Every 2 weeks') }}</option>
                    </select>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Allocation order') }}</label>
                    <select name="allocation_order">
                        <option value="interest_first" @selected(old('allocation_order', $options->allocation_order) === 'interest_first')>{{ ___('Interest first') }}</option>
                        <option value="principal_first" @selected(old('allocation_order', $options->allocation_order) === 'principal_first')>{{ ___('Principal first') }}</option>
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('Grace days') }}</label>
                    <input name="grace_days" value="{{ old('grace_days', $options->grace_days) }}" placeholder="{{ ___('0') }}">
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Late fee') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Late fee type') }}</label>
                    <select name="late_fee_type" id="lateFeeType">
                        <option value="none" @selected(old('late_fee_type', $options->late_fee_type) === 'none')>{{ ___('None') }}</option>
                        <option value="fixed" @selected(old('late_fee_type', $options->late_fee_type) === 'fixed')>{{ ___('Fixed amount') }}</option>
                        <option value="percent" @selected(old('late_fee_type', $options->late_fee_type) === 'percent')>{{ ___('Percentage') }}</option>
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('Late fee value') }}</label>
                    <input name="late_fee_value" id="lateFeeValue" value="{{ old('late_fee_value', $options->late_fee_value) }}" placeholder="{{ ___('0') }}">
                    <div class="muted">{{ ___('Fixed: AZN, Percentage: %') }}</div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Rounding step') }}</label>
                    <input name="rounding_step" value="{{ old('rounding_step', $options->rounding_step) }}" placeholder="{{ ___('0.01') }}">
                    <div class="muted">{{ ___('e.g. 0.01 / 0.05 / 0.1') }}</div>
                </div>

                <div class="field" style="flex-direction:row; align-items:center; gap:10px;">
                    <input style="width:auto;" type="checkbox" name="allow_partial_payments" value="1"
                           @checked(old('allow_partial_payments', (int)$options->allow_partial_payments) === 1)>
                    <label style="margin:0;">{{ ___('Allow partial payments') }}</label>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Note') }}</div>
            <div class="field">
                <label>{{ ___('Internal note') }}</label>
                <textarea name="notes" rows="4" placeholder="{{ ___('Internal note...') }}">{{ old('notes', $options->notes) }}</textarea>
            </div>
        </div>

        <div class="card">
            <div class="h">{{ ___('Parameters (key/value)') }}</div>
            <div class="muted" style="margin-bottom:10px;">{{ ___('Any parameter as key/value. Add more with “+”.') }}</div>

            <div id="settingsRows" style="display:grid; gap:10px;">
                @foreach($rows as $i => $row)
                    <div class="settings-row" style="display:grid; grid-template-columns: 260px 1fr 90px; gap:10px; align-items:center;">
                        <input name="settings_k[{{ $i }}]" value="{{ $row['k'] ?? '' }}" placeholder="{{ ___('key (e.g. schedule.rounding_mode)') }}">
                        <input name="settings_v[{{ $i }}]" value="{{ $row['v'] ?? '' }}" placeholder="{{ ___('value (e.g. nearest)') }}">
                        <button type="button" class="btn danger settings-remove">{{ ___('Delete') }}</button>
                    </div>
                @endforeach
            </div>

            <div class="actions" style="justify-content:flex-start;">
                <button type="button" class="btn" id="settingsAdd">{{ ___('+ Add') }}</button>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </div>

    </form>
</div>

<script>
(function(){
    // Late fee type -> disable value input
    const type = document.getElementById('lateFeeType');
    const val  = document.getElementById('lateFeeValue');

    function syncLateFee(){
        if (!type || !val) return;
        const none = (type.value === 'none');
        val.disabled = none;
        if (none) val.value = '0';
    }
    type?.addEventListener('change', syncLateFee);
    syncLateFee();

    // Parameters (+ / delete)
    const settingsRows = document.getElementById('settingsRows');
    const settingsAdd  = document.getElementById('settingsAdd');

    function nextSettingsIndex(){
        return settingsRows.querySelectorAll('.settings-row').length;
    }

    function settingsRowHtml(i){
        return `
        <div class="settings-row" style="display:grid; grid-template-columns: 260px 1fr 90px; gap:10px; align-items:center;">
            <input name="settings_k[${i}]" value="" placeholder="{{ ___('key (e.g. schedule.rounding_mode)') }}">
            <input name="settings_v[${i}]" value="" placeholder="{{ ___('value (e.g. nearest)') }}">
            <button type="button" class="btn danger settings-remove">{{ ___('Delete') }}</button>
        </div>`;
    }

    settingsAdd?.addEventListener('click', () => {
        const i = nextSettingsIndex();
        settingsRows.insertAdjacentHTML('beforeend', settingsRowHtml(i));
    });

    settingsRows?.addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('settings-remove')) {
            e.target.closest('.settings-row')?.remove();
        }
    });
})();
</script>
@endsection