<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Payment' }}</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f8fafc; color:#0f172a; margin:0; }
        .wrap { max-width: 860px; margin: 32px auto; padding: 0 16px; }
        .card { background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:16px; }
        .btn { padding:10px 14px; border-radius:8px; border:1px solid #0f172a; background:#0f172a; color:white; text-decoration:none; display:inline-block; }
        .muted { color:#475569; }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="card">
            <h2 style="margin-top:0;">{{ $title ?? 'Payment' }}</h2>
            <div class="muted" style="margin-bottom:12px;">
                {{ ___('Complete your card payment below.') }}
            </div>
            {!! $checkoutFormContent !!}
            <div style="margin-top:16px;">
                <a class="btn" href="{{ $returnUrl ?? url('/') }}">{{ ___('Back') }}</a>
            </div>
        </div>
    </div>
</body>
</html>
