@extends('layouts.app')

@section('title', ___('Edit Installment'))
@section('page_title', ___('Installment #{{ $amortization->installment_no }} - BHPH #{{ $account->id }}'))
@section('page_subtitle', ___('Customer: {{ $account->customer?->first_name }} {{ $account->customer?->last_name }}'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('bhph_accounts.show', $account) }}">{{ ___('Back') }}</a>
@endsection

@section('content')
@if($errors->any())
        <div class="banner">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div style="font-weight:700; margin-bottom:8px;">{{ ___('Schedule details') }}</div>
        <div class="kv"><span class="muted">{{ ___('Due date') }}</span><span>{{ \Carbon\Carbon::parse($amortization->due_date)->format('Y-m-d') }}</span></div>
        <div class="kv"><span class="muted">{{ ___('Due amount') }}</span><span><b>{{ number_format((float)$amortization->due_amount,2) }} {{ $currencyCode ?? 'AZN' }}</b></span></div>
        <div class="kv"><span class="muted">{{ ___('Interest due') }}</span><span>{{ number_format((float)$amortization->paid_interest,2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
        <div class="kv"><span class="muted">{{ ___('Principal due') }}</span><span>{{ number_format((float)$amortization->paid_principal,2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
        <div class="kv"><span class="muted">{{ ___('Remaining balance') }}</span><span>{{ number_format((float)$amortization->remaining_balance,2) }} {{ $currencyCode ?? 'AZN' }}</span></div>
        <div class="kv"><span class="muted">{{ ___('Status') }}</span><span><b>{{ $amortization->status }}</b></span></div>
    </div>

    <div class="card">
        <form method="POST" action="{{ route('amortization.update', ['account'=>$account->id,'amortization'=>$amortization->id]) }}">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="field">
                    <label>{{ ___('Due date (edit)') }}</label>
                    <input type="date" name="due_date" value="{{ old('due_date', \Carbon\Carbon::parse($amortization->due_date)->toDateString()) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Paid amount (actual paid)') }}</label>
                    <input id="paid_amount" name="paid_amount" value="{{ old('paid_amount', $amortization->paid_amount) }}" required>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Paid date (optional)') }}</label>
                    <input type="date" name="paid_date" value="{{ old('paid_date', $amortization->paid_date ? \Carbon\Carbon::parse($amortization->paid_date)->toDateString() : '') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Quick actions') }}</label>
                    <div class="actions" style="justify-content:flex-start;">
                        <button class="btn ok" type="button" onclick="setFullPaid()">{{ ___('Pay in full (up to due)') }}</button>
                        <button class="btn danger" type="button" onclick="clearPaid()">{{ ___('Reset') }}</button>
                    </div>
                </div>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>
</div>

<script>
function setFullPaid(){
    document.getElementById('paid_amount').value = "{{ number_format((float)$amortization->due_amount, 2, '.', '') }}";
}
function clearPaid(){
    document.getElementById('paid_amount').value = "0";
}
</script>
@endsection