﻿@extends('layouts.app')

@section('title', ___('GPS tracking'))
@section('page_title', ___('GPS tracking'))
@section('page_subtitle')
    {{ $vehicle->display_name }} (ID #{{ $vehicle->id }})
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.index') }}">{{ ___('Back') }}</a>
@endsection

@push('styles')
@php
    $googleMapsKey = config('services.google_maps.key');
    $useGoogleMaps = !empty($googleMapsKey);
@endphp
@if(!$useGoogleMaps)
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
<link rel="stylesheet" href="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css" />
@endif
<style>
    #map { height: 360px; border-radius:12px; overflow:hidden; border:1px solid var(--border); }
    .geofence-actions { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
    .geofence-actions .btn { height: 40px; }
    .map-layer-toggle { display:flex; gap:6px; flex-wrap:wrap; }
    .map-layer-toggle .btn { height:28px; padding:0 10px; font-size:12px; }
    .map-layer-toggle .btn.active { border-color:#3b82f6; color:#3b82f6; }
</style>
@endpush

@section('content')
@php
    $gpsInitial = $position ?? null;
    $gpsWsUrl = $wsUrl ?? null;
    $gpsWsToken = $wsToken ?? null;
    $gpsProvider = $provider;
    $gpsDeviceId = $position['device_id']
        ?? ($gpsProvider === 'wialon'
            ? $vehicle->wialon_device_id
            : ($gpsProvider === 'traccar' ? $vehicle->traccar_device_id : null))
        ?? null;
    $isRentacar = in_array(($module ?? 'leasing'), ['rentacar','taxipark'], true);
    $googleMapsKey = config('services.google_maps.key');
    $useGoogleMaps = !empty($googleMapsKey);
@endphp
<div class="wrap">
    @if($error)
        <div class="banner error">
            <span class="badge bad">{{ ___('Error') }}</span>
            <span style="margin-left:10px;">{{ $error }}</span>
        </div>
    @endif

    <div class="card">
        <div class="h">{{ ___('Device info') }}</div>
        <div class="row">
            <div class="field">
                <div class="muted small">{{ ___('GPS provider') }}</div>
                <div style="font-weight:700;">
                    {{ $gpsProvider === 'wialon' ? 'Wialon' : ($gpsProvider === 'traccar' ? 'Traccar' : ___('Not connected')) }}
                </div>
            </div>
            <div class="field">
                <div class="muted small">
                    {{ $gpsProvider === 'wialon'
                        ? ___('Wialon unit ID')
                        : ($gpsProvider === 'traccar' ? ___('Traccar device ID') : ___('Device ID')) }}
                </div>
                <div style="font-weight:700;">
                    {{ $gpsProvider === 'wialon'
                        ? ($vehicle->wialon_device_id ?? '-')
                        : ($gpsProvider === 'traccar' ? ($vehicle->traccar_device_id ?? '-') : '-') }}
                </div>
            </div>
            <div class="field">
                <div class="muted small">{{ ___('Plate number') }}</div>
                <div style="font-weight:700;">{{ $vehicle->plate_number ?? '-' }}</div>
            </div>
            @if($isRentacar)
                <div class="field">
                    <div class="muted small">{{ ___('Return due') }}</div>
                    <div style="font-weight:700;">
                        {{ $vehicle->rent_due_at?->format('Y-m-d H:i') ?? '-' }}
                    </div>
                    @if(!empty($rentRemaining))
                        <div class="muted small">{{ $rentRemaining }}</div>
                    @endif
                </div>
            @endif
        </div>
    </div>

    @if($commandsEnabled && $gpsProvider === 'traccar' && $vehicle->traccar_device_id)
        <div class="card">
            <div class="h">{{ ___('Send command') }}</div>
            <form method="POST" action="{{ route('vehicles.command', $vehicle) }}">
                @csrf
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Command type') }}</label>
                        <select name="command_type" required>
                            @php
                                $cmdOptions = collect($commandTypes ?? [])->map(function($c){
                                    if (is_string($c)) return $c;
                                    if (is_array($c)) return $c['type'] ?? $c['name'] ?? null;
                                    return null;
                                })->filter()->values()->all();
                            @endphp
                            @forelse($cmdOptions as $cmd)
                                <option value="{{ $cmd }}">{{ $cmd }}</option>
                            @empty
                                <option value="custom">{{ ___('Custom') }}</option>
                            @endforelse
                        </select>
                    </div>
                    <div class="field">
                        <label>{{ ___('Attributes (JSON, optional)') }}</label>
                        <textarea name="attributes" rows="2" placeholder='{"data":""}'></textarea>
                        <div class="muted small">{{ ___('Leave empty for simple commands; otherwise key/value JSON.') }}</div>
                    </div>
                </div>
                <div class="actions">
                    <button class="btn" type="submit">{{ ___('Send') }}</button>
                </div>
            </form>
        </div>
    @endif

    @if($commandsEnabled && $gpsProvider === 'wialon' && $vehicle->wialon_device_id)
        <div class="card">
            <div class="h">{{ ___('Send command') }}</div>
            <form method="POST" action="{{ route('vehicles.command', $vehicle) }}">
                @csrf
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Command type') }}</label>
                        <select name="command_type" required>
                            @php
                                $cmdOptions = collect($commandTypes ?? [])->map(function($c){
                                    if (is_string($c)) return ['value' => $c, 'label' => $c];
                                    if (is_array($c)) {
                                        $val = $c['type'] ?? $c['name'] ?? null;
                                        if (!$val) return null;
                                        return ['value' => $val, 'label' => $c['label'] ?? $val];
                                    }
                                    return null;
                                })->filter()->values()->all();
                            @endphp
                            @foreach($cmdOptions as $cmd)
                                <option value="{{ $cmd['value'] }}">{{ $cmd['label'] }}</option>
                            @endforeach
                            <option value="custom">{{ ___('Custom') }}</option>
                        </select>
                        <div class="muted small">{{ ___('List comes from Wialon device capabilities.') }}</div>
                    </div>
                    <div class="field">
                        <label>{{ ___('Custom command type') }}</label>
                        <input name="command_type_custom" placeholder="engine_stop">
                    </div>
                </div>
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Link type') }}</label>
                        <select name="command_link_type">
                            <option value="">{{ ___('Auto') }}</option>
                            <option value="tcp">tcp</option>
                            <option value="udp">udp</option>
                            <option value="vrt">vrt</option>
                            <option value="gsm">gsm</option>
                        </select>
                    </div>
                    <div class="field">
                        <label>{{ ___('Command name (optional)') }}</label>
                        <input name="command_name" placeholder="engine_stop">
                    </div>
                </div>
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Param') }}</label>
                        <input name="command_param" placeholder="1234">
                        <div class="muted small">{{ ___('If param is JSON, set flags to 16 (0x10).') }}</div>
                    </div>
                    <div class="field">
                        <label>{{ ___('Timeout (sec)') }}</label>
                        <input type="number" min="1" max="600" name="command_timeout" value="60">
                    </div>
                    <div class="field">
                        <label>{{ ___('Flags') }}</label>
                        <input type="number" min="0" max="65535" name="command_flags" value="0">
                    </div>
                </div>
                <div class="field">
                    <label>{{ ___('Attributes (JSON, optional)') }}</label>
                    <textarea name="attributes" rows="2" placeholder='{"param":"", "linkType":"tcp", "timeout":60, "flags":0}'></textarea>
                    <div class="muted small">{{ ___('Optional override: param, linkType, timeout, flags, commandName.') }}</div>
                </div>
                <div class="actions">
                    <button class="btn" type="submit">{{ ___('Send') }}</button>
                </div>
            </form>
        </div>
    @endif
    @if(!$commandsEnabled)
        <div class="card">
            <div class="h">{{ ___('Send command') }}</div>
            <div class="muted">{{ ___('Commands are disabled by provider policy.') }}</div>
        </div>
    @endif

    @if($position)
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <div class="h">{{ ___('Last position') }}</div>
                    <div class="muted small">{{ ___('Device time:') }} <span id="pos-device-time">{{ $position['device_time'] ?? '—' }}</span></div>
                </div>
                @if(!empty($position['address']))
                    <div class="muted small">{{ $position['address'] }}</div>
                @endif
            </div>

            <div style="display:flex; gap:12px; flex-wrap:wrap; margin:10px 0;">
                <div class="badge">Lat: <span id="pos-lat">{{ $position['latitude'] }}</span></div>
                <div class="badge">Lng: <span id="pos-lng">{{ $position['longitude'] }}</span></div>
                @if(!is_null($position['speed']))
                    <div class="badge">{{ ___('Speed') }}: <span id="pos-speed">{{ $position['speed'] }}</span></div>
                @endif
            </div>
            @if($useGoogleMaps)
                <div class="map-layer-toggle" id="mapLayerToggle" style="margin-bottom:10px;">
                    <button class="btn ghost active" type="button" data-layer="roadmap">{{ ___('Street') }}</button>
                    <button class="btn ghost" type="button" data-layer="satellite">{{ ___('Satellite') }}</button>
                    <button class="btn ghost" type="button" data-layer="hybrid">{{ ___('Hybrid') }}</button>
                    <button class="btn ghost" type="button" data-layer="terrain">{{ ___('Light') }}</button>
                </div>
            @endif

            @if($gpsProvider !== 'wialon')
            <div class="card" style="margin-bottom:12px;">
                <div class="h">{{ ___('Alarm area (Geofence)') }}</div>
                <div class="muted small" style="margin-bottom:8px;">
                    {{ ___('Use the pen tool on the map to draw a circle. Coordinates are saved automatically from the map.') }}
                </div>
                <form id="geofenceForm" method="POST" action="{{ route('vehicles.geofence.save', $vehicle) }}">
                    @csrf
                    <input type="hidden" name="geofence_lat" id="geofence_lat" value="{{ old('geofence_lat', $geofence['lat'] ?? '') }}">
                    <input type="hidden" name="geofence_lng" id="geofence_lng" value="{{ old('geofence_lng', $geofence['lng'] ?? '') }}">
                    <input type="hidden" name="geofence_radius_m" id="geofence_radius_m" value="{{ old('geofence_radius_m', $geofence['radius_m'] ?? '') }}">
                    <input type="hidden" name="clear_geofence" id="geofence_clear" value="0">

                    <div class="muted small" id="geofenceStatus" style="margin-bottom:8px;"></div>
                    <div class="geofence-actions">
                        <button type="button" class="btn ghost" id="geofenceDrawBtn">{{ ___('Draw area') }}</button>
                        <button type="submit" class="btn primary">{{ ___('Save geofence') }}</button>
                        <button type="button" class="btn danger" id="geofenceClearBtn">{{ ___('Clear') }}</button>
                    </div>
                </form>
            </div>
            @elseif($gpsProvider === 'wialon')
                <div class="card" style="margin-bottom:12px;">
                    <div class="h">{{ ___('Alarm area (Geofence)') }}</div>
                    <div class="muted small">{{ ___('Geofence tools are available for Traccar provider only.') }}</div>
                </div>
            @endif

            <div id="map"></div>
        </div>
    @else
        <div class="card banner">
            <div class="badge">{{ ___('Info') }}</div>
            <span style="margin-left:10px;">{{ ___('No location data available yet.') }}</span>
        </div>
    @endif
</div>
@endsection

@push('scripts')
@if($useGoogleMaps)
<script src="https://maps.googleapis.com/maps/api/js?key={{ $googleMapsKey }}&v=weekly&libraries=drawing"></script>
@else
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js"></script>
@endif
<script>
    document.addEventListener('DOMContentLoaded', function(){
        const initialPos = @json($gpsInitial);
        const wsUrl = @json($gpsWsUrl);
        const wsToken = @json($gpsWsToken);
        const deviceIdMatch = @json($gpsDeviceId);
        const vehicleName = @json($vehicle->display_name);
        const vehiclePlate = @json($vehicle->plate_number);
        const rentRemaining = @json($rentRemaining ?? null);
        const statusLabel = @json(___('Status'));
        const activeLabel = @json(___('Active'));
        const returnLabel = @json(___('Return'));
        const geofence = @json($geofence ?? null);
        const gpsProvider = @json($gpsProvider);
        const pollUrl = @json(route('vehicles.gps.position', $vehicle));
        const useGoogleMaps = @json($useGoogleMaps);

        const mapEl = document.getElementById('map');
        let map = null;
        let marker = null;
        let geofenceLayer = null;
        let drawCircleTool = null;
        const drawnItems = !useGoogleMaps ? new L.FeatureGroup() : null;
        const fmtSpeed = (s) => (s === null || s === undefined || s === '') ? '—' : s;
        const latInput = document.getElementById('geofence_lat');
        const lngInput = document.getElementById('geofence_lng');
        const radiusInput = document.getElementById('geofence_radius_m');
        const statusEl = document.getElementById('geofenceStatus');
        let infoWindow = null;
        let drawingManager = null;
        let googleCircle = null;
        const layerToggle = document.getElementById('mapLayerToggle');

        const buildPopup = (pos) => {
            const returnLine = rentRemaining
                ? `<div class="muted small">${returnLabel}: ${rentRemaining}</div>`
                : `<div class="muted small">${statusLabel}: ${activeLabel}</div>`;
            return `
                <div style="min-width:200px;">
                    <div><strong>${vehicleName || pos.device_id || ''}</strong></div>
                    <div class="muted small">{{ ___('Plate number') }}: ${vehiclePlate || '—'}</div>
                    <div class="muted small">{{ ___('Speed') }}: ${fmtSpeed(pos.speed)}</div>
                    <div class="muted small">${pos.address || ''}</div>
                    <div class="muted small">{{ ___('Lat/Lng') }}: ${pos.latitude}, ${pos.longitude}</div>
                    ${returnLine}
                </div>`;
        };

        function initMap(pos){
            if(!mapEl || !pos || !pos.latitude || !pos.longitude) return;
            mapEl.style.height = '360px';
            if (useGoogleMaps && typeof google !== 'undefined' && google.maps) {
                map = new google.maps.Map(mapEl, {
                    center: { lat: pos.latitude, lng: pos.longitude },
                    zoom: 14,
                    mapTypeControl: false,
                    streetViewControl: false,
                    fullscreenControl: false,
                    mapTypeId: 'roadmap'
                });
                infoWindow = new google.maps.InfoWindow();
                marker = new google.maps.Marker({
                    position: { lat: pos.latitude, lng: pos.longitude },
                    map,
                    title: vehicleName || ''
                });
                marker.addListener('click', () => {
                    infoWindow.setContent(buildPopup(pos));
                    infoWindow.open({ anchor: marker, map });
                });
                if (layerToggle) {
                    layerToggle.addEventListener('click', (e) => {
                        const btn = e.target?.closest?.('button[data-layer]');
                        if (!btn) return;
                        const layer = btn.getAttribute('data-layer');
                        if (!layer) return;
                        map.setMapTypeId(layer);
                        layerToggle.querySelectorAll('button').forEach(b => b.classList.remove('active'));
                        btn.classList.add('active');
                    });
                }
                // Google drawing manager for geofence (circle)
                drawingManager = new google.maps.drawing.DrawingManager({
                    drawingMode: null,
                    drawingControl: false,
                    circleOptions: {
                        fillColor: '#3b82f6',
                        fillOpacity: 0.12,
                        strokeColor: '#3b82f6',
                        strokeWeight: 2,
                        clickable: false,
                        editable: true,
                        zIndex: 1
                    }
                });
                drawingManager.setMap(map);

                google.maps.event.addListener(drawingManager, 'overlaycomplete', function (event) {
                    if (event.type !== google.maps.drawing.OverlayType.CIRCLE) return;
                    if (googleCircle) {
                        googleCircle.setMap(null);
                    }
                    googleCircle = event.overlay;
                    drawingManager.setDrawingMode(null);
                    syncGoogleGeofence(googleCircle);
                    google.maps.event.addListener(googleCircle, 'radius_changed', () => syncGoogleGeofence(googleCircle));
                    google.maps.event.addListener(googleCircle, 'center_changed', () => syncGoogleGeofence(googleCircle));
                });

                if (geofence && geofence.enabled && geofence.lat && geofence.lng && geofence.radius_m) {
                    googleCircle = new google.maps.Circle({
                        center: { lat: Number(geofence.lat), lng: Number(geofence.lng) },
                        radius: Number(geofence.radius_m),
                        fillColor: '#3b82f6',
                        fillOpacity: 0.12,
                        strokeColor: '#3b82f6',
                        strokeWeight: 2,
                        editable: true,
                        map
                    });
                    syncGoogleGeofence(googleCircle);
                    google.maps.event.addListener(googleCircle, 'radius_changed', () => syncGoogleGeofence(googleCircle));
                    google.maps.event.addListener(googleCircle, 'center_changed', () => syncGoogleGeofence(googleCircle));
                }
            } else {
                map = L.map(mapEl).setView([pos.latitude, pos.longitude], 14);
                const baseLayers = {
                    'Street': L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        maxZoom: 19,
                        maxNativeZoom: 19,
                        attribution: '&copy; OpenStreetMap contributors'
                    }),
                    'Satellite': L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                        maxZoom: 18,
                        maxNativeZoom: 18,
                        attribution: 'Tiles &copy; Esri'
                    }),
                    'Light': L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
                        maxZoom: 20,
                        maxNativeZoom: 20,
                        attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
                    })
                };
                baseLayers.Street.addTo(map);
                L.control.layers(baseLayers, null, { position: 'topright' }).addTo(map);
                marker = L.marker([pos.latitude, pos.longitude]).addTo(map)
                    .bindPopup(buildPopup(pos))
                    .openPopup();
                map.addLayer(drawnItems);
            }

            if (useGoogleMaps) return;

            const drawControl = new L.Control.Draw({
                position: 'topright',
                draw: {
                    polygon: false,
                    polyline: false,
                    rectangle: false,
                    marker: false,
                    circlemarker: false,
                    circle: {
                        showRadius: true,
                        shapeOptions: { color: '#3b82f6' }
                    }
                },
                edit: {
                    featureGroup: drawnItems,
                    edit: true,
                    remove: false
                }
            });
            map.addControl(drawControl);
            drawCircleTool = new L.Draw.Circle(map, drawControl.options.draw.circle);

            map.on(L.Draw.Event.CREATED, function (e) {
                drawnItems.clearLayers();
                geofenceLayer = e.layer;
                drawnItems.addLayer(geofenceLayer);
                syncGeofenceInputs(geofenceLayer);
            });

            map.on(L.Draw.Event.EDITED, function (e) {
                e.layers.eachLayer(function (layer) {
                    if (layer instanceof L.Circle) {
                        geofenceLayer = layer;
                        syncGeofenceInputs(layer);
                    }
                });
            });

            if (geofence && geofence.enabled && geofence.lat && geofence.lng && geofence.radius_m) {
                geofenceLayer = L.circle([geofence.lat, geofence.lng], {
                    radius: geofence.radius_m,
                    color: '#3b82f6'
                });
                drawnItems.addLayer(geofenceLayer);
                syncGeofenceInputs(geofenceLayer);
                map.fitBounds(geofenceLayer.getBounds(), { padding: [20, 20] });
            } else {
                updateGeofenceStatus();
            }

            setTimeout(() => map.invalidateSize(), 200);
        }

        function syncGeofenceInputs(layer){
            if (!layer || !latInput || !lngInput || !radiusInput) return;
            const center = layer.getLatLng();
            const radius = Math.round(layer.getRadius());
            latInput.value = center.lat.toFixed(7);
            lngInput.value = center.lng.toFixed(7);
            radiusInput.value = radius;
            updateGeofenceStatus();
        }

        function syncGoogleGeofence(circle){
            if (!circle || !latInput || !lngInput || !radiusInput) return;
            const center = circle.getCenter();
            const radius = Math.round(circle.getRadius());
            latInput.value = center.lat().toFixed(7);
            lngInput.value = center.lng().toFixed(7);
            radiusInput.value = radius;
            updateGeofenceStatus();
        }

        function updateGeofenceStatus(){
            if (!statusEl) return;
            if (latInput && latInput.value && radiusInput && radiusInput.value) {
                statusEl.innerText = `{{ ___('Current geofence') }}: ${radiusInput.value}m`;
            } else {
                statusEl.innerText = `{{ ___('No geofence saved yet.') }}`;
            }
        }

        function updateUI(pos){
            const latEl = document.getElementById('pos-lat');
            if (latEl && pos.latitude !== undefined) latEl.innerText = pos.latitude;

            const lngEl = document.getElementById('pos-lng');
            if (lngEl && pos.longitude !== undefined) lngEl.innerText = pos.longitude;

            const spEl = document.getElementById('pos-speed');
            if (spEl && pos.speed !== undefined) spEl.innerText = pos.speed;

            const tEl = document.getElementById('pos-device-time');
            if (tEl && pos.device_time) tEl.innerText = pos.device_time;
            }


        function updateMarker(pos){
            if(!map || !marker || !pos.latitude || !pos.longitude) return;
            if (useGoogleMaps && typeof google !== 'undefined') {
                marker.setPosition({ lat: pos.latitude, lng: pos.longitude });
            } else {
                marker.setLatLng([pos.latitude, pos.longitude]);
                marker.setPopupContent(buildPopup(pos));
            }
        }

        if(initialPos && initialPos.latitude && initialPos.longitude){
            initialPos.name = initialPos.name || vehicleName;
            initialPos.plate = initialPos.plate || vehiclePlate;
            initMap(initialPos);
            updateUI(initialPos);
        }

        const form = document.getElementById('geofenceForm');
        const drawBtn = document.getElementById('geofenceDrawBtn');
        if (drawBtn) {
            drawBtn.addEventListener('click', function () {
                if (!map) return;
                if (useGoogleMaps) {
                    if (!drawingManager) return;
                    console.info('[geofence] drawing mode enabled (google)');
                    drawingManager.setDrawingMode(google.maps.drawing.OverlayType.CIRCLE);
                    return;
                }
                if (!drawCircleTool) return;
                console.info('[geofence] drawing mode enabled (leaflet)');
                drawCircleTool.enable();
            });
        }

        const clearBtn = document.getElementById('geofenceClearBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                if (useGoogleMaps) {
                    if (googleCircle) {
                        googleCircle.setMap(null);
                        googleCircle = null;
                    }
                } else {
                    if (geofenceLayer) {
                        drawnItems.removeLayer(geofenceLayer);
                        geofenceLayer = null;
                    }
                }
                if (latInput) latInput.value = '';
                if (lngInput) lngInput.value = '';
                if (radiusInput) radiusInput.value = '';
                const clearInput = document.getElementById('geofence_clear');
                if (clearInput) clearInput.value = '1';
                if (form) {
                    console.info('[geofence] clear -> submit');
                    form.submit();
                }
            });
        }

        if (form) {
            form.addEventListener('submit', function (e) {
                const clearInput = document.getElementById('geofence_clear');
                const isClear = clearInput && clearInput.value === '1';
                if (isClear) return;
                const latOk = latInput && latInput.value !== '';
                const lngOk = lngInput && lngInput.value !== '';
                const radOk = radiusInput && radiusInput.value !== '';
                if (!latOk || !lngOk || !radOk) {
                    e.preventDefault();
                    console.warn('[geofence] submit blocked: missing coords/radius');
                    alert('{{ ___('Please draw a geofence circle before saving.') }}');
                }
            });
        }

        // WebSocket real-time (Traccar)
        if(wsUrl && wsToken && deviceIdMatch){
            const socket = new WebSocket(wsUrl + '?token=' + encodeURIComponent(wsToken));
            socket.onmessage = (event) => {
                let payload = null;
                try { payload = JSON.parse(event.data); } catch(e){ return; }
                const items = Array.isArray(payload) ? payload : [payload];
                items.forEach(item => {
                    if(!item || typeof item !== 'object') return;
                    if(Array.isArray(item.positions)) {
                        item.positions.forEach(applyPosition);
                    } else if(item.latitude !== undefined && item.longitude !== undefined && (item.deviceId || item.device_id)) {
                        applyPosition(item);
                    }
                });
            };
        } else if (gpsProvider === 'wialon' && pollUrl) {
            const poll = () => {
                fetch(pollUrl, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                    .then(r => r.ok ? r.json() : null)
                    .then(pos => {
                        if (!pos || !pos.latitude || !pos.longitude) return;
                        const mapped = {
                            device_id: pos.device_id,
                            latitude: pos.latitude,
                            longitude: pos.longitude,
                            speed: pos.speed ?? null,
                            device_time: pos.device_time ?? null,
                            address: pos.address ?? '',
                            name: vehicleName,
                            plate: vehiclePlate
                        };
                        updateUI(mapped);
                        if (!map) {
                            initMap(mapped);
                        } else {
                            updateMarker(mapped);
                        }
                    })
                    .catch(() => null)
                    .finally(() => setTimeout(poll, 5000));
            };
            poll();
        }

        function matchesDevice(itemId){
            if(!itemId || !deviceIdMatch) return false;
            return String(itemId) === String(deviceIdMatch);
        }

        function applyPosition(pos){
            const devId = pos.deviceId || pos.device_id;
            if(!matchesDevice(devId)) return;
            const mapped = {
                device_id: devId,
                latitude: pos.latitude,
                longitude: pos.longitude,
                speed: pos.speed ?? null,
                device_time: pos.deviceTime ?? pos.device_time ?? null,
                address: pos.address ?? '',
                name: pos.name ?? vehicleName,
                plate: pos.plate ?? vehiclePlate
            };
            updateUI(mapped);
            updateMarker(mapped);
        }
    });
</script>
@endpush
