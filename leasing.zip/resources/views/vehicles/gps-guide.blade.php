@extends('layouts.app')

@section('title', 'GPS Cihaz Quraşdırması')
@section('page_title')
    <span data-i18n="page_title">LeasingERP – GPS Cihaz Quraşdırması</span>
@endsection
@section('page_subtitle')
    <span data-i18n="page_subtitle">Yeni nəqliyyat vasitəsi əlavə etdikdən sonra GPS sisteminə qoşulma üçün addım-addım təlimat.</span>
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.index') }}">{{ __('Back') }}</a>
@endsection

@push('styles')
<style>
    .gps-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px;align-items:start;}
    .gps-card h4{margin:0 0 6px;}
    .gps-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:12px;background:rgba(255,255,255,0.04);border:1px solid var(--border);margin-right:6px;margin-bottom:6px;font-weight:700;}
    .gps-steps{margin:0;padding-left:18px;display:grid;gap:6px;}
    .gps-steps li{line-height:1.45;}
    .gps-checklist{display:grid;gap:6px;margin:0;padding-left:0;list-style:none;}
    .gps-checklist li{display:flex;gap:8px;align-items:flex-start;}
    .gps-checklist .box{width:18px;height:18px;border-radius:6px;border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-weight:700;}
    .gps-banner{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;}
    .gps-banner .muted{max-width:780px;}
    .gps-modal{position:fixed;inset:0;background:rgba(0,0,0,0.7);display:none;align-items:center;justify-content:center;padding:16px;z-index:3000;}
    .gps-modal.show{display:flex;}
    .gps-modal .inner{background:#0f1115;border-radius:14px;padding:16px;width:min(1100px,100%);max-height:90vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.45);}
    .gps-modal header{display:flex;gap:10px;align-items:center;justify-content:space-between;}
    .gps-modal table{width:100%;border-collapse:collapse;}
    .gps-modal th,.gps-modal td{padding:8px 10px;border-bottom:1px solid var(--border);}
    .gps-modal tbody{display:block;overflow:auto;max-height:60vh;}
    .gps-modal thead, .gps-modal tbody tr{display:table;width:100%;table-layout:fixed;}
    .gps-modal input{width:100%;}
    .gps-modal .note{font-size:12px;color:var(--muted);}
    .support-form{display:grid;gap:10px;}
    .support-form .row{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;}
    .support-note{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
    @media (max-width:640px){
        .gps-banner{flex-direction:column;align-items:flex-start;}
    }
</style>
@endpush

@section('content')
<div class="wrap gps-guide">
    @if(($gpsProvider ?? 'traccar') === 'wialon')
        <div class="card gps-card" style="margin-bottom:12px;">
            <div class="gps-banner">
                <div>
                    <div class="h">Wialon</div>
                    <div class="muted small">{{ ___('This company is configured to use Wialon for GPS tracking.') }}</div>
                </div>
                <div>
                    <div class="gps-chip">Host: <code>{{ $wialonHost ?? '' }}</code></div>
                </div>
            </div>
            <div class="muted small" style="margin-top:8px;">
                {{ ___('Add the Wialon unit ID to each vehicle. Traccar setup steps below are optional if you are not using Traccar.') }}
            </div>
        </div>
    @endif
    <div class="card gps-card">
        <div class="gps-banner">
            <div>
                <div class="h" data-i18n="needs_title">GPS qoşulması üçün lazım olanlar</div>
                <div class="muted small" data-i18n="needs_body">
                    Aktiv SIM (data paketi qoşulu), cihazın IMEI/Device ID-si və server host/port məlumatı ilə başlayın.
                </div>
            </div>
            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                <div class="gps-chip">Host: <code>{{ $traccarHost }}</code></div>
                <div class="gps-chip" data-i18n="needs_ports">Server protokollarının portları aktivdir</div>
                <button class="btn primary" type="button" id="openProtocolModal" data-i18n="btn_protocols">Protocol/Port siyahısı</button>
                <select id="langSelect" class="input" style="width:120px;">
                    <option value="az">AZ</option>
                    <option value="tr">TR</option>
                    <option value="ru">RU</option>
                    <option value="en">EN</option>
                </select>
            </div>
        </div>
        <div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:8px;">
            <span class="badge ok" data-i18n="badge_sim">SIM interneti aktivdir</span>
            <span class="badge" data-i18n="badge_imei">IMEI/Device ID hazırdır</span>
            <span class="badge ghost" data-i18n="badge_protocol">Protocol + Port uyğun seçilib</span>
        </div>
    </div>

    <div class="gps-grid">
        <div class="card gps-card">
            <h4 data-i18n="s1_title">1) Cihaz identifikatoru (Unique ID)</h4>
            <ol class="gps-steps">
                <li data-i18n="s1_li1"><b>Unique ID</b>: cihazın göndərdiyi identifikator (adətən <b>IMEI</b> / 15 rəqəm) ilə eyni olmalıdır.</li>
                <li data-i18n="s1_li2">Unikal ID uyğun deyilsə sistemdə “Unknown device” kimi görünəcək.</li>
            </ol>
        </div>
        <div class="card gps-card">
            <h4 data-i18n="s2_title">2) Protocol və Port</h4>
            <div class="muted small" data-i18n="s2_hint">Serverdə aktiv protokollar üçün port siyahısı aşağıdadır.</div>
            <ul class="gps-steps">
                <li data-i18n="s2_li1">İstifadə edəcəyiniz protokolu seçin.</li>
                <li data-i18n="s2_li2">Port dəyərini qeyd edin və cihazda eyni portu yazın.</li>
                <li><button class="btn ghost" type="button" id="openProtocolModal2" data-i18n="s2_btn">Cihaz üzrə protokol/port tap</button></li>
            </ul>
        </div>
        <div class="card gps-card">
            <h4 data-i18n="s3_title">3) Cihazda GPRS/Server parametrləri</h4>
            <ul class="gps-steps">
                <li data-i18n="s3_li1"><b>Server / Host / Domain / IP</b>: <code>{{ $traccarHost }}</code></li>
                <li data-i18n="s3_li2"><b>Port</b>: protokol üçün port (yuxarıdakı siyahıdan).</li>
                <li data-i18n="s3_li3"><b>Protocol / Type / Data format</b>: seçdiyiniz protokol adı.</li>
                <li data-i18n="s3_li4"><b>Device ID / IMEI</b>: cihazın göndərdiyi identifikator (Unique ID ilə eyni).</li>
                <li data-i18n="s3_li5">Server1-i doldurun, Server2-ni boş saxlayın və ya disable edin.</li>
            </ul>
        </div>
        <div class="card gps-card">
            <h4 data-i18n="s4_title">4) SIM/APN (mobil internet)</h4>
            <div class="muted small" data-i18n="s4_hint">Cihaz internetə çıxmalıdır, əks halda serverə qoşulmayacaq.</div>
            <div style="margin-top:8px;display:grid;gap:6px;">
                <div class="gps-chip" data-i18n="s4_apn1">Azercell / Bakcell — APN: <b>internet</b></div>
                <div class="gps-chip" data-i18n="s4_apn2">Nar — APN: <b>narinternet</b></div>
                <div class="muted small" data-i18n="s4_hint2">User/Password sahələri çox vaxt boş qalır. Korporativ SIM üçün operatorun verdiyi APN-i yazın.</div>
            </div>
        </div>
        <div class="card gps-card">
            <h4 data-i18n="s5_title">5) Göndərmə intervalı</h4>
            <ul class="gps-steps">
                <li data-i18n="s5_li1"><b>Test</b>: 10 saniyə</li>
                <li data-i18n="s5_li2"><b>Normal istifadə</b>: 20–30 saniyə</li>
                <li data-i18n="s5_li3">Interval çox kiçik olarsa trafik və batareya sərfi artacaq.</li>
            </ul>
            <h4 style="margin-top:12px;" data-i18n="s6_title">6) Statusu yoxlama</h4>
            <ul class="gps-steps">
                <li data-i18n="s6_li1">Server statusunda “Connections / Active devices” görünsün.</li>
                <li data-i18n="s6_li2">Devices siyahısında cihaz <b>online</b> olmalıdır; xəritədə ilk koordinat 1–3 dəqiqə çəkə bilər.</li>
            </ul>
        </div>
        <div class="card gps-card">
            <h4 data-i18n="s7_title">7) Problem olduqda</h4>
            <ul class="gps-steps">
                <li data-i18n="s7_li1"><b>Unknown device</b>: cihazın göndərdiyi ID ≠ sistemdə yazdığınız Unique ID.</li>
                <li data-i18n="s7_li2"><b>Offline qalır</b>: APN səhv, data paketi yoxdur, host səhv, port/protocol uyğun deyil.</li>
                <li data-i18n="s7_li3"><b>Online, amma koordinat yoxdur</b>: GPS siqnalı zəifdir; açıq havada 5–10 dəq saxlayın.</li>
            </ul>
        </div>
        <div class="card gps-card">
            <h4 data-i18n="s8_title">8) Minimum checklist</h4>
            <ul class="gps-checklist">
                <li><span class="box">✓</span><span data-i18n="s8_li1">Server-də cihaz yaradıldı, <b>Unique ID = IMEI</b>.</span></li>
                <li><span class="box">✓</span><span data-i18n="s8_li2">Host = <code>{{ $traccarHost }}</code>, Port = protokolun portu.</span></li>
                <li><span class="box">✓</span><span data-i18n="s8_li3">APN operatora uyğun yazıldı.</span></li>
                <li><span class="box">✓</span><span data-i18n="s8_li4">Interval 10г—30 saniyə.</span></li>
                <li><span class="box">✓</span><span data-i18n="s8_li5">Server Status-da bağlantı görünür.</span></li>
            </ul>
        </div>
    </div>

    <div class="card gps-card" id="support-block">
        <div class="gps-banner">
            <div>
                <div class="h" data-i18n="support_title">Məlumatları bizə göndərin</div>
                <div class="muted small" data-i18n="support_hint">Aşağıdakı sahələri doldurub məlumatı kopyalayın və dəstəyə göndərin.</div>
            </div>
            <div class="support-note">
                <span class="badge ghost" data-i18n="support_badge1">Unknown device</span>
                <span class="badge ghost" data-i18n="support_badge2">Offline</span>
                <span class="badge ghost" data-i18n="support_badge3">No GPS</span>
            </div>
        </div>
        <div style="margin-top:10px;">
            <form class="support-form" id="gpsSupportForm">
                <div class="row">
                    <div class="field">
                        <label data-i18n="form_device_name">Cihaz adı</label>
                        <input name="device_name" data-i18n-placeholder="ph_device_name" placeholder="Avto-01">
                    </div>
                    <div class="field">
                        <label data-i18n="form_device_id">IMEI / Device ID</label>
                        <input name="device_id" data-i18n-placeholder="ph_device_id" placeholder="15 rəqəm">
                    </div>
                    <div class="field">
                        <label data-i18n="form_operator">Operator</label>
                        <input name="operator" data-i18n-placeholder="ph_operator" placeholder="Azercell / Bakcell / Nar / Korporativ">
                    </div>
                </div>
                <div class="row">
                    <div class="field">
                        <label data-i18n="form_protocol">Protocol</label>
                        <input name="protocol" data-i18n-placeholder="ph_protocol" placeholder="məs: freematics">
                    </div>
                    <div class="field">
                        <label data-i18n="form_port">Port</label>
                        <input name="port" data-i18n-placeholder="ph_port" placeholder="məs: 5170">
                    </div>
                    <div class="field">
                        <label data-i18n="form_issue">Problem təsviri</label>
                        <input name="issue" data-i18n-placeholder="ph_issue" placeholder="Unknown device / Offline / No GPS">
                    </div>
                </div>
                <div class="actions" style="justify-content:flex-start; gap:10px;">
                    <button class="btn ghost" type="button" id="copySupport" data-i18n="form_copy_btn">Məlumatı kopyala</button>
                    <span id="supportCopied" class="muted small" style="display:none;" data-i18n="form_copied">Kopyalandı! Dəstəyə göndərin.</span>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- Modal --}}
<div id="protocolModal" class="gps-modal" aria-hidden="true">
    <div class="inner">
        <header>
            <div>
                <div class="h" data-i18n="modal_title">Cihaz protokolu və portu</div>
                <div class="muted small" data-i18n="modal_hint">Axtarışa cihaz adı, protokol və ya porta görə yazın.</div>
            </div>
            <div style="display:flex; gap:8px; align-items:center;">
                <input type="text" id="protocolSearch" class="input" style="width:220px;" data-i18n-placeholder="modal_search" placeholder="Cihaz / protokol / port">
                <button class="btn ghost" type="button" id="closeProtocolModal" data-i18n="btn_close">Bağla</button>
            </div>
        </header>
        <div style="margin:10px 0 6px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <span class="badge ghost" id="protocolCount" data-i18n="modal_count">0 cihaz</span>
            <span class="muted small" data-i18n="modal_note">Məlumat Server port siyahısından gətirilir.</span>
        </div>
        <div style="border:1px solid var(--border); border-radius:10px; overflow:hidden;">
            <table>
                <thead>
                <tr>
                    <th style="width:55%;" data-i18n="th_device">Device</th>
                    <th style="width:20%;" data-i18n="th_protocol">Protocol</th>
                    <th style="width:25%;" data-i18n="th_port">Port</th>
                </tr>
                </thead>
                <tbody id="protocolTableBody"></tbody>
            </table>
        </div>
    </div>
</div>

{{-- Clones modal --}}
<div id="clonesModal" class="gps-modal" aria-hidden="true">
    <div class="inner">
        <header>
            <div>
                <div class="h" data-i18n="clones_title">Çin klonları haqqında</div>
                <div class="muted small" data-i18n="clones_subtitle">“clones” portu göstərilən modellər üçün tez-tez istifadə olunan portlar və problemlər</div>
            </div>
            <button class="btn ghost" type="button" id="closeClonesModal" data-i18n="btn_close">Bağla</button>
        </header>
        <div style="margin-top:10px;">
            <div class="muted small" style="margin-bottom:6px;" data-i18n="clones_intro1">
                Əgər Çin istehsalı GPS izləmə cihazınız varsa, aşağıdakı məlumatları diqqətlə oxuyun.
            </div>
            <div class="muted small" style="margin-bottom:6px;" data-i18n="clones_intro2">
                Müxtəlif istehsalçılar cihazlarını oxşar adlarla sata bilər (TK102, TK103, GT02A, H02 və s.). Bu səbəbdən təkcə model adına baxaraq doğru port/protokolu seçmək həmişə mümkün olmur. Aşağıdakı portları ardıcıllıqla sınayın:
            </div>
            <div style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:8px;">
                @foreach([5001,5002,5006,5013,5015,5023,5036,5093] as $p)
                    <span class="gps-chip">Port: <b>{{ $p }}</b></span>
                @endforeach
            </div>
            <div class="muted small" style="margin-bottom:6px;" data-i18n="clones_intro3">
                Tez-tez rast gəlinən problemlər və həlli:
            </div>
            <ul class="gps-steps">
                <li data-i18n="clones_li1">GPS103 (5001) protokolunda cihaz yalnız status göndərir, koordinat yoxdur: cihaza bu komandanı göndərin: <code>fix060s***n123456</code> (060s interval, *** davamlı göndər, 123456 default parol)</li>
                <li data-i18n="clones_li2">TK103 (5002) protokolunda cihaz IMEI yerinə 12 rəqəmli ID göndərir. Çox vaxt IMEI-nin son 11 rəqəmi + başdakı 0 olur. Məs: IMEI 123456789012345 → ID 056789012345. Həll: Server-də iki cihaz yaradın – biri tam IMEI, biri 12 rəqəmli ID ilə.</li>
                <li data-i18n="clones_li3">Bunlar kömək etmirsə, protokolu manual təyin etməyə çalışın və ya dəstək kanallarına müraciət edin.</li>
            </ul>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function(){
    const devices = @json($devicePorts, JSON_UNESCAPED_UNICODE);
    const modal = document.getElementById('protocolModal');
    const tableBody = document.getElementById('protocolTableBody');
    const searchInput = document.getElementById('protocolSearch');
    const countBadge = document.getElementById('protocolCount');
    const openBtns = [document.getElementById('openProtocolModal'), document.getElementById('openProtocolModal2')].filter(Boolean);
    const closeBtn = document.getElementById('closeProtocolModal');
    const clonesModal = document.getElementById('clonesModal');
    const closeClonesBtn = document.getElementById('closeClonesModal');
    const langSelect = document.getElementById('langSelect');
    const host = @json($traccarHost);
    const appLang = @json(app()->getLocale());

    const t = {
  az: {
    meta_title: `GPS Cihaz Quraşdırması`,
    page_title: `LeasingERP – GPS Cihaz Quraşdırması`,
    page_subtitle: `Yeni nəqliyyat vasitəsi əlavə etdikdən sonra GPS sisteminə qoşulma üçün addım-addım təlimat.`,
    needs_title: `GPS qoşulması üçün lazım olanlar`,
    needs_body: `Aktiv SIM (data paketi qoşulu), cihazın IMEI/Device ID-si və server host/port məlumatı ilə başlayın.`,
    needs_ports: `Server protokollarının portları aktivdir`,
    btn_protocols: `Protocol/Port siyahısı`,
    badge_sim: `SIM interneti aktivdir`,
    badge_imei: `IMEI/Device ID hazırdır`,
    badge_protocol: `Protocol + Port uyğun seçilib`,

    s1_title: `1) Cihaz identifikatoru (Unique ID)`,
    s1_li1: `<b>Unique ID</b>: cihazın göndərdiyi identifikator (adətən <b>IMEI</b> / 15 rəqəm) ilə eyni olmalıdır.`,
    s1_li2: `Unikal ID uyğun deyilsə sistemdə “Unknown device” kimi görünəcək.`,

    s2_title: `2) Protocol və Port`,
    s2_hint: `Serverdə aktiv protokollar üçün port siyahısı aşağıdadır.`,
    s2_li1: `İstifadə edəcəyiniz protokolu seçin.`,
    s2_li2: `Port dəyərini qeyd edin və cihazda eyni portu yazın.`,
    s2_btn: `Cihaz üzrə protokol/port tap`,

    s3_title: `3) Cihazda GPRS/Server parametrləri`,
    s3_li1: `<b>Server / Host / Domain / IP</b>: <code>${host}</code>`,
    s3_li2: `<b>Port</b>: protokol üçün port (yuxarıdakı siyahıdan).`,
    s3_li3: `<b>Protocol / Type / Data format</b>: seçdiyiniz protokol adı.`,
    s3_li4: `<b>Device ID / IMEI</b>: cihazın göndərdiyi identifikator (Unique ID ilə eyni).`,
    s3_li5: `Server1-i doldurun, Server2-ni boş saxlayın və ya disable edin.`,

    s4_title: `4) SIM/APN (mobil internet)`,
    s4_hint: `Cihaz internetə çıxmalıdır, əks halda serverə qoşulmayacaq.`,
    s4_apn1: `Azercell / Bakcell — APN: <b>internet</b>`,
    s4_apn2: `Nar — APN: <b>narinternet</b>`,
    s4_hint2: `User/Password sahələri çox vaxt boş qalır. Korporativ SIM üçün operatorun verdiyi APN-i yazın.`,

    s5_title: `5) Göndərmə intervalı`,
    s5_li1: `<b>Test</b>: 10 saniyə`,
    s5_li2: `<b>Normal istifadə</b>: 20–30 saniyə`,
    s5_li3: `Interval çox kiçik olarsa trafik və batareya sərfi artacaq.`,

    s6_title: `6) Statusu yoxlama`,
    s6_li1: `Server statusunda “Connections / Active devices” görünsün.`,
    s6_li2: `Devices siyahısında cihaz <b>online</b> olmalıdır; xəritədə ilk koordinat 1–3 dəqiqə çəkə bilər.`,

    s7_title: `7) Problem olduqda`,
    s7_li1: `<b>Unknown device</b>: cihazın göndərdiyi ID ≠ sistemdə yazdığınız Unique ID.`,
    s7_li2: `<b>Offline qalır</b>: APN səhv, data paketi yoxdur, host səhv, port/protocol uyğun deyil.`,
    s7_li3: `<b>Online, amma koordinat yoxdur</b>: GPS siqnalı zəifdir; açıq havada 5–10 dəq saxlayın.`,

    s8_title: `8) Minimum checklist`,
    s8_li1: `Server-də cihaz yaradıldı, <b>Unique ID = IMEI</b>.`,
    s8_li2: `Host = <code>${host}</code>, Port = protokolun portu.`,
    s8_li3: `APN operatora uyğun yazıldı.`,
    s8_li4: `Interval 10–30 saniyə.`,
    s8_li5: `Server Status-da bağlantı görünür.`,

    support_title: `Məlumatları bizə göndərin`,
    support_hint: `Aşağıdakı sahələri doldurub məlumatı kopyalayın və dəstəyə göndərin.`,
    support_badge1: `Unknown device`,
    support_badge2: `Offline`,
    support_badge3: `No GPS`,

    form_device_name: `Cihaz adı`,
    form_device_id: `IMEI / Device ID`,
    form_operator: `Operator`,
    form_protocol: `Protocol`,
    form_port: `Port`,
    form_issue: `Problem təsviri`,

    ph_device_name: `Avto-01`,
    ph_device_id: `15 rəqəm`,
    ph_operator: `Azercell / Bakcell / Nar / Korporativ`,
    ph_protocol: `məs: freematics`,
    ph_port: `məs: 5170`,
    ph_issue: `Unknown device / Offline / No GPS`,

    form_copy_btn: `Məlumatı kopyala`,
    form_copied: `Kopyalandı! Dəstəyə göndərin.`,

    modal_title: `Cihaz protokolu və portu`,
    modal_hint: `Axtarışa cihaz adı, protokol və ya porta görə yazın.`,
    modal_search: `Cihaz / protokol / port`,
    modal_count: `{count} cihaz`,
    modal_note: `Məlumat Server port siyahısından gətirilir.`,

    th_device: `Device`,
    th_protocol: `Protocol`,
    th_port: `Port`,

    btn_close: `Bağla`,

    clones_title: `Çin klonları haqqında`,
    clones_subtitle: `“clones” portu göstərilən modellər üçün tez-tez istifadə olunan portlar və problemlər`,
    clones_intro1: `Əgər Çin istehsalı GPS izləmə cihazınız varsa, aşağıdakı məlumatları diqqətlə oxuyun.`,
    clones_intro2: `Fərqli istehsalçılar cihazlarını oxşar adlarla satır (TK102, TK103, GT02A, H02 və s.), bu səbəbdən təkcə model adına baxaraq doğru portu/protokolu seçmək olmur. Aşağıdakı portları ardıcıl sınayın:`,
    clones_intro3: `Sıx rastlanan problemlər və həlli:`,
    clones_li1: `GPS103 (5001) protokolunda cihaz yalnız status göndərir, koordinat yoxdur: cihaza bu komandanı göndərin: <code>fix060s***n123456</code> (060s interval, *** davamlı göndər, 123456 default parol)`,
    clones_li2: `TK103 (5002) protokolunda cihaz IMEI yerinə 12 rəqəmli ID göndərir. Çox vaxt IMEI-nin son 11 rəqəmi + başdakı 0 olur. Məs: IMEI 123456789012345 → ID 056789012345. Həll: Server-də iki cihaz yaradın – biri tam IMEI, biri 12 rəqəmli ID ilə.`,
    clones_li3: `Bunlar kömək etmirsə, protokolu manual təyin etməyə çalışın və ya dəstək kanallarına müraciət edin.`
  },

  tr: {
    meta_title: `GPS Cihaz Kurulumu`,
    page_title: `LeasingERP – GPS Cihaz Kurulumu`,
    page_subtitle: `Yeni araç ekledikten sonra GPS sistemine bağlanmak için adım adım rehber.`,
    needs_title: `GPS bağlantısı için gerekenler`,
    needs_body: `Aktif SIM (data paketli), cihaz IMEI/Device ID ve sunucu host/port bilgisiyle başlayın.`,
    needs_ports: `Sunucu protokol portları aktiftir`,
    btn_protocols: `Protokol/Port listesi`,
    badge_sim: `SIM interneti aktif`,
    badge_imei: `IMEI/Device ID hazır`,
    badge_protocol: `Protokol + Port seçildi`,
    s1_title: `1) Cihaz kimliği (Unique ID)`,
    s1_li1: `<b>Unique ID</b>: cihazın gönderdiği kimlik (çoğu zaman <b>IMEI</b> / 15 hane) ile aynı olmalı.`,
    s1_li2: `ID eşleşmezse sistemde “Unknown device” görünür.`,
    s2_title: `2) Protokol ve Port`,
    s2_hint: `Sunucuda aktif protokoller için port listesi aşağıdadır.`,
    s2_li1: `Kullanacağınız protokolü seçin.`,
    s2_li2: `Port değerini not edin ve cihazda aynı portu yazın.`,
    s2_btn: `Cihaza göre protokol/port bul`,
    s3_title: `3) Cihazda GPRS/Sunucu ayarları`,
    s3_li1: `<b>Sunucu / Host / Domain / IP</b>: <code>${host}</code>`,
    s3_li2: `<b>Port</b>: protokol portu (listeden).`,
    s3_li3: `<b>Protocol / Type / Data format</b>: seçtiğiniz protokol adı.`,
    s3_li4: `<b>Device ID / IMEI</b>: cihazın gönderdiği kimlik (Unique ID ile aynı).`,
    s3_li5: `Server1 doldurun, Server2 boş bırakın veya kapatın.`,
    s4_title: `4) SIM/APN (mobil internet)`,
    s4_hint: `Cihaz internete çıkmalı, aksi halde sunucuya bağlanmaz.`,
    s4_apn1: `Azercell / Bakcell — APN: <b>internet</b>`,
    s4_apn2: `Nar — APN: <b>narinternet</b>`,
    s4_hint2: `User/Password alanları çoğu zaman boş kalır. Kurumsal SIM için operatörün verdiği APN yazılmalı.`,
    s5_title: `5) Gönderim aralığı`,
    s5_li1: `<b>Test</b>: 10 saniye`,
    s5_li2: `<b>Normal kullanım</b>: 20–30 saniye`,
    s5_li3: `Çok küçük aralık trafik ve pil tüketimini artırır.`,
    s6_title: `6) Durum kontrolü`,
    s6_li1: `Sunucu durumunda “Connections / Active devices” görünsün.`,
    s6_li2: `Cihaz listede <b>online</b> olmalı; ilk koordinat 1–3 dk sürebilir.`,
    s7_title: `7) Sorun olduğunda`,
    s7_li1: `<b>Unknown device</b>: cihazın gönderdiği ID ≠ sistemdeki Unique ID.`,
    s7_li2: `<b>Offline</b>: APN hatalı, data yok, host hatalı, port/protokol uyumsuz.`,
    s7_li3: `<b>Online ama koordinat yok</b>: GPS sinyali zayıf; açık havada 5–10 dk bekletin.`,
    s8_title: `8) Minimum checklist`,
    s8_li1: `Sunucuda cihaz açıldı, <b>Unique ID = IMEI</b>.`,
    s8_li2: `Host = <code>${host}</code>, Port = protokol portu.`,
    s8_li3: `APN operatöre uygun yazıldı.`,
    s8_li4: `Aralık 10–30 saniye.`,
    s8_li5: `Sunucu durumunda bağlantı görünüyor.`,
    support_title: `Bilgileri bize gönderin`,
    support_hint: `Alanları doldurun, kopyalayın ve desteğe iletin.`,
    support_badge1: `Unknown device`,
    support_badge2: `Offline`,
    support_badge3: `No GPS`,
    form_device_name: `Cihaz adı`,
    form_device_id: `IMEI / Device ID`,
    form_operator: `Operatör`,
    form_protocol: `Protokol`,
    form_port: `Port`,
    form_issue: `Sorun açıklaması`,
    ph_device_name: `Arac-01`,
    ph_device_id: `15 hane`,
    ph_operator: `Azercell / Bakcell / Nar / Kurumsal`,
    ph_protocol: `örn: freematics`,
    ph_port: `örn: 5170`,
    ph_issue: `Unknown device / Offline / No GPS`,
    form_copy_btn: `Bilgiyi kopyala`,
    form_copied: `Kopyalandı! Desteğe gönderin.`,
    modal_title: `Cihaz protokolü ve portu`,
    modal_hint: `Cihaz adı, protokol veya port ile arayın.`,
    modal_search: `Cihaz / protokol / port`,
    modal_count: `{count} cihaz`,
    modal_note: `Bilgi sunucu port listesinden alınır.`,
    th_device: `Device`,
    th_protocol: `Protocol`,
    th_port: `Port`,
    btn_close: `Kapat`,
    clones_title: `Çin klonları hakkında`,
    clones_subtitle: `“clones” portu olan modeller için sık kullanılan portlar ve sorunlar`,
    clones_intro1: `Eğer Çin'de üretilmiş bir GPS takip cihazınız varsa, lütfen aşağıdaki bilgileri okuyun.`,
    clones_intro2: `Farklı üreticiler cihazlarını benzer adlarla satar (TK102, TK103, GT02A, H02 vb.), bu yüzden sadece modele bakarak doğru port/protokol seçilemez. Aşağıdaki portları sırayla deneyin:`,
    clones_intro3: `Sık karşılaşılan sorunlar ve çözümler:`,
    clones_li1: `GPS103 (5001) protokolünde cihaz sadece durum yollar, koordinat yok: şu komutu gönderin: <code>fix060s***n123456</code> (060s aralık, *** sürekli gönder, 123456 varsayılan şifre)`,
    clones_li2: `TK103 (5002) protokolünde cihaz IMEI yerine 12 haneli ID yollar; çoğu zaman IMEI son 11 hane + baştaki 0. Örn: IMEI 123456789012345 → ID 056789012345. Çözüm: Sunucuda iki cihaz açın – biri tam IMEI, biri 12 haneli ID ile.`,
    clones_li3: `Bunlar olmazsa protokolü manuel tespit etmeyi deneyin veya destekle iletişime geçin.`
  },

  ru: {
    meta_title: `Установка GPS устройства`,
    page_title: `LeasingERP – Установка GPS устройства`,
    page_subtitle: `Пошаговая инструкция по подключению GPS после добавления новой техники.`,
    needs_title: `Что нужно для подключения GPS`,
    needs_body: `Начните с активной SIM (с интернетом), IMEI/Device ID устройства и данных host/port сервера.`,
    needs_ports: `Порты серверных протоколов активны`,
    btn_protocols: `Список Protocol/Port`,
    badge_sim: `SIM с интернетом`,
    badge_imei: `IMEI/Device ID готов`,
    badge_protocol: `Протокол + порт выбраны`,
    s1_title: `1) Идентификатор устройства (Unique ID)`,
    s1_li1: `<b>Unique ID</b>: должен совпадать с ID, который шлет устройство (обычно <b>IMEI</b> / 15 цифр).`,
    s1_li2: `Если ID не совпадает — в системе будет “Unknown device”.`,
    s2_title: `2) Протокол и порт`,
    s2_hint: `Ниже — список портов для активных протоколов на сервере.`,
    s2_li1: `Выберите протокол, который будете использовать.`,
    s2_li2: `Запишите порт и укажите тот же на устройстве.`,
    s2_btn: `Подобрать протокол/порт по устройству`,
    s3_title: `3) Настройки GPRS/Server на устройстве`,
    s3_li1: `<b>Server / Host / Domain / IP</b>: <code>${host}</code>`,
    s3_li2: `<b>Port</b>: порт для протокола (из списка).`,
    s3_li3: `<b>Protocol / Type / Data format</b>: имя выбранного протокола.`,
    s3_li4: `<b>Device ID / IMEI</b>: идентификатор, который шлет устройство (должен совпадать с Unique ID).`,
    s3_li5: `Server1 заполните, Server2 оставьте пустым или отключите.`,
    s4_title: `4) SIM/APN (мобильный интернет)`,
    s4_hint: `Устройство должно выходить в интернет, иначе сервер не увидит его.`,
    s4_apn1: `Azercell / Bakcell — APN: <b>internet</b>`,
    s4_apn2: `Nar — APN: <b>narinternet</b>`,
    s4_hint2: `User/Password чаще всего пустые. Для корпоративных SIM укажите APN от оператора.`,
    s5_title: `5) Интервал отправки`,
    s5_li1: `<b>Тест</b>: 10 секунд`,
    s5_li2: `<b>Обычное использование</b>: 20–30 секунд`,
    s5_li3: `Слишком маленький интервал увеличит трафик и расход батареи.`,
    s6_title: `6) Проверка статуса`,
    s6_li1: `В статусе сервера должны быть “Connections / Active devices”.`,
    s6_li2: `В списке устройств девайс должен быть <b>online</b>; первая точка может прийти за 1–3 минуты.`,
    s7_title: `7) Если есть проблема`,
    s7_li1: `<b>Unknown device</b>: ID от устройства ≠ Unique ID в системе.`,
    s7_li2: `<b>Offline</b>: APN неверен, нет интернета, host/port/protocol неверны.`,
    s7_li3: `<b>Online, но нет координат</b>: слабый GPS сигнал; подержите 5–10 минут на открытом воздухе.`,
    s8_title: `8) Минимальный чеклист`,
    s8_li1: `На сервере создано устройство, <b>Unique ID = IMEI</b>.`,
    s8_li2: `Host = <code>${host}</code>, Port = порт протокола.`,
    s8_li3: `APN указан верно для оператора.`,
    s8_li4: `Интервал 10–30 секунд.`,
    s8_li5: `В статусе сервера видна активная связь.`,
    support_title: `Отправьте нам данные`,
    support_hint: `Заполните поля, скопируйте и отправьте в поддержку.`,
    support_badge1: `Unknown device`,
    support_badge2: `Offline`,
    support_badge3: `No GPS`,
    form_device_name: `Название устройства`,
    form_device_id: `IMEI / Device ID`,
    form_operator: `Оператор`,
    form_protocol: `Протокол`,
    form_port: `Порт`,
    form_issue: `Описание проблемы`,
    ph_device_name: `Auto-01`,
    ph_device_id: `15 цифр`,
    ph_operator: `Azercell / Bakcell / Nar / Корпоративный`,
    ph_protocol: `напр.: freematics`,
    ph_port: `напр.: 5170`,
    ph_issue: `Unknown device / Offline / No GPS`,
    form_copy_btn: `Скопировать данные`,
    form_copied: `Скопировано! Отправьте в поддержку.`,
    modal_title: `Протокол и порт устройства`,
    modal_hint: `Ищите по названию, протоколу или порту.`,
    modal_search: `Устройство / протокол / порт`,
    modal_count: `{count} устройств`,
    modal_note: `Данные берутся из списка портов сервера.`,
    th_device: `Device`,
    th_protocol: `Protocol`,
    th_port: `Port`,
    btn_close: `Закрыть`,
    clones_title: `О китайских клонах`,
    clones_subtitle: `Порты и частые проблемы для моделей с “clones” портом`,
    clones_intro1: `Если у вас GPS-трекер, произведенный в Китае, прочтите это.`,
    clones_intro2: `Разные производители продают девайсы под схожими именами (TK102, TK103, GT02A, H02 и т.д.), поэтому только по названию модели выбрать порт/протокол нельзя. Пробуйте порты ниже по очереди:`,
    clones_intro3: `Частые проблемы и решения:`,
    clones_li1: `GPS103 (5001): устройство шлет только статус, координат нет — отправьте команду <code>fix060s***n123456</code> (060s интервал, *** — слать постоянно, 123456 — дефолтный пароль).`,
    clones_li2: `TK103 (5002): устройство шлет 12-значный ID вместо IMEI, чаще всего это последние 11 цифр IMEI + ведущий 0. Пример: IMEI 123456789012345 → ID 056789012345. Решение: создайте два устройства — с полным IMEI и с 12-значным ID.`,
    clones_li3: `Если не помогло — пытайтесь определить протокол вручную или обратитесь в поддержку.`
  },

  en: {
    meta_title: `GPS Device Setup`,
    page_title: `LeasingERP – GPS Device Setup`,
    page_subtitle: `Step-by-step guide to connect GPS after adding a new vehicle.`,
    needs_title: `What you need for GPS setup`,
    needs_body: `Start with an active SIM (data on), the device IMEI/Device ID, and the server host/port.`,
    needs_ports: `Server protocol ports are enabled`,
    btn_protocols: `Protocol/Port list`,
    badge_sim: `SIM data is active`,
    badge_imei: `IMEI/Device ID ready`,
    badge_protocol: `Protocol + Port selected`,
    s1_title: `1) Device identifier (Unique ID)`,
    s1_li1: `<b>Unique ID</b>: must match the ID the device sends (usually <b>IMEI</b> / 15 digits).`,
    s1_li2: `If it differs, the system will show “Unknown device”.`,
    s2_title: `2) Protocol and Port`,
    s2_hint: `Below is the port list for active protocols on the server.`,
    s2_li1: `Pick the protocol you will use.`,
    s2_li2: `Note the port and set the same on the device.`,
    s2_btn: `Find protocol/port by device`,
    s3_title: `3) GPRS/Server parameters on the device`,
    s3_li1: `<b>Server / Host / Domain / IP</b>: <code>${host}</code>`,
    s3_li2: `<b>Port</b>: the port for the protocol (from the list).`,
    s3_li3: `<b>Protocol / Type / Data format</b>: the protocol name you chose.`,
    s3_li4: `<b>Device ID / IMEI</b>: the identifier the device sends (same as Unique ID).`,
    s3_li5: `Fill Server1, leave Server2 empty or disable it.`,
    s4_title: `4) SIM/APN (mobile internet)`,
    s4_hint: `Device must reach the internet; otherwise it will not connect.`,
    s4_apn1: `Azercell / Bakcell — APN: <b>internet</b>`,
    s4_apn2: `Nar — APN: <b>narinternet</b>`,
    s4_hint2: `User/Password are usually blank. For corporate SIMs, use the APN provided by the operator.`,
    s5_title: `5) Sending interval`,
    s5_li1: `<b>Test</b>: 10 seconds`,
    s5_li2: `<b>Normal use</b>: 20–30 seconds`,
    s5_li3: `Very small intervals increase traffic and battery drain.`,
    s6_title: `6) Check status`,
    s6_li1: `In server status, “Connections / Active devices” should appear.`,
    s6_li2: `In Devices list the unit should be <b>online</b>; first fix may take 1–3 minutes.`,
    s7_title: `7) If problems`,
    s7_li1: `<b>Unknown device</b>: device ID ≠ Unique ID in the system.`,
    s7_li2: `<b>Offline</b>: APN wrong, no data plan, host/port/protocol wrong.`,
    s7_li3: `<b>Online but no coordinates</b>: weak GPS signal; keep it outside 5–10 minutes.`,
    s8_title: `8) Minimum checklist`,
    s8_li1: `Device created on server, <b>Unique ID = IMEI</b>.`,
    s8_li2: `Host = <code>${host}</code>, Port = protocol port.`,
    s8_li3: `APN set according to operator.`,
    s8_li4: `Interval 10–30 seconds.`,
    s8_li5: `Connection visible in server status.`,
    support_title: `Send us the details`,
    support_hint: `Fill the fields, copy the text, and send to support.`,
    support_badge1: `Unknown device`,
    support_badge2: `Offline`,
    support_badge3: `No GPS`,
    form_device_name: `Device name`,
    form_device_id: `IMEI / Device ID`,
    form_operator: `Operator`,
    form_protocol: `Protocol`,
    form_port: `Port`,
    form_issue: `Issue description`,
    ph_device_name: `Auto-01`,
    ph_device_id: `15 digits`,
    ph_operator: `Azercell / Bakcell / Nar / Corporate`,
    ph_protocol: `e.g. freematics`,
    ph_port: `e.g. 5170`,
    ph_issue: `Unknown device / Offline / No GPS`,
    form_copy_btn: `Copy details`,
    form_copied: `Copied! Send to support.`,
    modal_title: `Device protocol and port`,
    modal_hint: `Search by device, protocol, or port.`,
    modal_search: `Device / protocol / port`,
    modal_count: `{count} devices`,
    modal_note: `Data comes from the server port list.`,
    th_device: `Device`,
    th_protocol: `Protocol`,
    th_port: `Port`,
    btn_close: `Close`,
    clones_title: `About China clones`,
    clones_subtitle: `Ports and common issues for models with “clones” port`,
    clones_intro1: `If your GPS tracker is made in China, please read this.`,
    clones_intro2: `Different vendors sell devices under similar names (TK102, TK103, GT02A, H02, etc.), so you cannot pick the right port/protocol by name only. Try the ports below in order:`,
    clones_intro3: `Frequent issues and fixes:`,
    clones_li1: `GPS103 (5001): device sends only status, no coords — send command <code>fix060s***n123456</code> (060s interval, *** keep sending, 123456 default pass).`,
    clones_li2: `TK103 (5002): device sends 12-digit ID instead of IMEI; often last 11 digits of IMEI plus leading 0. Example IMEI 123456789012345 → ID 056789012345. Solution: create two devices — one with full IMEI, one with 12-digit ID.`,
    clones_li3: `If all else fails, try manual protocol detection or contact support.`
  }
};


    // YUXARIDA tr/ru/en bloklarını sənin mövcud mətnlərinlə saxla,
    // sadəcə btn_close dəyərlərini yuxarıdakı kimi düzəlt.

    function applyLang(lang){
        const activeLang = t[lang] ? lang : 'az';
        const dict = t[activeLang] || t.az;

        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (dict[key]) el.innerHTML = dict[key];
        });

        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (dict[key]) el.setAttribute('placeholder', dict[key]);
        });

        if (countBadge){
            const current = countBadge.getAttribute('data-count') || countBadge.textContent.replace(/\D/g,'');
            const val = dict.modal_count ? dict.modal_count.replace('{count}', current || '0') : countBadge.textContent;
            countBadge.textContent = val;
        }

        if (dict.meta_title) document.title = dict.meta_title;
        document.documentElement.setAttribute('lang', activeLang);
    }

    function renderRows(term=''){
        const q = (term || '').trim().toLowerCase();
        const filtered = !q ? devices : devices.filter(d =>
            (d.device || '').toLowerCase().includes(q) ||
            (d.protocol || '').toLowerCase().includes(q) ||
            String(d.port || '').toLowerCase().includes(q)
        );

        countBadge.setAttribute('data-count', filtered.length);

        const lang = langSelect?.value || 'az';
        const dict = t[lang] || t.az;
        countBadge.textContent = dict.modal_count ? dict.modal_count.replace('{count}', filtered.length) : `${filtered.length}`;

        tableBody.innerHTML = filtered.map(d => `
            <tr>
                <td>${d.device}</td>
                <td><code>${d.protocol}</code></td>
                <td>
                    ${String(d.port || '').toLowerCase().includes('clone')
                        ? `<button type="button" class="btn ghost" data-clone="1">${dict.clones_title}</button>`
                        : `<code>${d.port}</code>`}
                </td>
            </tr>
        `).join('');
    }

    function openModal(){
        if (!devices || devices.length === 0) return;
        renderRows(searchInput?.value || '');
        modal.classList.add('show');
        searchInput?.focus();
    }
    function closeModal(){ modal.classList.remove('show'); }

    openBtns.forEach(btn => btn.addEventListener('click', openModal));
    closeBtn?.addEventListener('click', closeModal);
    modal?.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    searchInput?.addEventListener('input', (e) => renderRows(e.target.value));
    tableBody?.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-clone]');
        if (btn) clonesModal.classList.add('show');
    });

    closeClonesBtn?.addEventListener('click', () => clonesModal.classList.remove('show'));
    clonesModal?.addEventListener('click', (e) => { if (e.target === clonesModal) clonesModal.classList.remove('show'); });

    const copyBtn = document.getElementById('copySupport');
    const copiedNote = document.getElementById('supportCopied');
    const form = document.getElementById('gpsSupportForm');

    copyBtn?.addEventListener('click', () => {
        const data = new FormData(form);
        const text = [
            `Cihaz adı: ${data.get('device_name') || '-'}`,
            `IMEI/Device ID: ${data.get('device_id') || '-'}`,
            `Operator: ${data.get('operator') || '-'}`,
            `Protocol: ${data.get('protocol') || '-'}`,
            `Port: ${data.get('port') || '-'}`,
            `Problem: ${data.get('issue') || '-'}`
        ].join('\n');

        if (navigator.clipboard?.writeText) {
            navigator.clipboard.writeText(text).then(() => {
                copiedNote.style.display = 'inline';
                setTimeout(() => copiedNote.style.display = 'none', 3000);
            });
        } else { alert(text); }
    });

    const storage = {
        get(key){
            try { return localStorage.getItem(key); } catch (_) { return null; }
        },
        set(key, val){
            try { localStorage.setItem(key, val); } catch (_) {}
        }
    };

    const availableLangs = Object.keys(t);
    const savedLang = storage.get('gps_lang');
    const savedAppLang = storage.get('gps_lang_app');
    const appDefaultLang = availableLangs.includes(appLang) ? appLang : 'az';
    const initialLang = (savedAppLang && savedAppLang !== appLang)
        ? appDefaultLang
        : (availableLangs.includes(savedLang) ? savedLang : appDefaultLang);

    if (langSelect && availableLangs.includes(initialLang)) {
        langSelect.value = initialLang;
    }

    const setLang = (lang, persist = true) => {
        const next = availableLangs.includes(lang) ? lang : appDefaultLang;
        if (langSelect) langSelect.value = next;
        applyLang(next);
        renderRows(searchInput?.value || '');
        if (persist) {
            storage.set('gps_lang', next);
            storage.set('gps_lang_app', appLang);
        }
    };

    langSelect?.addEventListener('change', (e) => setLang(e.target.value));

    setLang(initialLang, false);
});
</script>
@endpush
