@extends('layouts.app')
@section('title', ___('Vehicle authorizations'))
@section('page_title', ___('Vehicle authorizations'))
@section('page_subtitle', ___('All vehicles'))

@section('content')
    <div class="card">
        <form class="row" method="GET" action="{{ route('vehicles.authorizations.all') }}">
            <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <input name="q" value="{{ $q }}" placeholder="{{ ___('Search: name or note') }}">
                <input type="number" min="0" name="ends_in_days" value="{{ $endsIn }}" placeholder="{{ ___('Ends in (days)') }}">
                <button class="btn" type="submit">{{ ___('Filter') }}</button>
                @if($q !== '' || $endsIn !== null)
                    <a class="btn" href="{{ route('vehicles.authorizations.all') }}">{{ ___('Reset') }}</a>
                @endif
            </div>
        </form>

        <table style="margin-top:12px;">
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Authorized person') }}</th>
                <th>{{ ___('Start') }}</th>
                <th>{{ ___('End') }}</th>
                <th>{{ ___('Note') }}</th>
                <th style="width:140px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($authorizations as $a)
                <tr>
                    <td>{{ $a->id }}</td>
                    <td>{{ $a->vehicle?->display_name ?? '-' }}</td>
                    <td>{{ $a->authorized_name }}</td>
                    <td>{{ $a->start_date?->format('Y-m-d') ?? '-' }}</td>
                    <td>{{ $a->end_date?->format('Y-m-d') ?? '-' }}</td>
                    <td>{{ $a->note ?? '-' }}</td>
                    <td>
                        @if($a->vehicle_id)
                            <a class="btn ghost" href="{{ route('vehicles.authorizations.index', $a->vehicle_id) }}">{{ ___('Open') }}</a>
                        @else
                            -
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">{{ ___('No authorizations found.') }}</td></tr>
            @endforelse
            </tbody>
        </table>

        <div style="margin-top:12px;">
            {{ $authorizations->links() }}
        </div>
    </div>
@endsection
