@extends('layouts.app')

@section('title', ___('GPS map'))
@section('page_title', ___('GPS map'))
@section('page_subtitle', ___('All company vehicles on map'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.index') }}">{{ ___('Back') }}</a>
@endsection

@push('styles')
@php
    $googleMapsKey = config('services.google_maps.key');
    $useGoogleMaps = !empty($googleMapsKey);
@endphp
@if(!$useGoogleMaps)
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
@endif
<style>
    #fleet-map { height: 480px; border-radius:12px; border:1px solid var(--border); overflow:hidden; }
    .fleet-sidebar { max-height:480px; overflow:auto; }
    .device-row { padding:8px 10px; border:1px solid var(--border); border-radius:10px; margin-bottom:8px; background:var(--surface); display:flex; flex-direction:column; gap:4px; }
    .device-row .muted { font-size:12px; }
    .map-layer-toggle { display:flex; gap:6px; flex-wrap:wrap; }
    .map-layer-toggle .btn { height:28px; padding:0 10px; font-size:12px; }
    .map-layer-toggle .btn.active { border-color:#3b82f6; color:#3b82f6; }
</style>
@endpush

@section('content')
@php
    $fleetWsUrl = $wsUrl ?? null;
    $fleetWsToken = $wsToken ?? null;
    $showReturnDue = $showReturnDue ?? false;
    $gpsProvider = $provider ?? 'traccar';
    $devicesSeed = $vehicles->map(function ($v) use ($gpsProvider) {
        return [
            'device_id' => $gpsProvider === 'wialon' ? $v->wialon_device_id : $v->traccar_device_id,
            'name' => $v->display_name,
            'plate' => $v->plate_number,
            'brand' => $v->brand,
            'model' => $v->model,
            'year' => $v->year,
            'rent_remaining' => $v->rent_remaining ?? null,
        ];
    })->values();
@endphp
<div class="wrap">
    @if(session('status'))
        <div class="banner"><span class="badge ok">{{ session('status') }}</span></div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="grid" style="grid-template-columns: 2fr 1fr;">
        <div class="card">
            <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
                <div class="h">{{ ___('Map') }}</div>
                @if($useGoogleMaps)
                    <div class="map-layer-toggle" id="mapLayerToggle">
                        <button class="btn ghost active" type="button" data-layer="roadmap">{{ ___('Street') }}</button>
                        <button class="btn ghost" type="button" data-layer="satellite">{{ ___('Satellite') }}</button>
                        <button class="btn ghost" type="button" data-layer="hybrid">{{ ___('Hybrid') }}</button>
                        <button class="btn ghost" type="button" data-layer="terrain">{{ ___('Light') }}</button>
                    </div>
                @endif
            </div>
            <div id="fleet-map"></div>
        </div>
        <div class="card">
            <div class="h">{{ ___('Devices') }}</div>
            <div class="fleet-sidebar" id="fleet-list">
                @foreach($vehicles as $v)
                    @php $deviceId = $gpsProvider === 'wialon' ? $v->wialon_device_id : $v->traccar_device_id; @endphp
                    <div class="device-row" data-device="{{ $deviceId }}">
                        <div style="font-weight:700;">{{ $v->display_name }} ({{ $v->plate_number ?? '-' }})</div>
                        <div class="muted">{{ $gpsProvider === 'wialon' ? 'Wialon' : 'Traccar' }} ID: {{ $deviceId }}</div>
                        <div class="muted small" id="info-{{ $deviceId }}">-</div>
                        @if($showReturnDue)
                            <div class="muted small" id="return-{{ $deviceId }}">-</div>
                        @endif
                        @if($gpsProvider === 'wialon' && ($historyEnabled ?? true))
                            <div class="muted small">
                                <a href="{{ route('company.gps.history', $deviceId) }}">{{ ___('History') }}</a>
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
            @if($commandsEnabled)
                <div class="h" style="margin-top:12px;">{{ ___('Send command') }}</div>
                <form method="POST" action="{{ route('company.gps.command') }}">
                    @csrf
                    <div class="field">
                        <label>{{ ___('Device') }}</label>
                        <select name="device_id" required>
                            @foreach($vehicles as $v)
                                @php $did = $gpsProvider === 'wialon' ? $v->wialon_device_id : $v->traccar_device_id; @endphp
                                <option value="{{ $did }}">{{ $v->display_name }} ({{ $did }})</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="field">
                        <label>{{ ___('Command type') }}</label>
                        <select name="command_type" id="cmd-type-select" required></select>
                    </div>
                    @if($gpsProvider === 'wialon')
                        <div class="field">
                            <label>{{ ___('Custom command type') }}</label>
                            <input name="command_type_custom" placeholder="engine_stop">
                        </div>
                        <div class="field">
                            <label>{{ ___('Link type') }}</label>
                            <select name="command_link_type">
                                <option value="">{{ ___('Auto') }}</option>
                                <option value="tcp">tcp</option>
                                <option value="udp">udp</option>
                                <option value="vrt">vrt</option>
                                <option value="gsm">gsm</option>
                            </select>
                        </div>
                        <div class="field">
                            <label>{{ ___('Command name (optional)') }}</label>
                            <input name="command_name" placeholder="engine_stop">
                        </div>
                        <div class="field">
                            <label>{{ ___('Param') }}</label>
                            <input name="command_param" placeholder="1234">
                            <div class="muted small">{{ ___('If param is JSON, set flags to 16 (0x10).') }}</div>
                        </div>
                        <div class="field">
                            <label>{{ ___('Timeout (sec)') }}</label>
                            <input type="number" min="1" max="600" name="command_timeout" value="60">
                        </div>
                        <div class="field">
                            <label>{{ ___('Flags') }}</label>
                            <input type="number" min="0" max="65535" name="command_flags" value="0">
                        </div>
                        <div class="field">
                            <label>{{ ___('Attributes (JSON, optional)') }}</label>
                            <textarea name="attributes" rows="2" placeholder='{"param":"", "linkType":"tcp", "timeout":60, "flags":0}'></textarea>
                        </div>
                    @else
                        <div class="field">
                            <label>{{ ___('Attributes (JSON, optional)') }}</label>
                            <textarea name="attributes" rows="2" placeholder='{"data":""}'></textarea>
                        </div>
                    @endif
                    <div class="actions">
                        <button class="btn primary" type="submit">{{ ___('Send') }}</button>
                    </div>
                </form>
            @else
                <div class="muted" style="margin-top:12px;">{{ ___('Commands are disabled by provider policy.') }}</div>
            @endif
        </div>
    </div>
</div>
@endsection

@push('scripts')
@if($useGoogleMaps)
<script src="https://maps.googleapis.com/maps/api/js?key={{ $googleMapsKey }}&v=weekly"></script>
@else
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
@endif
<script>
    document.addEventListener('DOMContentLoaded', function(){
        const devicesSeed = @json($devicesSeed);
        const wsUrl = @json($fleetWsUrl);
        const wsToken = @json($fleetWsToken);
        const positions = @json($positions ?? []);
        const commandTypes = @json($commandTypes ?? []);
        const showReturnDue = @json($showReturnDue);
        const pollIntervalMs = @json((int) (($pollIntervalSec ?? 5) * 1000));
        const returnLabel = @json(___('Return'));
        const statusLabel = @json(___('Status'));
        const activeLabel = @json(___('Active'));
        const plateLabel = @json(___('Plate number'));
        const speedLabel = @json(___('Speed'));
        const latLngLabel = @json(___('Lat/Lng'));
        const gpsProvider = @json($gpsProvider);
        const pollUrl = @json(route('company.gps.positions'));
        const useGoogleMaps = @json($useGoogleMaps);
        // Cihaz whitelist-i: yaln„+z ‰?irk‰Ttin avtomobill‰Tri
        const allowedDevices = new Set();
        (devicesSeed || []).forEach((row) => {
            const devId = row?.device_id ?? null;
            if (devId === null || devId === undefined) return;
            allowedDevices.add(String(devId));
            const numId = Number(devId);
            if(!Number.isNaN(numId)) allowedDevices.add(String(numId));
        });

        // device id -> info (name, plate, brand, model, year)
        const devicesInfo = (() => {
            const base = {};
            (devicesSeed || []).forEach((row) => {
                const uid = String(row?.device_id ?? '');
                if (uid === '') return;
                const info = {
                    name: row?.name || '',
                    plate: row?.plate || '',
                    brand: row?.brand || '',
                    model: row?.model || '',
                    year: row?.year || '',
                    rent_remaining: row?.rent_remaining || '',
                };
                base[uid] = info;
                // əgər device ID rəqəmdirsə, numeric versiyanı da xəritəyə əlavə et
                const numId = Number(uid);
                if (!Number.isNaN(numId)) {
                    base[String(numId)] = info;
                }
            });
            (positions || []).forEach(p => {
                const info = {
                    name: p.name || '',
                    plate: p.plate || '',
                    brand: p.brand || '',
                    model: p.model || '',
                    year: p.year || '',
                    rent_remaining: p.rent_remaining || '',
                };
                if(p.device_id) base[String(p.device_id)] = { ...(base[String(p.device_id)] || {}), ...info };
                if(p.unique_id) base[String(p.unique_id)] = { ...(base[String(p.unique_id)] || {}), ...info };
                if(p.device_id && p.unique_id && base[String(p.unique_id)]) {
                    base[String(p.device_id)] = { ...(base[String(p.unique_id)]), ...(base[String(p.device_id)] || {}) };
                }
            });
            return base;
        })();
        const mapEl = document.getElementById('fleet-map');
        if(!mapEl) return;

        let map = null;
        let markersGroup = null;
        let markers = {};
        const fmtSpeed = (s) => (s === null || s === undefined || s === '') ? '—' : s;
        let infoWindow = null;
        let bounds = null;

        const layerToggle = document.getElementById('mapLayerToggle');
        if (useGoogleMaps && typeof google !== 'undefined' && google.maps) {
            map = new google.maps.Map(mapEl, {
                center: { lat: 40.4, lng: 49.8 },
                zoom: 11,
                mapTypeControl: false,
                streetViewControl: false,
                fullscreenControl: false,
                mapTypeId: 'roadmap'
            });
            infoWindow = new google.maps.InfoWindow();
            bounds = new google.maps.LatLngBounds();
            if (layerToggle) {
                layerToggle.addEventListener('click', (e) => {
                    const btn = e.target?.closest?.('button[data-layer]');
                    if (!btn) return;
                    const layer = btn.getAttribute('data-layer');
                    if (!layer) return;
                    map.setMapTypeId(layer);
                    layerToggle.querySelectorAll('button').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                });
            }
        } else {
            map = L.map(mapEl).setView([40.4, 49.8], 11);
            const baseLayers = {
                'Street': L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 19,
                    maxNativeZoom: 19,
                    attribution: '&copy; OpenStreetMap contributors'
                }),
                'Satellite': L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                    maxZoom: 18,
                    maxNativeZoom: 18,
                    attribution: 'Tiles &copy; Esri'
                }),
                'Light': L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
                    maxZoom: 20,
                    maxNativeZoom: 20,
                    attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
                })
            };
            baseLayers.Street.addTo(map);
            L.control.layers(baseLayers, null, { position: 'topright' }).addTo(map);
            markersGroup = L.featureGroup().addTo(map);
        }

        function ensureMarker(pos){
            if(!pos.device_id || pos.latitude === undefined || pos.longitude === undefined) return;
            const fallback = devicesInfo[String(pos.device_id)] || devicesInfo[String(pos.unique_id ?? '')] || {};
            pos.name = fallback.name || pos.name || '';
            pos.plate = fallback.plate || pos.plate || '-';
            pos.brand = fallback.brand || pos.brand || '';
            pos.model = fallback.model || pos.model || '';
            pos.year = fallback.year || pos.year || '';
            pos.rent_remaining = pos.rent_remaining || fallback.rent_remaining || '';
            const displayTitle = (() => {
                if (pos.name) return pos.name;
                const parts = [pos.brand, pos.model].filter(Boolean).join(' ').trim();
                const yr = pos.year ? ` (${pos.year})` : '';
                if (parts) return parts + yr;
                if (pos.plate) return pos.plate;
                return pos.device_id || '';
            })();
            const returnLine = (showReturnDue && pos.rent_remaining)
                ? `<div class="muted small">${returnLabel}: ${pos.rent_remaining}</div>`
                : `<div class="muted small">${statusLabel}: ${activeLabel}</div>`;
            const popup = `
                <div style="min-width:220px;">
                    <div><strong>${displayTitle}</strong></div>
                    <div class="muted small">${plateLabel}: ${pos.plate || '-'}</div>
                    <div class="muted small">${speedLabel}: ${fmtSpeed(pos.speed)}</div>
                    <div class="muted small">${latLngLabel}: ${pos.latitude}, ${pos.longitude}</div>
                    <div class="muted small">${pos.address || ''}</div>
                    ${returnLine}
                </div>`;
            if (useGoogleMaps && map && typeof google !== 'undefined') {
                if (!markers[pos.device_id]) {
                    markers[pos.device_id] = new google.maps.Marker({
                        position: { lat: pos.latitude, lng: pos.longitude },
                        map,
                        title: displayTitle
                    });
                    markers[pos.device_id].addListener('click', () => {
                        if (!infoWindow) return;
                        infoWindow.setContent(popup);
                        infoWindow.open({ anchor: markers[pos.device_id], map });
                    });
                } else {
                    markers[pos.device_id].setPosition({ lat: pos.latitude, lng: pos.longitude });
                }
                if (bounds) bounds.extend({ lat: pos.latitude, lng: pos.longitude });
            } else {
                if(!markers[pos.device_id]){
                    markers[pos.device_id] = L.marker([pos.latitude, pos.longitude]).addTo(markersGroup);
                }
                markers[pos.device_id].setLatLng([pos.latitude, pos.longitude]).bindPopup(popup);
            }
            updateList(pos);
        }

        function focusToVehicles(){
            if (useGoogleMaps) {
                if (!bounds || bounds.isEmpty()) return;
                map.fitBounds(bounds, { padding: 30 });
                return;
            }
            const layers = markersGroup?.getLayers?.() || [];
            if (!layers.length) return;
            const b = markersGroup.getBounds();
            if (b.isValid()) {
                map.fitBounds(b, { padding: [30, 30] });
            }
        }

        function updateList(pos){
            const info = document.getElementById('info-' + pos.device_id);
            if(info){
                const nm = pos.name || pos.device_id || '';
                const pl = pos.plate || '-';
                info.innerText = `${nm} | ${pl} | ${pos.latitude}, ${pos.longitude} | ${fmtSpeed(pos.speed)} | ${pos.device_time ?? ''}`;
            }
            if (showReturnDue) {
                const ret = document.getElementById('return-' + pos.device_id);
                if (ret) {
                    ret.innerText = pos.rent_remaining ? `${returnLabel}: ${pos.rent_remaining}` : `${returnLabel}: -`;
                }
            }
        }

        // initial positions already server-filtered by company, ona görə əlavə filtrsiz göstər
        (positions || []).forEach(p => ensureMarker(p));
        focusToVehicles();

        // command type dynamic select
        const deviceSelect = document.querySelector('select[name="device_id"]');
        const cmdSelect = document.getElementById('cmd-type-select');
        function fillCmdOptions(devId){
            if(!cmdSelect) return;
            cmdSelect.innerHTML = '';
            const types = commandTypes[devId] || [];
            const opts = Array.isArray(types) ? types.map(t => {
                if (typeof t === 'string') return { value: t, label: t };
                if (t && typeof t === 'object') {
                    const val = t.type || t.name;
                    if (!val) return null;
                    return { value: val, label: t.label || val };
                }
                return null;
            }).filter(Boolean) : [];
            opts.push({ value: 'custom', label: 'Custom' });
            opts.forEach(t => {
                const opt = document.createElement('option');
                opt.value = t.value;
                opt.textContent = t.label;
                cmdSelect.appendChild(opt);
            });
        }
        if(deviceSelect){
            fillCmdOptions(deviceSelect.value);
            deviceSelect.addEventListener('change', () => fillCmdOptions(deviceSelect.value));
        }

        if (gpsProvider !== 'wialon') {
            if(wsUrl && wsToken){
                const socket = new WebSocket(wsUrl + '?token=' + encodeURIComponent(wsToken));
                socket.onmessage = (event) => {
                    let payload = null;
                    try { payload = JSON.parse(event.data); } catch(e){ return; }
                    const items = Array.isArray(payload) ? payload : [payload];
                    items.forEach(item => {
                        if(!item || typeof item !== 'object') return;
                        if(Array.isArray(item.positions)) {
                            item.positions.forEach(applyPosition);
                        } else if(item.latitude !== undefined && item.longitude !== undefined && (item.deviceId || item.device_id)) {
                            applyPosition(item);
                        }
                    });
                };
            }
        }

        if (gpsProvider === 'wialon' && pollUrl) {
            const poll = () => {
                fetch(pollUrl, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                    .then(r => r.ok ? r.json() : null)
                    .then(payload => {
                        const list = payload?.positions || [];
                        list.forEach(p => ensureMarker(p));
                        focusToVehicles();
                    })
                    .catch(() => null)
                    .finally(() => setTimeout(poll, pollIntervalMs || 5000));
            };
            poll();
        }

        function applyPosition(pos){
            const devId = pos.deviceId || pos.device_id;
            if(!devId) return;
            if(!allowedDevices.has(String(devId)) && !allowedDevices.has(String(pos.uniqueId ?? pos.unique_id ?? ''))) return;
            ensureMarker({
                device_id: devId,
                latitude: pos.latitude,
                longitude: pos.longitude,
                speed: pos.speed ?? null,
                device_time: pos.deviceTime ?? pos.device_time ?? null,
                address: pos.address ?? '',
                name: pos.name ?? (devicesInfo[String(devId)]?.name ?? ''),
                plate: pos.plate ?? (devicesInfo[String(devId)]?.plate ?? ''),
                brand: pos.brand ?? (devicesInfo[String(devId)]?.brand ?? ''),
                model: pos.model ?? (devicesInfo[String(devId)]?.model ?? ''),
                year: pos.year ?? (devicesInfo[String(devId)]?.year ?? ''),
                rent_remaining: devicesInfo[String(devId)]?.rent_remaining ?? ''
            });
            focusToVehicles();
        }
    });
</script>
@endpush
