@extends('layouts.app')

@section('title', ___('GPS history'))
@section('page_title', ___('GPS history'))
@section('page_subtitle')
    {{ ___('Unit ID') }}: {{ $unitId }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('company.gps') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
<div class="wrap">
    <div class="card">
        <div class="h">{{ ___('History range') }}</div>
        <form method="GET" action="{{ route('company.gps.history', $unitId) }}" class="row" style="align-items:end;">
            <div class="field">
                <label>{{ ___('From') }}</label>
                <input type="date" name="from" value="{{ $from }}">
            </div>
            <div class="field">
                <label>{{ ___('To') }}</label>
                <input type="date" name="to" value="{{ $to }}">
            </div>
            <div class="field">
                <button class="btn primary" type="submit">{{ ___('Apply') }}</button>
            </div>
        </form>
    </div>

    <div class="card" style="margin-top:12px;">
        <div class="h">{{ ___('Positions') }}</div>
        @if(empty($points))
            <div class="muted" style="margin-top:10px;">{{ ___('No data available for this range.') }}</div>
        @else
            <div class="table" style="margin-top:10px;">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Time') }}</th>
                        <th>{{ ___('Lat') }}</th>
                        <th>{{ ___('Lng') }}</th>
                        <th>{{ ___('Speed') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($points as $row)
                        <tr>
                            <td>{{ $row['time'] ?? '-' }}</td>
                            <td>{{ $row['lat'] ?? '-' }}</td>
                            <td>{{ $row['lng'] ?? '-' }}</td>
                            <td>{{ $row['speed'] ?? '-' }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>
@endsection
