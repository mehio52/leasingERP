@extends('layouts.app')
@php
    $isRentacar = in_array(($module ?? 'leasing'), ['rentacar','taxipark'], true);
    $pageTitle = $isRentacar ? ___('Rent cars') : ___('Cars');
@endphp
@section('title', $pageTitle)
@section('page_title', $pageTitle)
@section('page_subtitle')
    {{ ___('User') }}: {{ $user->first_name }} {{ $user->last_name }}
@endsection
@section('page_actions')
    <a class="btn primary action-right" href="{{ route('vehicles.create') }}">+ {{ ___('New car') }}</a>
    <a class="btn ghost" href="{{ route('vehicles.gps_setup') }}">{{ ___('GPS guide') }}</a>
    <a class="btn ghost" href="{{ route('company.gps') }}">{{ ___('Fleet map') }}</a>
@endsection

@section('content')
    <div class="card">
        <form class="row" method="GET" action="{{ route('vehicles.index') }}">
            <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <input name="q" value="{{ $q }}" placeholder="{{ ___('Search: brand, model, plate, status') }}">
                <select name="status">
                    <option value="">{{ ___('Status: all') }}</option>
                    @foreach($statuses as $key => $label)
                        <option value="{{ $key }}" @selected($status === $key)>{{ $label }}</option>
                    @endforeach
                </select>
                <button class="btn" type="submit">{{ ___('Search') }}</button>
                @if($q !== '' || $status !== '')
                    <a class="btn" href="{{ route('vehicles.index') }}">{{ ___('Reset') }}</a>
                @endif
            </div>
        </form>

        <table style="margin-top:12px;">
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Brand/Model') }}</th>
                @if($isRentacar)
                    <th>{{ ___('Plate') }}</th>
                    <th>{{ ___('Prices') }}</th>
                    <th>{{ ___('Return due') }}</th>
                @else
                    <th>{{ ___('Year') }}</th>
                    <th>{{ ___('Plate') }}</th>
                @endif
                <th>{{ ___('Status') }}</th>
                <th style="width:260px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($vehicles as $v)
                @php
                    $ownershipClass = '';
                    if ($isRentacar) {
                        $ownershipClass = $v->owner_type === 'owner' ? 'vehicle-row owner' : 'vehicle-row company';
                    }
                @endphp
                <tr class="{{ $ownershipClass }}">
                    <td>{{ $v->id }}</td>
                    <td>{{ $v->brand }} {{ $v->model }}</td>
                    @if($isRentacar)
                        <td>{{ $v->plate_number ?? '-' }}</td>
                        <td>
                            @php
                                $daily = $v->rent_daily_price !== null ? number_format((float)$v->rent_daily_price, 2) . ' AZN' : '-';
                                $weekly = $v->rent_weekly_price !== null ? number_format((float)$v->rent_weekly_price, 2) . ' AZN' : '-';
                                $monthly = $v->rent_monthly_price !== null ? number_format((float)$v->rent_monthly_price, 2) . ' AZN' : '-';
                            @endphp
                            <div class="muted small">{{ ___('Daily') }}: {{ $daily }}</div>
                            <div class="muted small">{{ ___('Weekly') }}: {{ $weekly }}</div>
                            <div class="muted small">{{ ___('Monthly') }}: {{ $monthly }}</div>
                        </td>
                        <td>
                            @if($v->rent_due_at)
                                <div>{{ $v->rent_due_at->format('Y-m-d H:i') }}</div>
                                <div class="muted small">
                                    {{ $v->rent_due_at->isPast() ? ___('Overdue by') : ___('Remaining') }}
                                    {{ $v->rent_due_at->diffForHumans(now(), true) }}
                                </div>
                            @else
                                -
                            @endif
                        </td>
                    @else
                        <td>{{ $v->year ?? '-' }}</td>
                        <td>{{ $v->plate_number ?? '-' }}</td>
                    @endif
                    <td>
                        @php
                            $statusClass = 'bad';
                            if ($v->status === 'available') $statusClass = 'ok';
                            elseif ($v->status === 'leasing' || $v->status === 'rented') $statusClass = 'warn';
                        @endphp
                        <span class="badge {{ $statusClass }}">
                            {{ $statuses[$v->status] ?? $v->status }}
                        </span>
                    </td>
                    <td>
                        <div class="actions">
                            <a class="btn ghost" href="{{ route('vehicles.gps', $v) }}">{{ ___('GPS') }}</a>
                            <a class="btn" href="{{ route('vehicles.edit', $v) }}">{{ ___('Edit') }}</a>

                            <form method="POST" action="{{ route('vehicles.destroy', $v) }}"
                                  onsubmit="return confirm(@json(___('Are you sure you want to delete?')));">
                                @csrf
                                @method('DELETE')
                                <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6" class="muted">{{ ___('No cars found.') }}</td>
                </tr>
            @endforelse
            </tbody>
        </table>

        <div style="margin-top:12px;">
            {{ $vehicles->links() }}
        </div>
    </div>
@endsection
