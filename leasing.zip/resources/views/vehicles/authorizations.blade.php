@extends('layouts.app')
@section('title', ___('Vehicle authorizations'))
@section('page_title', ___('Vehicle authorizations'))
@section('page_subtitle')
    {{ $vehicle->display_name }} (ID #{{ $vehicle->id }})
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.edit', $vehicle) }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="card banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('vehicles.authorizations.store', $vehicle) }}">
            @csrf
            <div class="row">
                <div class="field">
                    <label>{{ ___('Authorized person') }}</label>
                    <input name="authorized_name" value="{{ old('authorized_name') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Start date') }}</label>
                    <input type="date" name="start_date" value="{{ old('start_date') }}">
                </div>
                <div class="field">
                    <label>{{ ___('End date') }}</label>
                    <input type="date" name="end_date" value="{{ old('end_date') }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="field">
                <label>{{ ___('Note') }}</label>
                <textarea name="note" rows="3">{{ old('note') }}</textarea>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Add authorization') }}</button>
            </div>
        </form>
    </div>

    <div class="card" style="margin-top:12px;">
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Authorized person') }}</th>
                <th>{{ ___('Start') }}</th>
                <th>{{ ___('End') }}</th>
                <th>{{ ___('Note') }}</th>
                <th style="width:140px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($authorizations as $a)
                <tr>
                    <td>{{ $a->id }}</td>
                    <td>{{ $a->authorized_name }}</td>
                    <td>{{ $a->start_date?->format('Y-m-d') ?? '-' }}</td>
                    <td>{{ $a->end_date?->format('Y-m-d') ?? '-' }}</td>
                    <td>{{ $a->note ?? '-' }}</td>
                    <td>
                        <form method="POST" action="{{ route('vehicles.authorizations.destroy', $a) }}"
                              onsubmit="return confirm('{{ ___('Are you sure you want to delete?') }}');">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">{{ ___('No authorizations yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:12px;">
            {{ $authorizations->links() }}
        </div>
    </div>
@endsection
