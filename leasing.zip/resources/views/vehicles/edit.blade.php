@extends('layouts.app')
@php
    $isRentacar = in_array(($module ?? 'leasing'), ['rentacar','taxipark'], true);
    $pageTitle = $isRentacar ? ___('Edit rent car') : ___('Edit Car');
    $rentDueValue = old('rent_due_at');
    if ($rentDueValue === null && $vehicle->rent_due_at) {
        $rentDueValue = $vehicle->rent_due_at->format('Y-m-d\\TH:i');
    }
    $gpsProvider = $gpsProvider ?? null;
    $gpsConnected = !empty($gpsProvider);
    $vehicleRequest = $vehicleRequest ?? null;
@endphp
@section('title', $pageTitle)
@section('page_title', $pageTitle)
@section('page_subtitle')
    ID #{{ $vehicle->id }} - {{ $vehicle->display_name }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('vehicles.index') }}">{{ ___('Back') }}</a>
    <a class="btn ghost" href="{{ route('vehicles.authorizations.index', $vehicle) }}">{{ ___('Authorizations') }}</a>
@endsection

@section('content')
@if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('vehicles.update', $vehicle) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="field">
                    <label>{{ ___('Mark') }}</label>
                    <input name="brand" value="{{ old('brand', $vehicle->brand) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Model') }}</label>
                    <input name="model" value="{{ old('model', $vehicle->model) }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Alt model (opsional)') }}</label>
                    <input name="sub_model" value="{{ old('sub_model', $vehicle->sub_model) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Year (optional)') }}</label>
                    <input name="year" value="{{ old('year', $vehicle->year) }}" placeholder="2020">
                </div>
                <div class="field">
                    <label>{{ ___('Color (optional)') }}</label>
                    <input name="color" value="{{ old('color', $vehicle->color) }}" placeholder="{{ ___('Example: Black / White') }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Plate number (opsional)') }}</label>
                    <input name="plate_number" value="{{ old('plate_number', $vehicle->plate_number) }}" placeholder="10-AA-123">
                </div>
                <div class="field">
                    <label>{{ ___('VIN (opsional)') }}</label>
                    <input name="vin_code" value="{{ old('vin_code', $vehicle->vin_code) }}" placeholder="VIN...">
                </div>
                <div class="field">
                    <label>{{ ___('GPS provider') }}</label>
                    <div class="muted small">{{ $gpsProvider === 'wialon' ? 'Wialon' : ($gpsProvider === 'traccar' ? 'Traccar' : ___('Not connected')) }}</div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field" data-gps-provider="traccar" style="{{ $gpsProvider === 'wialon' ? 'display:none;' : '' }}">
                    <label>{{ ___('Traccar device ID (optional)') }}</label>
                    <input name="traccar_device_id" value="{{ old('traccar_device_id', $vehicle->traccar_device_id) }}" placeholder="uniqueId" @disabled(!$gpsConnected)>
                    <div class="muted small">{{ ___('Enter the device uniqueId configured in Traccar') }}</div>
                </div>
                <div class="field" data-gps-provider="wialon" style="{{ $gpsProvider === 'wialon' ? '' : 'display:none;' }}">
                    <label>{{ ___('Wialon device unique ID (optional)') }}</label>
                    <input name="wialon_unique_id" value="{{ old('wialon_unique_id', $vehicle->wialon_unique_id) }}" placeholder="IMEI / serial" @disabled(!$gpsConnected)>
                    <div class="muted small">{{ ___('Unique ID will be sent to provider for unit creation.') }}</div>
                    @if($vehicle->wialon_device_id)
                        <div class="muted small">{{ ___('Unit ID') }}: {{ $vehicle->wialon_device_id }}</div>
                    @endif
                    @if($vehicleRequest)
                        <div class="muted small">{{ ___('Request status') }}: {{ strtoupper($vehicleRequest->status) }}</div>
                    @endif
                </div>
            </div>
            @if(!$gpsConnected)
                <div class="muted small" style="margin-top:8px;">{{ ___('GPS provider is not connected yet. Device fields are disabled.') }}</div>
            @endif

            <div style="height:12px;"></div>

            @if($isRentacar)
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Daily price') }}</label>
                        <input name="rent_daily_price" value="{{ old('rent_daily_price', $vehicle->rent_daily_price) }}" placeholder="0">
                    </div>
                    <div class="field">
                        <label>{{ ___('Weekly price') }}</label>
                        <input name="rent_weekly_price" value="{{ old('rent_weekly_price', $vehicle->rent_weekly_price) }}" placeholder="0">
                    </div>
                    <div class="field">
                        <label>{{ ___('Monthly price') }}</label>
                        <input name="rent_monthly_price" value="{{ old('rent_monthly_price', $vehicle->rent_monthly_price) }}" placeholder="0">
                    </div>
                </div>

                <div style="height:12px;"></div>

                @php
                    $ownerType = old('owner_type', $vehicle->owner_type ?: 'company');
                @endphp
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Ownership') }}</label>
                        <select name="owner_type" id="ownerType">
                            <option value="company" @selected($ownerType === 'company')>{{ ___('Company-owned') }}</option>
                            <option value="owner" @selected($ownerType === 'owner')>{{ ___('Owner vehicle (leased)') }}</option>
                        </select>
                    </div>
                </div>

                <div id="ownerSection" style="margin-top:12px; display:none;">
                    <div class="row">
                        <div class="field">
                            <label>{{ ___('Vehicle owner') }}</label>
                            <select name="owner_customer_id">
                                <option value="">{{ ___('Select') }}</option>
                                @foreach($customers ?? [] as $c)
                                    @php $name = trim($c->first_name.' '.$c->last_name); @endphp
                                    <option value="{{ $c->id }}" @selected(old('owner_customer_id', $vehicle->owner_customer_id) == $c->id)>
                                        {{ $name }} {{ $c->phone ? '(' . $c->phone . ')' : '' }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="field">
                            <label>{{ ___('Owner payment type') }}</label>
                            <select name="owner_payment_type">
                                <option value="">{{ ___('Select') }}</option>
                                <option value="daily" @selected(old('owner_payment_type', $vehicle->owner_payment_type) === 'daily')>{{ ___('Daily') }}</option>
                                <option value="weekly" @selected(old('owner_payment_type', $vehicle->owner_payment_type) === 'weekly')>{{ ___('Weekly') }}</option>
                                <option value="monthly" @selected(old('owner_payment_type', $vehicle->owner_payment_type) === 'monthly')>{{ ___('Monthly') }}</option>
                                <option value="per_rental" @selected(old('owner_payment_type', $vehicle->owner_payment_type) === 'per_rental')>{{ ___('Per rental') }}</option>
                            </select>
                        </div>
                        <div class="field">
                            <label>{{ ___('Owner payment amount') }}</label>
                            <input name="owner_payment_amount" value="{{ old('owner_payment_amount', $vehicle->owner_payment_amount) }}" placeholder="0">
                        </div>
                    </div>
                </div>

                <div style="height:12px;"></div>

                <div class="row">
                    <div class="field">
                        <label>{{ ___('Car source (supplier/owner)') }}</label>
                        <input name="rent_source" value="{{ old('rent_source', $vehicle->rent_source) }}" placeholder="{{ ___('Example: Owner name') }}">
                    </div>
                    <div class="field">
                        <label>{{ ___('Return due at') }}</label>
                        <input type="datetime-local" name="rent_due_at" value="{{ $rentDueValue }}">
                    </div>
                </div>
            @else
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Purchase price (opsional)') }}</label>
                        <input name="purchase_price" value="{{ old('purchase_price', $vehicle->purchase_price) }}" placeholder="0">
                    </div>
                    <div class="field">
                        <label>{{ ___('Selling price (opsional)') }}</label>
                        <input name="sale_price" value="{{ old('sale_price', $vehicle->sale_price) }}" placeholder="0">
                    </div>
                </div>
            @endif

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Specs') }}</label>
                    @php
                        $specKeys = old('specs_k');
                        $specVals = old('specs_v');
                        if (!is_array($specKeys)) { $specKeys = array_keys($vehicle->specs ?? []); }
                        if (!is_array($specVals)) { $specVals = array_values($vehicle->specs ?? []); }
                        $specCount = max(1, count($specKeys), count($specVals));
                    @endphp
                    <div id="specs-rows"
                         data-kv-key-name="specs_k"
                         data-kv-value-name="specs_v"
                         data-kv-key-placeholder="{{ ___('Key') }}"
                         data-kv-value-placeholder="{{ ___('Value') }}">
                        @for($i = 0; $i < $specCount; $i++)
                            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:8px; margin-bottom:8px;">
                                <input class="input" name="specs_k[]" value="{{ $specKeys[$i] ?? '' }}" placeholder="{{ ___('Key') }}">
                                <input class="input" name="specs_v[]" value="{{ $specVals[$i] ?? '' }}" placeholder="{{ ___('Value') }}">
                            </div>
                        @endfor
                    </div>
                    <button class="btn ghost" type="button" data-kv-add="specs-rows">{{ ___('+ Add spec') }}</button>
                </div>
                <div class="field">
                    <label>{{ ___('Comfort') }}</label>
                    @php
                        $comfortKeys = old('comforts_k');
                        $comfortVals = old('comforts_v');
                        if (!is_array($comfortKeys)) { $comfortKeys = array_keys($vehicle->comforts ?? []); }
                        if (!is_array($comfortVals)) { $comfortVals = array_values($vehicle->comforts ?? []); }
                        $comfortCount = max(1, count($comfortKeys), count($comfortVals));
                    @endphp
                    <div id="comforts-rows"
                         data-kv-key-name="comforts_k"
                         data-kv-value-name="comforts_v"
                         data-kv-key-placeholder="{{ ___('Key') }}"
                         data-kv-value-placeholder="{{ ___('Value') }}">
                        @for($i = 0; $i < $comfortCount; $i++)
                            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:8px; margin-bottom:8px;">
                                <input class="input" name="comforts_k[]" value="{{ $comfortKeys[$i] ?? '' }}" placeholder="{{ ___('Key') }}">
                                <input class="input" name="comforts_v[]" value="{{ $comfortVals[$i] ?? '' }}" placeholder="{{ ___('Value') }}">
                            </div>
                        @endfor
                    </div>
                    <button class="btn ghost" type="button" data-kv-add="comforts-rows">{{ ___('+ Add comfort') }}</button>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Public title (optional)') }}</label>
                    <input name="public_title" value="{{ old('public_title', $vehicle->public_title) }}" placeholder="{{ ___('Shown on public theme') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Public description (optional)') }}</label>
                    <textarea name="public_description" rows="3" placeholder="{{ ___('Short description for public page') }}">{{ old('public_description', $vehicle->public_description) }}</textarea>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Status') }}</label>
                    <select name="status">
                        @foreach($statuses as $key => $label)
                            <option value="{{ $key }}" @selected(old('status', $vehicle->status) === $key)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('Flags') }}</label>

                    <div class="switch">
                        <input type="checkbox" name="has_insurance" value="1" @checked(old('has_insurance', (int)$vehicle->has_insurance) == 1)>
                        <div>
                            <div style="font-weight:700;">{{ ___('Has insurance') }}</div>
                            <div class="muted small">has_insurance</div>
                        </div>
                    </div>

                    <div style="height:10px;"></div>

                    <div class="switch">
                        <input type="checkbox" name="has_technical" value="1" @checked(old('has_technical', (int)$vehicle->has_technical) == 1)>
                        <div>
                            <div style="font-weight:700;">{{ ___('Has technical') }}</div>
                            <div class="muted small">has_technical</div>
                        </div>
                    </div>

                    <div style="height:10px;"></div>

                    <div class="switch">
                        <input type="checkbox" name="is_returned" value="1" @checked(old('is_returned', (int)$vehicle->is_returned) == 1)>
                        <div>
                            <div style="font-weight:700;">{{ ___('Is returned') }}</div>
                            <div class="muted small">is_returned</div>
                        </div>
                    </div>
                </div>
            </div>

            <div style="height:14px;"></div>

            <div class="field">
                <label>{{ ___('Upload new images (opsional)') }}</label>
                <input type="file" name="images_new[]" id="imagesNew" accept="image/*" multiple>
                <div class="muted small">{{ ___('You can select multiple images. Uploaded ones will be previewed below.') }}</div>
            </div>

            <div style="height:12px;"></div>

            @php
                $existing = is_array($vehicle->images) ? $vehicle->images : [];
            @endphp

            @if(count($existing))
                <div style="font-weight:700; margin-bottom:8px;">
                    {{ ___('Available images') }} ({{ count($existing) }})
                </div>

                <div class="gridimg">
                    @foreach($existing as $path)
                        @php
                            // $path is already converted to string in controller; keep safe
                            $p = is_array($path) ? ($path['path'] ?? $path['url'] ?? '') : (string)$path;
                            $p = trim($p);
                        @endphp

                        @if($p !== '')
                            <label class="imgbox">
                                <img src="{{ Storage::disk('public')->url($p) }}" alt="img">
                                <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-top:8px;">
                                    <div class="muted small" style="word-break:break-all;">{{ $p }}</div>
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <span class="muted small">{{ ___('Delete') }}</span>
                                        <input type="checkbox" name="delete_images[]" value="{{ $p }}">
                                    </div>
                                </div>
                            </label>
                        @endif
                    @endforeach
                </div>
            @endif

            <div style="height:12px;"></div>

            <div style="font-weight:700; margin-bottom:8px;">{{ ___('Newly selected (preview)') }}</div>
            <div id="newPreview" class="gridimg"></div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

<script>
(function(){
    const input = document.getElementById('imagesNew');
    const box   = document.getElementById('newPreview');

    function clearBox(){ box.innerHTML = ''; }

    function addThumb(file){
        const wrap = document.createElement('div');
        wrap.className = 'imgbox';

        const img = document.createElement('img');
        img.alt = 'preview';
        wrap.appendChild(img);

        const meta = document.createElement('div');
        meta.className = 'muted small';
        meta.style.marginTop = '8px';
        meta.textContent = file.name + ' - ' + Math.round(file.size/1024) + ' KB';
        wrap.appendChild(meta);

        const reader = new FileReader();
        reader.onload = (e) => { img.src = e.target.result; };
        reader.readAsDataURL(file);

        box.appendChild(wrap);
    }

    input?.addEventListener('change', () => {
        clearBox();
        const files = Array.from(input.files || []);
        files.forEach(addThumb);
    });
})();
</script>
<script>
(function(){
    function addKvRow(targetId) {
        const wrap = document.getElementById(targetId);
        if (!wrap) return;
        const keyName = wrap.getAttribute('data-kv-key-name');
        const valueName = wrap.getAttribute('data-kv-value-name');
        const keyPh = wrap.getAttribute('data-kv-key-placeholder') || '';
        const valPh = wrap.getAttribute('data-kv-value-placeholder') || '';

        const row = document.createElement('div');
        row.style.display = 'grid';
        row.style.gridTemplateColumns = '1fr 1fr';
        row.style.gap = '8px';
        row.style.marginBottom = '8px';

        const keyInput = document.createElement('input');
        keyInput.className = 'input';
        keyInput.name = keyName + '[]';
        keyInput.placeholder = keyPh;

        const valInput = document.createElement('input');
        valInput.className = 'input';
        valInput.name = valueName + '[]';
        valInput.placeholder = valPh;

        row.appendChild(keyInput);
        row.appendChild(valInput);
        wrap.appendChild(row);
    }

    document.querySelectorAll('[data-kv-add]').forEach(btn => {
        btn.addEventListener('click', () => addKvRow(btn.getAttribute('data-kv-add')));
    });
})();
</script>
<script>
(function(){
    const ownerType = document.getElementById('ownerType');
    const ownerSection = document.getElementById('ownerSection');
    function toggleOwner(){
        if (!ownerType || !ownerSection) return;
        ownerSection.style.display = ownerType.value === 'owner' ? 'block' : 'none';
    }
    ownerType?.addEventListener('change', toggleOwner);
    toggleOwner();
})();
</script>
@endsection
