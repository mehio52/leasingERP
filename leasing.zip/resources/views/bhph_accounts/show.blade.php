@extends('layouts.app')

@section('title', ___('bhph_account_title', ['id' => $account->id]))
@section('page_title', ___('bhph_account_title', ['id' => $account->id]))
@section('page_subtitle')
Customer: {{ $account->customer?->first_name }} {{ $account->customer?->last_name }}
- Vehicle: {{ $account->vehicle?->brand }} {{ $account->vehicle?->model }}
{{ $account->vehicle?->year ? "({$account->vehicle->year})" : '' }}

@endsection

@section('page_actions')
    <a class="btn ghost" href="{{ route('bhph_accounts.index') }}">{{ ___('Back') }}</a>
    <a class="btn" href="{{ route('bhph_accounts.edit', $account) }}">{{ ___('Edit') }}</a>
    <form method="POST" action="{{ route('bhph_accounts.destroy', $account) }}" onsubmit="return confirm('{{ ___('This account will be archived. Continue?') }}');">
        @csrf
        @method('DELETE')
        <button class="btn danger" type="submit">{{ ___('Archive') }}</button>
    </form>
@endsection

@section('content')
@php
    // Avoid undefined in Blade
    $paymentOption = $paymentOption ?? null;
    $payments = $payments ?? collect();
    $penaltySummary = $penaltySummary ?? ['outstanding' => 0, 'total_accrued' => 0, 'total_paid' => 0, 'rows' => []];
    $penaltyOutstanding = (float)($penaltySummary['outstanding'] ?? 0);
    $penaltyAccrued = (float)($penaltySummary['total_accrued'] ?? 0);
    $penaltyPaid = (float)($penaltySummary['total_paid'] ?? 0);
    $penaltyRows = $penaltySummary['rows'] ?? [];

    $ov = session('need_overpay_choice');
    $allowed = is_array($ov) ? ($ov['allowed_actions'] ?? []) : [];
    $balQ = session('need_balance_choice');

    // Default overpay_action selection:
    // 1) old('overpay_action')
    // 2) paymentOption->overpayment_behavior (if allowed)
    // 3) allowed_actions[0]
    $defaultAction = old('overpay_action');
    if (!$defaultAction) {
        $pref = $paymentOption?->overpayment_behavior;
        if ($pref && in_array($pref, $allowed, true)) {
            $defaultAction = $pref;
        } elseif (!empty($allowed)) {
            $defaultAction = $allowed[0];
        } else {
            $defaultAction = '';
        }
    }

    $isAllowed = function(string $a) use ($allowed): bool {
        return empty($allowed) ? true : in_array($a, $allowed, true);
    };

    $suggestedAmount = (float)($currentDue ?? 0) + $penaltyOutstanding;
@endphp

<div class="wrap">

    @if(session('status'))
        <div class="card"><span class="badge ok">{{ session('status') }}</span></div>
    @endif

    @if($balQ)
        <div class="card banner info">
            <div>
                <span class="badge">{{ ___('Balance') }}</span>
                <div style="margin-top:10px; font-weight:800;">
                    {{ $balQ['message'] ?? ___('The balance is not enough to complete the payment.') }}
                </div>
                <div class="muted" style="margin-top:6px;">
                    {{ ___('Balance:') }} <b>{{ number_format((float)($balQ['balance'] ?? 0),2) }} AZN</b>
                </div>
            </div>

            <div style="display:flex; gap:10px; margin-top:12px; flex-wrap:wrap;">
                <form method="POST" action="{{ route('payments.cash.store', $account) }}">
                    @csrf
                    <input type="hidden" name="paid_date" value="{{ $balQ['draft']['paid_date'] ?? old('paid_date') }}">
                    <input type="hidden" name="amount" value="{{ $balQ['draft']['amount'] ?? old('amount') }}">
                    <input type="hidden" name="reference" value="{{ $balQ['draft']['reference'] ?? old('reference') }}">
                    <input type="hidden" name="note" value="{{ $balQ['draft']['note'] ?? old('note') }}">
                    <input type="hidden" name="use_balance" value="partial">
                    <button class="btn primary" type="submit">{{ ___('Pay up to balance') }}</button>
                </form>

                <form method="POST" action="{{ route('payments.cash.store', $account) }}">
                    @csrf
                    <input type="hidden" name="paid_date" value="{{ $balQ['draft']['paid_date'] ?? old('paid_date') }}">
                    <input type="hidden" name="amount" value="{{ $balQ['draft']['amount'] ?? old('amount') }}">
                    <input type="hidden" name="reference" value="{{ $balQ['draft']['reference'] ?? old('reference') }}">
                    <input type="hidden" name="note" value="{{ $balQ['draft']['note'] ?? old('note') }}">
                    <input type="hidden" name="use_balance" value="topup">
                    <button class="btn" type="submit">{{ ___('I will top up the rest with cash') }}</button>
                </form>
            </div>
        </div>
    @endif

    {{-- ✅ Overpayment choice --}}
    @if($ov)
        <div class="card banner warn">
            <div>
                <span class="badge warn">{{ ___('Question') }}</span>
                <div style="margin-top:10px; font-weight:800;">
                    {{ $ov['message'] ?? ___('There is an excess amount. A choice is required.') }}
                </div>
                <div class="muted" style="margin-top:6px;">
                    {{ ___('Overpayment:') }} <b>{{ number_format((float)($ov['remainder'] ?? 0), 2) }} AZN</b>
                </div>
            </div>

            <form method="POST" action="{{ route('payments.cash.store', $account) }}" style="margin-top:12px;">
                @csrf

                <input type="hidden" name="paid_date" value="{{ $ov['draft']['paid_date'] ?? old('paid_date') }}">
                <input type="hidden" name="amount" value="{{ $ov['draft']['amount'] ?? old('amount') }}">
                <input type="hidden" name="reference" value="{{ $ov['draft']['reference'] ?? old('reference') }}">
                <input type="hidden" name="note" value="{{ $ov['draft']['note'] ?? old('note') }}">

                <div class="muted" style="margin-bottom:8px;">{{ ___('What should we do with the overpayment?') }}</div>

                @php
                    $canAdvance  = (bool)($paymentOption?->allow_advance_payment ?? false);
                    $canOverpay  = (bool)($paymentOption?->allow_overpayment ?? false);
                    $canPrincipalOnly = (bool)($paymentOption?->allow_principal_only_payment ?? false);

                    $chosen = old('overpay_action', $defaultAction); // default: reduce principal
                @endphp

                <label style="display:block; margin:8px 0; {{ $canAdvance ? '' : 'opacity:.5;' }}">
                    <input type="radio" name="overpay_action" value="apply_next_installments"
                        {{ $canAdvance ? '' : 'disabled' }}
                        {{ $chosen === 'apply_next_installments' ? 'checked' : '' }}>
                    {{ ___('Apply to next installments') }}
                    @if(!$canAdvance) <span class="muted"> {{ ___('(advance payment is disabled)') }}</span> @endif
                </label>

                <label style="display:block; margin:8px 0; {{ ($canOverpay && $canPrincipalOnly) ? '' : 'opacity:.5;' }}">
                    <input type="radio" name="overpay_action" value="reduce_principal"
                        {{ ($canOverpay && $canPrincipalOnly) ? '' : 'disabled' }}
                        {{ $chosen === 'reduce_principal' ? 'checked' : '' }}>
                    {{ ___('Reduce principal (without changing amortization)') }}
                    @if(!($canOverpay && $canPrincipalOnly)) <span class="muted"> {{ ___('(permission is disabled)') }}</span> @endif
                </label>

                <label style="display:block; margin:8px 0; {{ $canOverpay ? '' : 'opacity:.5;' }}">
                    <input type="radio" name="overpay_action" value="keep_as_credit"
                        {{ $canOverpay ? '' : 'disabled' }}
                        {{ $chosen === 'keep_as_credit' ? 'checked' : '' }}>
                    {{ ___('Keep as credit (store in balance)') }}
                    @if(!$canOverpay) <span class="muted"> {{ ___('(overpayment is disabled)') }}</span> @endif
                </label>

                @if($errors->any())
                    <div style="margin-top:10px; padding:10px 12px; border-radius:12px; border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.08);">
                        <div class="badge bad">{{ ___('Error') }}</div>
                        <ul style="margin:10px 0 0; padding-left:18px;">
                            @foreach($errors->all() as $e) <li>{{ $e }}</li> @endforeach
                        </ul>
                    </div>
                @endif

                <div style="margin-top:10px; display:flex; gap:10px; justify-content:flex-end;">
                    <a class="btn" href="{{ route('bhph_accounts.show', $account) }}">{{ ___('Cancel') }}</a>
                    <button class="btn primary" type="submit">{{ ___('Confirm and apply') }}</button>
                </div>
            </form>
        </div>
    @endif

    @if($penaltyOutstanding > 0)
        <div class="card banner warn">
            <div>
                <span class="badge warn">{{ ___('Penalty') }}</span>
                <div style="margin-top:10px; font-weight:800;">
                    {{ ___('Current late penalty:') }} <b>{{ number_format($penaltyOutstanding,2) }} AZN</b>
                </div>
                <div class="muted" style="margin-top:6px;">
                    {{ ___('It will be deducted automatically when entering the payment.') }}
                </div>
            </div>
        </div>
    @endif

    {{-- Cash payment form --}}
    <div class="card">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:12px;">
            <div>
                <div style="font-weight:800;">{{ ___('Cash payment') }}</div>
                <div class="muted" style="margin-top:4px;">
                    {{ ___('apply_to:') }} <b>{{ $paymentOption?->apply_to ?? '-' }}</b> •
                    {{ ___('allocation order:') }} <b>{{ $paymentOption?->allocation_order ?? '-' }}</b> •
                    {{ ___('partial:') }} <b>{{ ($paymentOption?->allow_partial_payment ?? false) ? ___('yes') : ___('no') }}</b> •
                    {{ ___('overpayment:') }} <b>{{ ($paymentOption?->allow_overpayment ?? false) ? ___('yes') : ___('no') }}</b> •
                    {{ ___('advance:') }} <b>{{ ($paymentOption?->allow_advance_payment ?? false) ? ___('yes') : ___('no') }}</b>
                </div>
            </div>
        </div>

        @if($errors->any() && !$ov)
            <div style="margin-top:10px; padding:10px 12px; border-radius:12px; border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.08);">
                <div class="badge bad">{{ ___('Error') }}</div>
                <ul style="margin:10px 0 0; padding-left:18px;">
                    @foreach($errors->all() as $e) <li>{{ $e }}</li> @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('payments.cash.store', $account) }}" style="margin-top:12px;">
            @csrf
            <table>
                <tr>
                    <th style="width:180px;">{{ ___('Date') }}</th>
                    <td><input class="input" name="paid_date" type="date" value="{{ old('paid_date', now()->toDateString()) }}"></td>
                </tr>
                <tr>
                    <th>{{ ___('Amount (AZN)') }}</th>
                    <td>
                        <input class="input" name="amount" type="number" step="0.01" value="{{ old('amount', number_format((float)$suggestedAmount,2,'.','')) }}" required style="width:220px;">
                        <div class="muted small" style="margin-top:6px;">
                            {{ ___('Current penalty:') }} <b>{{ number_format($penaltyOutstanding,2) }} AZN</b> {{ ___('(deducted automatically from the payment)') }}
                        </div>
                    </td>
                </tr>
                <tr>
                    <th>{{ ___('Receipt/Reference (optional)') }}</th>
                    <td><input class="input" name="reference" value="{{ old('reference') }}" style="width:420px;"></td>
                </tr>
                <tr>
                    <th>{{ ___('Note') }}</th>
                    <td><input class="input" name="note" value="{{ old('note') }}" style="width:100%;"></td>
                </tr>
                <tr>
                    <th>{{ ___('Balance') }}</th>
                    <td>
                        <div class="muted">{{ ___('Current balance:') }} <b>{{ number_format((float)($account->credit_balance ?? 0),2) }} AZN</b></div>
                        <label class="radioRow">
                            <input type="radio" name="use_balance" value="none" {{ old('use_balance','auto')==='none' ? 'checked' : '' }}>
                            <div>
                                <b>{{ ___('Do not use balance') }}</b>
                            </div>
                        </label>
                        <label class="radioRow">
                            <input type="radio" name="use_balance" value="auto" {{ old('use_balance','auto')==='auto' ? 'checked' : '' }}>
                            <div>
                                <b>{{ ___('Use balance as much as possible') }}</b>
                                <div class="muted small">{{ ___('If sufficient, it pays in full; if not, you will be asked to choose.') }}</div>
                            </div>
                        </label>
                        <label class="radioRow">
                            <input type="radio" name="use_balance" value="partial" {{ old('use_balance')==='partial' ? 'checked' : '' }}>
                            <div>
                                <b>{{ ___('Pay only up to balance') }}</b>
                                <div class="muted small">{{ ___('Applies the balance amount without adding cash.') }}</div>
                            </div>
                        </label>
                        <label class="radioRow">
                            <input type="radio" name="use_balance" value="topup" {{ old('use_balance')==='topup' ? 'checked' : '' }}>
                            <div>
                                <b>{{ ___('Balance + top up with cash') }}</b>
                                <div class="muted small">{{ ___('Will use the maximum from balance, and you will pay the rest.') }}</div>
                            </div>
                        </label>
                    </td>
                </tr>
            </table>

            <div style="margin-top:10px; display:flex; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ ___('Accept cash payment') }}</button>
            </div>
        </form>
    </div>

    {{-- Recent payments --}}
    <div class="card">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
            <div style="font-weight:800;">{{ ___('Recent payments') }}</div>
            <div class="muted">{{ ___('Last 20 records') }}</div>
        </div>

        <table>
            <thead>
            <tr>
                <th>{{ ___('ID') }}</th>
                <th>{{ ___('History') }}</th>
                <th>{{ ___('Method') }}</th>
                <th>{{ ___('Status') }}</th>
                <th class="right">{{ ___('Amount') }}</th>
                <th class="right">{{ ___('Interest') }}</th>
                <th class="right">{{ ___('Principal') }}</th>
                <th class="right">{{ ___('Penalty') }}</th>
                <th>{{ ___('Receipt/Reference') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($payments as $p)
                <tr>
                    <td>{{ $p->id }}</td>
                    <td>{{ optional($p->paid_date)->format('Y-m-d') }}</td>
                    <td><span class="badge">{{ $p->method }}</span></td>
                    <td><span class="badge">{{ $p->status }}</span></td>
                    <td class="right">{{ number_format((float)$p->amount,2) }}</td>
                    <td class="right">{{ number_format((float)$p->interest_amount,2) }}</td>
                    <td class="right">{{ number_format((float)$p->principal_amount,2) }}</td>
                    <td class="right">{{ number_format((float)$p->penalty_amount,2) }}</td>
                    <td class="small">{{ $p->reference ?? '-' }}</td>
                </tr>
            @empty
                <tr><td colspan="9" class="muted">{{ ___('No payments yet.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    {{-- Late penalties --}}
    <div class="card">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
            <div style="font-weight:800;">{{ ___('Late penalties') }}</div>
            <div class="muted">{{ ___('As of:') }} {{ now()->toDateString() }}</div>
        </div>

        <div class="grid" style="margin-top:8px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:10px;">
            <div class="kv"><span class="muted">{{ ___('Accrued') }}</span><span>{{ number_format($penaltyAccrued,2) }} AZN</span></div>
            <div class="kv"><span class="muted">{{ ___('Paid') }}</span><span>{{ number_format($penaltyPaid,2) }} AZN</span></div>
            <div class="kv"><span class="muted">{{ ___('Outstanding') }}</span><span><b>{{ number_format($penaltyOutstanding,2) }} AZN</b></span></div>
        </div>

        @if(empty($penaltyRows))
            <div class="muted" style="margin-top:10px;">{{ ___('No active penalties.') }}</div>
        @else
            <table style="margin-top:12px;">
                <thead>
                <tr>
                    <th>#</th>
                    <th>{{ ___('Date') }}</th>
                    <th class="right">{{ ___('Late (days)') }}</th>
                    <th class="right">{{ ___('Base') }}</th>
                    <th class="right">{{ ___('Penalty') }}</th>
                </tr>
                </thead>
                <tbody>
                @foreach($penaltyRows as $pr)
                    <tr>
                        <td>{{ $pr['installment_no'] ?? '-' }}</td>
                        <td>{{ \Carbon\Carbon::parse($pr['due_date'] ?? now())->format('Y-m-d') }}</td>
                        <td class="right">{{ number_format((float)($pr['days_late'] ?? 0),0) }}</td>
                        <td class="right">{{ number_format((float)($pr['base'] ?? 0),2) }}</td>
                        <td class="right">{{ number_format((float)($pr['accrued'] ?? 0),2) }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        @endif
    </div>

    {{-- Account info --}}
    <div class="card">
        <div class="grid">
            <div>
                <div style="font-weight:800; margin-bottom:8px;">{{ ___('Account') }}</div>
                <div class="kv"><span class="muted">{{ ___('Status') }}</span><span class="badge">{{ $account->status }}</span></div>
                <div class="kv"><span class="muted">{{ ___('Start date') }}</span><span>{{ optional($account->payment_start_date)->format('Y-m-d') }}</span></div>
                <div class="kv"><span class="muted">{{ ___('Term (months)') }}</span><span>{{ $account->term_months }}</span></div>
                <div class="kv"><span class="muted">{{ ___('Annual interest') }}</span><span>{{ $account->annual_interest_rate }}%</span></div>
                <div class="kv"><span class="muted">{{ ___('Contract No') }}</span><span>{{ $account->contract?->contract_no ?? '-' }}</span></div>
            </div>

            <div>
                <div style="font-weight:800; margin-bottom:8px;">{{ ___('Amounts') }}</div>
                <div class="kv"><span class="muted">{{ ___('Loan amount') }}</span><span>{{ number_format((float)$account->loan_amount,2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Down payment') }}</span><span>{{ number_format((float)$account->down_payment,2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Insurance') }}</span><span>{{ number_format((float)$account->insurance_fee,2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Commission') }}</span><span>{{ number_format((float)$account->commission_fee,2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('GPS') }}</span><span>{{ number_format((float)$account->gps_fee,2) }} AZN</span></div>
            </div>

            <div>
                <div style="font-weight:800; margin-bottom:8px;">{{ ___('Calculations') }}</div>
                <div class="kv"><span class="muted">{{ ___('Financed principal') }}</span><span><b>{{ number_format((float)$financedPrincipal,2) }} AZN</b></span></div>
                <div class="kv"><span class="muted">{{ ___('Total paid amount') }}</span><span>{{ number_format((float)($paymentSummary->total_paid ?? $amortSummary->total_paid ?? $account->paid_total_amount ?? 0),2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Total principal paid') }}</span><span>{{ number_format((float)($paymentSummary->principal_paid ?? $amortSummary->principal_paid ?? $account->paid_principal_amount ?? 0),2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Total interest paid') }}</span><span>{{ number_format((float)($paymentSummary->interest_paid ?? $amortSummary->interest_paid ?? $account->paid_interest_amount ?? 0),2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Total principal due') }}</span><span>{{ number_format((float)($amortSummary->principal_due ?? $account->total_principal_amount ?? 0),2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Total interest due') }}</span><span>{{ number_format((float)($amortSummary->interest_due ?? $account->total_interest_amount ?? 0),2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Remaining') }}</span><span>{{ number_format((float)max(0, ($amortSummary->total_due ?? $account->remaining_amount ?? 0) - ($amortSummary->total_paid ?? 0)),2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Penalty (accrued)') }}</span><span>{{ number_format($penaltyAccrued,2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Penalty paid') }}</span><span>{{ number_format($penaltyPaid,2) }} AZN</span></div>
                <div class="kv"><span class="muted">{{ ___('Outstanding penalty') }}</span><span><b>{{ number_format($penaltyOutstanding,2) }} AZN</b></span></div>
                <div class="kv">
                    <span class="muted">{{ ___('Credit balance') }}</span>
                    <span><b>{{ number_format((float)($account->credit_balance ?? 0), 2) }} AZN</b></span>
                </div>
            </div>

            <div>
                <div style="font-weight:800; margin-bottom:8px;">{{ ___('Leasing rules') }}</div>
                <div class="kv"><span class="muted">{{ ___('Method') }}</span><span>{{ $methodLabel }}</span></div>
                <div class="kv"><span class="muted">{{ ___('Frequency') }}</span><span>{{ $freqLabel }}</span></div>
                <div class="kv"><span class="muted">{{ ___('Allocation') }}</span><span>{{ $allocLabel }}</span></div>
                <div class="kv"><span class="muted">{{ ___('Rounding') }}</span><span>{{ $leasing?->rounding_step ?? '0.01' }}</span></div>
                <div class="kv"><span class="muted">{{ ___('Installments (estimated)') }}</span><span>{{ $estimatedN }}</span></div>
            </div>
        </div>
    </div>

    @if($documents->isNotEmpty())
        <div class="card">
            <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
                <div style="font-weight:800;">{{ ___('Generated documents') }}</div>
                <div class="muted">{{ ___('Download for the selected contract') }}</div>
            </div>

            <table>
                <thead>
                <tr>
                    <th>{{ ___('Template') }}</th>
                    <th>{{ ___('Uploaded at') }}</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                @foreach($documents as $doc)
                    <tr>
                        <td>{{ $doc->template?->name ?? ___('Document') }}</td>
                        <td>{{ optional($doc->created_at)->format('Y-m-d H:i') }}</td>
                        <td class="right">
                            <a class="btn ghost" href="{{ route('bhph_accounts.documents.download', ['account' => $account, 'document' => $doc]) }}">
                                {{ ___('Download') }}
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    @endif

    {{-- Amortization --}}
    <div class="card">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
            <div style="font-weight:800;">{{ ___('Amortization schedule') }}</div>
            <div style="display:flex; gap:10px; align-items:center;">
                @if($previewTemplate)
                    <a class="btn ghost" href="{{ route('company.document_templates.preview', ['template' => $previewTemplate, 'account' => $account]) }}">
                        {{ ___('Preview contract document') }}
                    </a>
                @endif
                <div class="muted">{{ ___('Page:') }} {{ $rows->currentPage() }} / {{ $rows->lastPage() }}</div>
            </div>
        </div>

        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Date') }}</th>
                <th class="right">{{ ___('Due') }}</th>
                <th class="right">{{ ___('Interest due') }}</th>
                <th class="right">{{ ___('Principal due') }}</th>
                <th class="right">{{ ___('Paid') }}</th>
                <th>{{ ___('Payment date') }}</th>
                <th class="right">{{ ___('Remaining balance') }}</th>
                <th>{{ ___('Status') }}</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @foreach($rows as $r)
                <tr>
                    <td>{{ $r->installment_no }}</td>
                    <td>{{ optional($r->due_date)->format('Y-m-d') }}</td>
                    <td class="right">{{ number_format((float)$r->due_amount,2) }}</td>
                    <td class="right">{{ number_format((float)($r->interest_amount ?? $r->paid_interest ?? 0),2) }}</td>
                    <td class="right">{{ number_format((float)($r->principal_amount ?? $r->paid_principal ?? 0),2) }}</td>
                    <td class="right">{{ number_format((float)$r->paid_amount,2) }}</td>
                    <td class="small">{{ $r->paid_date ? \Carbon\Carbon::parse($r->paid_date)->format('Y-m-d') : '-' }}</td>
                    <td class="right">{{ number_format((float)$r->remaining_balance,2) }}</td>
                    <td><span class="badge">{{ $r->status }}</span></td>
                    <td>
                        <a class="btn" href="{{ route('amortization.edit', ['account'=>$account->id,'amortization'=>$r->id]) }}">{{ ___('Edit payment') }}</a>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

        <div style="margin-top:12px;">
            {{ $rows->onEachSide(1)->links('pagination::simple-default') }}
        </div>
    </div>
</div>
@endsection
