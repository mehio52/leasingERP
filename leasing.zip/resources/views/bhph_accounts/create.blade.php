@extends('layouts.app')

@section('title', ___('New BHPH Account'))
@section('page_title', ___('New BHPH Account'))
@section('page_subtitle')
User: {{ $user->first_name }} {{ $user->last_name }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('bhph_accounts.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if($errors->any())
        <div class="banner card error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div style="font-weight:700; margin-bottom:8px;">{{ ___('Leasing rules (company selection)') }}</div>
        <div class="kv"><span class="muted">{{ ___('Method') }}</span><span>{{ $methodLabel }} ({{ $leasing->amortization_method }})</span></div>
        <div class="kv"><span class="muted">{{ ___('Frequency') }}</span><span>{{ $freqLabel }} ({{ $leasing->payment_frequency }})</span></div>
        <div class="kv"><span class="muted">{{ ___('Allocation') }}</span><span>{{ $allocLabel }} ({{ $leasing->allocation_order }})</span></div>
        <div class="kv"><span class="muted">{{ ___('Rounding step') }}</span><span>{{ $leasing->rounding_step ?? '0.01' }}</span></div>
    </div>

    <div class="card">
        <form method="POST" action="{{ route('bhph_accounts.store') }}">
            @csrf

            <div class="row">
                <div class="field">
                    <label>{{ ___('Customer') }}</label>
                    <select name="customer_id" required>
                        <option value="">{{ ___('Select') }}</option>
                        @foreach($customers as $c)
                            <option value="{{ $c->id }}" @selected(old('customer_id') == $c->id)>
                                {{ $c->first_name }} {{ $c->last_name }} - {{ $c->phone }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="field">
                    <label>{{ ___('Vehicle') }}</label>
                    <select name="vehicle_id" required>
                        <option value="">{{ ___('Select') }}</option>
                        @foreach($vehicles as $v)
                            <option value="{{ $v->id }}" @selected(old('vehicle_id') == $v->id)>
                                #{{ $v->id }} - {{ $v->brand }} {{ $v->model }} {{ $v->year ? '(' . $v->year . ')' : '' }} - {{ $v->plate_number ?? '-' }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Contract type') }}</label>
                    <select name="contract_type" id="contractType" required>
                        <option value="two" @selected(old('contract_type','two')==='two')>{{ ___('2-sided (company & buyer)') }}</option>
                        <option value="three" @selected(old('contract_type')==='three')>{{ ___('3-sided (seller included)') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Contract No') }}</label>
                    <input name="contract_no" value="{{ old('contract_no') }}" placeholder="{{ ___('E.g.: CN-0001') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Start date') }}</label>
                    <input type="date" name="payment_start_date" value="{{ old('payment_start_date', now()->toDateString()) }}" required>
                </div>
            </div>

            <div class="row">
            </div>

            <div class="row seller-fields" style="display:none;">
                <div class="field">
                    <label>{{ ___('Seller full name') }}</label>
                    <input name="seller_name" value="{{ old('seller_name') }}" placeholder="{{ ___('Owner of the vehicle') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Seller phone') }}</label>
                    <input name="seller_phone" value="{{ old('seller_phone') }}" placeholder="+994...">
                </div>
                <div class="field">
                    <label>{{ ___('Seller ID number (optional)') }}</label>
                    <input name="seller_id_number" value="{{ old('seller_id_number') }}" placeholder="{{ ___('ID / FIN / passport') }}">
                </div>
            </div>

            @include('bhph_accounts._document_metadata', ['documentMetadata' => old('document_metadata', [])])

            <div class="row">
                <div class="field">
                    <label>{{ ___('3rd party seller full name') }}</label>
                    <input name="third_party_seller_fullname" value="{{ old('third_party_seller_fullname') }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Loan amount') }}</label>
                    <input type="number" step="0.01" min="0" name="loan_amount" value="{{ old('loan_amount') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Down payment') }}</label>
                    <input type="number" step="0.01" min="0" name="down_payment" value="{{ old('down_payment', 0) }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Annual interest (%)') }}</label>
                    <input type="number" step="0.01" min="0" name="annual_interest_rate" value="{{ old('annual_interest_rate', $leasing->interest_rate ?? null) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Term (months)') }}</label>
                    <input type="number" step="1" min="1" name="term_months" value="{{ old('term_months', $leasing->term_months ?? null) }}" required>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Insurance') }}</label>
                    <input type="number" step="0.01" min="0" name="insurance_fee" value="{{ old('insurance_fee', 0) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Commission') }}</label>
                    <input type="number" step="0.01" min="0" name="commission_fee" value="{{ old('commission_fee', 0) }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('GPS') }}</label>
                    <input type="number" step="0.01" min="0" name="gps_fee" value="{{ old('gps_fee', 0) }}">
                </div>
            </div>

            <div class="actions">
                <a class="btn ghost" href="{{ route('bhph_accounts.index') }}">{{ ___('Cancel') }}</a>
                <button class="btn primary" type="submit">{{ ___('Create account') }}</button>
            </div>
        </form>
    </div>

    <script>
        (function(){
            const typeSel = document.getElementById('contractType');
            const sellerBlock = document.querySelector('.seller-fields');
            const sellerInputs = sellerBlock ? sellerBlock.querySelectorAll('input') : [];

            function syncSellerBlock(){
                if (!typeSel || !sellerBlock) return;
                const three = typeSel.value === 'three';
                sellerBlock.style.display = three ? 'flex' : 'none';
                sellerInputs.forEach(inp => {
                    if (three) {
                        inp.setAttribute('required','required');
                    } else {
                        inp.removeAttribute('required');
                    }
                });
            }

            typeSel?.addEventListener('change', syncSellerBlock);
            syncSellerBlock();
        })();
    </script>
@endsection
