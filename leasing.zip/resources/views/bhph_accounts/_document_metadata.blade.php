@php
    $documentMetadata = $documentMetadata ?? [];
    $meta = $documentMetadata;
    $fields = [
        'customer_address' => ___('Customer address'),
        'customer_id_card_issue_date' => ___('Customer identity issue date'),
        'customer_id_card_authority' => ___('Customer identity issuing authority'),
        'customer_bank_details' => ___('Customer bank details'),
        'seller_fin' => ___('Seller FIN'),
        'seller_id_issue_date' => ___('Seller identity issue date'),
        'seller_id_authority' => ___('Seller identity issuing authority'),
        'third_party_seller_fullname' => ___('3rd party seller full name'),
    ];
@endphp

@foreach($fields as $key => $label)
    <input type="hidden" name="document_metadata[{{ $key }}]" id="document_metadata_{{ $key }}" value="{{ old('document_metadata.' . $key, $meta[$key] ?? '') }}">
@endforeach

<div class="row">
    <div class="field">
        <button type="button" class="btn ghost" id="openDocumentMetadataModal">
            {{ ___('Provide document data') }}
        </button>
        <p class="hint small">
            {{ ___('These fields help document automation substitute keywords when contracts are generated.') }}
        </p>
    </div>
</div>

<div class="modal-backdrop" id="documentMetadataModal">
    <div class="modal">
        <div class="modal-h">
            <div>{{ ___('Document metadata') }}</div>
            <button type="button" class="x" data-close-doc-meta>&times;</button>
        </div>
        <div class="modal-b">
            @foreach($fields as $key => $label)
                <div class="field">
                    <label>{{ $label }}</label>
                    @if(str_ends_with($key, '_date'))
                        <input type="date" id="doc_meta_{{ $key }}" value="{{ old('document_metadata.' . $key, $meta[$key] ?? '') }}">
                    @else
                        <input id="doc_meta_{{ $key }}" value="{{ old('document_metadata.' . $key, $meta[$key] ?? '') }}">
                    @endif
                </div>
            @endforeach
        </div>
        <div class="modal-h">
            <button type="button" class="btn primary" data-save-doc-meta>{{ ___('Save data') }}</button>
        </div>
    </div>
</div>

@once
    @push('styles')
    <style>
        #documentMetadataModal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.65);
            z-index: 2200;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        #documentMetadataModal.active {
            display: flex;
        }

        #documentMetadataModal .modal {
            width: min(520px, 100%);
            background: var(--card);
            border-radius: 14px;
            box-shadow: 0 20px 45px rgba(0, 0, 0, 0.4);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            max-height: 90vh;
        }

        #documentMetadataModal .modal-h {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
        }

        #documentMetadataModal .modal-b {
            padding: 20px;
            overflow-y: auto;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        #documentMetadataModal .x {
            border: none;
            background: transparent;
            font-size: 22px;
            cursor: pointer;
            color: var(--muted);
        }

        #documentMetadataModal .x:hover {
            color: var(--text);
        }
    </style>
    @endpush

    @push('scripts')
    <script>
        (function(){
            const modal = document.getElementById('documentMetadataModal');
            const openBtn = document.getElementById('openDocumentMetadataModal');
            const closeBtns = modal ? modal.querySelectorAll('[data-close-doc-meta]') : [];
            const saveBtn = modal ? modal.querySelector('[data-save-doc-meta]') : null;
            const keys = @json(array_keys($fields));
            let lastBodyOverflow = '';

            const updateHidden = () => {
                keys.forEach(key => {
                    const hidden = document.getElementById('document_metadata_' + key);
                    const input = document.getElementById('doc_meta_' + key);
                    if (hidden && input) {
                        hidden.value = input.value;
                    }
                });
            };

            const openModal = () => {
                if (!modal) return;
                lastBodyOverflow = document.body.style.overflow;
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';
            };

            const closeModal = () => {
                if (!modal) return;
                modal.classList.remove('active');
                document.body.style.overflow = lastBodyOverflow || '';
            };

            if (openBtn) {
                openBtn.addEventListener('click', openModal);
            }

            if (closeBtns && closeBtns.length) {
                closeBtns.forEach(btn => btn.addEventListener('click', closeModal));
            }

            if (saveBtn) {
                saveBtn.addEventListener('click', () => {
                    updateHidden();
                    closeModal();
                });
            }

            if (modal) {
                modal.addEventListener('click', event => {
                    if (event.target === modal) {
                        closeModal();
                    }
                });
            }
        })();
    </script>
    @endpush
@endonce
