@extends('layouts.app')

@section('title', ___('BHPH #') . $account->id)
@section('page_title', ___('BHPH #') . $account->id)
@section('page_subtitle')
User: {{ $user->first_name }} {{ $user->last_name }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('bhph_accounts.show', $account) }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if($errors->any())
        <div class="banner card">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div style="font-weight:700; margin-bottom:8px;">{{ ___('Leasing rules (company selection)') }}</div>
        <div class="kv"><span class="muted">{{ ___('Method') }}</span><span>{{ $methodLabel }} ({{ $leasing->amortization_method }})</span></div>
        <div class="kv"><span class="muted">{{ ___('Frequency') }}</span><span>{{ $freqLabel }} ({{ $leasing->payment_frequency }})</span></div>
        <div class="kv"><span class="muted">{{ ___('Allocation') }}</span><span>{{ $allocLabel }} ({{ $leasing->allocation_order }})</span></div>
        <div class="kv"><span class="muted">{{ ___('Rounding step') }}</span><span>{{ $leasing->rounding_step ?? '0.01' }}</span></div>
        <div class="muted" style="margin-top:8px;">
            {{ ___('If you want to rebuild the amortization schedule, select “Regenerate schedule” below. (If there are payments, the system will not allow it.)') }}
        </div>
    </div>

    <div class="card">
        <form method="POST" action="{{ route('bhph_accounts.update', $account) }}">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="field">
                    <label>{{ ___('Customer') }}</label>
                    <select name="customer_id" required>
                        @foreach($customers as $c)
                            <option value="{{ $c->id }}" @selected((int)old('customer_id', $account->customer_id) === (int)$c->id)>
                                #{{ $c->id }} — {{ $c->first_name }} {{ $c->last_name }} — {{ $c->phone }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Vehicle (unchanged)') }}</label>
                    <select disabled>
                        @foreach($vehicles as $v)
                            <option selected>
                                #{{ $v->id }} — {{ $v->brand }} {{ $v->model }} {{ $v->year ? '(' . $v->year . ')' : '' }} — {{ $v->plate_number ?? '-' }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Contract type') }}</label>
                    <select name="contract_type" id="contractTypeEdit" required>
                        <option value="two" @selected(old('contract_type', $account->contract_type ?? 'two')==='two')>{{ ___('2-sided (company & buyer)') }}</option>
                        <option value="three" @selected(old('contract_type', $account->contract_type ?? 'two')==='three')>{{ ___('3-sided (seller included)') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Contract No') }}</label>
                    <input value="{{ $account->contract?->contract_no ?? '-' }}" disabled>
                </div>
            </div>

            <div class="row seller-fields-edit" style="display:none;">
                <div class="field">
                    <label>{{ ___('Seller full name') }}</label>
                    <input name="seller_name" value="{{ old('seller_name', $account->seller_name ?? $account->contract?->seller_name) }}" placeholder="{{ ___('Owner of the vehicle') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Seller phone') }}</label>
                    <input name="seller_phone" value="{{ old('seller_phone', $account->seller_phone ?? $account->contract?->seller_phone) }}" placeholder="+994...">
                </div>
                <div class="field">
                    <label>{{ ___('Seller ID number (optional)') }}</label>
                    <input name="seller_id_number" value="{{ old('seller_id_number', $account->seller_id_number ?? $account->contract?->seller_id_number) }}" placeholder="{{ ___('ID / FIN / passport') }}">
                </div>
            </div>

            @include('bhph_accounts._document_metadata', ['documentMetadata' => old('document_metadata', $account->document_metadata ?? [])])

            <div class="row">
                <div class="field">
                    <label>{{ ___('3rd party seller full name') }}</label>
                    <input name="third_party_seller_fullname" value="{{ old('third_party_seller_fullname', $account->third_party_seller_fullname) }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Loan amount') }}</label>
                    <input name="loan_amount" value="{{ old('loan_amount', $account->loan_amount) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Down payment') }}</label>
                    <input name="down_payment" value="{{ old('down_payment', $account->down_payment) }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Annual interest (%)') }}</label>
                    <input name="annual_interest_rate" value="{{ old('annual_interest_rate', $account->annual_interest_rate) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Term (months)') }}</label>
                    <input name="term_months" value="{{ old('term_months', $account->term_months) }}" required>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Insurance') }}</label>
                    <input name="insurance_fee" value="{{ old('insurance_fee', $account->insurance_fee) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Commission') }}</label>
                    <input name="commission_fee" value="{{ old('commission_fee', $account->commission_fee) }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('GPS') }}</label>
                    <input name="gps_fee" value="{{ old('gps_fee', $account->gps_fee) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Start date') }}</label>
                    <input type="date" name="payment_start_date" value="{{ old('payment_start_date', optional($account->payment_start_date)->toDateString()) }}" required>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Status') }}</label>
                    <select name="status" required>
                        <option value="active" @selected(old('status', $account->status)==='active')>{{ ___('active') }}</option>
                        <option value="overdue" @selected(old('status', $account->status)==='overdue')>{{ ___('overdue') }}</option>
                        <option value="legal" @selected(old('status', $account->status)==='legal')>{{ ___('legal') }}</option>
                        <option value="inactive" @selected(old('status', $account->status)==='inactive')>{{ ___('inactive') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Regenerate schedule') }}</label>
                    <select name="regenerate_schedule">
                        <option value="0" @selected((int)old('regenerate_schedule',0)===0)>{{ ___('No') }}</option>
                        <option value="1" @selected((int)old('regenerate_schedule',0)===1)>{{ ___('Yes (if there are no payments)') }}</option>
                    </select>
                </div>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

    <script>
        (function(){
            const typeSel = document.getElementById('contractTypeEdit');
            const sellerBlock = document.querySelector('.seller-fields-edit');
            const sellerInputs = sellerBlock ? sellerBlock.querySelectorAll('input') : [];

            function syncSellerBlock(){
                if (!typeSel || !sellerBlock) return;
                const three = typeSel.value === 'three';
                sellerBlock.style.display = three ? 'flex' : 'none';
                sellerInputs.forEach(inp => {
                    if (three) {
                        inp.setAttribute('required','required');
                    } else {
                        inp.removeAttribute('required');
                    }
                });
            }

            typeSel?.addEventListener('change', syncSellerBlock);
            syncSellerBlock();
        })();
    </script>
@endsection
