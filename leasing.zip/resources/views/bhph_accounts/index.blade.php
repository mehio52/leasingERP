@extends('layouts.app')

@section('title', ___('BHPH Accounts'))
@section('page_title', ___('BHPH Accounts'))
@section('page_subtitle')
User: {{ $user->first_name }} {{ $user->last_name }}
@endsection
@section('page_actions')
    <a class="btn primary" href="{{ route('bhph_accounts.create') }}">{{ ___('+ New account') }}</a>
@endsection

@section('content')
    <div class="card">
        <form method="GET" action="{{ route('bhph_accounts.index') }}" class="form-grid" style="grid-template-columns: 1fr 220px 140px; align-items:center;">
            <input name="q" value="{{ $q }}" placeholder="{{ ___('Search: customer/phone/FIN/Tax ID/plate/VIN/ID') }}">
            <select name="status">
                <option value="">{{ ___('Status: all') }}</option>
                @foreach($statuses as $k => $label)
                    <option value="{{ $k }}" @selected($status === $k)>{{ $label }}</option>
                @endforeach
            </select>
            <button class="btn primary" type="submit">{{ ___('Search') }}</button>
        </form>

        <table style="margin-top:12px;">
            <thead>
            <tr>
                <th>{{ ___('ID') }}</th>
                <th>{{ ___('Contract') }}</th>
                <th>{{ ___('Customer') }}</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Amount') }}</th>
                <th>{{ ___('Balance') }}</th>
                <th>{{ ___('Status') }}</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($accounts as $a)
                <tr>
                    <td>#{{ $a->id }}</td>
                    <td>{{ $a->contract?->contract_no ?? '-' }}</td>
                    <td>
                        <div style="font-weight:700;">
                            {{ $a->customer?->first_name }} {{ $a->customer?->last_name }}
                        </div>
                        <div class="muted">{{ $a->customer?->phone }}</div>
                    </td>
                    <td>
                        <div style="font-weight:700;">
                            {{ $a->vehicle?->brand }} {{ $a->vehicle?->model }}
                        </div>
                        <div class="muted">{{ $a->vehicle?->plate_number }}</div>
                    </td>
                    <td>{{ number_format($a->amount, 2) }}</td>
                    <td>{{ number_format($a->balance, 2) }}</td>
                    <td>
                        @php
                            $displayStatus = $a->status;
                            if (
                                $displayStatus === \App\Models\BhphAccount::STATUS_ACTIVE
                                && ($a->overdue_installments_count ?? 0) > 0
                            ) {
                                $displayStatus = \App\Models\BhphAccount::STATUS_OVERDUE;
                            }
                        @endphp
                        <span class="badge">{{ $statuses[$displayStatus] ?? $displayStatus }}</span>
                    </td>
                    <td>
                        <div class="actions" style="justify-content:flex-end;">
                            <a class="btn" href="{{ route('bhph_accounts.show', $a) }}">{{ ___('View') }}</a>
                            <a class="btn" href="{{ route('bhph_accounts.edit', $a) }}">{{ ___('Edit') }}</a>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="muted">{{ ___('No accounts found.') }}</td>
                </tr>
            @endforelse
            </tbody>
        </table>

        <div style="margin-top:12px;">
            {{ $accounts->links() }}
        </div>
    </div>
@endsection
