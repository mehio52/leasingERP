@extends('layouts.app')

@section('title', ___('Penalties'))
@section('page_title', ___('Late Payment Penalties'))
@section('page_subtitle')
Company ID: {{ $user?->company_id ?? '-' }}
@endsection

@section('content')
<div class="wrap">
    <div class="card">
        <form method="GET" action="{{ route('penalties.index') }}" class="form-grid" style="grid-template-columns: 1fr 200px 160px; align-items:center;">
            <input class="input" name="q" value="{{ $q }}" placeholder="{{ ___('Account ID, customer, vehicle') }}">
            <label style="display:flex; align-items:center; gap:8px;">
                <input type="checkbox" name="show_all" value="1" {{ $showAll ? 'checked' : '' }}>
                <span class="muted small">{{ ___('Show all (including those without penalties)') }}</span>
            </label>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button class="btn ghost" type="submit">{{ ___('Search') }}</button>
                <a class="btn" href="{{ route('penalties.index') }}">{{ ___('Reset') }}</a>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="grid" style="grid-template-columns: repeat(auto-fit,minmax(200px,1fr)); gap:12px;">
            <div class="kv"><span class="muted">{{ ___('Accrued') }}</span><span><b>{{ number_format((float)($totals['accrued'] ?? 0),2) }} AZN</b></span></div>
            <div class="kv"><span class="muted">{{ ___('Paid') }}</span><span>{{ number_format((float)($totals['paid'] ?? 0),2) }} AZN</span></div>
            <div class="kv"><span class="muted">{{ ___('Outstanding penalty') }}</span><span>{{ number_format((float)($totals['outstanding'] ?? 0),2) }} AZN</span></div>
            <div class="kv"><span class="muted">{{ ___('Number of accounts') }}</span><span>{{ count($rows) }}</span></div>
        </div>
    </div>

    <div class="card">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
            <div style="font-weight:800;">{{ ___('Penalties by account') }}</div>
            <div class="muted">{{ ___('Current company only') }}</div>
        </div>

        <table>
            <thead>
            <tr>
                <th>{{ ___('ID') }}</th>
                <th>{{ ___('Customer') }}</th>
                <th>{{ ___('Vehicle') }}</th>
                <th>{{ ___('Status') }}</th>
                <th class="right">{{ ___('Accrued') }}</th>
                <th class="right">{{ ___('Paid') }}</th>
                <th class="right">{{ ___('Outstanding') }}</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($rows as $row)
                @php
                    $acc = $row['account'] ?? null;
                    $sum = $row['summary'] ?? [];
                    $accrued = (float)($sum['total_accrued'] ?? 0);
                    $paid = (float)($sum['total_paid'] ?? 0);
                    $out = (float)($sum['outstanding'] ?? 0);
                @endphp
                <tr>
                    <td>#{{ $acc?->id }}</td>
                    <td>
                        <div>{{ $acc?->customer?->first_name }} {{ $acc?->customer?->last_name }}</div>
                        <div class="muted small">{{ $acc?->customer?->phone }}</div>
                    </td>
                    <td>
                        <div>{{ $acc?->vehicle?->brand }} {{ $acc?->vehicle?->model }}</div>
                        <div class="muted small">{{ $acc?->vehicle?->plate_number ?? '-' }}</div>
                    </td>
                    <td><span class="badge">{{ $acc?->status }}</span></td>
                    <td class="right">{{ number_format($accrued,2) }}</td>
                    <td class="right">{{ number_format($paid,2) }}</td>
                    <td class="right"><b>{{ number_format($out,2) }}</b></td>
                    <td><a class="btn" href="{{ route('bhph_accounts.show', $acc) }}">{{ ___('View') }}</a></td>
                </tr>
            @empty
                <tr><td colspan="8" class="muted">{{ ___('No penalties found.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection