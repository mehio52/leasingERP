<!doctype html>
<html lang="az">
<head>
    <meta charset="utf-8">
    <title>{{ ___('Leasing dashboard report') }}</title>
    <style>
        body { font-family: Arial, sans-serif; color: #111; margin: 24px; }
        h1, h2, h3 { margin: 0 0 8px; }
        .meta { margin-bottom: 16px; color: #444; }
        .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .card { border: 1px solid #ddd; padding: 10px; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin: 12px 0 20px; }
        th, td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; }
        th { background: #f3f4f6; }
        .right { text-align: right; }
        .muted { color: #666; }
    </style>
</head>
<body>
    <h1>{{ ___('Leasing dashboard report') }}</h1>
    <div class="meta">
        <div>{{ $company?->name ?? '-' }}</div>
        <div>{{ $filters['start_date'] ?? '' }} - {{ $filters['end_date'] ?? '' }}</div>
        <div>{{ ___('Currency') }}: {{ $currencyCode ?? 'AZN' }}</div>
    </div>

    @php
        $canPayments = $user?->hasPermission('payments.view') ?? false;
        $canBhph = $user?->hasPermission('bhph.view') ?? false;
        $canVehicles = $user?->hasPermission('vehicles.view') ?? false;
        $canCustomers = $user?->hasPermission('customers.view') ?? false;
        $canSettings = $user?->hasPermission('settings.edit') ?? false;
        $canAnyDashboard = $canPayments || $canBhph || $canVehicles || $canCustomers || $canSettings;
    @endphp

    @if(!$canAnyDashboard)
        <div class="muted">{{ ___('No permission to view dashboard data.') }}</div>
    @endif

    @if($canPayments || $canBhph)
        <div class="grid">
            @if($canPayments)
                <div class="card">
                    <h2>{{ ___('Payment totals') }}</h2>
                    <div>{{ ___('Total') }}: {{ number_format((float)($paymentTotals->total_amount ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Principal') }}: {{ number_format((float)($paymentTotals->principal_amount ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Interest') }}: {{ number_format((float)($paymentTotals->interest_amount ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Penalty') }}: {{ number_format((float)($paymentTotals->penalty_amount ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                </div>
            @endif
            @if($canBhph)
                <div class="card">
                    <h2>{{ ___('Account status') }}</h2>
                    <div>{{ ___('Total') }}: {{ (int) ($accountCounts['total'] ?? 0) }}</div>
                    <div>{{ ___('Active') }}: {{ (int) ($accountCounts['active'] ?? 0) }}</div>
                    <div>{{ ___('Late') }}: {{ (int) ($accountCounts['overdue'] ?? 0) }}</div>
                    <div>{{ ___('Legal') }}: {{ (int) ($accountCounts['legal'] ?? 0) }}</div>
                </div>
            @endif
        </div>
    @endif

    @if($canPayments || $canBhph || $canVehicles || $canCustomers)
        <div class="grid" style="margin-top:12px;">
            <div class="card">
                <h2>{{ ___('Monthly metrics') }}</h2>
                @if($canPayments)
                    <div>{{ ___('Payments') }}: {{ number_format((float)($creditDashboard['monthly']['payments'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Interest collected') }}: {{ number_format((float)($creditDashboard['monthly']['interest'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                @endif
                @if($canBhph)
                    <div>{{ ___('Overdue accounts') }}: {{ (int) ($creditDashboard['monthly']['overdue_accounts'] ?? 0) }}</div>
                    <div>{{ ___('Overdue amount') }}: {{ number_format((float)($creditDashboard['monthly']['overdue_amount'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                @endif
                @if($canCustomers)
                    <div>{{ ___('Customers') }}: {{ (int) ($creditDashboard['monthly']['customers'] ?? 0) }}</div>
                @endif
                @if($canVehicles)
                    <div>{{ ___('Sold vehicles') }}: {{ (int) ($creditDashboard['monthly']['sold_vehicles'] ?? 0) }}</div>
                @endif
            </div>
            @if($canBhph || $canVehicles)
                <div class="card">
                    <h2>{{ ___('Overall metrics') }}</h2>
                    @if($canBhph)
                        <div>{{ ___('Down payment') }}: {{ number_format((float)($creditDashboard['overall']['down_payment'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                        <div>{{ ___('Paid interest') }}: {{ number_format((float)($creditDashboard['overall']['paid_interest'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                        <div>{{ ___('Remaining principal') }}: {{ number_format((float)($creditDashboard['overall']['remaining_principal'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                        <div>{{ ___('Remaining total') }}: {{ number_format((float)($creditDashboard['overall']['remaining_total'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                        <div>{{ ___('Remaining interest') }}: {{ number_format((float)($creditDashboard['overall']['remaining_interest'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                        <div>{{ ___('Paid principal') }}: {{ number_format((float)($creditDashboard['overall']['paid_principal'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                        <div>{{ ___('Paid total') }}: {{ number_format((float)($creditDashboard['overall']['paid_total'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    @endif
                    @if($canVehicles)
                        <div>{{ ___('Inventory value') }}: {{ number_format((float)($creditDashboard['overall']['inventory_value'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    @endif
                </div>
            @endif
        </div>
    @endif

    @if($canBhph || $canPayments || $canVehicles)
        <div class="grid" style="margin-top:12px;">
            @if($canBhph)
                <div class="card">
                    <h2>{{ ___('Aging buckets + PAR') }}</h2>
                    <div>{{ ___('0-30 days') }}: {{ number_format((float)($creditReports['aging']['bucket_0_30'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('31-60 days') }}: {{ number_format((float)($creditReports['aging']['bucket_31_60'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('61-90 days') }}: {{ number_format((float)($creditReports['aging']['bucket_61_90'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('90+ days') }}: {{ number_format((float)($creditReports['aging']['bucket_90_plus'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('PAR') }}: {{ number_format((float)($creditReports['par']['ratio'] ?? 0), 2) }}%</div>
                </div>
            @endif
            @if($canPayments)
                <div class="card">
                    <h2>{{ ___('Collection performance') }}</h2>
                    <div>{{ ___('Target') }}: {{ number_format((float)($creditReports['collection']['target'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Actual') }}: {{ number_format((float)($creditReports['collection']['actual'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Performance') }}: {{ number_format((float)($creditReports['collection']['performance'] ?? 0), 2) }}%</div>
                    <div>{{ ___('Gap') }}: {{ number_format((float)($creditReports['collection']['gap'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                </div>
            @endif
        </div>

        <div class="grid" style="margin-top:12px;">
            @if($canPayments)
                <div class="card">
                    <h2>{{ ___('Accrued vs collected interest') }}</h2>
                    <div>{{ ___('Accrued') }}: {{ number_format((float)($creditReports['interest']['accrued'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Collected') }}: {{ number_format((float)($creditReports['interest']['collected'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Gap') }}: {{ number_format((float)($creditReports['interest']['gap'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                </div>
            @endif
            @if($canVehicles)
                <div class="card">
                    <h2>{{ ___('Vehicles summary') }}</h2>
                    <div>{{ ___('Total') }}: {{ (int) ($vehicleCounts['total'] ?? 0) }}</div>
                    <div>{{ ___('Available') }}: {{ (int) ($vehicleCounts['available'] ?? 0) }}</div>
                    <div>{{ ___('Leasing') }}: {{ (int) ($vehicleCounts['leasing'] ?? 0) }}</div>
                    <div>{{ ___('Sold') }}: {{ (int) ($vehicleCounts['sold'] ?? 0) }}</div>
                    <div>{{ ___('Purchase total') }}: {{ number_format((float)($vehicleValues['purchase_total'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Sales total') }}: {{ number_format((float)($vehicleValues['sale_total'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                    <div>{{ ___('Sold profit') }}: {{ number_format((float)($soldValues['profit'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                </div>
            @endif
        </div>
    @endif

    @if($canSettings)
        <h2>{{ ___('Taxes') }}</h2>
        <table>
            <thead>
            <tr>
                <th>{{ ___('Tax YTD') }}</th>
                <th>{{ ___('Last tax amount') }}</th>
                <th>{{ ___('Last tax rate') }}</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>{{ number_format((float)($taxTotalYear ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</td>
                <td>{{ $lastTax?->tax_amount ? number_format((float)$lastTax->tax_amount, 2).' '.($currencyCode ?? 'AZN') : '—' }}</td>
                <td>{{ $lastTax?->tax_rate ? number_format((float)$lastTax->tax_rate, 3).'%' : '—' }}</td>
            </tr>
            </tbody>
        </table>
    @endif

    @if($canPayments)
        <h2>{{ ___('Forecast') }}</h2>
        <table>
            <thead>
            <tr>
                <th>{{ ___('Period') }}</th>
                <th class="right">{{ ___('Turnover') }}</th>
                <th>{{ ___('Range') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($forecastTurnover as $f)
                @php
                    $lo = $f->meta['yhat_lower'] ?? null;
                    $hi = $f->meta['yhat_upper'] ?? null;
                @endphp
                <tr>
                    <td>{{ optional($f->forecast_date)->format('Y-m') }}</td>
                    <td class="right">{{ number_format((float)$f->value, 2) }} {{ $currencyCode ?? 'AZN' }}</td>
                    <td>{{ $lo !== null && $hi !== null ? number_format((float)$lo,2).' - '.number_format((float)$hi,2) : '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="3" class="muted">{{ ___('No information') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    @endif

    @if($canPayments)
        <h2>{{ ___('Recent payments') }}</h2>
        <table>
            <thead>
            <tr>
                <th>{{ ___('Date') }}</th>
                <th class="right">{{ ___('Amount') }}</th>
                <th class="right">{{ ___('Penalty') }}</th>
                <th>{{ ___('Reference') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($recentPayments as $p)
                <tr>
                    <td>{{ optional($p->paid_date ?? $p->created_at)->format('Y-m-d') }}</td>
                    <td class="right">{{ number_format((float)$p->amount, 2) }} {{ $currencyCode ?? 'AZN' }}</td>
                    <td class="right">{{ number_format((float)($p->penalty_amount ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</td>
                    <td>{{ $p->reference ?? '-' }}</td>
                </tr>
            @empty
                <tr><td colspan="4" class="muted">{{ ___('No payment.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    @endif

    @if($canBhph)
        <h2>{{ ___('Overdue accounts') }}</h2>
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Customer') }}</th>
                <th>{{ ___('Status') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($topOverdue as $acc)
                <tr>
                    <td>{{ $acc->id }}</td>
                    <td>{{ $acc->customer?->first_name }} {{ $acc->customer?->last_name }}</td>
                    <td>{{ $acc->status }}</td>
                </tr>
            @empty
                <tr><td colspan="3" class="muted">{{ ___('No overdue bills.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    @endif

    @if($canPayments)
        <h2>{{ ___('Daily payments') }}</h2>
        <table>
            <thead>
            <tr>
                <th>{{ ___('Date') }}</th>
                <th class="right">{{ ___('Total') }}</th>
                <th class="right">{{ ___('Penalty') }}</th>
            </tr>
            </thead>
            <tbody>
            @foreach($daily as $row)
                <tr>
                    <td>{{ $row['date'] ?? '' }}</td>
                    <td class="right">{{ number_format((float)($row['total'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</td>
                    <td class="right">{{ number_format((float)($row['penalty'] ?? 0), 2) }} {{ $currencyCode ?? 'AZN' }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    @endif

    @if($canBhph)
        @php
            $calStart = !empty($filters['start_date'])
                ? \Carbon\Carbon::parse($filters['start_date'])->startOfDay()
                : now()->startOfMonth();
            $calEnd = !empty($filters['end_date'])
                ? \Carbon\Carbon::parse($filters['end_date'])->endOfDay()
                : now()->endOfMonth();

            $calendarItems = collect($amortTimeline ?? [])->filter(function ($row) use ($calStart, $calEnd) {
                $date = $row['date'] ?? null;
                if (!$date) return false;
                $d = \Carbon\Carbon::parse($date);
                return $d->between($calStart, $calEnd);
            })->values();

            $byDate = [];
            foreach ($calendarItems as $row) {
                $date = $row['date'] ?? null;
                if (!$date) continue;
                if (!isset($byDate[$date])) {
                    $byDate[$date] = ['count' => 0, 'amount' => 0.0];
                }
                $byDate[$date]['count'] += 1;
                $byDate[$date]['amount'] += (float) ($row['amount'] ?? 0);
            }
        @endphp

        <h2>{{ ___('Payment calendar') }}</h2>
        <div class="muted" style="margin-bottom:8px;">{{ ___('Only scheduled payments within the selected date range are shown.') }}</div>

        @php
            $monthCursor = $calStart->copy()->startOfMonth();
            $monthEnd = $calEnd->copy()->startOfMonth();
            $weekDays = [___('Mon'), ___('Tue'), ___('Wed'), ___('Thu'), ___('Fri'), ___('Sat'), ___('Sun')];
        @endphp

        @while($monthCursor->lte($monthEnd))
            @php
                $first = $monthCursor->copy()->startOfMonth();
                $last = $monthCursor->copy()->endOfMonth();
                $daysInMonth = $first->daysInMonth;
                $startWeekday = (int) $first->dayOfWeekIso; // 1=Mon
            @endphp
            <h3 style="margin-top:14px;">{{ $first->format('Y-m') }}</h3>
            <table>
                <thead>
                <tr>
                    @foreach($weekDays as $wd)
                        <th>{{ $wd }}</th>
                    @endforeach
                </tr>
                </thead>
                <tbody>
                @php $day = 1; @endphp
                @while($day <= $daysInMonth)
                    <tr>
                        @for($col = 1; $col <= 7; $col++)
                            @if(($day === 1 && $col < $startWeekday) || $day > $daysInMonth)
                                <td class="muted">&nbsp;</td>
                            @else
                                @php
                                    $dateStr = $monthCursor->copy()->day($day)->toDateString();
                                    $isInRange = $dateStr >= $calStart->toDateString() && $dateStr <= $calEnd->toDateString();
                                    $summary = $byDate[$dateStr] ?? null;
                                @endphp
                                <td style="vertical-align:top; min-width:90px;">
                                    <div style="font-weight:700;">{{ $day }}</div>
                                    @if($isInRange && $summary)
                                        <div style="font-size:12px;">{{ $summary['count'] }} {{ ___('payment(s)') }}</div>
                                        <div style="font-size:12px; font-weight:700;">{{ number_format((float)$summary['amount'], 2) }} {{ $currencyCode ?? 'AZN' }}</div>
                                    @elseif(!$isInRange)
                                        <div class="muted" style="font-size:12px;">—</div>
                                    @endif
                                </td>
                                @php $day++; @endphp
                            @endif
                        @endfor
                    </tr>
                @endwhile
                </tbody>
            </table>
            @php $monthCursor->addMonth(); @endphp
        @endwhile
    @endif
</body>
</html>
