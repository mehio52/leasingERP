@extends('layouts.app')

@section('title', ___('Risk Analizi'))
@section('page_title', ___('Risk Analizi'))
@section('page_subtitle', ___('Yeni qiymətləndirmə'))

@section('content')
<div class="wrap">
    <div class="card">
        <div class="h" style="margin-bottom:8px;">{{ ___('Base informations') }}</div>
        <form method="POST" action="{{ route('risk_assessments.store') }}" class="grid" style="grid-template-columns: repeat(auto-fit,minmax(260px,1fr)); gap:12px;">
            @csrf
            <div>
                <label class="muted small">{{ ___('Monthly income') }}</label>
                <input class="input" type="number" step="0.01" name="monthly_income" value="{{ old('monthly_income') }}" required>
            </div>
            <div>
                <label class="muted small">{{ ___('Current monthly debt') }}</label>
                <input class="input" type="number" step="0.01" name="existing_monthly_debt" value="{{ old('existing_monthly_debt', 0) }}" required>
            </div>
            <div>
                <label class="muted small">{{ ___('Work experience value') }}</label>
                <input class="input" type="number" step="0.1" min="0" name="job_value" value="{{ old('job_value') }}" required>
            </div>
            <div>
                <label class="muted small">{{ ___('Internship unit') }}</label>
                <select class="input" name="job_unit">
                    <option value="months" @selected(old('job_unit') === 'months')>{{ ___('Month') }}</option>
                    <option value="years" @selected(old('job_unit') === 'years')>{{ ___('Year') }}</option>
                </select>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <div class="h" style="margin:10px 0;">{{ ___('Risk factors') }}</div>
                <div class="grid" style="grid-template-columns: repeat(auto-fit,minmax(240px,1fr)); gap:10px;">
                    @forelse($factors as $factor)
                        @php
                            $key = $factor->key;
                            $oldVal = old("factors.$key");
                        @endphp
                        <div class="card" style="padding:12px;">
                            <div class="muted small">{{ $factor->label }} ({{ $factor->type }})</div>
                            @if($factor->type === 'boolean')
                                <label style="display:flex; align-items:center; gap:8px; margin-top:6px;">
                                    <input type="hidden" name="factors[{{ $key }}]" value="0">
                                    <input type="checkbox" name="factors[{{ $key }}]" value="1" @checked($oldVal) >
                                    <span>{{ $factor->label }}</span>
                                </label>
                            @elseif($factor->type === 'select')
                                @php
                                    $opts = $factor->options ?? [];
                                @endphp
                                <select class="input" name="factors[{{ $key }}]">
                                    <option value="">{{ ___('Select') }}</option>
                                    @foreach($opts as $opt)
                                        <option value="{{ $opt['value'] ?? '' }}" @selected($oldVal == ($opt['value'] ?? ''))>{{ $opt['label'] ?? $opt['value'] ?? '' }}</option>
                                    @endforeach
                                </select>
                            @elseif($factor->type === 'text')
                                <input class="input" type="text" name="factors[{{ $key }}]" value="{{ $oldVal }}">
                            @else
                                <input class="input" type="number" step="0.01" name="factors[{{ $key }}]" value="{{ $oldVal }}">
                            @endif
                        </div>
                    @empty
                        <div class="muted">{{ ___('There are no active risk factors. Before Company Options → Create in the Risk Factors section.') }}</div>
                    @endforelse
                </div>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <div class="h" style="margin:10px 0;">{{ ___('Additional factor (opsional)') }}</div>
                <div id="extra-factors" class="grid" style="grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:8px;">
                </div>
                <button type="button" class="btn ghost" id="add-extra-factor" style="margin-top:8px;">{{ ___('+ Add factor') }}</button>
            </div>

            <div class="span-12" style="grid-column: span 12;">
                <div class="h" style="margin:10px 0;">{{ ___('Manual corrections') }}</div>
                <div id="adjustment-rows" class="grid" style="grid-template-columns: repeat(auto-fit,minmax(240px,1fr)); gap:8px;">
                </div>
                <button type="button" class="btn ghost" id="add-adjustment" style="margin-top:8px;">{{ ___('+Add correction') }}</button>
            </div>

            <div class="span-12" style="grid-column: span 12; display:flex; gap:10px; justify-content:flex-end;">
                <a class="btn ghost" href="{{ route('dashboard') }}">{{ ___('Cancel') }}</a>
                <button class="btn primary" type="submit">{{ ___('Calculate and remember') }}</button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function(){
    const extraWrap = document.getElementById('extra-factors');
    const addExtra = document.getElementById('add-extra-factor');
    const adjWrap = document.getElementById('adjustment-rows');
    const addAdj = document.getElementById('add-adjustment');

    function makeExtraRow() {
        const idx = extraWrap.children.length;
        const div = document.createElement('div');
        div.className = 'card';
        div.style.padding = '10px';
        div.innerHTML = `
            <input class="input" type="text" name="extra_factors[${idx}][key]" placeholder="{{ ___('Key') }}">
            <input class="input" type="text" name="extra_factors[${idx}][value]" placeholder="{{ ___('Value') }}">
        `;
        extraWrap.appendChild(div);
    }

    function makeAdjRow() {
        const idx = adjWrap.children.length;
        const div = document.createElement('div');
        div.className = 'card';
        div.style.padding = '10px';
        div.innerHTML = `
            <input class="input" type="text" name="adjustments[${idx}][key]" placeholder="{{ ___('Key') }}">
            <input class="input" type="number" step="0.01" name="adjustments[${idx}][points]" placeholder="{{ ___('Points (+risk)') }}">
            <input class="input" type="text" name="adjustments[${idx}][note]" placeholder="{{ ___('note') }}">
        `;
        adjWrap.appendChild(div);
    }

    addExtra?.addEventListener('click', makeExtraRow);
    addAdj?.addEventListener('click', makeAdjRow);

    // start with one empty row for UX
    makeExtraRow();
    makeAdjRow();
});
</script>
@endpush
@endsection