@extends('layouts.app')

@section('title', ___('Risk outcome'))
@section('page_title', ___('Risk outcome'))
@section('page_subtitle', ___('Calculated score'))

@section('content')
<div class="wrap">
    <div class="grid" style="grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:12px;">
        <div class="card slab">
            <div class="muted small">{{ ___('Score') }}</div>
            <div class="h" style="font-size:28px;">{{ $assessment->score }}</div>
        </div>
        <div class="card slab">
            <div class="muted small">{{ ___('Risk Band') }}</div>
            <div class="h" style="font-size:28px;">{{ $assessment->risk_band }}</div>
        </div>
        <div class="card slab">
            <div class="muted small">{{ ___('Max allowed monthly payment') }}</div>
            <div class="h" style="font-size:28px;">{{ number_format((float)$assessment->max_allowed_payment,2) }} AZN</div>
        </div>
        <div class="card slab">
            <div class="muted small">{{ ___('Decision') }}</div>
            <div class="h" style="font-size:22px; text-transform:capitalize;">{{ $assessment->decision_status ?? 'review' }}</div>
            <div class="muted small">{{ $assessment->decision_comment }}</div>
        </div>
        <div class="card slab">
            <div class="muted small">{{ ___('Recommended monthly payment') }}</div>
            <div class="h" style="font-size:24px;">{{ number_format((float)($assessment->requested_monthly_payment ?? 0),2) }} AZN</div>
            <div class="muted small">{{ ___('Automatically calculated') }}</div>
        </div>
        <div class="card slab">
            <div class="muted small">{{ ___('Available credit amount (approximate)') }}</div>
            <div class="h" style="font-size:24px;">{{ number_format(((float)($assessment->max_allowed_payment ?? 0))*12,2) }} AZN</div>
            <div class="muted small">{{ ___('Based on 12-month distribution') }}</div>
        </div>
        <div class="card slab">
            <div class="muted small">{{ ___('Guarantor required') }}</div>
            <div class="h" style="font-size:20px;">{{ ($assessment->guarantor_required ?? false) ? ___('Bəli') : ___('Xeyr') }}</div>
        </div>
    </div>

    <div class="card">
        <div class="h" style="margin-bottom:10px;">{{ ___('Breakdown') }}</div>
        <table>
            <thead>
            <tr>
                <th>{{ ___('Key') }}</th>
                <th>{{ ___('Label') }}</th>
                <th>{{ ___('Value') }}</th>
                <th>{{ ___('Points') }}</th>
                <th>{{ ___('Note') }}</th>
            </tr>
            </thead>
            <tbody>
            @foreach(($assessment->explain ?? []) as $row)
                <tr>
                    <td>{{ $row['key'] ?? '' }}</td>
                    <td>{{ $row['label'] ?? '' }}</td>
                    <td>{{ $row['value'] ?? '' }}</td>
                    <td class="right">{{ $row['points'] ?? '' }}</td>
                    <td class="small">{{ $row['note'] ?? '' }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    @if(($assessment->decision_notes ?? []))
    <div class="card">
        <div class="h" style="margin-bottom:6px;">{{ ___('Decision notes') }}</div>
        <ul>
            @foreach($assessment->decision_notes as $n)
                <li class="muted small">{{ $n }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <div class="card">
        <div class="h" style="margin-bottom:6px;">{{ ___('Factors (JSON)') }}</div>
        <pre style="background:var(--surface); padding:12px; border-radius:12px; border:1px solid var(--border); white-space:pre-wrap;">{{ json_encode($assessment->factors, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
    </div>

    <div class="card">
        <div class="h" style="margin-bottom:6px;">{{ ___('Edits (JSON)') }}</div>
        <pre style="background:var(--surface); padding:12px; border-radius:12px; border:1px solid var(--border); white-space:pre-wrap;">{{ json_encode($assessment->adjustments, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
    </div>

    <div class="card">
        <a class="btn ghost" href="{{ route('risk_assessments.create') }}">{{ ___('New risk analysis') }}</a>
    </div>
</div>
@endsection