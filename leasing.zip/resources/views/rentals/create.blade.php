@extends('layouts.app')
@section('title', ___('New rental'))
@section('page_title', ___('New rental'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('rentals.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('rentals.store') }}" enctype="multipart/form-data">
            @csrf

            <div class="row">
                <div class="field">
                    <label>{{ ___('Vehicle') }}</label>
                    <select name="vehicle_id" required>
                        <option value="">{{ ___('Select') }}</option>
                        @foreach($vehicles as $v)
                            <option value="{{ $v->id }}"
                                    data-daily="{{ $v->rent_daily_price ?? 0 }}"
                                    data-weekly="{{ $v->rent_weekly_price ?? 0 }}"
                                    data-monthly="{{ $v->rent_monthly_price ?? 0 }}"
                                    @selected(old('vehicle_id') == $v->id)>
                                {{ $v->display_name }} {{ $v->plate_number ? '(' . $v->plate_number . ')' : '' }}
                            </option>
                        @endforeach
                    </select>
                    <div class="muted small">{{ ___('Only available vehicles are listed.') }}</div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Renter name') }}</label>
                    <input name="renter_name" value="{{ old('renter_name') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Renter phone') }}</label>
                    <input name="renter_phone" value="{{ old('renter_phone') }}" placeholder="+994501234567">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('FIN code') }}</label>
                    <input name="renter_fin_code" value="{{ old('renter_fin_code') }}">
                </div>
                <div class="field">
                    <label>{{ ___('ID card number') }}</label>
                    <input name="renter_id_card_number" value="{{ old('renter_id_card_number') }}">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="field">
                <label>{{ ___('Driver license') }}</label>
                <div class="row">
                    <div class="field">
                        <label class="muted">{{ ___('Number') }}</label>
                        <input name="driver_license_number" value="{{ old('driver_license_number') }}">
                    </div>
                    <div class="field">
                        <label class="muted">{{ ___('Category') }}</label>
                        <input name="driver_license_category" value="{{ old('driver_license_category') }}" placeholder="B">
                    </div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Driver license image') }}</label>
                    <input type="file" name="driver_license_image" accept="image/*">
                </div>
                <div class="field">
                    <label>{{ ___('ID card image') }}</label>
                    <input type="file" name="id_card_image" accept="image/*">
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Start at') }}</label>
                    <input type="datetime-local" name="start_at" value="{{ old('start_at') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Rent days') }}</label>
                    <input type="number" min="1" max="365" name="rent_days" id="rentDays" value="{{ old('rent_days', 1) }}" required>
                </div>
            </div>

            <div style="height:12px;"></div>

            @if(!empty($addons))
                <div class="field">
                    <label>{{ ___('Add-ons') }}</label>
                    <div class="muted small" style="margin-bottom:6px;">{{ ___('Optional services added to the rental.') }}</div>
                    <div style="display:grid; gap:6px;">
                        @foreach($addons as $addon)
                            <label class="muted small" style="display:flex; align-items:center; gap:8px;">
                                <input type="checkbox" name="addons[]" value="{{ $addon->id }}" data-addon-price="{{ $addon->price }}" data-addon-billing="{{ $addon->billing_type ?? 'per_rental' }}"
                                    @disabled(($addon->remaining ?? 0) <= 0)
                                    @checked(is_array(old('addons')) && in_array($addon->id, old('addons')))>
                                {{ $addon->name }} ({{ number_format((float)$addon->price, 2) }} AZN {{ ($addon->billing_type ?? 'per_rental') === 'per_day' ? '/day' : '' }})
                                <span class="muted small">— {{ ___('Remaining') }}: {{ $addon->remaining ?? 0 }}</span>
                            </label>
                        @endforeach
                    </div>
                </div>

                <div style="height:12px;"></div>
            @endif

            <div class="row">
                <div class="field">
                    <label>{{ ___('Price breakdown') }}</label>
                    <div class="muted small" id="priceBreakdown">{{ ___('Select a vehicle and days to calculate.') }}</div>
                </div>
                <div class="field">
                    <label>{{ ___('Total price') }}</label>
                    <div class="h" id="priceTotal">0 AZN</div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Discount type') }}</label>
                    <select name="discount_type" id="discountType">
                        <option value="">{{ ___('No discount') }}</option>
                        <option value="percent" @selected(old('discount_type') === 'percent')>{{ ___('Percent (%)') }}</option>
                        <option value="amount" @selected(old('discount_type') === 'amount')>{{ ___('Amount') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Discount value') }}</label>
                    <input type="number" min="0" step="0.01" name="discount_value" id="discountValue" value="{{ old('discount_value') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Total after discount') }}</label>
                    <div class="h" id="priceTotalAfter">0 AZN</div>
                </div>
            </div>

            <div style="height:12px;"></div>

            <div class="field">
                <label>{{ ___('Note') }}</label>
                <textarea name="renter_note" rows="3">{{ old('renter_note') }}</textarea>
            </div>

            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Create rental') }}</button>
            </div>
        </form>
    </div>

    <script>
        (function () {
            const vehicleSelect = document.querySelector('select[name="vehicle_id"]');
            const daysInput = document.getElementById('rentDays');
            const breakdown = document.getElementById('priceBreakdown');
            const totalEl = document.getElementById('priceTotal');

            function num(v) {
                const n = parseFloat(v);
                return isNaN(n) ? 0 : n;
            }

            function calc() {
                const opt = vehicleSelect?.selectedOptions?.[0];
                if (!opt) return;
                const daily = num(opt.getAttribute('data-daily'));
                const weekly = num(opt.getAttribute('data-weekly')) || daily * 7;
                const monthly = num(opt.getAttribute('data-monthly')) || daily * 30;
                const days = Math.max(1, parseInt(daysInput?.value || '1', 10));

                let addonsTotal = 0;
                document.querySelectorAll('input[name="addons[]"]:checked').forEach((el) => {
                    const price = num(el.getAttribute('data-addon-price'));
                    const billing = el.getAttribute('data-addon-billing') || 'per_rental';
                    addonsTotal += billing === 'per_day' ? (price * days) : price;
                });

                const months = Math.floor(days / 30);
                const rem1 = days % 30;
                const weeks = Math.floor(rem1 / 7);
                const rem2 = rem1 % 7;

                const priceMonthly = months * monthly;
                const priceWeekly = weeks * weekly;
                const priceDaily = rem2 * daily;
                const total = priceMonthly + priceWeekly + priceDaily + addonsTotal;
                const discountType = document.getElementById('discountType')?.value || '';
                const discountValue = num(document.getElementById('discountValue')?.value);
                let totalAfter = total;
                if (discountType === 'percent') {
                    totalAfter = Math.max(0, total - (total * (discountValue / 100)));
                } else if (discountType === 'amount') {
                    totalAfter = Math.max(0, total - discountValue);
                }

                breakdown.textContent =
                    `${months}m x ${monthly.toFixed(2)} + ${weeks}w x ${weekly.toFixed(2)} + ${rem2}d x ${daily.toFixed(2)} + addons ${addonsTotal.toFixed(2)}`;
                totalEl.textContent = `${total.toFixed(2)} AZN`;
                const totalAfterEl = document.getElementById('priceTotalAfter');
                if (totalAfterEl) {
                    totalAfterEl.textContent = `${totalAfter.toFixed(2)} AZN`;
                }
            }

            vehicleSelect?.addEventListener('change', calc);
            daysInput?.addEventListener('input', calc);
            document.querySelectorAll('input[name="addons[]"]').forEach((el) => {
                el.addEventListener('change', calc);
            });
            document.getElementById('discountType')?.addEventListener('change', calc);
            document.getElementById('discountValue')?.addEventListener('input', calc);
            calc();
        })();
    </script>
@endsection
