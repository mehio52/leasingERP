@extends('layouts.app')
@section('title', ___('Rentals'))
@section('page_title', ___('Rentals'))
@section('page_subtitle', ___('Active rentals and history'))
@section('page_actions')
    <a class="btn primary action-right" href="{{ route('rentals.create') }}">+ {{ ___('New rental') }}</a>
@endsection

@section('content')
    <div class="card">
        <form class="row" method="GET" action="{{ route('rentals.index') }}">
            <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <select name="status">
                    <option value="">{{ ___('Status: all') }}</option>
                    <option value="active" @selected($status === 'active')>{{ ___('Active') }}</option>
                    <option value="closed" @selected($status === 'closed')>{{ ___('Closed') }}</option>
                    <option value="cancelled" @selected($status === 'cancelled')>{{ ___('Cancelled') }}</option>
                </select>
                <button class="btn" type="submit">{{ ___('Filter') }}</button>
                @if($status !== '')
                    <a class="btn" href="{{ route('rentals.index') }}">{{ ___('Reset') }}</a>
                @endif
            </div>
        </form>

        <table style="margin-top:12px;">
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Car') }}</th>
                <th>{{ ___('Renter') }}</th>
                <th>{{ ___('Start') }}</th>
                <th>{{ ___('Days') }}</th>
                <th>{{ ___('Due') }}</th>
                <th>{{ ___('Total') }}</th>
                <th>{{ ___('Discount') }}</th>
                <th>{{ ___('Total after') }}</th>
                <th>{{ ___('Status') }}</th>
                <th style="width:140px;">{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($rentals as $r)
                <tr>
                    <td>{{ $r->id }}</td>
                    <td>{{ $r->vehicle?->display_name ?? '-' }}</td>
                    <td>
                        <div>{{ $r->renter_name }}</div>
                        <div class="muted small">{{ $r->renter_phone ?? '-' }}</div>
                    </td>
                    <td>{{ $r->start_at?->format('Y-m-d H:i') ?? '-' }}</td>
                    <td>{{ $r->rent_days ?? '-' }}</td>
                    <td>{{ $r->due_at?->format('Y-m-d H:i') ?? '-' }}</td>
                    <td>{{ $r->total_price !== null ? number_format((float)$r->total_price, 2) . ' AZN' : '-' }}</td>
                    <td>
                        @if($r->discount_type && $r->discount_value !== null)
                            {{ $r->discount_type === 'percent'
                                ? number_format((float)$r->discount_value, 2) . '%'
                                : number_format((float)$r->discount_value, 2) . ' AZN' }}
                        @else
                            -
                        @endif
                    </td>
                    <td>{{ $r->total_after_discount !== null ? number_format((float)$r->total_after_discount, 2) . ' AZN' : '-' }}</td>
                    <td>
                        <span class="badge {{ $r->status === 'active' ? 'warn' : 'ok' }}">
                            {{ ucfirst($r->status) }}
                        </span>
                    </td>
                    <td>
                        @if($r->status === 'active')
                            <form method="POST" action="{{ route('rentals.close', $r) }}"
                                  onsubmit="return confirm('{{ ___('Close this rental?') }}');">
                                @csrf
                                <input type="datetime-local" name="closed_at" value="{{ now()->format('Y-m-d\\TH:i') }}" style="margin-bottom:6px; width:100%;">
                                <input type="number" min="0" max="168" name="grace_hours" placeholder="{{ ___('Grace (hours)') }}" style="margin-bottom:6px; width:100%;">
                                <input type="number" min="0" step="0.01" name="extra_day_rate" placeholder="{{ ___('Extra day rate') }}" value="{{ $r->vehicle?->rent_daily_price ?? '' }}" style="margin-bottom:6px; width:100%;">
                                <select name="penalty_type" style="margin-bottom:6px; width:100%;">
                                    <option value="">{{ ___('Penalty type') }}</option>
                                    <option value="amount_per_day">{{ ___('Amount per day') }}</option>
                                    <option value="percent_per_day">{{ ___('Percent per day') }}</option>
                                    <option value="fixed">{{ ___('Fixed amount') }}</option>
                                </select>
                                <input type="number" min="0" step="0.01" name="penalty_value" placeholder="{{ ___('Penalty value') }}" style="margin-bottom:6px; width:100%;">
                                <button class="btn danger" type="submit">{{ ___('Close') }}</button>
                            </form>
                        @else
                            <div class="muted small">{{ $r->closed_at?->format('Y-m-d H:i') ?? '-' }}</div>
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="11" class="muted">{{ ___('No rentals found.') }}</td></tr>
            @endforelse
            </tbody>
        </table>

        <div style="margin-top:12px;">
            {{ $rentals->links() }}
        </div>
    </div>
@endsection
