@extends('layouts.app')

@section('title', ___('System Settings'))
@section('page_title', ___('System Settings'))
@section('page_subtitle', ___('Superadmin only'))

@section('content')
<div class="wrap">
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="h" style="margin-bottom:6px;">{{ ___('Global options') }}</div>
        <div class="muted small" style="margin-bottom:14px;">{{ ___('These settings apply to all tenants and are visible only to superadmins.') }}</div>

        <form method="POST" action="{{ route('superadmin.settings.update') }}" class="grid" enctype="multipart/form-data" style="grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap:12px;">
            @csrf

            <div class="span-12" style="grid-column: span 12;">
                <div class="h small" style="margin:0 0 6px;">{{ ___('WhatsApp provider') }}</div>
                <div class="muted small" style="margin-bottom:8px;">{{ ___('Used by superadmin notifications when WhatsApp delivery is enabled.') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('API endpoint URL') }}</label>
                <input class="input" name="wa_api_url" value="{{ old('wa_api_url', $settings->wa_api_url) }}" placeholder="https://.../api/send">
            </div>
            <div>
                <label class="muted small">{{ ___('API key (account)') }}</label>
                <input class="input" name="wa_api_key" value="{{ old('wa_api_key', $settings->wa_api_key) }}">
            </div>
            <div>
                <label class="muted small">{{ ___('Secret/token') }}</label>
                <input class="input" name="wa_api_secret" value="{{ old('wa_api_secret', $settings->wa_api_secret) }}">
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div class="h small" style="margin:0 0 6px;">{{ ___('Epoint payment') }}</div>
                <div class="muted small" style="margin-bottom:8px;">{{ ___('Global merchant keys for card payments.') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('Public key (merchant ID)') }}</label>
                <input class="input" name="epoint_public_key" value="{{ old('epoint_public_key', $settings->epoint_public_key) }}" placeholder="i000000001">
            </div>
            <div>
                <label class="muted small">{{ ___('Private key') }}</label>
                <input class="input" name="epoint_private_key" value="{{ old('epoint_private_key', $settings->epoint_private_key) }}">
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div class="h small" style="margin:0 0 6px;">{{ ___('Payment gateway') }}</div>
                <div class="muted small" style="margin-bottom:8px;">{{ ___('Choose the default provider for new payments.') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('Default provider') }}</label>
                @php
                    $providerValue = old('payment_gateway_provider', $settings->payment_gateway_provider);
                @endphp
                <select class="input" name="payment_gateway_provider">
                    <option value="auto" @selected(!$providerValue || $providerValue === 'auto')>{{ ___('Auto (by country)') }}</option>
                    <option value="epoint" @selected($providerValue === 'epoint')>{{ ___('Epoint (AZ)') }}</option>
                    <option value="iyzico" @selected($providerValue === 'iyzico')>{{ ___('Iyzico (TR)') }}</option>
                    <option value="stripe" @selected($providerValue === 'stripe')>{{ ___('Stripe (US)') }}</option>
                </select>
                <div class="muted small">{{ ___('Auto uses company country (AZ->Epoint, TR->Iyzico, US->Stripe).') }}</div>
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div class="h small" style="margin:0 0 6px;">{{ ___('Stripe payment') }}</div>
                <div class="muted small" style="margin-bottom:8px;">{{ ___('Global Stripe keys for card payments.') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('Publishable key') }}</label>
                <input class="input" name="stripe_public_key" value="{{ old('stripe_public_key', $settings->stripe_public_key) }}" placeholder="pk_live_...">
            </div>
            <div>
                <label class="muted small">{{ ___('Secret key') }}</label>
                <input class="input" name="stripe_secret_key" value="{{ old('stripe_secret_key', $settings->stripe_secret_key) }}" placeholder="sk_live_...">
            </div>
            <div>
                <label class="muted small">{{ ___('Webhook secret') }}</label>
                <input class="input" name="stripe_webhook_secret" value="{{ old('stripe_webhook_secret', $settings->stripe_webhook_secret) }}" placeholder="whsec_...">
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div class="h small" style="margin:0 0 6px;">{{ ___('Iyzico payment') }}</div>
                <div class="muted small" style="margin-bottom:8px;">{{ ___('Global Iyzico keys for card payments in Turkey.') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('API key') }}</label>
                <input class="input" name="iyzico_api_key" value="{{ old('iyzico_api_key', $settings->iyzico_api_key) }}" placeholder="sandbox-...">
            </div>
            <div>
                <label class="muted small">{{ ___('Secret key') }}</label>
                <input class="input" name="iyzico_secret_key" value="{{ old('iyzico_secret_key', $settings->iyzico_secret_key) }}" placeholder="sandbox-...">
            </div>
            <div>
                <label class="muted small">{{ ___('Base URL') }}</label>
                <input class="input" name="iyzico_base_url" value="{{ old('iyzico_base_url', $settings->iyzico_base_url) }}" placeholder="https://sandbox-api.iyzipay.com">
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div class="h small" style="margin:0 0 6px;">{{ ___('Branding') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('SaaS logo URL') }}</label>
                <input class="input" name="saas_logo" value="{{ old('saas_logo', $settings->saas_logo) }}" placeholder="https://.../logo.png">
                <div class="muted small">{{ ___('Shown in the admin layout if provided.') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('Upload logo (image)') }}</label>
                <input class="input" type="file" name="saas_logo_file" accept="image/*">
                <div class="muted small">{{ ___('Upload overrides the URL. Max 2MB.') }}</div>
                @if($settings->saas_logo)
                    <div style="margin-top:8px; display:flex; align-items:center; gap:10px;">
                        <img src="{{ $settings->saas_logo }}" alt="Logo" style="width:40px; height:40px; object-fit:contain; border:1px solid var(--border); border-radius:8px; background:var(--surface);">
                        <label class="checkbox" style="display:flex; align-items:center; gap:6px;">
                            <input type="checkbox" name="remove_saas_logo" value="1">
                            <span>{{ ___('Remove logo') }}</span>
                        </label>
                    </div>
                @endif
            </div>

            <div class="span-12" style="grid-column: span 12; margin-top:10px;">
                <div class="h small" style="margin:0 0 6px;">{{ ___('Mail settings') }}</div>
                <div class="muted small" style="margin-bottom:6px;">{{ ___('SMTP credentials for outgoing emails.') }}</div>
            </div>
            <div>
                <label class="muted small">{{ ___('Host') }}</label>
                <input class="input" name="mail_host" value="{{ old('mail_host', $settings->mail_host) }}" placeholder="smtp.example.com">
            </div>
            <div>
                <label class="muted small">{{ ___('Port') }}</label>
                <input class="input" type="number" min="1" max="65535" name="mail_port" value="{{ old('mail_port', $settings->mail_port) }}" placeholder="587">
            </div>
            <div>
                <label class="muted small">{{ ___('Username') }}</label>
                <input class="input" name="mail_username" value="{{ old('mail_username', $settings->mail_username) }}">
            </div>
            <div>
                <label class="muted small">{{ ___('Password') }}</label>
                <input class="input" name="mail_password" value="{{ old('mail_password', $settings->mail_password) }}">
            </div>
            <div>
                <label class="muted small">{{ ___('Encryption') }}</label>
                <select class="input" name="mail_encryption">
                    <option value="">{{ ___('Default') }}</option>
                    <option value="tls" @selected(old('mail_encryption', $settings->mail_encryption) === 'tls')>TLS</option>
                    <option value="ssl" @selected(old('mail_encryption', $settings->mail_encryption) === 'ssl')>SSL</option>
                </select>
            </div>
            <div>
                <label class="muted small">{{ ___('From address') }}</label>
                <input class="input" name="mail_from_address" value="{{ old('mail_from_address', $settings->mail_from_address) }}" placeholder="noreply@example.com">
            </div>
            <div>
                <label class="muted small">{{ ___('From name') }}</label>
                <input class="input" name="mail_from_name" value="{{ old('mail_from_name', $settings->mail_from_name) }}" placeholder="Leasing SaaS">
            </div>

            <div class="span-12" style="grid-column: span 12; display:flex; justify-content:flex-end; gap:10px; margin-top:6px;">
                <a class="btn ghost" href="{{ route('superadmin.dashboard') }}">{{ ___('Back') }}</a>
                <button class="btn primary" type="submit">{{ ___('Save settings') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
