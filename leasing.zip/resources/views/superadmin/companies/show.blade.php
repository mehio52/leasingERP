@extends('layouts.app')

@section('title', $company->name)
@section('page_title', $company->name)
@section('page_subtitle', ___('Superadmin view'))
@section('page_actions')
    @if(isset($owner) && $owner)
        <form method="POST" action="{{ route('impersonate.start', $owner) }}" style="display:inline;">
            @csrf
            <button class="btn primary" type="submit">{{ ___('Login as owner') }}</button>
        </form>
    @endif
    <a class="btn ghost" href="{{ route('superadmin.companies.index') }}">{{ ___('Back') }}</a>
@endsection

@push('styles')
<style>
    .sa-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;}
    .sa-stat{padding:14px;border:1px solid var(--border);border-radius:12px;background:var(--card);}
    .sa-stat .value{font-size:24px;font-weight:800;margin:4px 0;}
</style>
@endpush

@section('content')
<div class="wrap">
    @if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ ___('OK') }}</span>
            <span style="margin-left:10px;">{{ session('status') }}</span>
        </div>
    @endif

    @if(session('error'))
        <div class="banner error">
            <span class="badge bad">{{ ___('Error') }}</span>
            <span style="margin-left:10px;">{{ session('error') }}</span>
        </div>
    @endif

    @if($company->suspended_at)
        <div class="card banner warn">
            <div class="badge warn">{{ ___('Suspended') }}</div>
            <div class="muted" style="margin-top:8px;">
                {{ ___('Reason') }}: {{ $company->suspend_reason ?? '—' }} |
                {{ ___('Since') }}: {{ optional($company->suspended_at)->format('Y-m-d H:i') }}
            </div>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="sa-grid">
        <div class="sa-stat">
            <div class="muted small">{{ ___('Plan') }}</div>
            <div class="value">{{ $company->plan_code ?? '—' }}</div>
            <div class="muted small">{{ ___('Trial ends at') }}: {{ optional($company->trial_ends_at)->format('Y-m-d') ?? '—' }}</div>
        </div>
        <div class="sa-stat">
            <div class="muted small">{{ ___('Subscription ends at') }}</div>
            <div class="value">{{ optional($company->subscription_ends_at)->format('Y-m-d') ?? '—' }}</div>
            <div class="muted small">{{ ___('Status') }}: {{ $company->is_active ? ___('Active') : ___('Deactive') }}</div>
        </div>
        <div class="sa-stat">
            <div class="muted small">{{ ___('Contact') }}</div>
            <div class="value">{{ $company->phone }}</div>
            <div class="muted small">{{ $company->email }}</div>
        </div>
        <div class="sa-stat">
            <div class="muted small">{{ ___('Locale / Currency') }}</div>
            <div class="value">{{ $company->locale }} / {{ $company->currency }}</div>
            <div class="muted small">{{ ___('Timezone') }}: {{ $company->timezone }}</div>
        </div>
    </div>

    <div class="card">
        <div class="h">{{ ___('Owner access') }}</div>
        @if(isset($owner) && $owner)
            <div style="display:flex; flex-wrap:wrap; align-items:center; gap:12px;">
                <div>
                    <div class="muted small">{{ ___('Owner') }}</div>
                    <div style="font-weight:700;">{{ $owner->full_name }} ({{ $owner->email ?? $owner->phone }})</div>
                </div>
                <form method="POST" action="{{ route('impersonate.start', $owner) }}">
                    @csrf
                    <button class="btn primary" type="submit">{{ ___('Open session as owner') }}</button>
                </form>
            </div>
        @else
            <div class="muted">{{ ___('Owner account not found for this company.') }}</div>
        @endif
    </div>

    <div class="card">
        <div class="h">{{ ___('Update company') }}</div>
        <form method="POST" action="{{ route('superadmin.companies.update', $company) }}" class="grid">
            @csrf
            @method('PUT')
            <div class="row">
                <div class="field">
                    <label>{{ ___('Name') }}</label>
                    <input class="input" name="name" value="{{ old('name', $company->name) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Plan code') }}</label>
                    <input class="input" name="plan_code" value="{{ old('plan_code', $company->plan_code) }}" placeholder="basic / pro">
                </div>
                <div class="field">
                    <label>{{ ___('Module') }}</label>
                    <select class="input" name="module">
                        <option value="leasing" @selected(old('module', $company->module ?? 'leasing') === 'leasing')>{{ ___('Leasing') }}</option>
                        <option value="rentacar" @selected(old('module', $company->module ?? '') === 'rentacar')>{{ ___('Rent a car') }}</option>
                        <option value="taxipark" @selected(old('module', $company->module ?? '') === 'taxipark')>{{ ___('Taxi park') }}</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Trial ends at') }}</label>
                    <input class="input" type="date" name="trial_ends_at" value="{{ old('trial_ends_at', optional($company->trial_ends_at)->format('Y-m-d')) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Subscription ends at') }}</label>
                    <input class="input" type="date" name="subscription_ends_at" value="{{ old('subscription_ends_at', optional($company->subscription_ends_at)->format('Y-m-d')) }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Active') }}</label>
                    <input type="hidden" name="is_active" value="0">
                    <label class="checkbox">
                        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $company->is_active))>
                        <span>{{ ___('Allow login and writes') }}</span>
                    </label>
                </div>
                <div class="field">
                    <label>{{ ___('Suspend company') }}</label>
                    <input type="hidden" name="suspend" value="0">
                    <label class="checkbox">
                        <input type="checkbox" name="suspend" value="1" @checked(old('suspend', $company->suspended_at ? 1 : 0))>
                        <span>{{ ___('Put in suspended mode') }}</span>
                    </label>
                    <input class="input" name="suspend_reason" value="{{ old('suspend_reason', $company->suspend_reason) }}" placeholder="{{ ___('Reason (optional)') }}">
                </div>
            </div>
            <div style="display:flex; gap:8px; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="h">{{ ___('Usage') }}</div>
        @php
            $statLabels = [
                'users' => ___('Users'),
                'customers' => ___('Customers'),
                'vehicles' => ___('Vehicles'),
                'accounts' => ___('Accounts'),
                'payments' => ___('Payments'),
            ];
        @endphp
        <div class="sa-grid">
            @foreach($stats as $key => $value)
                <div class="sa-stat">
                    <div class="muted small">{{ $statLabels[$key] ?? $key }}</div>
                    <div class="value">{{ $value }}</div>
                </div>
            @endforeach
        </div>
    </div>

    <div class="card">
        <div class="h">{{ ___('Subscriptions') }}</div>
        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th>{{ ___('Plan') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Billing period') }}</th>
                <th>{{ ___('Starts at') }}</th>
                <th>{{ ___('Trial ends at') }}</th>
                <th>{{ ___('Ends at') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($subscriptions as $s)
                <tr>
                    <td>{{ $s->id }}</td>
                    <td>{{ $s->plan?->name ?? $s->plan_name_snapshot ?? '—' }}</td>
                    <td><span class="badge">{{ $s->status }}</span></td>
                    <td>{{ $s->billing_period }}</td>
                    <td>{{ optional($s->starts_at)->format('Y-m-d') ?? '—' }}</td>
                    <td>{{ optional($s->trial_ends_at)->format('Y-m-d') ?? '—' }}</td>
                    <td>{{ optional($s->ends_at)->format('Y-m-d') ?? '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">{{ ___('No information') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
            <div>
                <div class="h">{{ ___('Addons') }}</div>
                <div class="muted small">{{ ___('Active addons extend plan features. Deactivate to remove access.') }}</div>
            </div>
            @if($availableAddons->count())
                <form method="POST" action="{{ route('superadmin.companies.addons.store', $company) }}" style="display:flex; gap:8px; align-items:center;">
                    @csrf
                    <select name="addon_code" class="input" required>
                        @foreach($availableAddons as $addon)
                            <option value="{{ $addon->code }}">{{ $addon->name }} ({{ $addon->code }})</option>
                        @endforeach
                    </select>
                    <button class="btn primary" type="submit">{{ ___('Activate') }}</button>
                </form>
            @endif
        </div>

        <table class="table" style="margin-top:10px;">
            <thead>
            <tr>
                <th>ID</th>
                <th>{{ ___('Name') }}</th>
                <th>{{ ___('Starts at') }}</th>
                <th>{{ ___('Ends at') }}</th>
                <th>{{ ___('Features') }}</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($activeAddons as $a)
                <tr>
                    <td>{{ $a->id }}</td>
                    <td>{{ $a->addon_name_snapshot ?? $a->addon?->name }}</td>
                    <td>{{ optional($a->starts_at)->format('Y-m-d') }}</td>
                    <td>{{ $a->ends_at ? $a->ends_at->format('Y-m-d') : '—' }}</td>
                    <td class="small">
                        @php $feat = $a->features_snapshot ?? []; @endphp
                        {{ implode(', ', array_keys(array_filter($feat, fn($v) => $v))) ?: '—' }}
                    </td>
                    <td style="text-align:right;">
                        <form method="POST" action="{{ route('superadmin.companies.addons.destroy', [$company, $a]) }}" onsubmit="return confirm('{{ ___('Deactivate addon?') }}');">
                            @csrf
                            @method('DELETE')
                            <button class="btn ghost" type="submit">{{ ___('Deactivate') }}</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">{{ ___('No active addons') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="card">
        <div class="h">{{ ___('Assign / create subscription') }}</div>
        @php
            $latestSub = $subscriptions->sortByDesc('id')->first();
        @endphp
        <form method="POST" action="{{ route('superadmin.companies.subscriptions.store', $company) }}" class="grid">
            @csrf
            <div class="row">
                <div class="field">
                    <label>{{ ___('Plan') }}</label>
                    <select class="input" name="plan_id" required>
                        <option value="">{{ ___('Select plan') }}</option>
                        @foreach($plans as $plan)
                            <option value="{{ $plan->id }}" @selected(old('plan_id', $latestSub?->plan_id) == $plan->id)>{{ $plan->name }} ({{ $plan->code }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Status') }}</label>
                    <select class="input" name="status">
                        <option value="trial" @selected(old('status', $latestSub?->status) === 'trial')>{{ ___('Trial') }}</option>
                        <option value="active" @selected(old('status', $latestSub?->status) === 'active')>{{ ___('Active') }}</option>
                        <option value="past_due" @selected(old('status', $latestSub?->status) === 'past_due')>{{ ___('Past due') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Billing period') }}</label>
                    <select class="input" name="billing_period">
                        <option value="monthly" @selected(old('billing_period', $latestSub?->billing_period) === 'monthly')>{{ ___('Monthly') }}</option>
                        <option value="yearly" @selected(old('billing_period', $latestSub?->billing_period) === 'yearly')>{{ ___('Yearly') }}</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Starts at') }}</label>
                    <input class="input" type="date" name="starts_at" value="{{ old('starts_at', optional($latestSub?->starts_at)->format('Y-m-d')) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Trial ends at') }}</label>
                    <input class="input" type="date" name="trial_ends_at" value="{{ old('trial_ends_at', optional($latestSub?->trial_ends_at)->format('Y-m-d')) }}">
                    <div class="muted small">{{ ___('Or set Trial days override below') }}</div>
                </div>
                <div class="field">
                    <label>{{ ___('Subscription ends at') }}</label>
                    <input class="input" type="date" name="ends_at" value="{{ old('ends_at', optional($latestSub?->ends_at)->format('Y-m-d')) }}">
                </div>
            </div>
            <div class="row">
                <div class="field">
                    <label>{{ ___('Trial days override') }}</label>
                    <input class="input" type="number" name="trial_days" min="0" value="{{ old('trial_days', $latestSub?->meta['trial_days'] ?? '') }}" placeholder="14">
                </div>
                <div class="field">
                    <label>{{ ___('Note') }}</label>
                    <input class="input" type="text" name="meta_note" value="{{ old('meta_note', $latestSub?->meta['note'] ?? '') }}" placeholder="{{ ___('Internal note (optional)') }}">
                </div>
            </div>
            <div style="display:flex; gap:8px; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ ___('Create') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
