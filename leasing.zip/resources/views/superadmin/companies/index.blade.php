@extends('layouts.app')

@section('title', ___('Companies'))
@section('page_title', ___('Companies'))
@section('page_subtitle', ___('Superadmin view'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('superadmin.dashboard') }}">{{ ___('Overview') }}</a>
@endsection

@section('content')
<div class="wrap">
    <div class="card">
        <form method="GET" action="{{ route('superadmin.companies.index') }}" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px; align-items:end;">
            <div>
                <label class="muted small">{{ ___('Search') }}</label>
                <input class="input" type="text" name="q" value="{{ $q }}" placeholder="{{ ___('Name, phone, email') }}">
            </div>
            <div>
                <label class="muted small">{{ ___('Status') }}</label>
                <select class="input" name="status">
                    <option value="">{{ ___('All') }}</option>
                    <option value="active" @selected($status === 'active')>{{ ___('Active') }}</option>
                    <option value="suspended" @selected($status === 'suspended')>{{ ___('Suspended') }}</option>
                    <option value="trial" @selected($status === 'trial')>{{ ___('Trialing') }}</option>
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <button class="btn ghost" type="button" onclick="window.location='{{ route('superadmin.companies.index') }}'">{{ ___('Reset') }}</button>
                <button class="btn primary" type="submit">{{ ___('Apply') }}</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="h">{{ ___('Companies') }}</div>
        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th>{{ ___('Name') }}</th>
                <th>{{ ___('Plan') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Trial ends at') }}</th>
                <th>{{ ___('Subscription ends at') }}</th>
                <th>{{ ___('Created') }}</th>
                <th>{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($companies as $c)
                <tr>
                    <td>{{ $c->id }}</td>
                    <td>
                        <div style="display:flex; flex-direction:column;">
                            <strong>{{ $c->name }}</strong>
                            <span class="muted small">{{ $c->phone }}</span>
                        </div>
                    </td>
                    <td>{{ $c->plan_code ?? '—' }}</td>
                    <td>
                        @if($c->suspended_at)
                            <span class="badge bad">{{ ___('Suspended') }}</span>
                        @elseif(!$c->is_active)
                            <span class="badge bad">{{ ___('Deactive') }}</span>
                        @else
                            <span class="badge ok">{{ ___('Active') }}</span>
                        @endif
                    </td>
                    <td>{{ optional($c->trial_ends_at)->format('Y-m-d') ?? '—' }}</td>
                    <td>{{ optional($c->subscription_ends_at)->format('Y-m-d') ?? '—' }}</td>
                    <td>{{ optional($c->created_at)->format('Y-m-d') }}</td>
                    <td><a class="btn outline" href="{{ route('superadmin.companies.show', $c) }}">{{ ___('View') }}</a></td>
                </tr>
            @empty
                <tr><td colspan="8" class="muted">{{ ___('No information') }}</td></tr>
            @endforelse
            </tbody>
        </table>

        @if($companies->hasPages())
            <div class="pager">
                <div class="muted">{{ ___('Page') }} {{ $companies->currentPage() }} / {{ $companies->lastPage() }}</div>
                <div style="display:flex; gap:10px;">
                    <a class="pill {{ $companies->onFirstPage() ? 'disabled' : '' }}" href="{{ $companies->previousPageUrl() ?? '#' }}">{{ ___('Previous') }}</a>
                    <a class="pill {{ $companies->hasMorePages() ? '' : 'disabled' }}" href="{{ $companies->nextPageUrl() ?? '#' }}">{{ ___('Next') }}</a>
                </div>
            </div>
        @endif
    </div>
</div>
@endsection
