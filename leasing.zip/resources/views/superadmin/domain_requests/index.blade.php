@extends('layouts.app')

@section('title', ___('Domain requests'))
@section('page_title', ___('Domain requests'))
@section('page_subtitle', ___('Custom domain approvals'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('superadmin.dashboard') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ session('status') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="GET" action="{{ route('superadmin.domain_requests.index') }}" class="row">
            <div class="field">
                <label>{{ ___('Status') }}</label>
                <select name="status">
                    <option value="">{{ ___('All') }}</option>
                    <option value="pending" @selected($status === 'pending')>{{ ___('Pending') }}</option>
                    <option value="approved" @selected($status === 'approved')>{{ ___('Approved') }}</option>
                    <option value="rejected" @selected($status === 'rejected')>{{ ___('Rejected') }}</option>
                </select>
            </div>
            <div class="field" style="align-self:flex-end;">
                <button class="btn">{{ ___('Filter') }}</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="muted small" style="margin-bottom:10px;">
            {{ ___('Manual process: approve/reject here, then add a domain route in code when DNS is configured.') }}
        </div>
        <table>
            <thead>
                <tr>
                    <th>{{ ___('Company') }}</th>
                    <th>{{ ___('Domain') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Routing') }}</th>
                    <th>{{ ___('Requested at') }}</th>
                    <th style="width:260px;">{{ ___('Actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($requests as $req)
                    <tr>
                        <td>
                            <div style="font-weight:700;">@include('partials.company_label', ['company' => $req->company, 'companyId' => $req->company_id])</div>
                            <div class="muted small">#{{ $req->company_id }}</div>
                        </td>
                        <td>{{ $req->requested_domain }}</td>
                        <td>{{ ucfirst($req->status) }}</td>
                        <td>
                            @if($req->is_active)
                                <span class="badge ok">{{ ___('Active') }}</span>
                            @else
                                <span class="badge">{{ ___('Inactive') }}</span>
                            @endif
                        </td>
                        <td>{{ $req->created_at?->format('Y-m-d H:i') }}</td>
                        <td>
                            @if($req->status === 'pending')
                                <form method="POST" action="{{ route('superadmin.domain_requests.approve', $req) }}" style="display:flex; gap:6px; margin-bottom:6px;">
                                    @csrf
                                    @method('PUT')
                                    <input name="admin_note" placeholder="{{ ___('Admin note (optional)') }}" value="{{ old('admin_note') }}">
                                    <button class="btn primary" type="submit">{{ ___('Approve') }}</button>
                                </form>
                                <form method="POST" action="{{ route('superadmin.domain_requests.reject', $req) }}" style="display:flex; gap:6px;">
                                    @csrf
                                    @method('PUT')
                                    <input name="admin_note" placeholder="{{ ___('Admin note (optional)') }}" value="{{ old('admin_note') }}">
                                    <button class="btn danger" type="submit">{{ ___('Reject') }}</button>
                                </form>
                            @elseif($req->status === 'approved')
                                <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                    @if(!$req->is_active)
                                        <form method="POST" action="{{ route('superadmin.domain_requests.activate', $req) }}">
                                            @csrf
                                            @method('PUT')
                                            <button class="btn primary" type="submit">{{ ___('Activate routing') }}</button>
                                        </form>
                                    @else
                                        <form method="POST" action="{{ route('superadmin.domain_requests.deactivate', $req) }}">
                                            @csrf
                                            @method('PUT')
                                            <button class="btn warn" type="submit">{{ ___('Deactivate routing') }}</button>
                                        </form>
                                    @endif
                                </div>
                                <div class="muted small" style="margin-top:6px;">{{ $req->admin_note ?: '-' }}</div>
                            @else
                                <div class="muted small">{{ $req->admin_note ?: '-' }}</div>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="muted">{{ ___('No requests found.') }}</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        <div style="margin-top:10px;">{{ $requests->links() }}</div>
    </div>
@endsection
