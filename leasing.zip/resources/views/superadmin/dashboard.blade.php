@extends('layouts.app')

@section('title', ___('Superadmin'))
@section('page_title', ___('Superadmin'))
@section('page_subtitle', ___('System overview'))
@section('page_actions')
    <a class="btn primary" href="{{ route('superadmin.plans.create') }}">{{ ___('New plan') }}</a>
    <a class="btn ghost" href="{{ route('superadmin.companies.index') }}">{{ ___('Companies') }}</a>
@endsection

@push('styles')
<style>
    .sa-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;}
    .sa-stat{padding:14px;border:1px solid var(--border);border-radius:12px;background:var(--card);}
    .sa-stat .value{font-size:26px;font-weight:800;margin:4px 0;}
    .sa-columns{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:12px;}
</style>
@endpush

@section('content')
<div class="wrap">

    <div class="sa-grid">
        <div class="sa-stat">
            <div class="muted small">{{ ___('Companies') }}</div>
            <div class="value">{{ $companyCounts['total'] }}</div>
            <div class="muted small">
                {{ ___('Active') }}: {{ $companyCounts['active'] }},
                {{ ___('Suspended') }}: {{ $companyCounts['suspended'] }}
            </div>
        </div>
        <div class="sa-stat">
            <div class="muted small">{{ ___('Trialing') }}</div>
            <div class="value">{{ $companyCounts['trialing'] }}</div>
            <div class="muted small">{{ ___('Companies currently on trial') }}</div>
        </div>
        <div class="sa-stat">
            <div class="muted small">{{ ___('Plans') }}</div>
            <div class="value">{{ $plans->count() }}</div>
            <div class="muted small">{{ ___('Manage packages and pricing') }}</div>
        </div>
        <div class="sa-stat">
            <div class="muted small">{{ ___('Subscriptions') }}</div>
            <div class="value">{{ $subscriptionCounts['active'] }} / {{ $subscriptionCounts['trial'] }}</div>
            <div class="muted small">{{ ___('Active / Trial / Past due:') }} {{ $subscriptionCounts['past_due'] }}</div>
        </div>
    </div>

    <div class="sa-columns">
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div class="h">{{ ___('Latest companies') }}</div>
                <a class="btn ghost" href="{{ route('superadmin.companies.index') }}">{{ ___('All companies') }}</a>
            </div>
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>{{ ___('Name') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Plan') }}</th>
                    <th>{{ ___('Trial ends at') }}</th>
                </tr>
                </thead>
                <tbody>
                @forelse($recentCompanies as $c)
                    <tr>
                        <td>{{ $c->id }}</td>
                        <td><a class="link" href="{{ route('superadmin.companies.show', $c) }}">{{ $c->name }}</a></td>
                        <td>
                            @if($c->suspended_at)
                                <span class="badge bad">{{ ___('Suspended') }}</span>
                            @elseif(!$c->is_active)
                                <span class="badge bad">{{ ___('Deactive') }}</span>
                            @else
                                <span class="badge ok">{{ ___('Active') }}</span>
                            @endif
                        </td>
                        <td>{{ $c->plan_code ?? '—' }}</td>
                        <td>{{ optional($c->trial_ends_at)->format('Y-m-d') ?? '—' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="muted">{{ ___('No information') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div class="h">{{ ___('Latest subscriptions') }}</div>
                <a class="btn ghost" href="{{ route('superadmin.companies.index') }}">{{ ___('Companies') }}</a>
            </div>
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>{{ ___('Company') }}</th>
                    <th>{{ ___('Plan') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Starts at') }}</th>
                </tr>
                </thead>
                <tbody>
                @forelse($recentSubscriptions as $s)
                    <tr>
                        <td>{{ $s->id }}</td>
                        <td>
                            <a class="link" href="{{ route('superadmin.companies.show', $s->company_id) }}">
                                @include('partials.company_label', ['company' => $s->company, 'companyId' => $s->company_id, 'size' => 18])
                            </a>
                        </td>
                        <td>{{ $s->plan?->name ?? $s->plan_name_snapshot ?? '—' }}</td>
                        <td><span class="badge">{{ $s->status }}</span></td>
                        <td>{{ optional($s->starts_at)->format('Y-m-d') ?? '—' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="muted">{{ ___('No information') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

</div>
@endsection
