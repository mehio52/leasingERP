@extends('layouts.app')

@section('title', ___('GPS Providers'))
@section('page_title', ___('GPS Providers'))

@section('page_actions')
    <a class="btn primary" href="{{ route('superadmin.gps_providers.create') }}">{{ ___('+ New provider') }}</a>
@endsection

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

<div class="wrap">
    <div class="card">
        @if($providers->isEmpty())
            <div class="muted">{{ ___('No providers yet.') }}</div>
        @else
            <div class="table">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Name') }}</th>
                        <th>{{ ___('Slug') }}</th>
                        <th>{{ ___('Status') }}</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($providers as $provider)
                        <tr>
                            <td>@include('partials.provider_label', ['provider' => $provider, 'size' => 18])</td>
                            <td>{{ $provider->slug }}</td>
                            <td>{{ $provider->is_active ? ___('Active') : ___('Inactive') }}</td>
                            <td>
                                <a class="btn ghost" href="{{ route('superadmin.gps_providers.edit', $provider) }}">{{ ___('Edit') }}</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div style="margin-top:10px;">{{ $providers->links() }}</div>
        @endif
    </div>
</div>
@endsection
