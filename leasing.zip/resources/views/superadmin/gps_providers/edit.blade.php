@extends('layouts.app')

@section('title', ___('Edit GPS provider'))
@section('page_title', ___('Edit GPS provider'))

@section('content')
@if(session('status'))
    <div class="banner">
        <span class="badge ok">{{ session('status') }}</span>
    </div>
@endif

@if($errors->any())
    <div class="banner error">
        <div class="badge bad">{{ ___('Xeta') }}</div>
        <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <form method="POST" action="{{ route('superadmin.gps_providers.update', $gpsProvider) }}">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="field">
                    <label>{{ ___('Provider name') }}</label>
                    <input name="name" value="{{ old('name', $gpsProvider->name) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Slug (optional)') }}</label>
                    <input name="slug" value="{{ old('slug', $gpsProvider->slug) }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Active') }}</label>
                    <select name="is_active">
                        <option value="1" @selected(old('is_active', $gpsProvider->is_active ? '1' : '0') === '1')>{{ ___('Active') }}</option>
                        <option value="0" @selected(old('is_active', $gpsProvider->is_active ? '1' : '0') === '0')>{{ ___('Inactive') }}</option>
                    </select>
                </div>
            </div>

            <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
                <button class="btn primary" type="submit">{{ ___('Save') }}</button>
            </div>
        </form>
    </div>

    <div style="height:12px;"></div>

    <div class="card">
        <div class="h">{{ ___('Provider users') }}</div>
        @if($users->isEmpty())
            <div class="muted">{{ ___('No users yet.') }}</div>
        @else
            <div class="table">
                <table>
                    <thead>
                    <tr>
                        <th>{{ ___('Name') }}</th>
                        <th>{{ ___('Phone') }}</th>
                        <th>{{ ___('Role') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($users as $u)
                        <tr>
                            <td>{{ $u->full_name }}</td>
                            <td>{{ $u->phone }}</td>
                            <td>{{ $u->role }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>

    <div style="height:12px;"></div>

    <div class="card">
        <div class="h">{{ ___('Add provider user') }}</div>
        <form method="POST" action="{{ route('superadmin.gps_providers.users.store', $gpsProvider) }}">
            @csrf

            <div class="row">
                <div class="field">
                    <label>{{ ___('First name') }}</label>
                    <input name="first_name" value="{{ old('first_name') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Last name') }}</label>
                    <input name="last_name" value="{{ old('last_name') }}" required>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Phone') }}</label>
                    <input name="phone" value="{{ old('phone') }}" placeholder="+994xxxxxxxxx" required>
                </div>
                <div class="field">
                    <label>{{ ___('Email') }}</label>
                    <input name="email" value="{{ old('email') }}" placeholder="example@mail.com">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Password') }}</label>
                    <input type="password" name="password" required>
                </div>
                <div class="field">
                    <label>{{ ___('Confirm password') }}</label>
                    <input type="password" name="password_confirmation" required>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Role') }}</label>
                    <select name="role">
                        <option value="gps_provider_admin">{{ ___('Admin') }}</option>
                        <option value="gps_provider_staff">{{ ___('Staff') }}</option>
                    </select>
                </div>
            </div>

            <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
                <button class="btn primary" type="submit">{{ ___('Add user') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
