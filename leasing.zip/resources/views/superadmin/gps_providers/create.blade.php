@extends('layouts.app')

@section('title', ___('New GPS provider'))
@section('page_title', ___('New GPS provider'))

@section('content')
@if($errors->any())
    <div class="banner error">
        <div class="badge bad">{{ ___('Xeta') }}</div>
        <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
            @foreach($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="wrap">
    <div class="card">
        <form method="POST" action="{{ route('superadmin.gps_providers.store') }}">
            @csrf

            <div class="row">
                <div class="field">
                    <label>{{ ___('Provider name') }}</label>
                    <input name="name" value="{{ old('name') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Slug (optional)') }}</label>
                    <input name="slug" value="{{ old('slug') }}" placeholder="gps-provider">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Active') }}</label>
                    <select name="is_active">
                        <option value="1" @selected(old('is_active', '1') === '1')>{{ ___('Active') }}</option>
                        <option value="0" @selected(old('is_active') === '0')>{{ ___('Inactive') }}</option>
                    </select>
                </div>
            </div>

            <hr class="hr">

            <div class="h">{{ ___('Create provider admin (optional)') }}</div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('First name') }}</label>
                    <input name="admin_first_name" value="{{ old('admin_first_name') }}">
                </div>
                <div class="field">
                    <label>{{ ___('Last name') }}</label>
                    <input name="admin_last_name" value="{{ old('admin_last_name') }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Phone') }}</label>
                    <input name="admin_phone" value="{{ old('admin_phone') }}" placeholder="+994xxxxxxxxx">
                </div>
                <div class="field">
                    <label>{{ ___('Email') }}</label>
                    <input name="admin_email" value="{{ old('admin_email') }}" placeholder="example@mail.com">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Password') }}</label>
                    <input type="password" name="admin_password">
                </div>
                <div class="field">
                    <label>{{ ___('Confirm password') }}</label>
                    <input type="password" name="admin_password_confirmation">
                </div>
            </div>

            <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
                <button class="btn primary" type="submit">{{ ___('Create') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
