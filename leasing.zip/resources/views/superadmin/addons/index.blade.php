@extends('layouts.app')

@section('title', 'Addons')
@section('page_title', 'Addons')
@section('page_subtitle', 'Manage addon catalog')
@section('page_actions')
    <a class="btn primary" href="{{ route('superadmin.addons.create') }}">{{ ___('New addon') }}</a>
@endsection

@section('content')
<div class="wrap">
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif
    @if(session('error'))
        <div class="banner error">{{ session('error') }}</div>
    @endif

    <div class="card">
        <div class="h">{{ ___('Addons') }}</div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Code</th>
                    <th>Name</th>
                    <th>{{ ___('Module') }}</th>
                    <th>Price (mo)</th>
                    <th>Price (yr)</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @forelse($addons as $addon)
                    <tr>
                        <td>{{ $addon->id }}</td>
                        <td>{{ $addon->code }}</td>
                        <td>{{ $addon->name }}</td>
                        <td>{{ $addon->module ?? ___('Universal') }}</td>
                        <td>{{ number_format((float)$addon->price_monthly,2) }} {{ $addon->currency }}</td>
                        <td>{{ number_format((float)$addon->price_yearly,2) }} {{ $addon->currency }}</td>
                        <td><span class="badge">{{ $addon->is_active ? ___('Active') : ___('Inactive') }}</span></td>
                        <td style="text-align:right; display:flex; gap:8px; justify-content:flex-end;">
                            <a class="btn" href="{{ route('superadmin.addons.edit', $addon) }}">{{ ___('Edit') }}</a>
                            <form method="POST" action="{{ route('superadmin.addons.destroy', $addon) }}" onsubmit="return confirm('Silinsin?');">
                                @csrf
                                @method('DELETE')
                                <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="8" class="muted">{{ ___('No addons') }}</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
