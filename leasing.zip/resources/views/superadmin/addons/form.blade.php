@extends('layouts.app')

@php
    $isEdit = ($mode ?? 'create') === 'edit';
    $action = $isEdit ? route('superadmin.addons.update', $addon) : route('superadmin.addons.store');
    $featureOptions = $featureOptions ?? [];
    $features = old('features_k', array_keys($addon->features ?? []));
    $featureValues = old('features_v', array_values($addon->features ?? []));
@endphp

@section('title', $isEdit ? 'Addon edit' : 'Addon create')
@section('page_title', $isEdit ? 'Addon edit' : 'Addon create')
@section('page_subtitle', 'Addon management')
@section('page_actions')
    <a class="btn ghost" href="{{ route('superadmin.addons.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
<div class="wrap">
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="h">{{ $isEdit ? ___('Edit addon') : ___('New addon') }}</div>
        <form method="POST" action="{{ $action }}" class="grid">
            @csrf
            @if($isEdit)
                @method('PUT')
            @endif

            <div class="row">
                <div class="field">
                    <label>{{ ___('Code') }}</label>
                    <input class="input" name="code" value="{{ old('code', $addon->code) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Name') }}</label>
                    <input class="input" name="name" value="{{ old('name', $addon->name) }}" required>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Description') }}</label>
                    <textarea class="input" name="description" rows="2">{{ old('description', $addon->description) }}</textarea>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Module') }}</label>
                    @php $module = old('module', $addon->module ?? null); @endphp
                    <select name="module">
                        <option value="">{{ ___('Universal') }}</option>
                        <option value="leasing" @selected($module === 'leasing')>{{ ___('Leasing') }}</option>
                        <option value="rentacar" @selected($module === 'rentacar')>{{ ___('Rent a car') }}</option>
                        <option value="taxipark" @selected($module === 'taxipark')>{{ ___('Taxi park') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Monthly price') }}</label>
                    <input class="input" type="number" step="0.01" min="0" name="price_monthly" value="{{ old('price_monthly', $addon->price_monthly) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Yearly price') }}</label>
                    <input class="input" type="number" step="0.01" min="0" name="price_yearly" value="{{ old('price_yearly', $addon->price_yearly) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Currency') }}</label>
                    <input class="input" name="currency" value="{{ old('currency', $addon->currency ?? 'AZN') }}" required>
                </div>
            </div>

            <div class="card" style="grid-column: 1 / -1;">
                <div class="h">{{ ___('Features provided') }}</div>
                <div class="muted small" style="margin-bottom:8px;">
                    {{ ___('Pick from known features or type custom code; value 1=on, 0=off') }}
                </div>
                @for($i=0; $i< max(3, count($features)); $i++)
                    <div class="row">
                        <div class="field">
                            <label>{{ ___('Feature code') }}</label>
                            <input class="input" list="addon-feature-options" name="features_k[]" value="{{ $features[$i] ?? '' }}" placeholder="bhph">
                        </div>
                        <div class="field">
                            <label>{{ ___('Value') }}</label>
                            <select class="input" name="features_v[]">
                                @php $val = (string)($featureValues[$i] ?? '1'); @endphp
                                <option value="1" @selected($val==='1')>{{ ___('On') }}</option>
                                <option value="0" @selected($val==='0')>{{ ___('Off') }}</option>
                            </select>
                        </div>
                    </div>
                @endfor
                <datalist id="addon-feature-options">
                    @foreach($featureOptions as $code => $label)
                        <option value="{{ $code }}">{{ $label }}</option>
                    @endforeach
                </datalist>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Sort order') }}</label>
                    <input class="input" type="number" min="0" name="sort_order" value="{{ old('sort_order', $addon->sort_order ?? 0) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Active') }}</label>
                    <input type="hidden" name="is_active" value="0">
                    <label class="checkbox">
                        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $addon->is_active ?? true))>
                        <span>{{ ___('Addon visible to companies') }}</span>
                    </label>
                </div>
            </div>

            <div style="display:flex; gap:8px; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ $isEdit ? ___('Save') : ___('Create') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
