@extends('layouts.app')

@section('title', 'Ticket')
@section('page_title', $ticket->subject)
@section('page_subtitle')
    {{ ___('Şirkət') }}:
    @include('partials.company_label', ['company' => $ticket->company, 'companyId' => $ticket->company_id, 'size' => 16])
    — {{ ___('Prioritet') }}: {{ $priorities[$ticket->priority] ?? $ticket->priority }}
@endsection
@section('page_actions')
    <a class="btn ghost" href="{{ route('superadmin.tickets.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    <div class="card">
        <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center; justify-content:space-between;">
            <div>
                <div class="muted small">{{ ___('Status') }}</div>
                <div class="badge {{ $ticket->status === 'closed' ? 'ok' : 'warn' }}">
                    {{ $ticket->status === 'closed' ? ___('Bağlı') : ___('Açıq') }}
                </div>
            </div>
            <div class="muted small">
                {{ ___('Yaradıldı') }}: {{ optional($ticket->created_at)->format('Y-m-d H:i') }} |
                {{ ___('Yeniləndi') }}: {{ optional($ticket->updated_at)->format('Y-m-d H:i') }}
            </div>
        </div>
    </div>

    <div class="card">
        <div class="h" style="margin-bottom:8px;">{{ ___('Mesajlar') }}</div>
        <div style="display:grid; gap:10px;">
            @foreach($ticket->messages as $msg)
                <div style="border:1px solid var(--border); border-radius:10px; padding:10px;">
                    <div style="display:flex; gap:8px; align-items:center; justify-content:space-between; flex-wrap:wrap;">
                        <div style="font-weight:700;">
                            @if($msg->user?->isSuperAdmin())
                                Superadmin
                            @elseif($msg->user?->company)
                                @include('partials.company_label', ['company' => $msg->user->company, 'size' => 16])
                            @else
                                {{ ___('Şirkət istifadəçisi') }}
                            @endif
                        </div>
                        <div class="muted small">{{ optional($msg->created_at)->format('Y-m-d H:i') }}</div>
                    </div>
                    <div style="margin-top:6px; white-space:pre-wrap;">{{ $msg->body }}</div>
                </div>
            @endforeach
        </div>
    </div>

    <div class="card">
        <form method="POST" action="{{ route('superadmin.tickets.reply', $ticket) }}">
            @csrf
            <div class="field">
                <label>{{ ___('Cavab') }}</label>
                <textarea name="body" rows="4" required></textarea>
            </div>
            <div class="field">
                <label>{{ ___('Status') }}</label>
                <select name="status">
                    <option value="open" @selected($ticket->status==='open')>{{ ___('Açıq') }}</option>
                    <option value="closed" @selected($ticket->status==='closed')>{{ ___('Bağlı') }}</option>
                </select>
            </div>
            <div class="actions">
                <button class="btn primary" type="submit">{{ ___('Göndər') }}</button>
            </div>
        </form>
    </div>
@endsection
