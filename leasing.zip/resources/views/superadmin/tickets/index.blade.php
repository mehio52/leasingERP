@extends('layouts.app')

@section('title', 'Tickets')
@section('page_title', 'Ticketlər (Superadmin)')
@section('content')
    <div class="card">
        <form method="GET" action="{{ route('superadmin.tickets.index') }}" style="margin-bottom:10px; display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
            <label class="muted small">{{ ___('Status') }}</label>
            <select name="status">
                <option value="">{{ ___('Hamısı') }}</option>
                <option value="open" @selected($status==='open')>{{ ___('Açıq') }}</option>
                <option value="closed" @selected($status==='closed')>{{ ___('Bağlı') }}</option>
            </select>
            <button class="btn" type="submit">{{ ___('Filter') }}</button>
        </form>

        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>{{ ___('Şirkət') }}</th>
                <th>{{ ___('Mövzu') }}</th>
                <th>{{ ___('Prioritet') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Yenilənmə') }}</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($tickets as $t)
                <tr>
                    <td>{{ $t->id }}</td>
                    <td>@include('partials.company_label', ['company' => $t->company, 'companyId' => $t->company_id, 'size' => 18])</td>
                    <td>{{ $t->subject }}</td>
                    <td><span class="badge">{{ $priorities[$t->priority] ?? $t->priority }}</span></td>
                    <td>
                        <span class="badge {{ $t->status === 'closed' ? 'ok' : 'warn' }}">
                            {{ $t->status === 'closed' ? ___('Bağlı') : ___('Açıq') }}
                        </span>
                    </td>
                    <td class="small">{{ optional($t->updated_at)->format('Y-m-d H:i') }}</td>
                    <td><a class="btn ghost" href="{{ route('superadmin.tickets.show', $t) }}">{{ ___('Aç') }}</a></td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">{{ ___('Ticket yoxdur.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:12px;">{{ $tickets->links() }}</div>
    </div>
@endsection
