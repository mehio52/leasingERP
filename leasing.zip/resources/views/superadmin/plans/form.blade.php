@extends('layouts.app')

@php
    $isEdit = ($mode ?? 'create') === 'edit';
    $action = $isEdit ? route('superadmin.plans.update', $plan) : route('superadmin.plans.store');
    $limits = [
        'users' => old('limit_users', data_get($plan->limits, 'users')),
        'active_contracts' => old('limit_active_contracts', data_get($plan->limits, 'active_contracts')),
        'branches' => old('limit_branches', data_get($plan->limits, 'branches')),
    ];
    $features = old('features', $plan->features ?? []);
@endphp

@section('title', $isEdit ? ___('Edit plan') : ___('New plan'))
@section('page_title', $isEdit ? ___('Edit plan') : ___('New plan'))
@section('page_subtitle', ___('Packages management'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('superadmin.plans.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
<div class="wrap">
    @if($errors->any())
        <div class="banner error">
            <div class="badge bad">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="h">{{ $isEdit ? ___('Edit plan') : ___('New plan') }}</div>
        <form method="POST" action="{{ $action }}" class="grid">
            @csrf
            @if($isEdit)
                @method('PUT')
            @endif

            <div class="row">
                <div class="field">
                    <label>{{ ___('Code') }}</label>
                    <input class="input" name="code" value="{{ old('code', $plan->code) }}" required placeholder="basic">
                </div>
                <div class="field">
                    <label>{{ ___('Name') }}</label>
                    <input class="input" name="name" value="{{ old('name', $plan->name) }}" required placeholder="{{ ___('Basic') }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Description') }}</label>
                    <textarea class="input" name="description" rows="2" placeholder="{{ ___('Optional') }}">{{ old('description', $plan->description) }}</textarea>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Module') }}</label>
                    @php $module = old('module', $plan->module ?? null); @endphp
                    <select name="module">
                        <option value="">{{ ___('Universal') }}</option>
                        <option value="leasing" @selected($module === 'leasing')>{{ ___('Leasing') }}</option>
                        <option value="rentacar" @selected($module === 'rentacar')>{{ ___('Rent a car') }}</option>
                        <option value="taxipark" @selected($module === 'taxipark')>{{ ___('Taxi park') }}</option>
                    </select>
                </div>
                <div class="field">
                    <label>{{ ___('Monthly price') }}</label>
                    <input class="input" type="number" step="0.01" min="0" name="price_monthly" value="{{ old('price_monthly', $plan->price_monthly) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Yearly price') }}</label>
                    <input class="input" type="number" step="0.01" min="0" name="price_yearly" value="{{ old('price_yearly', $plan->price_yearly) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Currency') }}</label>
                    <input class="input" name="currency" value="{{ old('currency', $plan->currency ?? 'AZN') }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Trial days') }}</label>
                    <input class="input" type="number" min="0" max="365" name="trial_days" value="{{ old('trial_days', $plan->trial_days ?? 0) }}">
                </div>
            </div>

            <div class="card" style="grid-column: 1 / -1;">
                <div class="h">{{ ___('Limits') }}</div>
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Users') }}</label>
                        <input class="input" type="number" min="0" name="limit_users" value="{{ $limits['users'] }}">
                        <div class="muted small">{{ ___('Leave empty for unlimited') }}</div>
                    </div>
                    <div class="field">
                        <label>{{ ___('Active contracts') }}</label>
                        <input class="input" type="number" min="0" name="limit_active_contracts" value="{{ $limits['active_contracts'] }}">
                    </div>
                    <div class="field">
                        <label>{{ ___('Branches') }}</label>
                        <input class="input" type="number" min="0" name="limit_branches" value="{{ $limits['branches'] }}">
                    </div>
                </div>
            </div>

            <div class="card" style="grid-column: 1 / -1;">
                <div class="h">{{ ___('Features / permissions') }}</div>
                <div class="grid" style="grid-template-columns: repeat(auto-fit,minmax(200px,1fr)); gap:10px;">
                    @foreach($featureOptions as $code => $label)
                        @php $checked = data_get($features, $code, false); @endphp
                        <label class="checkbox" style="display:flex; gap:8px; align-items:center; padding:10px; border:1px solid var(--border); border-radius:12px; background:var(--surface);">
                            <input type="hidden" name="features[{{ $code }}]" value="0">
                            <input type="checkbox" name="features[{{ $code }}]" value="1" @checked($checked)>
                            <span>{{ $label }}</span>
                        </label>
                    @endforeach
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Sort order') }}</label>
                    <input class="input" type="number" min="0" name="sort_order" value="{{ old('sort_order', $plan->sort_order ?? 0) }}">
                </div>
                <div class="field">
                    <label>{{ ___('Active') }}</label>
                    <input type="hidden" name="is_active" value="0">
                    <label class="checkbox">
                        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $plan->is_active ?? true))>
                        <span>{{ ___('Plan visible to companies') }}</span>
                    </label>
                </div>
            </div>

            <div style="display:flex; gap:8px; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ $isEdit ? ___('Save') : ___('Create') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
