@extends('layouts.app')

@section('title', ___('Plans'))
@section('page_title', ___('Plans'))
@section('page_subtitle', ___('Packages management'))
@section('page_actions')
    <a class="btn primary" href="{{ route('superadmin.plans.create') }}">{{ ___('New plan') }}</a>
    <a class="btn ghost" href="{{ route('superadmin.dashboard') }}">{{ ___('Overview') }}</a>
@endsection

@section('content')
<div class="wrap">
    @if(session('status'))
        <div class="banner">
            <span class="badge ok">{{ ___('OK') }}</span>
            <span style="margin-left:10px;">{{ session('status') }}</span>
        </div>
    @endif
    @if(session('error'))
        <div class="banner error">
            <span class="badge bad">{{ ___('Error') }}</span>
            <span style="margin-left:10px;">{{ session('error') }}</span>
        </div>
    @endif

    <div class="card">
        <div class="h">{{ ___('Plans') }}</div>
        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th>{{ ___('Code') }}</th>
                <th>{{ ___('Name') }}</th>
                <th>{{ ___('Module') }}</th>
                <th>{{ ___('Price') }}</th>
                <th>{{ ___('Trial days') }}</th>
                <th>{{ ___('Active') }}</th>
                <th>{{ ___('Subscriptions') }}</th>
                <th>{{ ___('Actions') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($plans as $plan)
                <tr>
                    <td>{{ $plan->id }}</td>
                    <td>{{ $plan->code }}</td>
                    <td>{{ $plan->name }}</td>
                    <td>{{ $plan->module ?? ___('Universal') }}</td>
                    <td>
                        <div class="muted small">{{ ___('Monthly') }}: {{ $plan->price_monthly }} {{ $plan->currency }}</div>
                        <div class="muted small">{{ ___('Yearly') }}: {{ $plan->price_yearly }} {{ $plan->currency }}</div>
                    </td>
                    <td>{{ $plan->trial_days }}</td>
                    <td>
                        @if($plan->is_active)
                            <span class="badge ok">{{ ___('yes') }}</span>
                        @else
                            <span class="badge bad">{{ ___('no') }}</span>
                        @endif
                    </td>
                    <td>{{ $plan->subscriptions_count }}</td>
                    <td>
                        <div class="actions">
                            <a class="btn outline" href="{{ route('superadmin.plans.edit', $plan) }}">{{ ___('Edit') }}</a>
                            <form method="POST" action="{{ route('superadmin.plans.destroy', $plan) }}" onsubmit="return confirm('{{ ___('Are you sure you want to delete?') }}')">
                                @csrf
                                @method('DELETE')
                                <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr><td colspan="9" class="muted">{{ ___('No information') }}</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
