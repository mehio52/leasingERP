@extends('layouts.app')

@section('title', ___('Epoint transactions'))
@section('page_title', ___('Epoint transactions'))
@section('page_subtitle', ___('Superadmin view'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('superadmin.dashboard') }}">{{ ___('Overview') }}</a>
@endsection

@section('content')
<div class="wrap">
    <div class="card">
        <form method="GET" action="{{ route('superadmin.epoint.index') }}" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px; align-items:end;">
            <div>
                <label class="muted small">{{ ___('Search') }}</label>
                <input class="input" type="text" name="q" value="{{ $q }}" placeholder="{{ ___('Order ID / transaction / company') }}">
            </div>
            <div>
                <label class="muted small">{{ ___('Type') }}</label>
                <select class="input" name="type">
                    <option value="">{{ ___('All') }}</option>
                    <option value="plan" @selected($type === 'plan')>{{ ___('Plan') }}</option>
                    <option value="addon" @selected($type === 'addon')>{{ ___('Add-on') }}</option>
                    <option value="loan_payment" @selected($type === 'loan_payment')>{{ ___('Loan payment') }}</option>
                    <option value="payout_card" @selected($type === 'payout_card')>{{ ___('Payout card') }}</option>
                    <option value="payout" @selected($type === 'payout')>{{ ___('Payout') }}</option>
                </select>
            </div>
            <div>
                <label class="muted small">{{ ___('Status') }}</label>
                <select class="input" name="status">
                    <option value="">{{ ___('All') }}</option>
                    <option value="pending" @selected($status === 'pending')>{{ ___('Pending') }}</option>
                    <option value="success" @selected($status === 'success')>{{ ___('Success') }}</option>
                    <option value="failed" @selected($status === 'failed')>{{ ___('Failed') }}</option>
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <button class="btn ghost" type="button" onclick="window.location='{{ route('superadmin.epoint.index') }}'">{{ ___('Reset') }}</button>
                <button class="btn primary" type="submit">{{ ___('Apply') }}</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="h">{{ ___('Transactions') }}</div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>{{ ___('Company') }}</th>
                    <th>{{ ___('Type') }}</th>
                    <th>{{ ___('Gateway') }}</th>
                    <th>{{ ___('Amount') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Order ID') }}</th>
                    <th>{{ ___('Transaction') }}</th>
                    <th>{{ ___('Created') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($transactions as $tx)
                    <tr>
                        <td>{{ $tx->id }}</td>
                        <td>
                            <div style="display:flex; flex-direction:column;">
                                <strong>@include('partials.company_label', ['company' => $tx->company, 'companyId' => $tx->company_id, 'size' => 18])</strong>
                                <span class="muted small">{{ $tx->company?->slug ?? '' }}</span>
                            </div>
                        </td>
                        <td>{{ $tx->type }}</td>
                        <td>{{ $tx->gateway ?? 'epoint' }}</td>
                        <td>{{ number_format((float) $tx->amount, 2) }} {{ $tx->currency ?? 'AZN' }}</td>
                        <td>
                            @if($tx->status === 'success')
                                <span class="badge ok">{{ ___('Success') }}</span>
                            @elseif($tx->status === 'failed')
                                <span class="badge bad">{{ ___('Failed') }}</span>
                            @else
                                <span class="badge">{{ ___('Pending') }}</span>
                            @endif
                        </td>
                        <td>
                            <div style="max-width:220px; word-break:break-all;">{{ $tx->order_id }}</div>
                        </td>
                        <td>
                            <div class="muted small" style="max-width:220px; word-break:break-all;">
                                {{ $tx->gateway_transaction ?? $tx->epoint_transaction ?? $tx->bank_transaction ?? '—' }}
                            </div>
                        </td>
                        <td>{{ optional($tx->created_at)->format('Y-m-d H:i') }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="muted">{{ ___('No information') }}</td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        @if($transactions->hasPages())
            <div class="pager">
                <div class="muted">{{ ___('Page') }} {{ $transactions->currentPage() }} / {{ $transactions->lastPage() }}</div>
                <div style="display:flex; gap:10px;">
                    <a class="pill {{ $transactions->onFirstPage() ? 'disabled' : '' }}" href="{{ $transactions->previousPageUrl() ?? '#' }}">{{ ___('Previous') }}</a>
                    <a class="pill {{ $transactions->hasMorePages() ? '' : 'disabled' }}" href="{{ $transactions->nextPageUrl() ?? '#' }}">{{ ___('Next') }}</a>
                </div>
            </div>
        @endif
    </div>
</div>
@endsection
