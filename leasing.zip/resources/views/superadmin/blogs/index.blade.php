@extends('layouts.app')

@section('title', ___('Blog posts'))
@section('page_title', ___('Blog posts'))
@section('page_subtitle', ___('Platform blog'))
@section('page_actions')
    <a class="btn primary" href="{{ route('superadmin.blogs.create') }}">{{ ___('New post') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif

    <div class="card">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>{{ ___('Title') }}</th>
                    <th>{{ ___('Status') }}</th>
                    <th>{{ ___('Published at') }}</th>
                    <th style="width:260px;">{{ ___('Actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($posts as $p)
                    <tr>
                        <td>{{ $p->id }}</td>
                        <td>
                            <div style="font-weight:600;">{{ $p->title }}</div>
                            <div class="muted small">{{ $p->slug }}</div>
                        </td>
                        <td>{{ $p->status }}</td>
                        <td>{{ $p->published_at }}</td>
                        <td>
                            @if($p->status === 'published')
                                <a class="btn ghost" href="{{ route('public.blog.show', $p->slug) }}" target="_blank" rel="noopener">{{ ___('View') }}</a>
                            @endif
                            <a class="btn" href="{{ route('superadmin.blogs.edit', $p) }}">{{ ___('Edit') }}</a>
                            <form method="POST" action="{{ route('superadmin.blogs.destroy', $p) }}" style="display:inline-block;" onsubmit="return confirm('{{ ___('Delete this post?') }}');">
                                @csrf
                                @method('DELETE')
                                <button class="btn danger" type="submit">{{ ___('Delete') }}</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="muted">{{ ___('No posts yet.') }}</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        {{ $posts->links() }}
    </div>
@endsection
