@extends('layouts.app')

@php
    $isEdit = ($mode ?? 'create') === 'edit';
    $action = $isEdit ? route('superadmin.blogs.update', $post) : route('superadmin.blogs.store');
@endphp

@section('title', $isEdit ? ___('Edit blog post') : ___('New blog post'))
@section('page_title', $isEdit ? ___('Edit blog post') : ___('New blog post'))
@section('page_subtitle', ___('Platform blog'))
@section('page_actions')
    <a class="btn ghost" href="{{ route('superadmin.blogs.index') }}">{{ ___('Back') }}</a>
@endsection

@section('content')
    @if(session('status'))
        <div class="banner success">{{ session('status') }}</div>
    @endif
    @if($errors->any())
        <div class="banner error">
            <div style="font-weight:700;">{{ ___('Error') }}</div>
            <ul class="muted" style="margin:10px 0 0; padding-left:18px;">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ $action }}" class="grid" enctype="multipart/form-data" id="platform-blog-form">
            @csrf
            @if($isEdit)
                @method('PUT')
            @endif

            <div class="row">
                <div class="field">
                    <label>{{ ___('Title') }}</label>
                    <input class="input" name="title" value="{{ old('title', $post->title) }}" required>
                </div>
                <div class="field">
                    <label>{{ ___('Slug (optional)') }}</label>
                    <input class="input" name="slug" value="{{ old('slug', $post->slug) }}" placeholder="{{ ___('auto from title') }}">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label>{{ ___('Excerpt (optional)') }}</label>
                    <textarea class="input" name="excerpt" rows="2">{{ old('excerpt', $post->excerpt) }}</textarea>
                </div>
            </div>

            <div class="row" style="grid-column: 1 / -1;">
                <div class="field" style="grid-column: 1 / -1;">
                    <label>{{ ___('Content') }}</label>
                    <div class="muted small" style="margin-bottom:8px;">
                        {{ ___('HTML/CSS allowed. Use {keyword} placeholders for uploaded images.') }}
                    </div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px;">
                        <button class="btn ghost" type="button" data-editor-wrap="<strong>" data-editor-wrap-end="</strong>">{{ ___('Bold') }}</button>
                        <button class="btn ghost" type="button" data-editor-wrap="<em>" data-editor-wrap-end="</em>">{{ ___('Italic') }}</button>
                        <button class="btn ghost" type="button" data-editor-wrap="<h2>" data-editor-wrap-end="</h2>">{{ ___('Heading') }}</button>
                        <button class="btn ghost" type="button" data-editor-insert="<p></p>">{{ ___('Paragraph') }}</button>
                        <button class="btn ghost" type="button" data-editor-insert="<img src=&quot;URL&quot; alt=&quot;&quot;>">{{ ___('Image') }}</button>
                        <button class="btn ghost" type="button" data-editor-insert="{image_1}">{{ ___('Image placeholder') }}</button>
                    </div>
                    <textarea class="input" name="content" rows="14" id="platform-blog-content">{{ old('content', $post->content) }}</textarea>
                </div>
            </div>

            @if(!$isEdit)
                <div class="row">
                    <div class="field">
                        <label>{{ ___('Upload images (optional)') }}</label>
                        <input class="input" type="file" name="images[]" multiple accept="image/*">
                        <div class="muted small">{{ ___('Images will get keywords like image_1, image_2. Use {image_1} in content.') }}</div>
                    </div>
                </div>
            @endif

            <div class="row">
                <div class="field">
                    <label>{{ ___('Status') }}</label>
                    <select class="input" name="status">
                        <option value="published" @selected(old('status', $post->status) === 'published')>{{ ___('Published') }}</option>
                        <option value="draft" @selected(old('status', $post->status) === 'draft')>{{ ___('Draft') }}</option>
                    </select>
                </div>
            </div>

            <div style="display:flex; gap:8px; justify-content:flex-end;">
                <button class="btn primary" type="submit">{{ $isEdit ? ___('Save') : ___('Create') }}</button>
            </div>
        </form>
    </div>

    <div class="card" style="margin-top:16px;">
        <div class="h">{{ ___('Images') }}</div>
        <div class="muted small">
            {{ ___('Upload images and place them in content with keywords like {image_1}.') }}
        </div>

        @if($isEdit)
            <form method="POST" action="{{ route('superadmin.blogs.images.store', $post) }}" enctype="multipart/form-data" class="grid" style="margin-top:12px;">
                @csrf
                <div class="field">
                    <label>{{ ___('Upload images') }}</label>
                    <input class="input" type="file" name="images[]" multiple accept="image/*">
                    <div class="muted small">{{ ___('You can upload multiple images. Max 5MB each.') }}</div>
                </div>
                <div style="display:flex; justify-content:flex-end;">
                    <button class="btn primary" type="submit">{{ ___('Upload') }}</button>
                </div>
            </form>

            @if($post->images->isNotEmpty())
                <div class="grid" style="grid-template-columns: repeat(auto-fit,minmax(240px,1fr)); gap:12px; margin-top:16px;">
                    @foreach($post->images as $img)
                        <div class="card" style="padding:12px;">
                            <div style="aspect-ratio:16/9; background:var(--border); border-radius:8px; overflow:hidden;">
                                <img src="{{ $img->url }}" alt="" style="width:100%; height:100%; object-fit:cover;">
                            </div>

                            <form method="POST" action="{{ route('superadmin.blogs.images.update', $post) }}" style="margin-top:10px;">
                                @csrf
                                @method('PUT')
                                <div class="field">
                                    <label>{{ ___('Keyword') }}</label>
                                    <input class="input" name="images[{{ $img->id }}][keyword]" value="{{ old('images.'.$img->id.'.keyword', $img->keyword) }}" placeholder="image_1">
                                    @if($img->keyword)
                                        <div class="muted small">{{ ___('Placeholder') }}: {{ '{' . $img->keyword . '}' }}</div>
                                    @else
                                        <div class="muted small">{{ ___('Set keyword to use {keyword} in content.') }}</div>
                                    @endif
                                </div>
                                <div class="field">
                                    <label>{{ ___('Alt text') }}</label>
                                    <input class="input" name="images[{{ $img->id }}][alt_text]" value="{{ old('images.'.$img->id.'.alt_text', $img->alt_text) }}">
                                </div>
                                <div style="display:flex; gap:8px; justify-content:flex-end;">
                                    <button class="btn primary" type="submit">{{ ___('Save') }}</button>
                                    <button class="btn danger" type="submit" form="delete-image-{{ $img->id }}">{{ ___('Delete') }}</button>
                                </div>
                            </form>

                            <form id="delete-image-{{ $img->id }}" method="POST" action="{{ route('superadmin.blogs.images.destroy', [$post, $img]) }}" onsubmit="return confirm('{{ ___('Delete this image?') }}');" style="display:none;">
                                @csrf
                                @method('DELETE')
                            </form>
                        </div>
                    @endforeach
                </div>
            @endif
        @else
            <div class="muted small" style="margin-top:12px;">
                {{ ___('Upload images above and save to manage keywords and placement.') }}
            </div>
        @endif
    </div>
@endsection

@push('scripts')
<script>
    (function() {
        const editor = document.getElementById('platform-blog-content');
        if (!editor) return;

        const wrapSelection = (start, end) => {
            const s = editor.selectionStart || 0;
            const e = editor.selectionEnd || 0;
            const before = editor.value.slice(0, s);
            const middle = editor.value.slice(s, e);
            const after = editor.value.slice(e);
            editor.value = before + start + middle + end + after;
            editor.focus();
            const cursor = s + start.length + middle.length + end.length;
            editor.setSelectionRange(cursor, cursor);
        };

        const insertAtCursor = (value) => {
            const s = editor.selectionStart || 0;
            const e = editor.selectionEnd || 0;
            const before = editor.value.slice(0, s);
            const after = editor.value.slice(e);
            editor.value = before + value + after;
            editor.focus();
            const cursor = s + value.length;
            editor.setSelectionRange(cursor, cursor);
        };

        document.querySelectorAll('[data-editor-wrap]').forEach(btn => {
            btn.addEventListener('click', () => {
                wrapSelection(btn.getAttribute('data-editor-wrap'), btn.getAttribute('data-editor-wrap-end') || '');
            });
        });

        document.querySelectorAll('[data-editor-insert]').forEach(btn => {
            btn.addEventListener('click', () => {
                insertAtCursor(btn.getAttribute('data-editor-insert'));
            });
        });
    })();
</script>
@endpush
