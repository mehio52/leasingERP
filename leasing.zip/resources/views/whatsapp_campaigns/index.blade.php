@extends('layouts.app')

@section('title', ___('WhatsApp Kampaniyalar'))
@section('page_title', ___('WhatsApp Kampaniyalar'))
@section('page_subtitle', ___('Kampaniya siyahısı'))

@section('content')
<div class="wrap">
    <div class="card slab" style="display:flex; justify-content:space-between; align-items:center;">
        <div>
            <div class="h">{{ ___('WhatsApp Kampaniyalar') }}</div>
            <div class="muted small">{{ ___('Müştərilərə göndərilən kampaniyaların siyahısı') }}</div>
        </div>
        <div style="display:flex; gap:8px; align-items:center;">
            <a class="btn ghost" href="{{ route('company.notifications.edit') }}">{{ ___('Ayarlar') }}</a>
            <a class="btn primary" href="{{ route('company.whatsapp_campaigns.create') }}">{{ ___('Yeni kampaniya') }}</a>
        </div>
    </div>

    @if (session('status'))
        <div class="card" style="border-left:4px solid #16a34a;">{{ session('status') }}</div>
    @endif

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>{{ ___('Başlıq') }}</th>
                <th>{{ ___('Status') }}</th>
                <th>{{ ___('Göndərilən') }}</th>
                <th>{{ ___('Uğursuz') }}</th>
                <th>{{ ___('Səbəb') }}</th>
                <th>{{ ___('HTTP') }}</th>
                <th>{{ ___('Tarix') }}</th>
            </tr>
            </thead>
            <tbody>
            @forelse($campaigns as $c)
                <tr>
                    <td>{{ $c->title }}</td>
                    <td><span class="badge">{{ $c->status }}</span></td>
                    <td>{{ $c->sent_count }} / {{ $c->recipients_count }}</td>
                    <td>{{ $c->failed_count }}</td>
                    <td class="small">{{ $c->meta['error'] ?? '-' }}</td>
                    <td class="small">{{ $c->meta['http'] ?? '-' }}</td>
                    <td>{{ $c->created_at->format('Y-m-d H:i') }}</td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">{{ ___('Kampaniya yoxdur.') }}</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:10px;">
            {{ $campaigns->links() }}
        </div>
    </div>
</div>
@endsection
