@extends('layouts.app')

@section('title', ___('Yeni WhatsApp kampaniyası'))
@section('page_title', ___('Yeni WhatsApp kampaniyası'))
@section('page_subtitle', ___('Müştərilərə toplu mesaj göndərin'))

@section('content')
<div class="wrap">
    <div class="card slab" style="display:flex; justify-content:space-between; align-items:center;">
        <div>
            <div class="h">{{ ___('WhatsApp kampaniyası') }}</div>
            <div class="muted small">{{ ___('Mesaj hamısa göndəriləcək: şirkətin bütün müştəriləri') }}</div>
        </div>
        <a class="btn ghost" href="{{ route('company.whatsapp_campaigns.index') }}">{{ ___('Siyahı') }}</a>
    </div>

    @if (!$featureOk)
        <div class="card" style="border-left:4px solid #dc2626;">
            {{ ___('Planınızda kampaniya göndərmək üçün icazə yoxdur.') }}
        </div>
    @endif

    @if (!$option || !$option->wp_api_secret)
        <div class="card" style="border-left:4px solid #f97316;">
            {{ ___('WhatsApp API ayarları tamamlanmayıb. Ayarlardan aktivləşdirin.') }}
            <div style="margin-top:8px;">
                <a class="btn primary" href="{{ route('company.notifications.edit') }}">{{ ___('Ayarları aç') }}</a>
            </div>
        </div>
    @endif

    <div class="card">
        <form method="POST" action="{{ route('company.whatsapp_campaigns.store') }}" class="grid" style="gap:12px;">
            @csrf
            <div>
                <label class="muted small">{{ ___('Başlıq') }}</label>
                <input class="input" name="title" value="{{ old('title') }}" maxlength="160">
                @error('title')<div class="text-red small">{{ $message }}</div>@enderror
            </div>
            <div class="span-12" style="grid-column: span 12;">
                <label class="muted small">{{ ___('Mesaj məzmunu') }}</label>
                <textarea class="input" name="message" rows="4" maxlength="1000" placeholder="{{ ___('Müştəriyə göndəriləcək mətn...') }}">{{ old('message') }}</textarea>
                <div class="muted small">{{ ___('Əlavə açar sözlər: {customer_name} əvəzinə ad yerləşdirilməyəcək, sadəcə mətn göndərilir.') }}</div>
                @error('message')<div class="text-red small">{{ $message }}</div>@enderror
            </div>
            <div class="span-12" style="grid-column: span 12; display:flex; justify-content:flex-end; gap:10px;">
                <a class="btn ghost" href="{{ route('company.whatsapp_campaigns.index') }}">{{ ___('Ləğv et') }}</a>
                <button class="btn primary" type="submit" @disabled(!$featureOk || !$option || !$option->wp_api_secret)>{{ ___('Göndər') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
