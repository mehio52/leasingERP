<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToCompany;

class SubscriptionAddon extends Model
{
    use BelongsToCompany;

    protected $table = 'subscription_addons';

    protected $fillable = [
        'company_id',
        'subscription_id',
        'addon_id',
        'quantity',
        'starts_at','ends_at',
        'addon_code_snapshot','addon_name_snapshot',
        'price_snapshot','currency_snapshot',
        'features_snapshot',
        'meta',
    ];

    protected $casts = [
        'quantity' => 'integer',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
        'features_snapshot' => 'array',
        'meta' => 'array',
        'price_snapshot' => 'decimal:2',
    ];

    public function subscription()
    {
        return $this->belongsTo(Subscription::class);
    }

    public function addon()
    {
        return $this->belongsTo(Addon::class);
    }
}