<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class Contract extends Model
{

    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'contracts';

    // =========================
    // Status constants
    // =========================
    public const STATUS_ACTIVE = 'active';
    public const STATUS_CLOSED = 'closed';
    public const STATUS_CANCELLED = 'cancelled';

    /**
     * Toplu yazmağa icazə verilən sahələr
     */
    protected $fillable = [
        'company_id',
        'customer_id',
        'vehicle_id',
        'bhph_account_id',
        'contract_no',
        'seller_user_id',
        'contract_type',
        'seller_name',
        'seller_phone',
        'seller_id_number',
        'seller_fin',
        'seller_id_issue_date',
        'seller_id_authority',
        'signed_date',
        'start_date',
        'end_date',
        'status',
    ];

    /**
     * Tarix tipləri
     */
    protected $casts = [
        'signed_date' => 'date',
        'start_date'  => 'date',
        'end_date'    => 'date',
        'seller_id_issue_date' => 'date',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    public function scopeStatus(Builder $q, string $status): Builder
    {
        return $q->where('status', $status);
    }

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_ACTIVE);
    }

    public function scopeClosed(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_CLOSED);
    }

    public function scopeCancelled(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_CANCELLED);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function seller()
    {
        return $this->belongsTo(User::class, 'seller_user_id');
    }

    // bhph_accounts.contract_id -> contracts.id
    public function bhphAccount()
    {
        return $this->hasOne(BhphAccount::class, 'contract_id');
    }

    // =========================
    // Helpers
    // =========================

    public function isClosed(): bool
    {
        return $this->status === self::STATUS_CLOSED;
    }

    public function isCancelled(): bool
    {
        return $this->status === self::STATUS_CANCELLED;
    }

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function durationDays(): ?int
    {
        if (!$this->start_date || !$this->end_date) {
            return null;
        }
        return $this->start_date->diffInDays($this->end_date);
    }
}
