<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;

class EpointTransaction extends Model
{
    protected $table = 'epoint_transactions';

    public const STATUS_PENDING = 'pending';
    public const STATUS_SUCCESS = 'success';
    public const STATUS_FAILED = 'failed';

    public const TYPE_PLAN = 'plan';
    public const TYPE_ADDON = 'addon';
    public const TYPE_LOAN_PAYMENT = 'loan_payment';
    public const TYPE_PAYOUT_CARD = 'payout_card';
    public const TYPE_PAYOUT = 'payout';

    protected $fillable = [
        'company_id',
        'requested_by_user_id',
        'type',
        'gateway',
        'status',
        'amount',
        'currency',
        'order_id',
        'gateway_transaction',
        'description',
        'epoint_transaction',
        'bank_transaction',
        'code',
        'rrn',
        'message',
        'bank_response',
        'payload',
        'meta',
        'processed_at',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'payload' => 'array',
        'meta' => 'array',
        'processed_at' => 'datetime',
    ];

    public function scopePending(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_PENDING);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function requester()
    {
        return $this->belongsTo(User::class, 'requested_by_user_id');
    }

    public static function generateOrderId(string $prefix): string
    {
        $uid = Str::uuid()->toString();
        return $prefix . '-' . $uid;
    }
}
