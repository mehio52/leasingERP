<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatRoom extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'is_group',
        'created_by',
    ];

    protected $casts = [
        'company_id' => 'integer',
        'is_group' => 'boolean',
        'created_by' => 'integer',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'chat_room_user');
    }

    public function messages()
    {
        return $this->hasMany(ChatMessage::class);
    }
}
