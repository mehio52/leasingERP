<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TaxiDriver extends Model
{
    protected $fillable = [
        'company_id',
        'first_name',
        'last_name',
        'phone',
        'email',
        'address',
        'status',
        'salary_type',
        'salary_value',
        'salary_currency',
        'salary_meta',
        'notes',
        'certificate_no',
        'certificate_image',
        'id_card_no',
        'id_card_image',
        'driver_license_no',
        'driver_license_image',
        'created_by',
    ];

    protected $casts = [
        'salary_meta' => 'array',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function assignments()
    {
        return $this->hasMany(TaxiVehicleAssignment::class, 'driver_id');
    }

    public function trips()
    {
        return $this->hasMany(TaxiTrip::class, 'driver_id');
    }

    public function issues()
    {
        return $this->hasMany(TaxiVehicleIssue::class, 'driver_id');
    }

    public function getFullNameAttribute(): string
    {
        return trim(($this->first_name ?? '') . ' ' . ($this->last_name ?? ''));
    }
}
