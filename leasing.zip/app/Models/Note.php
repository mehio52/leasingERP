<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class Note extends Model
{
    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'notes';
    // =========================


    public const STATUS_ACTIVE = 'active';
    public const STATUS_ARCHIVED = 'archived';

    protected $fillable = [
        'company_id',
        'created_by_user_id',
        'noteable_type',
        'noteable_id',
        'title',
        'content',
        'status',
        'meta',
    ];

    protected $casts = [
        'meta' => 'array',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_ACTIVE);
    }

    public function scopeArchived(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_ARCHIVED);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Note-u kim yazıb?
     */
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by_user_id');
    }

    /**
     * Polymorphic relation:
     * $note->noteable  -> Vehicle/Customer/BhphAccount və s.
     */
    public function noteable()
    {
        return $this->morphTo();
    }

    // =========================
    // Helpers
    // =========================

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function isArchived(): bool
    {
        return $this->status === self::STATUS_ARCHIVED;
    }
}