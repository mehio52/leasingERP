<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TaxiTrip extends Model
{
    protected $fillable = [
        'company_id',
        'driver_id',
        'vehicle_id',
        'start_at',
        'end_at',
        'distance_km',
        'fare',
        'tip',
        'discount',
        'total',
        'payment_method',
        'status',
        'notes',
    ];

    protected $casts = [
        'start_at' => 'datetime',
        'end_at' => 'datetime',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function driver()
    {
        return $this->belongsTo(TaxiDriver::class, 'driver_id');
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }
}
