<?php

namespace App\Models\Concerns;

use App\Scopes\TenantScope;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

trait BelongsToCompany
{
    protected static function bootBelongsToCompany(): void
    {
        // Tenant global scope
        static::addGlobalScope(new TenantScope);

        // company_id auto-fill (yalnız user artıq resolve olunubsa)
        static::creating(function ($model) {
            if (!empty($model->company_id)) {
                return;
            }

            // Auth::check() YOX! (auth user resolve prosesində recursion yaradır)
            if (!Auth::hasUser()) {
                return;
            }

            $user = Auth::user();
            if (!$user?->company_id) {
                return;
            }

            $model->company_id = $user->company_id;
        });
    }

    public function scopeWithoutTenant(Builder $q): Builder
    {
        return $q->withoutGlobalScope(TenantScope::class);
    }
}