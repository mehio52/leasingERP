<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class GpsVehicleRequest extends Model
{
    protected $table = 'gps_vehicle_requests';

    protected $fillable = [
        'vehicle_id',
        'company_id',
        'gps_provider_id',
        'status',
        'unique_id',
        'unit_name',
        'hw_type_id',
        'requested_by',
        'approved_by',
        'requested_at',
        'approved_at',
        'rejected_at',
        'note',
    ];

    protected $casts = [
        'requested_at' => 'datetime',
        'approved_at' => 'datetime',
        'rejected_at' => 'datetime',
        'hw_type_id' => 'integer',
    ];

    public function scopePending(Builder $q): Builder
    {
        return $q->where('status', 'pending');
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function provider()
    {
        return $this->belongsTo(GpsProvider::class, 'gps_provider_id');
    }

    public function requester()
    {
        return $this->belongsTo(User::class, 'requested_by');
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }
}
