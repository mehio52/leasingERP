<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class DocumentTemplate extends Model
{
    use BelongsToCompany;

    protected $table = 'document_templates';

    protected $fillable = [
        'company_id',
        'uploaded_by_user_id',
        'name',
        'description',
        'file_path',
        'keywords',
        'is_active',
        'contract_type',
    ];

    protected $casts = [
        'keywords' => 'array',
        'is_active' => 'boolean',
    ];

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by_user_id');
    }
}
