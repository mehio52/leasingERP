<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NotificationOption extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'is_active',
        'wp_api_url',
        'wp_api_key',
        'wp_api_secret',
        'sender_label',
        'template_due_soon',
        'template_overdue',
        'template_penalty_applied',
        'settings',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'settings' => 'array',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
