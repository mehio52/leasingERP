<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\BhphAccount;
use App\Models\DocumentTemplate;

class AccountDocument extends Model
{
    protected $table = 'bhph_account_documents';

    protected $fillable = [
        'company_id',
        'bhph_account_id',
        'document_template_id',
        'file_path',
        'file_name',
    ];

    public function account(): BelongsTo
    {
        return $this->belongsTo(BhphAccount::class, 'bhph_account_id');
    }

    public function template(): BelongsTo
    {
        return $this->belongsTo(DocumentTemplate::class, 'document_template_id');
    }
}
