<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class TaxReport extends Model
{
    use BelongsToCompany;

    protected $fillable = [
        'company_id',
        'period_start',
        'period_end',
        'gross_revenue',
        'deductible_expenses',
        'taxable_income',
        'tax_rate',
        'tax_amount',
        'note',
    ];

    protected $casts = [
        'period_start' => 'date',
        'period_end'   => 'date',
        'gross_revenue' => 'decimal:2',
        'deductible_expenses' => 'decimal:2',
        'taxable_income' => 'decimal:2',
        'tax_rate' => 'decimal:3',
        'tax_amount' => 'decimal:2',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }
}
