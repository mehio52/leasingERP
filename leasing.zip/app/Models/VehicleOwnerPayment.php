<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToCompany;

class VehicleOwnerPayment extends Model
{
    use BelongsToCompany;

    protected $table = 'vehicle_owner_payments';

    protected $fillable = [
        'company_id',
        'vehicle_id',
        'owner_customer_id',
        'payment_type',
        'amount',
        'period_start',
        'period_end',
        'paid_at',
        'note',
        'created_by',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'period_start' => 'date',
        'period_end' => 'date',
        'paid_at' => 'datetime',
    ];

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function owner()
    {
        return $this->belongsTo(Customer::class, 'owner_customer_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
