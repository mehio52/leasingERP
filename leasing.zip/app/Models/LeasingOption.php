<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class LeasingOption extends Model
{
    use BelongsToCompany;
    // cədvəl adı plural deyil
    protected $table = 'leasing_options';
    // =========================

    // =========================
    // Constants (typo riskini azaldır)
    // =========================
    public const AMORT_REDUCING_BALANCE = 'reducing_balance';
    public const AMORT_ANNUITY = 'annuity';
    public const AMORT_FLAT = 'flat';

    public const FREQ_MONTHLY = 'monthly';
    public const FREQ_WEEKLY = 'weekly';
    public const FREQ_BIWEEKLY = 'biweekly';

    public const ALLOC_INTEREST_FIRST = 'interest_first';
    public const ALLOC_PRINCIPAL_FIRST = 'principal_first';

    public const LATE_FEE_NONE = 'none';
    public const LATE_FEE_FIXED = 'fixed';
    public const LATE_FEE_PERCENT = 'percent';

    /**
     * Toplu yazmağa icazə verilən sahələr
     */
    protected $fillable = [
        'company_id',
        'amortization_method',
        'payment_frequency',
        'allocation_order',
        'grace_days',
        'late_fee_type',
        'late_fee_value',
        'rounding_step',
        'allow_partial_payments',
        'notes',
        'settings',
    ];

    /**
     * Tip çevirmələri
     */
    protected $casts = [
        'grace_days' => 'integer',
        'allow_partial_payments' => 'boolean',
        'settings' => 'array',

        'late_fee_value' => 'decimal:2',
        'rounding_step' => 'decimal:2',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    // =========================
    // Helpers
    // =========================

    /**
     * Bu config-də gecikmə cəriməsi aktivdirmi?
     */
    public function hasLateFee(): bool
    {
        return $this->late_fee_type !== self::LATE_FEE_NONE
            && (float) $this->late_fee_value > 0;
    }

    /**
     * Ödəniş tezliyi aylıqdır?
     */
    public function isMonthly(): bool
    {
        return $this->payment_frequency === self::FREQ_MONTHLY;
    }

    /**
     * Qismən ödənişə icazə varmı?
     */
    public function partialPaymentsAllowed(): bool
    {
        return (bool) $this->allow_partial_payments;
    }
}