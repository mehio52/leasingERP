<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;
class Payment extends Model
{
    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'payments';
    // =========================

    // =========================
    // Constants
    // =========================

    // method
    public const METHOD_CASH     = 'cash';
    public const METHOD_CARD     = 'card';
    public const METHOD_BANK     = 'bank';
    public const METHOD_TRANSFER = 'transfer';
    public const METHOD_OTHER    = 'other';

    // status
    public const STATUS_PENDING   = 'pending';
    public const STATUS_CONFIRMED = 'confirmed';
    public const STATUS_REJECTED  = 'rejected';
    public const STATUS_CANCELLED = 'cancelled';

    protected $fillable = [
        'company_id',
        'bhph_account_id',
        'received_by_user_id',

        'paid_date',
        'amount',
        'currency',

        'interest_amount',
        'principal_amount',
        'penalty_amount',

        'method',
        'status',

        'reference',
        'note',
    ];

    protected $casts = [
        'paid_date' => 'date',

        'amount' => 'decimal:2',
        'interest_amount' => 'decimal:2',
        'principal_amount' => 'decimal:2',
        'penalty_amount' => 'decimal:2',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    public function scopeForAccount(Builder $q, int $bhphAccountId): Builder
    {
        return $q->where('bhph_account_id', $bhphAccountId);
    }

    public function scopeStatus(Builder $q, string $status): Builder
    {
        return $q->where('status', $status);
    }

    public function scopeConfirmed(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_CONFIRMED);
    }

    public function scopePending(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_PENDING);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function bhphAccount()
    {
        return $this->belongsTo(BhphAccount::class);
    }

    public function receiver()
    {
        return $this->belongsTo(User::class, 'received_by_user_id');
    }

    // =========================
    // Helpers
    // =========================

    public function isConfirmed(): bool
    {
        return $this->status === self::STATUS_CONFIRMED;
    }

    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    protected static function booted(): void
    {
        static::saved(function (Payment $payment) {
            $isConfirmed = $payment->status === self::STATUS_CONFIRMED;
            $companyId = $payment->bhphAccount?->company_id ?? $payment->company_id;
            if ($isConfirmed && $companyId) {
                \App\Jobs\RunForecastJob::dispatch($companyId)->delay(now()->addMinutes(1));
            }
        });
    }

    /**
     * Ödənişin “parçalanması” düzgündür?
     * (interest + principal + penalty) <= amount olmalıdır
     */
    public function breakdownIsValid(): bool
    {
        $sum = (float)$this->interest_amount + (float)$this->principal_amount + (float)$this->penalty_amount;
        return $sum <= (float)$this->amount + 0.0001;
    }
}
