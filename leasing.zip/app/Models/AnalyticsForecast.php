<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AnalyticsForecast extends Model
{
    protected $fillable = [
        'company_id',
        'metric',
        'period',
        'forecast_date',
        'value',
        'meta',
    ];

    protected $casts = [
        'forecast_date' => 'date',
        'value' => 'float',
        'meta' => 'array',
    ];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
