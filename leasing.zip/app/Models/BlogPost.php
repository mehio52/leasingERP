<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class BlogPost extends Model
{
    protected $fillable = [
        'company_id',
        'title',
        'slug',
        'excerpt',
        'content',
        'status',
        'published_at',
    ];

    protected $casts = [
        'company_id' => 'integer',
        'published_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::saving(function (BlogPost $post) {
            if (blank($post->slug)) {
                $post->slug = Str::slug($post->title);
            }
            $post->slug = Str::slug($post->slug);

            // Ensure uniqueness per company
            $base = $post->slug ?: Str::slug($post->title);
            $slug = $base;
            $i = 2;
            while (static::query()
                    ->where('company_id', $post->company_id)
                    ->where('slug', $slug)
                    ->whereKeyNot($post->id ?? 0)
                    ->exists()) {
                $slug = $base.'-'.$i;
                $i++;
            }
            $post->slug = $slug;
        });
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
