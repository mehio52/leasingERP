<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToCompany;

class VehicleRental extends Model
{
    use BelongsToCompany;

    protected $fillable = [
        'company_id',
        'vehicle_id',
        'renter_name',
        'renter_phone',
        'renter_fin_code',
        'renter_id_card_number',
        'driver_license_number',
        'driver_license_category',
        'driver_license_image_path',
        'id_card_image_path',
        'renter_note',
        'addons',
        'addons_total',
        'start_at',
        'due_at',
        'rent_days',
        'actual_rent_days',
        'price_daily',
        'price_weekly',
        'price_monthly',
        'discount_type',
        'discount_value',
        'total_after_discount',
        'total_price',
        'actual_price_daily',
        'actual_price_weekly',
        'actual_price_monthly',
        'actual_total_price',
        'actual_total_after_discount',
        'status',
        'created_by',
        'closed_at',
        'grace_hours',
        'extra_days',
        'extra_day_rate',
        'extra_days_charge',
        'penalty_type',
        'penalty_value',
        'penalty_amount',
        'total_after_penalty',
    ];

    protected $casts = [
        'start_at' => 'datetime',
        'due_at' => 'datetime',
        'closed_at' => 'datetime',
        'rent_days' => 'integer',
        'actual_rent_days' => 'integer',
        'addons' => 'array',
        'price_daily' => 'decimal:2',
        'price_weekly' => 'decimal:2',
        'price_monthly' => 'decimal:2',
        'discount_value' => 'decimal:2',
        'total_after_discount' => 'decimal:2',
        'total_price' => 'decimal:2',
        'addons_total' => 'decimal:2',
        'actual_price_daily' => 'decimal:2',
        'actual_price_weekly' => 'decimal:2',
        'actual_price_monthly' => 'decimal:2',
        'actual_total_price' => 'decimal:2',
        'actual_total_after_discount' => 'decimal:2',
        'extra_day_rate' => 'decimal:2',
        'extra_days_charge' => 'decimal:2',
        'penalty_value' => 'decimal:2',
        'penalty_amount' => 'decimal:2',
        'total_after_penalty' => 'decimal:2',
    ];

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }
}
