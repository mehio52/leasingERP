<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class PaymentOption extends Model
{

    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'payment_options';
    // =========================

    // =========================
    // Constants (string typo riskini azaldır)
    // =========================

    // apply_to
    public const APPLY_OLDEST_DUE_FIRST = 'oldest_due_first';
    public const APPLY_CURRENT_DUE_ONLY = 'current_due_only';
    public const APPLY_NEWEST_FIRST     = 'newest_first';

    // allocation_order
    public const ALLOC_INTEREST_THEN_PRINCIPAL = 'interest_then_principal';
    public const ALLOC_PRINCIPAL_THEN_INTEREST = 'principal_then_interest';

    // overpayment_behavior
    public const OVERPAY_KEEP_AS_CREDIT        = 'keep_as_credit';
    public const OVERPAY_REDUCE_PRINCIPAL      = 'reduce_principal';
    public const OVERPAY_APPLY_NEXT_INSTALLMENTS = 'apply_next_installments';

    /**
     * Toplu yazmağa icazə verilən sahələr
     */
    protected $fillable = [
        'company_id',

        'allow_payment_gateway',

        'allow_overpayment',
        'allow_partial_payment',
        'allow_principal_only_payment',

        'payment_gateway_provider',

        'apply_to',
        'allocation_order',
        'overpayment_behavior',

        'allow_advance_payment',

        'min_partial_payment_amount',
        'min_overpayment_amount',

        'notes',
        'settings',
    ];

    /**
     * Tip çevirmələri
     */
    protected $casts = [
        'allow_payment_gateway' => 'boolean',

        'allow_overpayment' => 'boolean',
        'allow_partial_payment' => 'boolean',
        'allow_principal_only_payment' => 'boolean',

        'allow_advance_payment' => 'boolean',

        'min_partial_payment_amount' => 'decimal:2',
        'min_overpayment_amount' => 'decimal:2',

        'payment_gateway_provider' => 'string',

        'settings' => 'array',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    // =========================
    // Helpers
    // =========================

    public function gatewayAllowed(): bool
    {
        return (bool) $this->allow_payment_gateway;
    }

    public function partialPaymentAllowed(): bool
    {
        return (bool) $this->allow_partial_payment;
    }

    public function overpaymentAllowed(): bool
    {
        return (bool) $this->allow_overpayment;
    }

    public function principalOnlyAllowed(): bool
    {
        return (bool) $this->allow_principal_only_payment;
    }

    public function advancePaymentAllowed(): bool
    {
        return (bool) $this->allow_advance_payment;
    }

    public static function defaults(): array
    {
        return [
            'allow_payment_gateway' => 0,
            'payment_gateway_provider' => 'auto',

            'allow_overpayment' => 0,
            'allow_partial_payment' => 1,
            'allow_principal_only_payment' => 0,

            'apply_to' => self::APPLY_OLDEST_DUE_FIRST,
            'allocation_order' => self::ALLOC_INTEREST_THEN_PRINCIPAL,
            'overpayment_behavior' => self::OVERPAY_KEEP_AS_CREDIT,

            'allow_advance_payment' => 0,

            'min_partial_payment_amount' => null,
            'min_overpayment_amount' => null,

            'notes' => null,
            'settings' => null,
        ];
    }

}
