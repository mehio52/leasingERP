<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;

class GpsProvider extends Model
{
    protected $table = 'gps_providers';

    protected $fillable = [
        'name',
        'slug',
        'is_active',
        'settings',
        'created_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'settings' => 'array',
    ];

    protected static function booted(): void
    {
        static::saving(function (GpsProvider $provider) {
            if (blank($provider->slug)) {
                $provider->slug = Str::slug($provider->name ?? 'gps-provider');
            }
            $provider->slug = Str::slug($provider->slug);
        });
    }

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true);
    }

    public function connections()
    {
        return $this->hasMany(CompanyGpsConnection::class, 'gps_provider_id');
    }

    public function users()
    {
        return $this->hasMany(User::class, 'gps_provider_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
