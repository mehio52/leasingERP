<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class PlatformBlogImage extends Model
{
    protected $fillable = [
        'platform_blog_post_id',
        'path',
        'keyword',
        'alt_text',
    ];

    public function post()
    {
        return $this->belongsTo(PlatformBlogPost::class, 'platform_blog_post_id');
    }

    public function getUrlAttribute(): string
    {
        return Storage::disk('public')->url($this->path);
    }

    protected static function booted(): void
    {
        static::deleting(function (PlatformBlogImage $image) {
            if ($image->path) {
                Storage::disk('public')->delete($image->path);
            }
        });
    }
}
