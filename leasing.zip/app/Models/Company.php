<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
use App\Models\CompanyDomainRequest;

class Company extends Model
{
    /**
     * DB-yə toplu yazmağa icazə verilən sahələr.
     * Company::create($data) və $company->update($data) zamanı yalnız bunlar yazılır.
     */
    protected $fillable = [
        'name','legal_name','slug','domain',
        'email','phone','address',
        'voen','bank_account','bank_name',
        'is_active','suspended_at','suspend_reason',
        'plan_code','module','trial_ends_at','subscription_ends_at',
        'timezone','locale','currency',
        'logo_path','primary_color',
        'settings','limits',
        'public_theme','public_enabled','public_settings',
    ];

    /**
     * DB-dən gələn dəyərləri düzgün tiplərə çevirir:
     * - is_active -> true/false
     * - settings/limits -> JSON string yox, PHP array
     * - *_at -> tarix obyektinə (Carbon) çevrilir
     */
    protected $casts = [
        'is_active' => 'boolean',
        'settings' => 'array',
        'limits' => 'array',
        'suspended_at' => 'datetime',
        'trial_ends_at' => 'datetime',
        'subscription_ends_at' => 'datetime',
        'public_enabled' => 'boolean',
        'public_settings' => 'array',
    ];

    /**
     * Scope: aktiv (bloklanmamış) şirkətlər.
     * İstifadə: Company::active()->get()
     */
    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true)
                 ->whereNull('suspended_at');
    }

    /**
     * Scope: bloklanmış şirkətlər.
     * İstifadə: Company::suspended()->get()
     */
    public function scopeSuspended(Builder $q): Builder
    {
        return $q->whereNotNull('suspended_at');
    }

    /**
     * Model hər save olunanda slug-ı avtomatik düzəldir:
     * - slug boşdursa: name-dən unikal slug yaradır
     * - sonra slug-ı təmiz formata salır (Str::slug)
     */
    protected static function booted(): void
    {
        static::saving(function (Company $company) {
            if (blank($company->slug)) {
                $company->slug = static::uniqueSlug($company->name);
            }
            $company->slug = Str::slug($company->slug);
        });
    }

    /**
     * Unikal slug generator:
     * "abc-leasing" varsa -> "abc-leasing-2", "abc-leasing-3" və s.
     */
    public static function uniqueSlug(string $name): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $i = 2;

        while (static::where('slug', $slug)->exists()) {
            $slug = $base . '-' . $i;
            $i++;
        }

        return $slug;
    }

    /**
     * Trial aktivdir?
     */
    public function isTrialActive(): bool
    {
        return $this->trial_ends_at && now()->lt($this->trial_ends_at);
    }

    /**
     * Subscription aktivdir?
     */
    public function isSubscriptionActive(): bool
    {
        return $this->subscription_ends_at && now()->lt($this->subscription_ends_at);
    }

    public function moduleCode(): string
    {
        $module = strtolower(trim((string) ($this->module ?? 'leasing')));
        return in_array($module, ['leasing', 'rentacar', 'taxipark'], true) ? $module : 'leasing';
    }

    public function isLeasingModule(): bool
    {
        return $this->moduleCode() === 'leasing';
    }

    public function isRentacarModule(): bool
    {
        return $this->moduleCode() === 'rentacar';
    }

    public function isTaxiparkModule(): bool
    {
        return $this->moduleCode() === 'taxipark';
    }

    // ========== Relations ==========
    // Bu relation-lar işləsin deyə digər cədvəllərdə company_id olmalıdır.

    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function customers()
    {
        return $this->hasMany(Customer::class);
    }

    public function vehicles()
    {
        return $this->hasMany(Vehicle::class);
    }

    public function contracts()
    {
        return $this->hasMany(Contract::class);
    }

    public function subscriptions()
    {
        return $this->hasMany(Subscription::class);
    }

    public function currentSubscription()
    {
        return $this->hasOne(Subscription::class)->whereIn('status', ['trial','active','past_due'])->latestOfMany();
    }

    public function options()
    {
        return $this->hasOne(CompanyOption::class);
    }

    public function gpsConnection()
    {
        return $this->hasOne(CompanyGpsConnection::class);
    }

    public function domainRequests()
    {
        return $this->hasMany(CompanyDomainRequest::class);
    }
}
