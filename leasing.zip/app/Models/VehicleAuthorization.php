<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToCompany;

class VehicleAuthorization extends Model
{
    use BelongsToCompany;

    protected $fillable = [
        'company_id',
        'vehicle_id',
        'authorized_name',
        'start_date',
        'end_date',
        'note',
        'created_by',
        'last_notified_at',
        'last_notified_days',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'last_notified_at' => 'datetime',
        'last_notified_days' => 'integer',
    ];

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }
}
