<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class Addon extends Model
{
    protected $fillable = [
        'code','name','description',
        'price_monthly','price_yearly','currency',
        'module',
        'features',
        'is_active','sort_order',
    ];

    protected $casts = [
        'features' => 'array',
        'is_active' => 'boolean',
        'price_monthly' => 'decimal:2',
        'price_yearly' => 'decimal:2',
    ];

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true);
    }

    public function subscriptionAddons()
    {
        return $this->hasMany(SubscriptionAddon::class);
    }
}
