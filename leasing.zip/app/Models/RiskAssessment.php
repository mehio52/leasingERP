<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskAssessment extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'created_by',
        'monthly_income',
        'existing_monthly_debt',
        'requested_monthly_payment',
        'job_months',
        'factors',
        'adjustments',
        'score',
        'risk_band',
        'decision_status',
        'decision_comment',
        'decision_notes',
        'guarantor_required',
        'max_allowed_payment',
        'explain',
    ];

    protected $casts = [
        'monthly_income' => 'float',
        'existing_monthly_debt' => 'float',
        'requested_monthly_payment' => 'float',
        'job_months' => 'integer',
        'factors' => 'array',
        'adjustments' => 'array',
        'explain' => 'array',
        'decision_notes' => 'array',
        'score' => 'integer',
        'decision_status' => 'string',
        'guarantor_required' => 'boolean',
        'max_allowed_payment' => 'float',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
