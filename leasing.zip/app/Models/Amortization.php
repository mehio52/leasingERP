<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class Amortization extends Model
{
    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'amortization';
    // =========================
    
    // =========================
    // Status constants
    // =========================
    public const STATUS_PENDING = 'pending';
    public const STATUS_PARTIAL = 'partial';
    public const STATUS_PAID    = 'paid';
    public const STATUS_OVERDUE = 'overdue';

    /**
     * Toplu yazmağa icazə verilən sahələr
     */
    protected $fillable = [
        'company_id',
        'bhph_account_id',

        'installment_no',

        'due_date',
        'due_amount',
        'principal_amount',
        'interest_amount',

        'paid_amount',
        'paid_interest',
        'paid_principal',
        'paid_date',

        'remaining_balance',

        'status',
    ];

    /**
     * Tip çevirmələri
     */
    protected $casts = [
        'installment_no' => 'integer',

        'due_date'  => 'date',
        'paid_date' => 'date',

        'due_amount' => 'decimal:2',
        'principal_amount' => 'decimal:2',
        'interest_amount' => 'decimal:2',
        'paid_amount' => 'decimal:2',
        'paid_interest' => 'decimal:2',
        'paid_principal' => 'decimal:2',
        'remaining_balance' => 'decimal:2',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    public function scopeForAccount(Builder $q, int $bhphAccountId): Builder
    {
        return $q->where('bhph_account_id', $bhphAccountId);
    }

    public function scopeStatus(Builder $q, string $status): Builder
    {
        return $q->where('status', $status);
    }

    public function scopePending(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_PENDING);
    }

    public function scopePartial(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_PARTIAL);
    }

    public function scopePaid(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_PAID);
    }

    public function scopeOverdue(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_OVERDUE);
    }

    public function scopeDueBefore(Builder $q, $date): Builder
    {
        return $q->whereDate('due_date', '<', $date);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function bhphAccount()
    {
        return $this->belongsTo(BhphAccount::class);
    }

    // =========================
    // Helpers
    // =========================

    public function isPaid(): bool
    {
        return $this->status === self::STATUS_PAID;
    }

    public function isOverdue(): bool
    {
        return $this->status === self::STATUS_OVERDUE;
    }

    /**
     * Bu taksit üçün qalan məbləğ (due - paid)
     * Qeyd: decimal cast string verir, burada sadə hesab var.
     */
    public function remainingDueCalc(): string
    {
        $due  = (float) $this->due_amount;
        $paid = (float) $this->paid_amount;
        $rem  = max(0, $due - $paid);

        return number_format($rem, 2, '.', '');
    }
}
