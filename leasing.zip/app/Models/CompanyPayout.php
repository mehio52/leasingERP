<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToCompany;
use Illuminate\Database\Eloquent\Builder;

class CompanyPayout extends Model
{
    use BelongsToCompany;

    protected $table = 'company_payouts';

    public const STATUS_PENDING = 'pending';
    public const STATUS_PROCESSING = 'processing';
    public const STATUS_SUCCESS = 'success';
    public const STATUS_FAILED = 'failed';

    protected $fillable = [
        'company_id',
        'requested_by_user_id',
        'epoint_transaction_id',
        'amount',
        'currency',
        'status',
        'order_id',
        'epoint_transaction',
        'message',
        'response',
        'processed_at',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'response' => 'array',
        'processed_at' => 'datetime',
    ];

    public function scopeCompleted(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_SUCCESS);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function requester()
    {
        return $this->belongsTo(User::class, 'requested_by_user_id');
    }

    public function epointTransaction()
    {
        return $this->belongsTo(EpointTransaction::class);
    }
}
