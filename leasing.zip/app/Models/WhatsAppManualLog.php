<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppManualLog extends Model
{
    protected $fillable = [
        'company_id',
        'user_id',
        'customer_id',
        'phone',
        'title',
        'message',
        'status',
        'reason',
        'response',
        'sent_at',
    ];

    protected $casts = [
        'response' => 'array',
        'sent_at' => 'datetime',
    ];
}
