<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class Subscription extends Model
{
    use BelongsToCompany;

    public const STATUS_TRIAL = 'trial';
    public const STATUS_ACTIVE = 'active';
    public const STATUS_PAST_DUE = 'past_due';
    public const STATUS_CANCELLED = 'cancelled';
    public const STATUS_EXPIRED = 'expired';

    public const PERIOD_MONTHLY = 'monthly';
    public const PERIOD_YEARLY = 'yearly';

    protected $fillable = [
        'company_id','plan_id',
        'status','billing_period',
        'starts_at','trial_ends_at','ends_at','cancelled_at',
        'plan_code_snapshot','plan_name_snapshot',
        'price_snapshot','currency_snapshot',
        'limits_snapshot','features_snapshot',
        'meta',
    ];

    protected $casts = [
        'starts_at' => 'datetime',
        'trial_ends_at' => 'datetime',
        'ends_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'limits_snapshot' => 'array',
        'features_snapshot' => 'array',
        'meta' => 'array',
        'price_snapshot' => 'decimal:2',
    ];

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_ACTIVE);
    }

    public function scopeCurrent(Builder $q): Builder
    {
        return $q->whereIn('status', [self::STATUS_TRIAL, self::STATUS_ACTIVE, self::STATUS_PAST_DUE])
                 ->orderByDesc('id');
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class);
    }

    public function addons()
    {
        return $this->hasMany(SubscriptionAddon::class);
    }

    public function isWritable(): bool
    {
        if ($this->status === self::STATUS_ACTIVE) {
            return !$this->ends_at || now()->lt($this->ends_at);
        }

        if ($this->status === self::STATUS_TRIAL) {
            return $this->trial_ends_at && now()->lt($this->trial_ends_at);
        }

        return false;
    }
}