<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class PublicPage extends Model
{
    protected $fillable = [
        'company_id',
        'title',
        'slug',
        'content',
        'status',
        'published_at',
    ];

    protected $casts = [
        'company_id' => 'integer',
        'published_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::saving(function (PublicPage $page) {
            if (blank($page->slug)) {
                $page->slug = Str::slug($page->title);
            }
            $page->slug = Str::slug($page->slug);

            // ensure unique per company
            $base = $page->slug ?: Str::slug($page->title);
            $slug = $base;
            $i = 2;
            while (static::query()
                ->where('company_id', $page->company_id)
                ->where('slug', $slug)
                ->whereKeyNot($page->id ?? 0)
                ->exists()) {
                $slug = $base . '-' . $i;
                $i++;
            }
            $page->slug = $slug;
        });
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
