<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Models\Concerns\BelongsToCompany;
// use Laravel\Sanctum\HasApiTokens; // əgər səndə varsa, açıq saxla

class User extends Authenticatable
{
    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'users';
    // =========================

    // use HasApiTokens, HasFactory, Notifiable; // Sanctum varsa belə yaz
    use HasFactory, Notifiable;

    protected $fillable = [
        'company_id',
        'gps_provider_id',
        'first_name', 'last_name',
        'phone', 'email',
        'password',
        'is_owner', 'role',
        'permissions',
        'is_active', 'last_login_at',
        'created_by',
        'base_salary','salary_currency',
        'commission_type','commission_rate','payout_period',
        'salary_notes',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'permissions' => 'array',
        'is_owner' => 'boolean',
        'is_active' => 'boolean',
        'last_login_at' => 'datetime',
        'password' => 'hashed', // ən vacib: plain text yazsan belə hash edəcək
        'base_salary' => 'decimal:2',
        'commission_rate' => 'decimal:2',
    ];

    // Scopes
    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true);
    }

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    public function scopeOwners(Builder $q): Builder
    {
        return $q->where(function ($w) {
            $w->where('is_owner', true)
              ->orWhere('role', 'owner');
        });
    }

    // Relations
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function gpsProvider()
    {
        return $this->belongsTo(GpsProvider::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function createdUsers()
    {
        return $this->hasMany(User::class, 'created_by');
    }

    public function chatRooms()
    {
        return $this->belongsToMany(ChatRoom::class, 'chat_room_user');
    }

    public function chatMessages()
    {
        return $this->hasMany(ChatMessage::class);
    }

    // Helpers
    public function getFullNameAttribute(): string
    {
        return trim($this->first_name.' '.$this->last_name);
    }

    public function hasPermission(string $perm): bool
    {
        if ($this->isSuperAdmin() || $this->is_owner || $this->role === 'owner') {
            return true;
        }
        if ($this->role === 'gps_provider_admin') {
            return str_starts_with($perm, 'gps_provider.');
        }
        return in_array($perm, $this->permissions ?? [], true);
    }

    public function hasRole(string $role): bool
    {
        return $this->role === $role;
    }

    public function isSuperAdmin(): bool
    {
        return ($this->role === 'superadmin');
    }

    public function isGpsProviderUser(): bool
    {
        return !empty($this->gps_provider_id);
    }

    public function isGpsProviderAdmin(): bool
    {
        return $this->role === 'gps_provider_admin';
    }
}
