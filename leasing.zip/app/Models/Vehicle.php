<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class Vehicle extends Model
{
    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'vehicles';
    // =========================

    /**
     * Toplu yazmağa icazə verilən sahələr:
     * Vehicle::create($data) / $vehicle->update($data)
     */
    protected $fillable = [
        'company_id',
        'purchase_price', 'sale_price',
        'rent_daily_price', 'rent_weekly_price', 'rent_monthly_price',
        'rent_source', 'rent_due_at',
        'owner_type', 'owner_customer_id', 'owner_payment_type', 'owner_payment_amount',
        'plate_number', 'vin_code',
        'brand', 'model', 'sub_model', 'year', 'color',
        'images', 'traccar_device_id', 'wialon_device_id', 'wialon_unique_id',
        'geofence_enabled', 'geofence_lat', 'geofence_lng', 'geofence_radius_m',
        'geofence_state', 'geofence_last_exit_at', 'geofence_last_enter_at', 'geofence_last_reminder_at',
        'status',
        'specs','comforts',
        'public_title','public_description',
        'has_insurance', 'has_technical', 'is_returned',
    ];

    /**
     * DB-dən gələn tiplər:
     * - images JSON -> array
     * - boolean flag-lar -> true/false
     * - qiymətlər -> decimal (string kimi saxlayır, float bug-larını azaldır)
     */
    protected $casts = [
        'images' => 'array',
        'has_insurance' => 'boolean',
        'has_technical' => 'boolean',
        'is_returned' => 'boolean',
        'purchase_price' => 'decimal:2',
        'sale_price' => 'decimal:2',
        'rent_daily_price' => 'decimal:2',
        'rent_weekly_price' => 'decimal:2',
        'rent_monthly_price' => 'decimal:2',
        'rent_due_at' => 'datetime',
        'owner_customer_id' => 'integer',
        'owner_payment_amount' => 'decimal:2',
        'year' => 'integer',
        'color' => 'string',
        'specs' => 'array',
        'comforts' => 'array',
        'public_title' => 'string',
        'public_description' => 'string',
        'wialon_unique_id' => 'string',
        'geofence_enabled' => 'boolean',
        'geofence_lat' => 'decimal:7',
        'geofence_lng' => 'decimal:7',
        'geofence_radius_m' => 'integer',
        'geofence_last_exit_at' => 'datetime',
        'geofence_last_enter_at' => 'datetime',
        'geofence_last_reminder_at' => 'datetime',
    ];

    // =========================
    // Scopes (hazır filterlər)
    // =========================

    /**
     * Tenant filter:
     * Vehicle::forCompany($companyId)->get()
     */
    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    /**
     * Status filter:
     * Vehicle::status('available')->get()
     */
    public function scopeStatus(Builder $q, string $status): Builder
    {
        return $q->where('status', $status);
    }

    /**
     * Only available:
     * Vehicle::available()->get()
     */
    public function scopeAvailable(Builder $q): Builder
    {
        return $q->where('status', 'available');
    }

    public function scopeLeasing(Builder $q): Builder
    {
        return $q->where('status', 'leasing');
    }

    public function scopeSold(Builder $q): Builder
    {
        return $q->where('status', 'sold');
    }

    // =========================
    // Relations
    // =========================

    /**
     * Bu vehicle hansı şirkətə aiddir?
     * $vehicle->company
     */
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    // =========================
    // Helpers
    // =========================

    /**
     * Tam ad (brand + model + il):
     * $vehicle->display_name
     */
    public function getDisplayNameAttribute(): string
    {
        $base = trim($this->brand . ' ' . $this->model);
        $year = $this->year ? ' (' . $this->year . ')' : '';
        return $base . $year;
    }

    /**
     * Əgər şəkil yoxdursa boş array qaytarsın:
     */
    public function getImagesAttribute($value): array
    {
        // casts da var, amma null gələndə [] qaytarsın deyə əlavə rahatlıq
        return $value ? (is_array($value) ? $value : (json_decode($value, true) ?: [])) : [];
    }
}
