<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TaxiVehicleAssignment extends Model
{
    protected $fillable = [
        'company_id',
        'vehicle_id',
        'driver_id',
        'assigned_at',
        'returned_at',
        'issues',
        'addons',
        'attributes',
        'notes',
    ];

    protected $casts = [
        'assigned_at' => 'datetime',
        'returned_at' => 'datetime',
        'issues' => 'array',
        'addons' => 'array',
        'attributes' => 'array',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver()
    {
        return $this->belongsTo(TaxiDriver::class, 'driver_id');
    }
}
