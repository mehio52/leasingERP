<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TaxiVehicleIssue extends Model
{
    protected $fillable = [
        'company_id',
        'vehicle_id',
        'driver_id',
        'title',
        'details',
        'severity',
        'status',
        'reported_at',
        'meta',
    ];

    protected $casts = [
        'reported_at' => 'datetime',
        'meta' => 'array',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver()
    {
        return $this->belongsTo(TaxiDriver::class, 'driver_id');
    }
}
