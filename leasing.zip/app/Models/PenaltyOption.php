<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class PenaltyOption extends Model
{
    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'penalty_options';
    // =========================


    // =========================
    // Constants
    // =========================

    // penalty_type
    public const TYPE_NONE    = 'none';
    public const TYPE_FIXED   = 'fixed';
    public const TYPE_PERCENT = 'percent';

    // penalty_frequency
    public const FREQ_ONCE    = 'once';
    public const FREQ_DAILY   = 'daily';
    public const FREQ_MONTHLY = 'monthly';

    // apply_on
    public const APPLY_REMAINING_DUE    = 'remaining_due';
    public const APPLY_PRINCIPAL_ONLY   = 'principal_only';
    public const APPLY_TOTAL_INSTALLMENT = 'total_installment';

    // rounding_mode
    public const ROUND_NEAREST = 'nearest';
    public const ROUND_UP      = 'up';
    public const ROUND_DOWN    = 'down';

    /**
     * Toplu yazmağa icazə verilən sahələr
     */
    protected $fillable = [
        'company_id',

        'grace_days',
        'overdue_after_days',

        'penalty_type',
        'penalty_value',
        'penalty_frequency',
        'apply_on',

        'penalty_cap_amount',
        'penalty_cap_percent',

        'rounding_step',
        'rounding_mode',

        'notes',
        'settings',
    ];

    /**
     * Tip çevirmələri
     */
    protected $casts = [
        'grace_days' => 'integer',
        'overdue_after_days' => 'integer',

        'penalty_value' => 'decimal:2',
        'penalty_cap_amount' => 'decimal:2',
        'penalty_cap_percent' => 'decimal:2',

        'rounding_step' => 'decimal:2',

        'settings' => 'array',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    // =========================
    // Helpers
    // =========================

    public function isEnabled(): bool
    {
        return $this->penalty_type !== self::TYPE_NONE
            && (float) $this->penalty_value > 0;
    }

    public function isFixed(): bool
    {
        return $this->penalty_type === self::TYPE_FIXED;
    }

    public function isPercent(): bool
    {
        return $this->penalty_type === self::TYPE_PERCENT;
    }

    public function isDaily(): bool
    {
        return $this->penalty_frequency === self::FREQ_DAILY;
    }

    public static function defaults(): array
    {
        return [
            'grace_days' => 0,
            'overdue_after_days' => 0,

            'penalty_type' => self::TYPE_NONE,
            'penalty_value' => 0,

            'penalty_frequency' => self::FREQ_ONCE,
            'apply_on' => self::APPLY_REMAINING_DUE,

            'penalty_cap_amount' => null,
            'penalty_cap_percent' => null,

            'rounding_step' => 0.01,
            'rounding_mode' => self::ROUND_NEAREST,

            'notes' => null,
            'settings' => null,
        ];
    }
}
