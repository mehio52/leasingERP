<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;

class SystemSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'wa_api_url',
        'wa_api_key',
        'wa_api_secret',
        'saas_logo',
        'epoint_public_key',
        'epoint_private_key',
        'payment_gateway_provider',
        'stripe_public_key',
        'stripe_secret_key',
        'stripe_webhook_secret',
        'iyzico_api_key',
        'iyzico_secret_key',
        'iyzico_base_url',
        'mail_host',
        'mail_port',
        'mail_username',
        'mail_password',
        'mail_encryption',
        'mail_from_address',
        'mail_from_name',
    ];

    /**
     * Return the single settings row (creates if missing).
     */
    public static function singleton(): self
    {
        return static::query()->first() ?? static::create([]);
    }

    /**
     * Apply settings to runtime config (mail, services, app logo).
     */
    public static function applyToConfig(?self $settings = null): void
    {
        try {
            if (!Schema::hasTable('system_settings')) {
                return;
            }
        } catch (\Throwable $e) {
            return;
        }

        $settings = $settings ?? static::query()->first();
        if (!$settings) {
            return;
        }

        // Mail settings
        if ($settings->mail_host || $settings->mail_username || $settings->mail_password || $settings->mail_port) {
            config(['mail.default' => 'smtp']);
            config(['mail.mailers.smtp.host' => $settings->mail_host ?: config('mail.mailers.smtp.host')]);
            if ($settings->mail_port) {
                config(['mail.mailers.smtp.port' => (int)$settings->mail_port]);
            }
            if ($settings->mail_username !== null) {
                config(['mail.mailers.smtp.username' => $settings->mail_username]);
            }
            if ($settings->mail_password !== null) {
                config(['mail.mailers.smtp.password' => $settings->mail_password]);
            }
            if ($settings->mail_encryption !== null) {
                config(['mail.mailers.smtp.encryption' => $settings->mail_encryption]);
            }
        }
        if ($settings->mail_from_address) {
            config(['mail.from.address' => $settings->mail_from_address]);
        }
        if ($settings->mail_from_name) {
            config(['mail.from.name' => $settings->mail_from_name]);
        }

        // WhatsApp provider (global)
        config(['services.whatsapp' => [
            'api_url' => $settings->wa_api_url,
            'api_key' => $settings->wa_api_key,
            'api_secret' => $settings->wa_api_secret,
        ]]);

        // Epoint provider (global)
        config(['services.epoint' => [
            'public_key' => $settings->epoint_public_key,
            'private_key' => $settings->epoint_private_key,
            'base_url' => config('services.epoint.base_url', 'https://epoint.az/api/1'),
        ]]);

        // Stripe provider (global)
        config(['services.stripe' => [
            'public_key' => $settings->stripe_public_key,
            'secret' => $settings->stripe_secret_key,
            'webhook_secret' => $settings->stripe_webhook_secret,
        ]]);

        // Iyzico provider (global)
        config(['services.iyzico' => [
            'api_key' => $settings->iyzico_api_key,
            'secret_key' => $settings->iyzico_secret_key,
            'base_url' => $settings->iyzico_base_url
                ?: config('services.iyzico.base_url', 'https://api.iyzipay.com'),
        ]]);

        // Gateway preference (global)
        config(['services.payment_gateway' => [
            'provider' => $settings->payment_gateway_provider,
            'pending_ttl_minutes' => config('services.payment_gateway.pending_ttl_minutes', 120),
        ]]);

        // SaaS logo for layout (optional)
        if ($settings->saas_logo) {
            config(['app.saas_logo' => $settings->saas_logo]);
        }
    }
}
