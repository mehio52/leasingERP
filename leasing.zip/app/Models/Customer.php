<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class Customer extends Model
{
    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'customers';
    // =========================

    /**
     * Formdan/servisdən toplu yazmağa icazə verilən sahələr.
     * Customer::create($data) / $customer->update($data)
     */
    protected $fillable = [
        'company_id',
        'first_name', 'last_name', 'father_name',
        'phone', 'voen',
        'address',
        'id_card_number', 'fin_code',
        'id_card_issue_date',
        'id_card_authority',
        'bank_details',
        'driver_license_number', 'driver_license_category',
        'birth_date',
        'whatsapp_opt_in','whatsapp_opt_in_at',
    ];

    /**
     * Tip çevirmə: birth_date tarix kimi işləsin.
     */
    protected $casts = [
        'birth_date' => 'date',
        'id_card_issue_date' => 'date',
        'whatsapp_opt_in' => 'boolean',
        'whatsapp_opt_in_at' => 'datetime',
    ];

    // =========================
    // Scopes (hazır filterlər)
    // =========================

    /**
     * Müəyyən şirkətin müştəriləri:
     * Customer::forCompany($companyId)->get()
     */
    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    /**
     * Telefonla axtarış (partial):
     * Customer::forCompany($id)->phoneLike('050')->get()
     */
    public function scopePhoneLike(Builder $q, string $phone): Builder
    {
        return $q->where('phone', 'like', '%' . $phone . '%');
    }

    /**
     * FIN ilə axtarış:
     * Customer::forCompany($id)->fin($fin)->first()
     */
    public function scopeFin(Builder $q, string $fin): Builder
    {
        return $q->where('fin_code', $fin);
    }

    // =========================
    // Relations
    // =========================

    /**
     * Bu müştəri hansı şirkətə aiddir?
     * $customer->company
     */
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    // =========================
    // Helpers (rahatlıqlar)
    // =========================

    /**
     * Tam ad:
     * $customer->full_name
     */
    public function getFullNameAttribute(): string
    {
        // father_name varsa əlavə et
        $parts = [
            $this->first_name,
            $this->father_name ? $this->father_name : null,
            $this->last_name,
        ];

        return trim(implode(' ', array_filter($parts)));
    }
}
