<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToCompany;

class CompanyPayoutCard extends Model
{
    use BelongsToCompany;

    protected $table = 'company_payout_cards';

    protected $fillable = [
        'company_id',
        'card_id',
        'card_mask',
        'card_name',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
