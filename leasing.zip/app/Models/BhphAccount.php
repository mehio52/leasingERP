<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\AccountDocument;
use App\Models\Concerns\BelongsToCompany;
use Illuminate\Database\Eloquent\SoftDeletes;

class BhphAccount extends Model
{
    use BelongsToCompany;
    use SoftDeletes;
    
    // cədvəl adı plural deyil
    protected $table = 'bhph_accounts';
    // =========================

    // =========================
    // Status constants
    // =========================
    public const STATUS_ACTIVE = 'active';
    public const STATUS_OVERDUE = 'overdue';
    public const STATUS_LEGAL = 'legal';
    public const STATUS_INACTIVE = 'inactive';

    /**
     * Toplu yazmağa icazə verilən sahələr
     */
    protected $fillable = [
        'company_id',
        'customer_id',
        'vehicle_id',
        'contract_id',

        'loan_amount',
        'annual_interest_rate',
        'term_months',

        'down_payment',
        'insurance_fee',
        'commission_fee',
        'gps_fee',

        'payment_start_date',

        'paid_total_amount',
        'remaining_amount',
        'document_metadata',

        'paid_interest_amount',
        'total_interest_amount',

        'paid_principal_amount',
        'total_principal_amount',

        'credit_balance',

        'seller_user_id',
        'contract_type',
        'seller_name',
        'seller_phone',
        'seller_id_number',
        'third_party_seller_fullname',
        'status',
    ];

    /**
     * Tip çevirmələri:
     * - price field-lər decimal:2 (float bug-larının qarşısı)
     * - payment_start_date date
     * - term_months integer
     */
    protected $casts = [
        'loan_amount' => 'decimal:2',
        'annual_interest_rate' => 'decimal:2',
        'term_months' => 'integer',

        'down_payment' => 'decimal:2',
        'insurance_fee' => 'decimal:2',
        'commission_fee' => 'decimal:2',
        'gps_fee' => 'decimal:2',

        'payment_start_date' => 'date',

        'paid_total_amount' => 'decimal:2',
        'remaining_amount' => 'decimal:2',

        'paid_interest_amount' => 'decimal:2',
        'total_interest_amount' => 'decimal:2',

        'paid_principal_amount' => 'decimal:2',
        'total_principal_amount' => 'decimal:2',
        'credit_balance' => 'decimal:2',
        'document_metadata' => 'array',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    public function scopeStatus(Builder $q, string $status): Builder
    {
        return $q->where('status', $status);
    }

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_ACTIVE);
    }

    public function scopeOverdue(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_OVERDUE);
    }

    public function documents()
    {
        return $this->hasMany(AccountDocument::class, 'bhph_account_id');
    }

    public function scopeLegal(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_LEGAL);
    }

    public function scopeInactive(Builder $q): Builder
    {
        return $q->where('status', self::STATUS_INACTIVE);
    }

    // =========================
    // Relations
    // =========================

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    // bhph_accounts.contract_id -> contracts.id (nullable)
    public function contract()
    {
        return $this->belongsTo(Contract::class);
    }

    // bhph_accounts.seller_user_id -> users.id (nullable)
    public function seller()
    {
        return $this->belongsTo(User::class, 'seller_user_id');
    }

    // =========================
    // Helpers
    // =========================

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function isOverdue(): bool
    {
        return $this->status === self::STATUS_OVERDUE;
    }

    public function isLegal(): bool
    {
        return $this->status === self::STATUS_LEGAL;
    }

    public function isInactive(): bool
    {
        return $this->status === self::STATUS_INACTIVE;
    }

    /**
     * Qalıq məbləği avtomatik hesablanmış kimi qaytarmaq istəsən:
     * (opsional) remaining_amount saxlanır, amma bəzən “loan - paid_principal”
     * kimi canlı hesab da istəyirlər.
     */
    public function remainingPrincipalCalc(): string
    {
        // decimal cast string qaytarır; BCMath istəsən sonra edərik
        $total = (float) $this->total_principal_amount;
        $paid  = (float) $this->paid_principal_amount;
        $rem   = max(0, $total - $paid);

        return number_format($rem, 2, '.', '');
    }

    public function amortizations()
    {
        return $this->hasMany(\App\Models\Amortization::class, 'bhph_account_id');
    }
}
