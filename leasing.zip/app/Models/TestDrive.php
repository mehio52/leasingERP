<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TestDrive extends Model
{
    protected $fillable = [
        'company_id',
        'vehicle_id',
        'name',
        'phone',
        'email',
        'status',
        'scheduled_for',
        'note',
    ];

    protected $casts = [
        'company_id' => 'integer',
        'vehicle_id' => 'integer',
        'scheduled_for' => 'datetime',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }
}
