<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $fillable = [
        'company_id',
        'sender_id',
        'target_scope',
        'target_user_id',
        'target_role',
        'title',
        'body',
        'data',
        'read_at',
    ];

    protected $casts = [
        'company_id' => 'integer',
        'sender_id' => 'integer',
        'target_user_id' => 'integer',
        'data' => 'array',
        'read_at' => 'datetime',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function sender()
    {
        return $this->belongsTo(User::class, 'sender_id');
    }

    public function targetUser()
    {
        return $this->belongsTo(User::class, 'target_user_id');
    }
}
