<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class PlatformBlogPost extends Model
{
    protected $fillable = [
        'title',
        'slug',
        'excerpt',
        'content',
        'status',
        'published_at',
    ];

    protected $casts = [
        'published_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::saving(function (PlatformBlogPost $post) {
            if (blank($post->slug)) {
                $post->slug = Str::slug($post->title);
            }
            $post->slug = Str::slug($post->slug);

            $base = $post->slug ?: Str::slug($post->title);
            $slug = $base;
            $i = 2;
            while (static::query()
                    ->where('slug', $slug)
                    ->whereKeyNot($post->id ?? 0)
                    ->exists()) {
                $slug = $base.'-'.$i;
                $i++;
            }
            $post->slug = $slug;
        });
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published');
    }

    public function images()
    {
        return $this->hasMany(PlatformBlogImage::class, 'platform_blog_post_id');
    }

    public function getRenderedContentAttribute(): string
    {
        return $this->renderContent();
    }

    public function renderContent(): string
    {
        $content = (string) ($this->content ?? '');
        if ($content === '') {
            return '';
        }

        $this->loadMissing('images');

        $replacements = [];
        foreach ($this->images as $image) {
            $keyword = trim((string) $image->keyword);
            if ($keyword === '') {
                continue;
            }
            $placeholder = '{' . $keyword . '}';
            $alt = e($image->alt_text ?? '');
            $src = e($image->url);
            $replacements[$placeholder] = '<img src="' . $src . '" alt="' . $alt . '" loading="lazy">';
        }

        if (!$replacements) {
            return $content;
        }

        return str_replace(array_keys($replacements), array_values($replacements), $content);
    }
}
