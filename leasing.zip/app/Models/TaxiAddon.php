<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TaxiAddon extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'price',
        'billing_type',
        'quantity',
        'is_active',
        'sort_order',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
