<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Concerns\BelongsToCompany;

class CompanyOption extends Model
{

    use BelongsToCompany;

    // cədvəl adı plural deyil
    protected $table = 'company_options';
    // =========================
    
    /**
     * Toplu yazmağa icazə verilən sahələr
     */
    protected $fillable = [
        'company_id',

        // branding
        'display_name',
        'logo_path',
        'cover_image_path',

        // contact
        'contact_email',
        'contact_phone',
        'whatsapp_phone',
        'address',
        'city',
        'country',

        // map
        'latitude',
        'longitude',
        'map_url',

        // json
        'working_hours',
        'social_links',

        // seo
        'seo_title',
        'seo_description',
        'seo_keywords',
        'seo_og_image',
        'seo_canonical_url',
        'seo_indexable',

        // calculator ranges
        'calc_interest_min',
        'calc_interest_max',
        'calc_term_min_months',
        'calc_term_max_months',
        'calc_amount_min',
        'calc_amount_max',

        // localization
        'timezone',
        'locale',
        'currency',

        // extra
        'settings',
        'payment_gateways',
    ];

    /**
     * Tip çevirmələri (JSON, boolean, decimal)
     */
    protected $casts = [
        'working_hours' => 'array',
        'social_links' => 'array',
        'settings' => 'array',
        'payment_gateways' => 'array',

        'seo_indexable' => 'boolean',

        'latitude' => 'decimal:7',
        'longitude' => 'decimal:7',

        'calc_interest_min' => 'decimal:2',
        'calc_interest_max' => 'decimal:2',
        'calc_amount_min' => 'decimal:2',
        'calc_amount_max' => 'decimal:2',

        'calc_term_min_months' => 'integer',
        'calc_term_max_months' => 'integer',
    ];

    // =========================
    // Scopes
    // =========================

    public function scopeForCompany(Builder $q, int $companyId): Builder
    {
        return $q->where('company_id', $companyId);
    }

    public function scopeIndexable(Builder $q): Builder
    {
        return $q->where('seo_indexable', true);
    }

    // =========================
    // Relations
    // =========================

    /**
     * Bu options hansı şirkətə aiddir?
     * $options->company
     */
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    // =========================
    // Helpers
    // =========================

    /**
     * Vitrin adı boşdursa, company.name istifadə etmək rahatdır.
     * $options->public_name
     */
    public function getPublicNameAttribute(): string
    {
        return $this->display_name ?: ($this->company?->name ?? '');
    }

    /**
     * Return the gateway config saved for the provided provider.
     */
    public function paymentGatewayConfig(string $provider): array
    {
        $map = is_array($this->payment_gateways) ? $this->payment_gateways : [];
        $providerData = $map[$provider] ?? [];
        return is_array($providerData) ? $providerData : [];
    }
}
