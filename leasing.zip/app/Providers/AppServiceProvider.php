<?php

namespace App\Providers;

use App\Models\Company;
use App\Models\SystemSetting;
use App\Observers\CompanyObserver;
use App\Models\Vehicle;
use App\Observers\VehicleObserver;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Company::observe(CompanyObserver::class);
        Vehicle::observe(VehicleObserver::class);

        SystemSetting::applyToConfig();

        // Register theme view namespaces: theme-{code}::<view>
        $base = config('public_theme.base_path', resource_path('themes'));
        $dirs = glob($base.'/*', GLOB_ONLYDIR) ?: [];
        foreach ($dirs as $dir) {
            $code = basename($dir);
            $viewPath = $dir . DIRECTORY_SEPARATOR . 'views';
            if (is_dir($viewPath)) {
                View::addNamespace("theme-{$code}", $viewPath);
            }
        }
    }
}
