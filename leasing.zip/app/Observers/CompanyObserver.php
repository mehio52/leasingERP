<?php

namespace App\Observers;

use App\Models\Company;
use App\Models\CompanyOption;
use App\Models\LeasingOption;
use App\Models\PaymentOption;
use App\Models\PenaltyOption;
use App\Scopes\TenantScope;

class CompanyObserver
{
    public function created(Company $company): void
    {
        CompanyOption::query()
            ->withoutGlobalScope(TenantScope::class)
            ->firstOrCreate(
                ['company_id' => $company->id],
                [
                    'timezone' => $company->timezone ?? 'Asia/Baku',
                    'locale'   => $company->locale ?? 'az',
                    'currency' => $company->currency ?? 'AZN',
                ]
            );

        LeasingOption::query()
            ->withoutGlobalScope(TenantScope::class)
            ->firstOrCreate(['company_id' => $company->id]);

        PaymentOption::query()
            ->withoutGlobalScope(TenantScope::class)
            ->firstOrCreate(['company_id' => $company->id]);

        PenaltyOption::query()
            ->withoutGlobalScope(TenantScope::class)
            ->firstOrCreate(['company_id' => $company->id]);
    }
}