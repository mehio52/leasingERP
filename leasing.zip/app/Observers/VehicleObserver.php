<?php

namespace App\Observers;

use App\Models\Vehicle;
use App\Services\TraccarService;
use App\Services\Gps\GpsManager;

class VehicleObserver
{
    public function created(Vehicle $vehicle): void
    {
        $this->syncTraccar($vehicle);
    }

    public function updated(Vehicle $vehicle): void
    {
        if ($vehicle->wasChanged(['traccar_device_id','brand','model','plate_number'])) {
            $this->syncTraccar($vehicle);
        }
    }

    private function syncTraccar(Vehicle $vehicle): void
    {
        $company = $vehicle->company;
        $gpsManager = app(GpsManager::class);
        if ($gpsManager->providerForCompany($company) !== 'traccar') {
            return;
        }

        $traccar = $gpsManager->traccarForCompany($company);
        if (!$traccar->isConfigured()) {
            return;
        }

        $uniqueId = $vehicle->traccar_device_id ?: 'vehicle-' . $vehicle->id;
        $name = trim(($vehicle->brand ?? '') . ' ' . ($vehicle->model ?? '') . ' ' . ($vehicle->plate_number ?? ''));
        $name = $name !== '' ? $name : ('Vehicle #' . $vehicle->id);

        $device = $traccar->ensureDevice($uniqueId, $name);
        if ($device && empty($vehicle->traccar_device_id)) {
            $vehicle->traccar_device_id = $uniqueId;
            $vehicle->saveQuietly();
        }
    }
}
