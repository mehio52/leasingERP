<?php

namespace App\Services;

use App\Models\RiskFactorDefinition;
use Illuminate\Support\Collection;

class RiskEngine
{
    public function evaluate(int $companyId, array $base, array $factors = [], array $adjustments = [], ?Collection $definitions = null): array
    {
        $definitions = $definitions ?? RiskFactorDefinition::query()
            ->where('company_id', $companyId)
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->get();

        $score = 100;
        $breakdown = [];

        $income = max(0.0, (float)($base['monthly_income'] ?? 0));
        $existing = max(0.0, (float)($base['existing_monthly_debt'] ?? 0));
        $maxAllowed = max(0.0, ($income * 0.45) - $existing);

        $requested = max(0.0, (float)($base['requested_monthly_payment'] ?? 0));
        if ($requested <= 0) {
            $requested = $maxAllowed;
        }

        $jobMonths = (int)($base['job_months'] ?? 0);

        // Base: DTI
        $dti = $income > 0 ? ($existing + $requested) / $income : 1;
        $dtiPenalty = $this->dtiPenalty($dti);
        $score -= $dtiPenalty;
        $breakdown[] = [
            'key' => 'dti',
            'label' => 'DTI (borc/gəlir)',
            'value' => round($dti, 3),
            'points' => $dtiPenalty,
            'note' => null,
        ];

        // Base: iş stajı
        $jobPenalty = $this->jobPenalty($jobMonths);
        $score -= $jobPenalty;
        $breakdown[] = [
            'key' => 'job_months',
            'label' => 'İş stajı (ay)',
            'value' => $jobMonths,
            'points' => $jobPenalty,
            'note' => null,
        ];

        // Dynamic factors
        foreach ($definitions as $def) {
            $key = $def->key;
            $label = $def->label;
            if (!array_key_exists($key, $factors)) {
                continue;
            }
            $value = $factors[$key];
            $penalty = $this->factorPenalty($def, $value);
            $score -= $penalty;
            $breakdown[] = [
                'key' => $key,
                'label' => $label,
                'value' => $value,
                'points' => $penalty,
                'note' => null,
            ];
        }

        // Manual adjustments
        foreach ($adjustments as $adj) {
            $points = (float)($adj['points'] ?? 0);
            $score -= $points;
            $breakdown[] = [
                'key' => $adj['key'] ?? 'manual',
                'label' => $adj['key'] ?? 'Manual',
                'value' => null,
                'points' => $points,
                'note' => $adj['note'] ?? null,
            ];
        }

        $score = max(0, min(100, (int)round($score)));
        $riskBand = $this->band($score);

        $decision = $this->decision($score, $dti);

        return [
            'score' => $score,
            'risk_band' => $riskBand,
            'max_allowed_payment' => round($maxAllowed, 2),
            'suggested_payment' => round($requested, 2),
            'suggested_credit_amount' => round($maxAllowed * 12, 2),
            'explain' => $breakdown,
            'decision_status' => $decision['status'],
            'decision_comment' => $decision['comment'],
            'decision_notes' => $decision['notes'],
            'guarantor_required' => $decision['guarantor_required'],
        ];
    }

    protected function dtiPenalty(float $dti): float
    {
        if ($dti <= 0.35) return 0;
        if ($dti <= 0.45) return 10;
        if ($dti <= 0.55) return 22;
        if ($dti <= 0.65) return 35;
        return 50;
    }

    protected function jobPenalty(int $months): float
    {
        if ($months >= 24) return 0;
        if ($months >= 12) return 6;
        if ($months >= 6) return 12;
        return 18;
    }

    protected function factorPenalty(RiskFactorDefinition $def, $value): float
    {
        $config = $def->config ?? [];
        $type = $def->type ?? 'number';
        $method = $config['method'] ?? ($type === 'boolean' ? 'boolean' : 'bands');

        switch ($method) {
            case 'linear':
                return $this->linearPenalty($value, $config);
            case 'boolean':
                return $this->booleanPenalty($value, $config);
            case 'select_map':
            case 'select':
                return $this->selectPenalty($value, $config);
            case 'bands':
            default:
                return $this->bandsPenalty($value, $config['penalties'] ?? []);
        }
    }

    protected function bandsPenalty($value, array $penalties): float
    {
        foreach ($penalties as $row) {
            $points = (float)($row['points'] ?? 0);
            if (array_key_exists('lte', $row) && $value <= $row['lte']) return $points;
            if (array_key_exists('lt', $row) && $value < $row['lt']) return $points;
            if (array_key_exists('gte', $row) && $value >= $row['gte']) return $points;
            if (array_key_exists('gt', $row) && $value > $row['gt']) return $points;
            if (array_key_exists('eq', $row) && $value == $row['eq']) return $points;
        }
        return 0;
    }

    protected function linearPenalty($value, array $config): float
    {
        $unit = (float)($config['unit'] ?? 1);
        $ppu = (float)($config['points_per_unit'] ?? 0);
        $max = isset($config['max_points']) ? (float)$config['max_points'] : null;
        if ($unit <= 0 || $ppu == 0) {
            return 0;
        }
        $penalty = ($value / $unit) * $ppu;
        if ($max !== null) {
            $penalty = max(-abs($max), min(abs($max), $penalty));
        }
        return $penalty;
    }

    protected function booleanPenalty($value, array $config): float
    {
        $bool = filter_var($value, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
        $bool = $bool ?? (bool)$value;
        if ($bool) {
            return (float)($config['true_points'] ?? 0);
        }
        return (float)($config['false_points'] ?? 0);
    }

    protected function selectPenalty($value, array $config): float
    {
        $map = $config['map'] ?? $config;
        return (float)($map[$value] ?? 0);
    }

    protected function band(int $score): string
    {
        if ($score >= 80) return 'A';
        if ($score >= 65) return 'B';
        if ($score >= 50) return 'C';
        return 'D';
    }

    protected function decision(int $score, float $dti): array
    {
        $notes = [];
        $guarantor = false;

        if ($dti > 0.65) {
            $notes[] = 'DTI 65%-dən yüksəkdir.';
        } elseif ($dti > 0.55) {
            $notes[] = 'DTI 55%-dən yuxarıdır.';
        } elseif ($dti > 0.45) {
            $notes[] = 'DTI 45%-55% arasıdır.';
        } else {
            $notes[] = 'DTI < 45%';
        }

        if ($score >= 80) {
            $notes[] = 'Skor 80+ (A bandı).';
        } elseif ($score >= 65) {
            $notes[] = 'Skor 65-79 (B bandı).';
        } elseif ($score >= 50) {
            $notes[] = 'Skor 50-64 (C bandı).';
        } else {
            $notes[] = 'Skor 50-dən aşağı (D bandı).';
        }

        if ($score < 65 || $dti > 0.55) {
            $guarantor = true;
            $notes[] = 'Zamin tələb oluna bilər.';
        }

        if ($dti > 0.65 || $score < 50) {
            $status = 'decline';
            $comment = 'Rədd: DTI çox yüksək və ya skor 50-dən aşağıdır.';
        } elseif ($score >= 80) {
            $status = 'approve';
            $comment = 'Tövsiyə: Kredit uyğundur (A bandı).';
        } elseif ($score >= 65) {
            $status = 'conditional';
            $comment = 'Şərti təsdiq: əlavə təminat və ya daha aşağı limitlə davam edin (B bandı).';
        } else {
            $status = 'review';
            $comment = 'Əlavə manual yoxlama tələb olunur (C bandı).';
        }

        return [
            'status' => $status,
            'comment' => $comment,
            'notes' => $notes,
            'guarantor_required' => $guarantor,
        ];
    }
}
