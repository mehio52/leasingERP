<?php

namespace App\Services;

use Iyzipay\Model\Address;
use Iyzipay\Model\BasketItem;
use Iyzipay\Model\BasketItemType;
use Iyzipay\Model\Buyer;
use Iyzipay\Model\CheckoutForm;
use Iyzipay\Model\CheckoutFormInitialize;
use Iyzipay\Model\Currency;
use Iyzipay\Model\Locale;
use Iyzipay\Model\PaymentGroup;
use Iyzipay\Options;
use Iyzipay\Request\CreateCheckoutFormInitializeRequest;
use Iyzipay\Request\RetrieveCheckoutFormRequest;

class IyzicoService
{
    private array $overrides = [];

    public function withConfig(array $config): self
    {
        $instance = clone $this;
        $instance->overrides = $config;
        return $instance;
    }

    public function isConfigured(): bool
    {
        return (bool) $this->apiKey() && (bool) $this->secretKey();
    }

    public function apiKey(): ?string
    {
        return $this->override('api_key') ?? config('services.iyzico.api_key');
    }

    public function secretKey(): ?string
    {
        return $this->override('secret_key') ?? config('services.iyzico.secret_key');
    }

    public function baseUrl(): string
    {
        $url = $this->override('base_url') ?? config('services.iyzico.base_url', 'https://api.iyzipay.com');
        return rtrim((string) $url, '/');
    }

    public function createCheckoutForm(array $payload): array
    {
        if (!$this->isConfigured()) {
            return [
                'status' => 'error',
                'message' => 'Iyzico is not configured.',
            ];
        }

        if (!$this->sdkAvailable()) {
            return [
                'status' => 'error',
                'message' => 'Iyzico SDK is not installed. Run composer install.',
            ];
        }

        $amount = (float) ($payload['amount'] ?? 0);
        $orderId = (string) ($payload['order_id'] ?? '');
        $currency = (string) ($payload['currency'] ?? 'TRY');
        $callbackUrl = (string) ($payload['callback_url'] ?? '');

        if ($amount <= 0 || $orderId === '' || $callbackUrl === '') {
            return [
                'status' => 'error',
                'message' => 'Invalid Iyzico checkout payload.',
            ];
        }

        $options = new Options();
        $options->setApiKey((string) $this->apiKey());
        $options->setSecretKey((string) $this->secretKey());
        $options->setBaseUrl($this->baseUrl());

        $request = new CreateCheckoutFormInitializeRequest();
        $request->setLocale($this->normalizeLocale($payload['locale'] ?? null));
        $request->setConversationId($orderId);
        $request->setPrice($this->formatAmount($amount));
        $request->setPaidPrice($this->formatAmount($amount));
        $request->setCurrency($this->normalizeCurrency($currency));
        $request->setBasketId($orderId);
        $request->setPaymentGroup(PaymentGroup::PRODUCT);
        $request->setCallbackUrl($callbackUrl);

        $buyer = $payload['buyer'] ?? [];
        $buyerModel = new Buyer();
        $buyerModel->setId((string) ($buyer['id'] ?? $orderId));
        $buyerModel->setName((string) ($buyer['name'] ?? 'Customer'));
        $buyerModel->setSurname((string) ($buyer['surname'] ?? 'Payment'));
        $buyerModel->setGsmNumber((string) ($buyer['gsm'] ?? ''));
        $buyerModel->setEmail((string) ($buyer['email'] ?? ''));
        $buyerModel->setIdentityNumber($this->normalizeIdentity($buyer['identity_number'] ?? $buyer['identity'] ?? ''));
        $buyerModel->setRegistrationAddress((string) ($buyer['address'] ?? ''));
        $buyerModel->setIp((string) ($buyer['ip'] ?? ''));
        $buyerModel->setCity((string) ($buyer['city'] ?? ''));
        $buyerModel->setCountry((string) ($buyer['country'] ?? ''));
        $buyerModel->setZipCode((string) ($buyer['zip'] ?? ''));
        $request->setBuyer($buyerModel);

        $billing = $payload['billing_address'] ?? $buyer;
        $billingModel = new Address();
        $billingModel->setContactName($this->addressContactName($buyer));
        $billingModel->setCity((string) ($billing['city'] ?? $buyer['city'] ?? ''));
        $billingModel->setCountry((string) ($billing['country'] ?? $buyer['country'] ?? ''));
        $billingModel->setAddress((string) ($billing['address'] ?? $buyer['address'] ?? ''));
        $billingModel->setZipCode((string) ($billing['zip'] ?? $buyer['zip'] ?? ''));
        $request->setBillingAddress($billingModel);

        $shipping = $payload['shipping_address'] ?? $buyer;
        $shippingModel = new Address();
        $shippingModel->setContactName($this->addressContactName($buyer));
        $shippingModel->setCity((string) ($shipping['city'] ?? $buyer['city'] ?? ''));
        $shippingModel->setCountry((string) ($shipping['country'] ?? $buyer['country'] ?? ''));
        $shippingModel->setAddress((string) ($shipping['address'] ?? $buyer['address'] ?? ''));
        $shippingModel->setZipCode((string) ($shipping['zip'] ?? $buyer['zip'] ?? ''));
        $request->setShippingAddress($shippingModel);

        $item = new BasketItem();
        $item->setId((string) ($payload['item_id'] ?? $orderId));
        $item->setName((string) ($payload['item_name'] ?? 'Payment'));
        $item->setCategory1((string) ($payload['item_category'] ?? 'Payment'));
        $item->setCategory2((string) ($payload['item_category2'] ?? 'Service'));
        $item->setItemType(BasketItemType::VIRTUAL);
        $item->setPrice($this->formatAmount($amount));
        $request->setBasketItems([$item]);

        $response = CheckoutFormInitialize::create($request, $options);
        $status = strtolower((string) $response->getStatus());

        if ($status !== 'success') {
            return [
                'status' => 'error',
                'message' => (string) ($response->getErrorMessage() ?: 'Iyzico request failed.'),
                'code' => $response->getErrorCode(),
                'raw' => $response->getRawResult(),
            ];
        }

        return [
            'status' => 'success',
            'token' => $response->getToken(),
            'content' => $response->getCheckoutFormContent(),
            'raw' => $response->getRawResult(),
        ];
    }

    public function retrieveCheckoutForm(string $token, ?string $locale = null, ?string $conversationId = null): array
    {
        if (!$this->isConfigured() || !$this->sdkAvailable()) {
            return [
                'status' => 'error',
                'message' => 'Iyzico is not configured.',
            ];
        }

        $options = new Options();
        $options->setApiKey((string) $this->apiKey());
        $options->setSecretKey((string) $this->secretKey());
        $options->setBaseUrl($this->baseUrl());

        $request = new RetrieveCheckoutFormRequest();
        $request->setLocale($this->normalizeLocale($locale));
        if ($conversationId) {
            $request->setConversationId($conversationId);
        }
        $request->setToken($token);

        $response = CheckoutForm::retrieve($request, $options);
        $raw = $response->getRawResult();
        $payload = json_decode((string) $raw, true);

        if (!is_array($payload)) {
            $payload = [
                'status' => $response->getStatus(),
                'payment_status' => $response->getPaymentStatus(),
                'conversation_id' => $response->getConversationId(),
                'payment_id' => $response->getPaymentId(),
                'token' => $response->getToken(),
                'errorCode' => $response->getErrorCode(),
                'errorMessage' => $response->getErrorMessage(),
            ];
        }

        return $payload;
    }

    private function sdkAvailable(): bool
    {
        return class_exists(Options::class);
    }

    private function normalizeLocale(?string $locale): string
    {
        $loc = strtolower(trim((string) $locale));
        return $loc === 'tr' ? Locale::TR : Locale::EN;
    }

    private function normalizeCurrency(string $currency): string
    {
        $cur = strtoupper(trim($currency));
        return match ($cur) {
            'USD' => Currency::USD,
            'EUR' => Currency::EUR,
            'GBP' => Currency::GBP,
            default => Currency::TL,
        };
    }

    private function formatAmount(float $amount): string
    {
        return number_format($amount, 2, '.', '');
    }

    private function normalizeIdentity(string $identity): string
    {
        $value = preg_replace('/\s+/', '', $identity);
        return $value !== '' ? $value : '00000000000';
    }

    private function addressContactName(array $buyer): string
    {
        $name = trim((string) ($buyer['name'] ?? ''));
        $surname = trim((string) ($buyer['surname'] ?? ''));
        return trim($name . ' ' . $surname);
    }

    private function override(string $key): ?string
    {
        if (!array_key_exists($key, $this->overrides)) {
            return null;
        }

        $value = $this->overrides[$key];
        if ($value === null || $value === '') {
            return null;
        }

        return (string) $value;
    }
}
