<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class EpointService
{
    private array $overrides = [];

    public function withConfig(array $config): self
    {
        $instance = clone $this;
        $instance->overrides = $config;
        return $instance;
    }

    public function isConfigured(): bool
    {
        return (bool) $this->publicKey() && (bool) $this->privateKey();
    }

    public function publicKey(): ?string
    {
        return $this->override('public_key') ?? config('services.epoint.public_key');
    }

    public function privateKey(): ?string
    {
        return $this->override('private_key') ?? config('services.epoint.private_key');
    }

    public function baseUrl(): string
    {
        $url = $this->override('base_url') ?? config('services.epoint.base_url', 'https://epoint.az/api/1');
        return rtrim((string) $url, '/');
    }

    public function normalizeLanguage(?string $lang): string
    {
        $lang = strtolower((string) $lang);
        return in_array($lang, ['az', 'en', 'ru'], true) ? $lang : 'en';
    }

    public function requestPayment(array $payload): array
    {
        return $this->post('request', $payload);
    }

    public function cardRegistration(array $payload): array
    {
        return $this->post('card-registration', $payload);
    }

    public function payoutRequest(array $payload): array
    {
        return $this->post('refund-request', $payload);
    }

    public function decodeData(string $data): array
    {
        $decoded = base64_decode($data, true);
        if ($decoded === false) {
            return [];
        }
        $json = json_decode($decoded, true);
        return is_array($json) ? $json : [];
    }

    public function signature(string $data): string
    {
        $privateKey = (string) $this->privateKey();
        $raw = $privateKey . $data . $privateKey;
        return base64_encode(sha1($raw, true));
    }

    public function verifySignature(string $data, string $signature): bool
    {
        return hash_equals($this->signature($data), $signature);
    }

    private function post(string $endpoint, array $payload): array
    {
        $data = base64_encode(json_encode($payload, JSON_UNESCAPED_UNICODE));
        $signature = $this->signature($data);

        $resp = Http::asForm()->post($this->baseUrl() . '/' . ltrim($endpoint, '/'), [
            'data' => $data,
            'signature' => $signature,
        ]);

        if (!$resp->ok()) {
            return [
                'status' => 'error',
                'message' => 'HTTP ' . $resp->status(),
                'body' => $resp->body(),
            ];
        }

        $json = $resp->json();
        return is_array($json) ? $json : [
            'status' => 'error',
            'message' => 'Invalid JSON response',
            'body' => $resp->body(),
        ];
    }

    private function override(string $key): ?string
    {
        if (!array_key_exists($key, $this->overrides)) {
            return null;
        }

        $value = $this->overrides[$key];
        if ($value === null || $value === '') {
            return null;
        }

        return (string) $value;
    }
}
