<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class StripeService
{
    private array $overrides = [];

    public function withConfig(array $config): self
    {
        $instance = clone $this;
        $instance->overrides = $config;
        return $instance;
    }

    public function isConfigured(): bool
    {
        return (bool) $this->secretKey();
    }

    public function publicKey(): ?string
    {
        return $this->override('public_key') ?? config('services.stripe.public_key');
    }

    public function secretKey(): ?string
    {
        return $this->override('secret') ?? config('services.stripe.secret');
    }

    public function webhookSecret(): ?string
    {
        return $this->override('webhook_secret') ?? config('services.stripe.webhook_secret');
    }

    public function baseUrl(): string
    {
        return 'https://api.stripe.com/v1';
    }

    public function createCheckoutSession(array $payload): array
    {
        if (!$this->secretKey()) {
            return [
                'status' => 'error',
                'message' => 'Stripe is not configured.',
            ];
        }

        $amount = (float) ($payload['amount'] ?? 0);
        $currency = strtolower((string) ($payload['currency'] ?? 'azn'));
        $orderId = (string) ($payload['order_id'] ?? '');
        $description = (string) ($payload['description'] ?? 'Payment');
        $successUrl = (string) ($payload['success_url'] ?? '');
        $cancelUrl = (string) ($payload['cancel_url'] ?? '');

        if ($amount <= 0 || $orderId === '' || $successUrl === '' || $cancelUrl === '') {
            return [
                'status' => 'error',
                'message' => 'Invalid Stripe checkout payload.',
            ];
        }

        $unitAmount = $this->amountToMinorUnits($amount, $currency);

        $resp = Http::asForm()
            ->withToken($this->secretKey())
            ->post($this->baseUrl() . '/checkout/sessions', [
                'mode' => 'payment',
                'success_url' => $this->ensureSessionParam($successUrl),
                'cancel_url' => $cancelUrl,
                'client_reference_id' => $orderId,
                'payment_method_types[0]' => 'card',
                'line_items[0][quantity]' => 1,
                'line_items[0][price_data][currency]' => $currency,
                'line_items[0][price_data][unit_amount]' => $unitAmount,
                'line_items[0][price_data][product_data][name]' => $description,
                'metadata[order_id]' => $orderId,
            ]);

        if (!$resp->ok()) {
            return [
                'status' => 'error',
                'message' => $this->extractErrorMessage($resp->json(), $resp->status()),
                'body' => $resp->body(),
            ];
        }

        $json = $resp->json();
        if (!is_array($json) || empty($json['url'])) {
            return [
                'status' => 'error',
                'message' => 'Invalid Stripe response.',
                'body' => $resp->body(),
            ];
        }

        return [
            'status' => 'success',
            'id' => $json['id'] ?? null,
            'url' => $json['url'],
            'payload' => $json,
        ];
    }

    public function verifySignature(string $payload, string $sigHeader): bool
    {
        $secret = $this->webhookSecret();
        if (!$secret || $sigHeader === '') {
            return false;
        }

        $parts = [];
        foreach (explode(',', $sigHeader) as $chunk) {
            $pair = explode('=', trim($chunk), 2);
            if (count($pair) === 2) {
                $parts[$pair[0]][] = $pair[1];
            }
        }

        $timestamp = $parts['t'][0] ?? null;
        $signatures = $parts['v1'] ?? [];
        if (!$timestamp || empty($signatures)) {
            return false;
        }

        $signedPayload = $timestamp . '.' . $payload;
        $expected = hash_hmac('sha256', $signedPayload, $secret);

        foreach ($signatures as $sig) {
            if (hash_equals($expected, $sig)) {
                if (abs(time() - (int) $timestamp) > 300) {
                    return false;
                }
                return true;
            }
        }

        return false;
    }

    private function amountToMinorUnits(float $amount, string $currency): int
    {
        return (int) round($amount * 100);
    }

    private function ensureSessionParam(string $url): string
    {
        if ($url === '' || str_contains($url, '{CHECKOUT_SESSION_ID}')) {
            return $url;
        }

        $sep = str_contains($url, '?') ? '&' : '?';
        return $url . $sep . 'session_id={CHECKOUT_SESSION_ID}';
    }

    private function extractErrorMessage($json, int $status): string
    {
        if (is_array($json) && isset($json['error']['message'])) {
            return (string) $json['error']['message'];
        }

        return 'HTTP ' . $status;
    }

    private function override(string $key): ?string
    {
        if (!array_key_exists($key, $this->overrides)) {
            return null;
        }

        $value = $this->overrides[$key];
        if ($value === null || $value === '') {
            return null;
        }

        return (string) $value;
    }
}
