<?php

namespace App\Services\Gps;

use App\Models\Company;
use App\Models\CompanyOption;
use App\Models\CompanyGpsConnection;
use App\Models\GpsProvider;
use App\Services\TraccarService;
use App\Services\WialonService;

class GpsManager
{
    public function providerForCompany(?Company $company): ?string
    {
        $providerSettings = $this->providerSettingsForCompany($company);
        $platform = $providerSettings['active_platform'] ?? null;
        $allowed = $providerSettings['platforms'] ?? [];

        if ($platform && in_array($platform, ['traccar', 'wialon'], true)) {
            if (empty($allowed) || in_array($platform, $allowed, true)) {
                return $platform;
            }
        }

        // Legacy fallback (old company options)
        $legacy = $this->legacyProviderForCompany($company);
        return $legacy;
    }

    public function traccarForCompany(Company $company): TraccarService
    {
        $providerSettings = $this->providerSettingsForCompany($company);
        $traccar = is_array($providerSettings['traccar'] ?? null) ? $providerSettings['traccar'] : [];
        $config = [
            'base_url' => $traccar['base_url'] ?? config('services.traccar.base_url'),
            'token' => $traccar['token'] ?? config('services.traccar.token'),
            'username' => $traccar['username'] ?? config('services.traccar.username'),
            'password' => $traccar['password'] ?? config('services.traccar.password'),
        ];
        return app(TraccarService::class)->withConfig($config);
    }

    public function wialonForCompany(Company $company): WialonService
    {
        $providerSettings = $this->providerSettingsForCompany($company);
        $wialon = is_array($providerSettings['wialon'] ?? null) ? $providerSettings['wialon'] : [];
        $config = [
            'base_url' => $wialon['base_url'] ?? config('services.wialon.base_url'),
            'token' => $wialon['token'] ?? config('services.wialon.token'),
            'username' => $wialon['username'] ?? null,
            'password' => $wialon['password'] ?? null,
        ];
        return app(WialonService::class)->withConfig($config, 'company-' . $company->id);
    }

    public function wialonForProvider(GpsProvider $provider): WialonService
    {
        $settings = is_array($provider->settings) ? $provider->settings : [];
        $wialon = is_array($settings['wialon'] ?? null) ? $settings['wialon'] : [];
        $config = [
            'base_url' => $wialon['base_url'] ?? config('services.wialon.base_url'),
            'token' => $wialon['token'] ?? config('services.wialon.token'),
            'username' => $wialon['username'] ?? null,
            'password' => $wialon['password'] ?? null,
        ];
        return app(WialonService::class)->withConfig($config, 'provider-' . $provider->id);
    }

    public function wialonUnitsForCompany(Company $company): array
    {
        $connection = $this->approvedConnectionForCompany($company);
        if (!$connection || !$connection->provider) return [];

        $providerSettings = is_array($connection->provider->settings) ? $connection->provider->settings : [];
        $mode = $providerSettings['gps_data_mode'] ?? 'by_user';
        $activePlatform = $providerSettings['active_platform'] ?? 'traccar';
        if ($activePlatform !== 'wialon') return [];
        $connectionSettings = is_array($connection->settings) ? $connection->settings : [];

        $wialon = $this->wialonForCompany($company);
        if (!$wialon->isConfigured()) return [];

        if ($mode === 'by_unit_group') {
            $groupIds = $this->normalizeIdList($connectionSettings['wialon_unit_group_ids'] ?? []);
            if (empty($groupIds)) return [];

            $groups = $wialon->searchUnitGroups(1);
            $unitIds = [];
            foreach ($groups as $group) {
                $gid = (int) ($group['id'] ?? 0);
                if (!in_array($gid, $groupIds, true)) continue;

                $members = $group['u'] ?? $group['units'] ?? $group['unit_ids'] ?? [];
                if (is_string($members)) {
                    $members = preg_split('/\s*,\s*/', $members, -1, PREG_SPLIT_NO_EMPTY);
                }
                if (!is_array($members)) continue;

                foreach ($members as $memberId) {
                    $memberId = (int) $memberId;
                    if ($memberId > 0) $unitIds[$memberId] = true;
                }
            }

            if (empty($unitIds)) return [];

            $units = $wialon->searchUnits(1);
            return array_values(array_filter($units, function ($unit) use ($unitIds) {
                $id = (int) ($unit['id'] ?? 0);
                return $id > 0 && isset($unitIds[$id]);
            }));
        }

        if ($mode === 'by_account') {
            $account = trim((string) ($connectionSettings['wialon_account_id'] ?? ''));
            if ($account === '') return [];
            return $wialon->searchItemsByProperty('avl_unit', 'sys_account', $account, 1);
        }

        $user = trim((string) ($connectionSettings['wialon_user'] ?? ''));
        if ($user === '') return [];
        return $wialon->searchItemsByProperty('avl_unit', 'sys_user', $user, 1);
    }

    public function approvedConnectionForCompany(Company $company): ?CompanyGpsConnection
    {
        return CompanyGpsConnection::query()
            ->with('provider')
            ->where('company_id', $company->id)
            ->where('status', 'approved')
            ->first();
    }

    public function wialonUnitIdsForCompany(Company $company): array
    {
        $units = $this->wialonUnitsForCompany($company);
        $ids = [];
        foreach ($units as $unit) {
            $id = (int) ($unit['id'] ?? 0);
            if ($id > 0) $ids[$id] = true;
        }
        return array_keys($ids);
    }

    public function settingsForCompany(?Company $company): array
    {
        if (!$company) return [];

        $connection = CompanyGpsConnection::query()
            ->with('provider')
            ->where('company_id', $company->id)
            ->first();

        $providerSettings = $this->providerSettingsForCompany($company);

        return [
            'gps_provider_id' => $connection?->gps_provider_id,
            'gps_provider_status' => $connection?->status,
            'gps_provider_name' => $connection?->provider?->name,
            'gps_platform' => $this->providerForCompany($company),
            'traccar_base_url' => $providerSettings['traccar']['base_url'] ?? config('services.traccar.base_url'),
            'wialon_base_url' => $providerSettings['wialon']['base_url'] ?? config('services.wialon.base_url'),
            'api_poll_interval' => $providerSettings['limits']['api_poll_interval'] ?? null,
        ];
    }

    public function providerSettings(Company $company): array
    {
        return $this->providerSettingsForCompany($company);
    }

    public function blockedCommandsForCompany(Company $company): array
    {
        $settings = $this->providerSettingsForCompany($company);
        $list = $settings['commands_blocklist'] ?? ($settings['commands_whitelist'] ?? []);
        if (!is_array($list)) return [];
        return array_values(array_unique(array_filter(array_map('strtolower', $list))));
    }

    public function policyForCompany(Company $company): array
    {
        $settings = $this->providerSettingsForCompany($company);
        $policy = $settings['policy'] ?? [];
        return is_array($policy) ? $policy : [];
    }

    public function featuresForCompany(Company $company): array
    {
        $settings = $this->providerSettingsForCompany($company);
        $features = $settings['features'] ?? [];
        return is_array($features) ? $features : [];
    }

    public function featureEnabled(Company $company, string $feature): bool
    {
        return in_array($feature, $this->featuresForCompany($company), true);
    }

    private function providerSettingsForCompany(?Company $company): array
    {
        if (!$company) return [];

        $connection = CompanyGpsConnection::query()
            ->with('provider')
            ->where('company_id', $company->id)
            ->where('status', 'approved')
            ->first();

        $settings = is_array($connection?->provider?->settings) ? $connection->provider->settings : [];
        return $settings;
    }

    private function normalizeIdList(array|string $value): array
    {
        if (is_string($value)) {
            $value = preg_split('/\s*,\s*/', $value, -1, PREG_SPLIT_NO_EMPTY);
        }

        if (!is_array($value)) return [];

        $ids = [];
        foreach ($value as $item) {
            $id = (int) $item;
            if ($id > 0) $ids[$id] = true;
        }
        return array_keys($ids);
    }

    private function legacyProviderForCompany(?Company $company): ?string
    {
        if (!$company) return null;
        $opt = CompanyOption::query()->where('company_id', $company->id)->first();
        $settings = is_array($opt?->settings) ? $opt->settings : [];
        $provider = $settings['gps_provider'] ?? null;
        if ($provider === 'wialon') {
            $wialonEnabled = (bool) config('services.wialon.enabled', true);
            return $wialonEnabled ? 'wialon' : 'traccar';
        }
        return $provider ? 'traccar' : null;
    }
}
