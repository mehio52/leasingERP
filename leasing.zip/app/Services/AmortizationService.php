<?php

namespace App\Services;

use App\Models\Amortization;
use App\Models\BhphAccount;
use App\Models\LeasingOption;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\Payment;
use Illuminate\Validation\ValidationException;

class AmortizationService
{
    public function financedPrincipal(BhphAccount $account): float
    {
        $baseLoan = (float) $account->loan_amount;
        $down     = (float) ($account->down_payment ?? 0);
        $fees     = (float) ($account->insurance_fee ?? 0)
                  + (float) ($account->commission_fee ?? 0)
                  + (float) ($account->gps_fee ?? 0);

        return max(0.0, $baseLoan - $down + $fees);
    }

    public function estimateInstallments(int $termMonths, string $freq): int
    {
        return $this->periodCount($termMonths, $freq);
    }

    public function generateForAccount(BhphAccount $account, LeasingOption $opt): void
    {
        DB::transaction(function () use ($account, $opt) {

            // köhnə cədvəli sil
            $account->amortizations()->delete();

            $method = (string) $opt->amortization_method;
            $freq   = (string) $opt->payment_frequency;
            $alloc  = (string) ($opt->allocation_order ?? LeasingOption::ALLOC_INTEREST_FIRST);

            $step = (float) ($opt->rounding_step ?? 0.01);
            if ($step <= 0) $step = 0.01;

            $termMonths = (int) $account->term_months;

            $principal  = $this->financedPrincipal($account);
            $annualRate = ((float) $account->annual_interest_rate) / 100.0;

            $n = $this->periodCount($termMonths, $freq);
            $r = $this->periodRate($annualRate, $freq);

            $grace = (int) ($opt->grace_days ?? 0);
            $firstDue = Carbon::parse($account->payment_start_date)->startOfDay();
            if ($grace > 0) $firstDue->addDays($grace);

            $remaining = $principal;

            $annuityPayment = null;
            if ($method === LeasingOption::AMORT_ANNUITY) {
                $annuityPayment = ($r <= 0)
                    ? ($principal / $n)
                    : ($principal * ($r / (1 - pow(1 + $r, -$n))));
            }

            $sumInterest  = 0.0;
            $sumPrincipal = 0.0;
            $sumDue       = 0.0;

            for ($i = 1; $i <= $n; $i++) {
                $dueDate = $this->addPeriod($firstDue->copy(), $freq, $i - 1);

                // --- RAW ---
                $interestRaw  = 0.0;
                $principalRaw = 0.0;

                if ($method === LeasingOption::AMORT_FLAT) {
                    // termMonths sabit müddətdir, freq sadəcə bölünmə sayını dəyişir
                    $totalInterestFlat = $principal * $annualRate * ($termMonths / 12.0);
                    $interestRaw  = $totalInterestFlat / $n;
                    $principalRaw = $principal / $n;
                } elseif ($method === LeasingOption::AMORT_REDUCING_BALANCE) {
                    $principalRaw = $principal / $n;
                    $interestRaw  = $remaining * $r;
                } else { // ANNUITY
                    $interestRaw  = $remaining * $r;
                    $principalRaw = ((float) $annuityPayment) - $interestRaw;
                }

                // son taksit: qalan principal bağlansın
                if ($i === $n) {
                    $principalRaw = $remaining;
                }

                // --- allocation_order + rounding (kritik hissə) ---
                $paymentRaw = $interestRaw + $principalRaw;
                $payment    = $this->roundStep($paymentRaw, $step);

                if ($alloc === LeasingOption::ALLOC_PRINCIPAL_FIRST) {
                    $prin = $this->roundStep($principalRaw, $step);
                    $interest = $payment - $prin;
                } else {
                    $interest = $this->roundStep($interestRaw, $step);
                    $prin = $payment - $interest;
                }

                // safety
                if ($interest < 0) { $interest = 0.0; $prin = $payment; }
                if ($prin < 0)     { $prin = 0.0;     $interest = $payment; }

                // son taksit üçün yenidən bağla
                if ($i === $n) {
                    $prin = $this->roundStep($remaining, $step);
                    $payment = $this->roundStep($interest + $prin, $step);

                    if ($alloc === LeasingOption::ALLOC_PRINCIPAL_FIRST) {
                        $interest = $payment - $prin;
                        if ($interest < 0) { $interest = 0.0; $payment = $prin; }
                    } else {
                        $prin = $payment - $interest;
                        if ($prin < 0) { $prin = 0.0; $payment = $interest; }
                    }
                }

                $dueAmount = $payment;

                // remaining
                $remaining = max(0.0, $remaining - $prin);
                $remBal = $this->roundStep($remaining, $step);

                Amortization::create([
                    'company_id'        => $account->company_id,
                    'bhph_account_id'   => $account->id,
                    'installment_no'    => $i,
                    'due_date'          => $dueDate->toDateString(),
                    'due_amount'        => $dueAmount,

                    // schedule breakdown
                    'interest_amount'   => $interest,
                    'principal_amount'  => $prin,

                    // real ödənişlər (başlanğıcda 0)
                    'paid_interest'     => 0,
                    'paid_principal'    => 0,

                    // real ödənən
                    'paid_amount'       => 0,
                    'paid_date'         => null,

                    'remaining_balance' => $remBal,
                    'status'            => Amortization::STATUS_PENDING,
                ]);

                $sumInterest  += $interest;
                $sumPrincipal += $prin;
                $sumDue       += $dueAmount;
            }

            // account totals
            $account->total_interest_amount  = $this->roundStep($sumInterest, $step);
            $account->total_principal_amount = $this->roundStep($sumPrincipal, $step);

            // remaining_amount = total due (sonra ödəniş çıxılacaq)
            $account->remaining_amount = $this->roundStep($sumDue, $step);

            $account->paid_total_amount     = 0;
            $account->paid_interest_amount  = 0;
            $account->paid_principal_amount = 0;

            $account->save();
        });
    }

    public function syncAccountPaymentsFromAmortization(BhphAccount $account, ?LeasingOption $opt): void
    {
        $rows = $account->amortizations()->get();

        $paidTotal = (float) $rows->sum('paid_amount');
        $alloc = (string)($opt?->allocation_order ?? LeasingOption::ALLOC_INTEREST_FIRST);

        $paidInterest  = 0.0;
        $paidPrincipal = 0.0;

        foreach ($rows as $r) {
            $pay = (float) $r->paid_amount;

            $schedInt  = (float) ($r->interest_amount ?? $r->paid_interest ?? 0);   // schedule faiz (ödənməli)
            $schedPrin = (float) ($r->principal_amount ?? $r->paid_principal ?? 0); // schedule əsas (ödənməli)

            // paid_interest/principal sahələri real ödənişlər üçün istifadə olunur (yoxdursa hesabla)
            $pi = (float) $r->paid_interest;
            $pp = (float) $r->paid_principal;

            if ($pi <= 0.0001 && $pp <= 0.0001 && $pay > 0) {
                if ($alloc === LeasingOption::ALLOC_PRINCIPAL_FIRST) {
                    $pp = min($pay, $schedPrin);
                    $pi = min(max(0.0, $pay - $pp), $schedInt);
                } else {
                    $pi = min($pay, $schedInt);
                    $pp = min(max(0.0, $pay - $pi), $schedPrin);
                }
            } else {
                $pi = min($pi, $schedInt);
                $pp = min($pp, $schedPrin);
            }

            // Ödənilmiş hissə ümumi ödənişi aşmasın
            $allocated = $pi + $pp;
            if ($allocated > $pay + 0.0001) {
                $overflow = $allocated - $pay;
                if ($pp >= $overflow) {
                    $pp -= $overflow;
                } else {
                    $pi = max(0.0, $pi - ($overflow - $pp));
                    $pp = 0.0;
                }
            }

            $paidInterest  += $pi;
            $paidPrincipal += $pp;
        }

        $totalDue  = (float) $rows->sum('due_amount');
        $remaining = max(0.0, $totalDue - $paidTotal);

        $account->paid_total_amount     = $paidTotal;
        $account->paid_interest_amount  = $paidInterest;
        $account->paid_principal_amount = $paidPrincipal;
        $account->remaining_amount      = $remaining;

        $account->save();
    }

    private function periodCount(int $termMonths, string $freq): int
    {
        if ($termMonths <= 0) return 1;

        // term_months = ay müddəti → həftəlik/2həftəlik period sayına çevir
        if ($freq === LeasingOption::FREQ_WEEKLY) {
            return max(1, (int) round($termMonths * (52 / 12)));
        }
        if ($freq === LeasingOption::FREQ_BIWEEKLY) {
            return max(1, (int) round($termMonths * (26 / 12)));
        }
        return max(1, $termMonths);
    }

    private function periodRate(float $annualRate, string $freq): float
    {
        if ($annualRate <= 0) return 0.0;
        if ($freq === LeasingOption::FREQ_WEEKLY)   return $annualRate / 52.0;
        if ($freq === LeasingOption::FREQ_BIWEEKLY) return $annualRate / 26.0;
        return $annualRate / 12.0;
    }

    private function addPeriod(Carbon $base, string $freq, int $add): Carbon
    {
        if ($add <= 0) return $base;
        if ($freq === LeasingOption::FREQ_WEEKLY)   return $base->addWeeks($add);
        if ($freq === LeasingOption::FREQ_BIWEEKLY) return $base->addWeeks($add * 2);
        return $base->addMonthsNoOverflow($add);
    }

    private function roundStep(float $value, float $step): float
    {
        return round($value / $step) * $step;
    }

    public function syncAccountTotalsFromPayments(BhphAccount $account): void
    {
        $sum = Payment::query()
            ->where('company_id', $account->company_id)
            ->where('bhph_account_id', $account->id)
            ->where('status', Payment::STATUS_CONFIRMED)
            ->selectRaw('
                COALESCE(SUM(amount),0) as t,
                COALESCE(SUM(interest_amount),0) as i,
                COALESCE(SUM(principal_amount),0) as p
            ')
            ->first();

        $paidTotal    = (float)($sum->t ?? 0);
        $paidInterest = (float)($sum->i ?? 0);
        $paidPrincipal= (float)($sum->p ?? 0);
        $paidOnSchedule = $paidInterest + $paidPrincipal;

        // schedule total
        $totalDue = (float) $account->amortizations()->sum('due_amount');

        $account->paid_total_amount     = $paidTotal;
        $account->paid_interest_amount  = $paidInterest;
        $account->paid_principal_amount = $paidPrincipal;

        $account->remaining_amount = max(0.0, $totalDue - $paidOnSchedule);

        $account->save();
    }

    public function rebuildRemainingScheduleAfterPrincipalReduction(
        BhphAccount $account,
        LeasingOption $opt,
        int $fromInstallmentNo,
        float $newOutstandingPrincipal
    ): void
    {
        DB::transaction(function () use ($account, $opt, $fromInstallmentNo, $newOutstandingPrincipal) {

            $rows = $account->amortizations()
                ->where('installment_no', '>=', $fromInstallmentNo)
                ->orderBy('installment_no')
                ->get();

            if ($rows->isEmpty()) {
                return;
            }

            // Qarışıq vəziyyət olmasın (hissə/hardasa ödəniş yazılıbsa schedule-i yenidən qurmaq risklidir)
            $hasPaid = $rows->first(function ($r) {
                return (float)$r->paid_amount > 0;
            });

            if ($hasPaid) {
                throw ValidationException::withMessages([
                    'overpay_action' => 'Bu hissədə artıq ödəniş var. Əsas borcu azaltmaq üçün növbəti tam ödənilməmiş taksitdən et.'
                ]);
            }

            $method = (string) $opt->amortization_method;
            $freq   = (string) $opt->payment_frequency;
            $alloc  = (string) ($opt->allocation_order ?? LeasingOption::ALLOC_INTEREST_FIRST);

            $step = (float) ($opt->rounding_step ?? 0.01);
            if ($step <= 0) $step = 0.01;

            $annualRate = ((float) $account->annual_interest_rate) / 100.0;

            $n = $rows->count();
            if ($n <= 0) return;

            $r = $this->periodRate($annualRate, $freq);

            $principal0 = max(0.0, (float)$newOutstandingPrincipal);
            $remaining  = $principal0;

            // Flat üçün qalan ayı təxmini hesabla
            $termMonthsRemain = match ($freq) {
                LeasingOption::FREQ_WEEKLY   => max(1, (int) round($n * (12 / 52))),
                LeasingOption::FREQ_BIWEEKLY => max(1, (int) round($n * (12 / 26))),
                default                      => $n, // aylıqda n = ay
            };

            $annuityPayment = null;
            if ($method === LeasingOption::AMORT_ANNUITY) {
                $annuityPayment = ($r <= 0)
                    ? ($principal0 / $n)
                    : ($principal0 * ($r / (1 - pow(1 + $r, -$n))));
            }

            foreach ($rows as $idx => $row) {
                $i = $idx + 1;

                $interestRaw  = 0.0;
                $principalRaw = 0.0;

                if ($method === LeasingOption::AMORT_FLAT) {
                    $totalInterestFlat = $principal0 * $annualRate * ($termMonthsRemain / 12.0);
                    $interestRaw  = $totalInterestFlat / $n;
                    $principalRaw = $principal0 / $n;
                } elseif ($method === LeasingOption::AMORT_REDUCING_BALANCE) {
                    $principalRaw = $principal0 / $n;
                    $interestRaw  = $remaining * $r;
                } else { // ANNUITY
                    $interestRaw  = $remaining * $r;
                    $principalRaw = ((float)$annuityPayment) - $interestRaw;
                }

                // Son taksit: qalan principal bağlansın
                if ($i === $n) {
                    $principalRaw = $remaining;
                }

                $paymentRaw = $interestRaw + $principalRaw;
                $payment    = $this->roundStep($paymentRaw, $step);

                if ($alloc === LeasingOption::ALLOC_PRINCIPAL_FIRST) {
                    $prin     = $this->roundStep($principalRaw, $step);
                    $interest = $payment - $prin;
                } else {
                    $interest = $this->roundStep($interestRaw, $step);
                    $prin     = $payment - $interest;
                }

                // safety
                if ($interest < 0) { $interest = 0.0; $prin = $payment; }
                if ($prin < 0)     { $prin = 0.0;     $interest = $payment; }

                if ($i === $n) {
                    $prin    = $this->roundStep($remaining, $step);
                    $payment = $this->roundStep($interest + $prin, $step);

                    if ($alloc === LeasingOption::ALLOC_PRINCIPAL_FIRST) {
                        $interest = $payment - $prin;
                        if ($interest < 0) { $interest = 0.0; $payment = $prin; }
                    } else {
                        $prin = $payment - $interest;
                        if ($prin < 0) { $prin = 0.0; $payment = $interest; }
                    }
                }

                $remaining = max(0.0, $remaining - $prin);
                $remBal    = $this->roundStep($remaining, $step);

                // Bu hissədə ödəniş yoxdur dedik, ona görə paid_amount=0 saxlanır
                $row->due_amount        = $payment;
                $row->interest_amount   = $interest;  // schedule faiz
                $row->principal_amount  = $prin;      // schedule əsas
                $row->remaining_balance = $remBal;

                $row->paid_amount    = 0;
                $row->paid_interest  = 0;
                $row->paid_principal = 0;
                $row->paid_date      = null;
                $row->status         = Amortization::STATUS_PENDING;

                $row->save();
            }

            // Account totals schedule-dən yenilə
            $sumInterest  = (float) $account->amortizations()->sum('interest_amount');
            $sumPrincipal = (float) $account->amortizations()->sum('principal_amount');
            $sumDue       = (float) $account->amortizations()->sum('due_amount');
            $sumPaid      = (float) $account->amortizations()->sum('paid_amount');

            $account->total_interest_amount  = $this->roundStep($sumInterest, $step);
            $account->total_principal_amount = $this->roundStep($sumPrincipal, $step);
            $account->remaining_amount       = $this->roundStep(max(0.0, $sumDue - $sumPaid), $step);

            $account->save();
        });
    }


}
