<?php

namespace App\Services;

use App\Models\AccountDocument;
use App\Models\BhphAccount;
use App\Models\DocumentTemplate;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpWord\TemplateProcessor;
use Illuminate\Support\Str;

class DocumentAutomationService
{
    public function gatherValues(BhphAccount $account): array
    {
        $customer = $account->customer;
        $vehicle = $account->vehicle;
        $company = $account->company;
        $contract = $account->contract;
        $metadata = $account->document_metadata ?? [];
        $loanAmount = (float) ($account->loan_amount ?? 0);
        $specs = is_array($vehicle?->specs) ? $vehicle->specs : (json_decode($vehicle?->specs ?? '[]', true) ?: []);

        $priceInteger = number_format($loanAmount, 2, '.', '');
        $priceText = $priceInteger . ' AZN';

        $values = [
            'customer_name' => $customer?->full_name ?? '',
            'customer_address' => $customer?->address ?? $metadata['customer_address'] ?? '',
            'customer_id_card_number' => $customer?->id_card_number ?? '',
            'customer_fin' => $customer?->fin_code ?? '',
            'customer_date_of_issue_of_identity_card' => optional($customer?->id_card_issue_date)->toDateString() ?? '',
            'customer_name_of_the_authority_issuing_the_identity_card' => $customer?->id_card_authority ?? '',
            'customer_bank_details' => $customer?->bank_details ?? $metadata['customer_bank_details'] ?? '',
            'company_name' => $company?->name ?? '',
            'company_address' => $company?->address ?? '',
            'seller_fullname' => $contract?->seller_name ?? $account->seller_name ?? '',
            'seller_id_card_number' => $contract?->seller_id_number ?? '',
            'seller_fin' => $contract?->seller_fin ?? '',
            'seller_date_of_issue_of_identity_card' => optional($contract?->seller_id_issue_date)->toDateString() ?? '',
            'seller_name_of_the_authority_issuing_the_identity_card' => $contract?->seller_id_authority ?? '',
            'company_bank_details' => $company ? trim(implode(' / ', array_filter([$company->bank_name, $company->bank_account]))) : '',
            'contract_date' => optional($contract?->signed_date)->toDateString() ?? '',
            'contract_id' => $contract?->contract_no ?? (string) ($contract?->id ?? ''),
            'vehicle_price_integer' => $priceInteger,
            'vehicle_price_text' => $priceText,
            'vehicle_fullname' => $vehicle ? trim($vehicle->brand . ' ' . $vehicle->model) : '',
            'vehicle_year_of_release' => (string) ($vehicle?->year ?? ''),
            'vehicle_specifications' => $this->formatSpecifications($specs),
            'vehicle_type' => $vehicle?->sub_model ?? ($vehicle?->status ?? ''),
            'vehicle_color' => $vehicle?->color ?? '',
            '3rd_party_seller_fullname' => $account->third_party_seller_fullname ?? $metadata['third_party_seller_fullname'] ?? '',
        ];

        return array_map(fn($value) => is_string($value) ? trim($value) : $value, $values);
    }

    public function render(DocumentTemplate $template, BhphAccount $account): string
    {
        $path = storage_path('app/' . $template->file_path);
        if (!file_exists($path)) {
            return '';
        }

        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if ($extension !== 'docx') {
            return file_get_contents($path);
        }

        try {
            $processor = new TemplateProcessor($path);
        } catch (\Throwable $e) {
            return '';
        }

        $values = $this->gatherValues($account);
        foreach ($values as $key => $value) {
            $processor->setValue($key, (string) $value);
        }

        $tmp = tempnam(sys_get_temp_dir(), 'docx');
        $processor->saveAs($tmp);
        $content = file_get_contents($tmp);
        @unlink($tmp);

        return $content ?: '';
    }

    public function exportForAccount(BhphAccount $account, DocumentTemplate $template): ?AccountDocument
    {
        $content = $this->render($template, $account);
        if ($content === '') {
            return null;
        }

        $extension = pathinfo($template->file_path, PATHINFO_EXTENSION) ?: 'txt';
        $filename = Str::slug($template->name ?: 'document', '-') . '-' . $account->id . '-' . now()->format('YmdHis') . '.' . $extension;
        $path = "document_exports/{$account->company_id}/{$account->id}/{$filename}";
        Storage::put($path, $content);

        return AccountDocument::create([
            'company_id' => $account->company_id,
            'bhph_account_id' => $account->id,
            'document_template_id' => $template->id,
            'file_path' => $path,
            'file_name' => $filename,
        ]);
    }

    public function missingKeywords(DocumentTemplate $template, BhphAccount $account): array
    {
        $keywords = $template->keywords ?? [];
        $values = $this->gatherValues($account);
        return array_values(array_filter($keywords, fn($key) => trim((string) ($values[$key] ?? '')) === ''));
    }

    public function keywordList(): array
    {
        static $list;
        if ($list === null) {
            $list = array_keys($this->gatherValues(new BhphAccount()));
        }
        return $list;
    }

    private function formatSpecifications(array $specs): string
    {
        if (empty($specs)) {
            return '';
        }
        return collect($specs)->map(fn($value, $key) => "{$key}: {$value}")->implode('; ');
    }
}
