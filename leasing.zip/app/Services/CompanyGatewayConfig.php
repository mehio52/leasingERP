<?php

namespace App\Services;

use App\Models\Company;
use App\Models\CompanyOption;

class CompanyGatewayConfig
{
    private array $cache = [];

    public function providerConfig(string $provider, ?Company $company = null): array
    {
        $provider = strtolower(trim($provider));
        $base = config("services.{$provider}", []) ?: [];
        $overrides = $this->companyOverrides($company)[$provider] ?? [];
        if (!is_array($overrides)) {
            $overrides = [];
        }
        $overrides = array_filter($overrides, fn($value) => $value !== null && $value !== '');
        return array_merge($base, $overrides);
    }

    public function hasConfig(string $provider, ?Company $company = null): bool
    {
        $provider = strtolower(trim($provider));
        $config = $this->providerConfig($provider, $company);

        return match ($provider) {
            'epoint' => !empty($config['public_key']) && !empty($config['private_key']),
            'stripe' => !empty($config['secret']),
            'iyzico' => !empty($config['api_key']) && !empty($config['secret_key']),
            default => false,
        };
    }

    private function companyOverrides(?Company $company): array
    {
        if (!$company) {
            return [];
        }

        if (isset($this->cache[$company->id])) {
            return $this->cache[$company->id];
        }

        $options = $company->options ?? CompanyOption::query()->where('company_id', $company->id)->first();
        $values = is_array($options?->payment_gateways) ? $options->payment_gateways : [];
        $this->cache[$company->id] = $values;

        return $values;
    }
}
