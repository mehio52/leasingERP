<?php

namespace App\Services;

use App\Models\Company;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\SubscriptionAddon;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class SubscriptionService
{
    public function assignTrial(Company $company, string $planCode = 'trial'): Subscription
    {
        $plan = Plan::where('code', $planCode)->firstOrFail();

        return $this->startSubscription($company, $plan, [
            'status' => Subscription::STATUS_TRIAL,
            'billing_period' => Subscription::PERIOD_MONTHLY,
            'trial_days' => $plan->trial_days,
        ]);
    }

    public function startSubscription(Company $company, Plan $plan, array $options = []): Subscription
    {
        $status = $options['status'] ?? Subscription::STATUS_ACTIVE;
        $billingPeriod = $options['billing_period'] ?? Subscription::PERIOD_MONTHLY;
        $startsAt = isset($options['starts_at']) ? Carbon::parse($options['starts_at']) : now();
        $trialEndsAt = $options['trial_ends_at'] ?? null;
        $endsAt = $options['ends_at'] ?? null;
        $meta = $options['meta'] ?? [];
        $trialDays = $options['trial_days'] ?? $plan->trial_days;

        $allowedStatuses = [
            Subscription::STATUS_TRIAL,
            Subscription::STATUS_ACTIVE,
            Subscription::STATUS_PAST_DUE,
            Subscription::STATUS_CANCELLED,
            Subscription::STATUS_EXPIRED,
        ];
        if (!in_array($status, $allowedStatuses, true)) {
            $status = Subscription::STATUS_ACTIVE;
        }

        $allowedPeriods = [Subscription::PERIOD_MONTHLY, Subscription::PERIOD_YEARLY];
        if (!in_array($billingPeriod, $allowedPeriods, true)) {
            $billingPeriod = Subscription::PERIOD_MONTHLY;
        }

        if ($trialEndsAt) {
            $trialEndsAt = Carbon::parse($trialEndsAt);
        } elseif ($status === Subscription::STATUS_TRIAL) {
            $trialEndsAt = $startsAt->copy()->addDays((int) $trialDays);
        }

        if ($endsAt) {
            $endsAt = Carbon::parse($endsAt);
        }

        $priceSnapshot = $billingPeriod === Subscription::PERIOD_YEARLY
            ? $plan->price_yearly
            : $plan->price_monthly;

        return DB::transaction(function () use ($company, $plan, $status, $billingPeriod, $startsAt, $trialEndsAt, $endsAt, $meta, $priceSnapshot) {

            Subscription::withoutTenant()
                ->where('company_id', $company->id)
                ->whereIn('status', [Subscription::STATUS_TRIAL, Subscription::STATUS_ACTIVE, Subscription::STATUS_PAST_DUE])
                ->update(['status' => Subscription::STATUS_EXPIRED]);

            $sub = Subscription::withoutTenant()->create([
                'company_id' => $company->id,
                'plan_id' => $plan->id,
                'status' => $status,
                'billing_period' => $billingPeriod,
                'starts_at' => $startsAt,
                'trial_ends_at' => $trialEndsAt,
                'ends_at' => $endsAt,

                // snapshot
                'plan_code_snapshot' => $plan->code,
                'plan_name_snapshot' => $plan->name,
                'price_snapshot' => $priceSnapshot ?? 0,
                'currency_snapshot' => $plan->currency,
                'limits_snapshot' => $plan->limits ?? [],
                'features_snapshot' => $plan->features ?? [],

                'meta' => $meta,
            ]);

            $settings = $company->settings ?? [];
            $settings['features'] = $plan->features ?? [];
            $settings['onboarding'] = $settings['onboarding'] ?? ['completed' => false];

            $company->update([
                'plan_code' => $plan->code,
                'trial_ends_at' => $trialEndsAt,
                'subscription_ends_at' => $endsAt,
                'limits' => $plan->limits ?? [],
                'settings' => $settings,
            ]);

            return $sub;
        });
    }

    public function current(Company $company): ?Subscription
    {
        return Subscription::withoutTenant()
            ->where('company_id', $company->id)
            ->whereIn('status', [Subscription::STATUS_TRIAL, Subscription::STATUS_ACTIVE, Subscription::STATUS_PAST_DUE])
            ->latest('id')
            ->first();
    }

    public function isWritable(Company $company): bool
    {
        if (!$company->is_active || $company->suspended_at) return false;

        // Əlavə (addon) aktivdirsə, yazma icazəsi açıq saxlanılsın
        if ($this->activeAddonCount($company) > 0) {
            return true;
        }

        $sub = $this->current($company);
        if ($sub) return $sub->isWritable();

        // fallback: company cache
        if ($company->trial_ends_at && now()->lt($company->trial_ends_at)) return true;
        if ($company->subscription_ends_at && now()->lt($company->subscription_ends_at)) return true;

        return false;
    }

    public function hasFeature(Company $company, string $key): bool
    {
        if ($this->featuresAreUnlimited($company)) {
            return true;
        }

        $features = $this->planFeatures($company) ?? [];

        // Aktiv addon-lar?n verdiyi x?susiyy?tl?ri plan x?susiyy?tl?rinin ?z?rin? yaz
        foreach ($this->activeAddonFeatures($company) as $k => $v) {
            if ($v === null) continue;
            $features[$k] = ($features[$k] ?? false) || (bool)$v;
        }

        $val = data_get($features, $key, null);
        return $val === true;
    }

    public function featuresAreUnlimited(Company $company): bool
    {
        $features = $this->planFeatures($company);
        return is_array($features) && array_key_exists('__unlimited', $features) && $features['__unlimited'] === true;
    }

    /**
     * Aktiv addon-ların verdiyi xüsusiyyətləri qaytarır.
     */
    public function activeAddonFeatures(Company $company): array
    {
        $addons = SubscriptionAddon::query()
            ->where('company_id', $company->id)
            ->where(function ($q) {
                $q->whereNull('ends_at')->orWhere('ends_at', '>', now());
            })
            ->get(['features_snapshot']);

        $merged = [];
        foreach ($addons as $add) {
            $feat = $add->features_snapshot ?? [];
            if (!is_array($feat)) continue;
            foreach ($feat as $k => $v) {
                $merged[$k] = ($merged[$k] ?? false) || (bool)$v;
            }
        }
        return $merged;
    }

    /**
     * Aktiv addonların sayı (features_snapshot boş olsa belə).
     */
    public function activeAddonCount(Company $company): int
    {
        return SubscriptionAddon::query()
            ->where('company_id', $company->id)
            ->where(function ($q) {
                $q->whereNull('ends_at')->orWhere('ends_at', '>', now());
            })
            ->count();
    }

    /**
     * Plan + aktiv addon xüsusiyyətlərini şirkət settings-də yenilə.
     */
    public function syncCompanyFeatures(Company $company): void
    {
        $settings = $company->settings ?? [];
        $planFeatures = $this->planFeatures($company);
        if ($planFeatures === null) {
            // limitsiz kimi saxlanılıbsa və ya plan məlum deyilsə, toxunma
            return;
        }
        $combined = $planFeatures;
        foreach ($this->activeAddonFeatures($company) as $k => $v) {
            $combined[$k] = ($combined[$k] ?? false) || (bool)$v;
        }
        $settings['features'] = $combined;
        $company->update(['settings' => $settings]);
    }

    public function limitOf(Company $company, string $key, $default = null)
    {
        return data_get($company->limits, $key, $default);
    }

    /**
     * Cari plan xüsusiyyətlərini qaytarır (subscription snapshot).
     */
    public function planFeatures(Company $company): array|null
    {
        $sub = $this->current($company);
        $features = $sub?->features_snapshot;
        if ($features === null) {
            $features = data_get($company->settings, 'features', null);
        }
        $planFeatures = $sub?->plan?->features;
        if ($features === null && is_array($planFeatures)) {
            $features = $planFeatures;
        } elseif (is_array($features) && is_array($planFeatures)) {
            foreach ($planFeatures as $key => $value) {
                if (!array_key_exists($key, $features)) {
                    $features[$key] = $value;
                }
            }
        }
        return $features;
    }
}
