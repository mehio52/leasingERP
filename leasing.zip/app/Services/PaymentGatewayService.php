<?php

namespace App\Services;

use App\Models\Company;
use App\Models\CompanyOption;
use App\Models\PaymentOption;
use Illuminate\Support\Str;

class PaymentGatewayService
{
    public function __construct(private CompanyGatewayConfig $gatewayConfig) {}

    public function activeProvider(?Company $company = null, ?PaymentOption $options = null): ?string
    {
        $options = $options ?? $this->resolvePaymentOption($company);
        $preferred = strtolower(trim((string) ($options->payment_gateway_provider ?? '')));
        if ($preferred !== '' && $preferred !== 'auto' && $this->isConfigured($preferred, $company)) {
            return $preferred;
        }

        $systemPreferred = strtolower(trim((string) config('services.payment_gateway.provider', '')));
        if ($systemPreferred !== '' && $systemPreferred !== 'auto' && $this->isConfigured($systemPreferred, $company)) {
            return $systemPreferred;
        }

        $regional = $this->regionalProvider($company);
        if ($regional && $this->isConfigured($regional, $company)) {
            return $regional;
        }

        foreach (['epoint', 'iyzico', 'stripe'] as $provider) {
            if ($this->isConfigured($provider, $company)) {
                return $provider;
            }
        }

        return null;
    }

    public function providerCurrency(string $provider, ?Company $company = null, ?string $fallback = null): string
    {
        $currency = strtoupper(trim((string) ($this->companyCurrency($company) ?: $fallback)));

        if ($provider === 'epoint') {
            return 'AZN';
        }

        if ($provider === 'iyzico') {
            return in_array($currency, ['TRY', 'USD', 'EUR', 'GBP'], true) ? $currency : 'TRY';
        }

        if ($provider === 'stripe') {
            return $currency !== '' ? $currency : 'USD';
        }

        return $currency !== '' ? $currency : 'AZN';
    }

    public function isConfigured(string $provider, ?Company $company = null): bool
    {
        return $this->gatewayConfig->hasConfig($provider, $company);
    }

    private function companyCurrency(?Company $company): ?string
    {
        if (!$company) {
            return null;
        }

        if (!empty($company->currency)) {
            return (string) $company->currency;
        }

        return CompanyOption::query()
            ->where('company_id', $company->id)
            ->value('currency');
    }

    private function regionalProvider(?Company $company): ?string
    {
        if (!$company) {
            return null;
        }

        $country = $this->companyCountry($company);
        $normalized = $this->normalizeCountry($country);

        if (in_array($normalized, ['az', 'aze', 'azerbaijan', 'azerbaycan', 'azerbaycanrespublikasi'], true)) {
            return 'epoint';
        }

        if (in_array($normalized, ['tr', 'turkey', 'turkiye', 'turkiyecumhuriyeti'], true)) {
            return 'iyzico';
        }

        if (in_array($normalized, ['us', 'usa', 'unitedstates', 'unitedstatesofamerica', 'america'], true)) {
            return 'stripe';
        }

        $locale = $this->companyLocale($company);
        if (str_starts_with($locale, 'tr')) {
            return 'iyzico';
        }
        if (str_starts_with($locale, 'az')) {
            return 'epoint';
        }
        if (str_starts_with($locale, 'en')) {
            return 'stripe';
        }

        return null;
    }

    private function companyCountry(Company $company): ?string
    {
        $options = CompanyOption::query()
            ->where('company_id', $company->id)
            ->first();

        return $options?->country ?: null;
    }

    private function companyLocale(Company $company): string
    {
        $locale = (string) ($company->locale ?? '');
        if ($locale !== '') {
            return strtolower($locale);
        }

        $optLocale = CompanyOption::query()
            ->where('company_id', $company->id)
            ->value('locale');

        return strtolower((string) $optLocale);
    }

    private function normalizeCountry(?string $country): string
    {
        $country = trim((string) $country);
        if ($country === '') {
            return '';
        }

        $normalized = Str::of($country)->lower()->ascii()->replace(['-', '_', ' '], '');
        return (string) $normalized;
    }

    private function resolvePaymentOption(?Company $company): PaymentOption
    {
        if (!$company) {
            return new PaymentOption(PaymentOption::defaults());
        }

        return PaymentOption::query()->firstOrNew(
            ['company_id' => $company->id],
            PaymentOption::defaults()
        );
    }
}
