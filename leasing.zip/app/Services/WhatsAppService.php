<?php

namespace App\Services;

use App\Models\NotificationOption;

class WhatsAppService
{
    /**
     * Send a WhatsApp message using company notification options.
     *
     * @return array [bool $sent, array $response, int $httpCode]
     */
    public function send(NotificationOption $opt, string $phone, string $message): array
    {
        $url = $opt->wp_api_url ?: 'https://whatsotp.az/api/send/otp';
        $fields = [
            'secret' => $opt->wp_api_secret,
            'type' => 'whatsapp',
            'message' => $message,
            'phone' => $phone,
        ];
        if ($opt->wp_api_key) {
            $fields['account'] = $opt->wp_api_key;
            $fields['priority'] = 1;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $fields,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
        ]);

        $resp = curl_exec($ch);
        if ($resp === false) {
            $err = curl_error($ch);
            curl_close($ch);
            return [false, ['error' => $err], 0];
        }
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $data = json_decode($resp, true);
        $status = (int)($data['status'] ?? 0);
        return [($http === 200 && $status === 200), ($data ?: ['raw' => $resp]), $http];
    }
}
