<?php

namespace App\Services;

use App\Models\Addon;
use App\Models\BhphAccount;
use App\Models\Company;
use App\Models\CompanyPayoutCard;
use App\Models\EpointTransaction;
use App\Models\Payment;
use App\Models\PaymentOption;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\SubscriptionAddon;
use Illuminate\Validation\ValidationException;

class GatewayTransactionService
{
    public function __construct(
        private SubscriptionService $subscriptions,
        private PaymentService $payments
    ) {}

    public function applySuccess(EpointTransaction $tx, array $payload): void
    {
        if (!$tx->company_id) {
            return;
        }

        $company = Company::find($tx->company_id);
        if (!$company) {
            return;
        }

        if ($tx->type === EpointTransaction::TYPE_PLAN) {
            $this->applyPlan($tx, $company);
            return;
        }

        if ($tx->type === EpointTransaction::TYPE_ADDON) {
            $this->applyAddon($tx, $company);
            return;
        }

        if ($tx->type === EpointTransaction::TYPE_LOAN_PAYMENT) {
            $this->applyLoanPayment($tx, $payload);
            return;
        }

        if ($tx->type === EpointTransaction::TYPE_PAYOUT_CARD) {
            $this->applyPayoutCard($tx, $payload);
        }
    }

    private function applyPlan(EpointTransaction $tx, Company $company): void
    {
        $meta = is_array($tx->meta) ? $tx->meta : [];
        $planId = (int) ($meta['plan_id'] ?? 0);
        if ($planId <= 0) {
            return;
        }

        $plan = Plan::find($planId);
        if (!$plan) {
            return;
        }

        $period = (string) ($meta['billing_period'] ?? Subscription::PERIOD_MONTHLY);
        $endsAt = $period === Subscription::PERIOD_YEARLY
            ? now()->addYear()
            : now()->addMonth();

        $this->subscriptions->startSubscription($company, $plan, [
            'status' => Subscription::STATUS_ACTIVE,
            'billing_period' => $period,
            'starts_at' => now(),
            'trial_ends_at' => null,
            'ends_at' => $endsAt,
            'meta' => [
                'source' => $tx->gateway ?? 'gateway',
                'order_id' => $tx->order_id,
            ],
        ]);
    }

    private function applyAddon(EpointTransaction $tx, Company $company): void
    {
        $meta = is_array($tx->meta) ? $tx->meta : [];
        $addonId = (int) ($meta['addon_id'] ?? 0);
        if ($addonId <= 0) {
            return;
        }

        $addon = Addon::find($addonId);
        if (!$addon) {
            return;
        }

        $subscription = $this->subscriptions->current($company);
        if (!$subscription) {
            return;
        }

        $period = (string) ($meta['billing_period'] ?? Subscription::PERIOD_MONTHLY);
        $endsAt = $period === Subscription::PERIOD_YEARLY
            ? now()->addYear()
            : now()->addMonth();

        $priceSnapshot = $period === Subscription::PERIOD_YEARLY
            ? $addon->price_yearly
            : $addon->price_monthly;

        SubscriptionAddon::updateOrCreate(
            ['subscription_id' => $subscription->id, 'addon_id' => $addon->id],
            [
                'company_id' => $company->id,
                'quantity' => 1,
                'starts_at' => now(),
                'ends_at' => $endsAt,
                'addon_code_snapshot' => $addon->code,
                'addon_name_snapshot' => $addon->name,
                'price_snapshot' => $priceSnapshot ?? 0,
                'currency_snapshot' => $addon->currency ?? 'AZN',
                'features_snapshot' => $addon->features ?? [],
                'meta' => [
                    'source' => $tx->gateway ?? 'gateway',
                    'order_id' => $tx->order_id,
                ],
            ]
        );

        $this->subscriptions->syncCompanyFeatures($company);
    }

    private function applyLoanPayment(EpointTransaction $tx, array $payload): void
    {
        $meta = is_array($tx->meta) ? $tx->meta : [];
        $accountId = (int) ($meta['bhph_account_id'] ?? 0);
        if ($accountId <= 0) {
            return;
        }

        $account = BhphAccount::query()->where('id', $accountId)->first();
        if (!$account) {
            return;
        }

        $reference = (string) ($payload['transaction'] ?? $payload['bank_transaction'] ?? $payload['payment_intent'] ?? $tx->order_id);
        $exists = Payment::query()
            ->where('company_id', $account->company_id)
            ->where('reference', $reference)
            ->exists();
        if ($exists) {
            return;
        }

        $opt = PaymentOption::query()->firstOrCreate(
            ['company_id' => $account->company_id],
            PaymentOption::defaults()
        );

        $overpayAction = null;
        if ($opt->allow_overpayment) {
            $allowed = [];
            if ($opt->allow_advance_payment) {
                $allowed[] = 'apply_next_installments';
            }
            if ($opt->allow_principal_only_payment) {
                $allowed[] = 'reduce_principal';
            }
            $allowed[] = 'keep_as_credit';

            if (in_array($opt->overpayment_behavior, $allowed, true)) {
                $overpayAction = $opt->overpayment_behavior;
            } else {
                $overpayAction = $allowed[0] ?? null;
            }
        }
        $amount = (float) ($payload['amount'] ?? $tx->amount ?? 0);
        if ($amount <= 0) {
            return;
        }

        $data = [
            'paid_date' => now()->toDateString(),
            'amount' => $amount,
            'note' => 'Gateway payment',
            'reference' => $reference,
            'method' => Payment::METHOD_CARD,
        ];

        $result = $this->payments->applyCashPayment($account, null, $data, $overpayAction, 0.0);
        if (($result['needs_choice'] ?? false) === true) {
            throw ValidationException::withMessages([
                'amount' => 'Overpayment action required for this payment.',
            ]);
        }
    }

    private function applyPayoutCard(EpointTransaction $tx, array $payload): void
    {
        if (!$tx->company_id) {
            return;
        }

        $cardId = (string) ($payload['card_id'] ?? '');
        if ($cardId === '') {
            return;
        }

        $cardMask = $payload['card_mask'] ?? null;
        $cardName = $payload['card_name'] ?? null;

        CompanyPayoutCard::updateOrCreate(
            ['company_id' => $tx->company_id],
            [
                'card_id' => $cardId,
                'card_mask' => $cardMask,
                'card_name' => $cardName,
                'is_active' => true,
            ]
        );
    }
}
