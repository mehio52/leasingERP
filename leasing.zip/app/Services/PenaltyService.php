<?php

namespace App\Services;

use App\Models\Amortization;
use App\Models\BhphAccount;
use App\Models\PenaltyOption;
use App\Models\Payment;
use Carbon\Carbon;

class PenaltyService
{
    public function optionsForCompany(int $companyId): PenaltyOption
    {
        return PenaltyOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            PenaltyOption::defaults()
        );
    }

    public function summarizeAccount(BhphAccount $account, ?Carbon $asOf = null): array
    {
        $date = $asOf ? $asOf->copy()->startOfDay() : Carbon::now()->startOfDay();

        $options = $this->optionsForCompany((int)$account->company_id);
        $paid = $this->paidPenalties($account, $date);

        if (!$options->isEnabled()) {
            return [
                'enabled' => false,
                'total_accrued' => 0.0,
                'total_paid' => $this->roundValue($paid, $options),
                'outstanding' => 0.0,
                'rows' => [],
                'options' => $options,
            ];
        }

        $rows = $account->amortizations()
            ->whereColumn('paid_amount', '<', 'due_amount')
            ->whereDate('due_date', '<=', $date->toDateString())
            ->orderBy('installment_no')
            ->get();

        $details = [];
        $totalAccrued = 0.0;

        foreach ($rows as $row) {
            $rowPenalty = $this->calculateForInstallment($row, $options, $date);
            if (($rowPenalty['accrued'] ?? 0) <= 0) {
                continue;
            }

            $totalAccrued += (float) $rowPenalty['accrued'];
            $details[] = $rowPenalty;
        }

        $totalAccrued = $this->roundValue($totalAccrued, $options);
        $outstanding = $this->roundValue(max(0.0, $totalAccrued - $paid), $options);

        return [
            'enabled' => true,
            'total_accrued' => $totalAccrued,
            'total_paid' => $this->roundValue($paid, $options),
            'outstanding' => $outstanding,
            'rows' => $details,
            'options' => $options,
        ];
    }

    public function calculateForInstallment(Amortization $row, PenaltyOption $options, Carbon $asOf): array
    {
        $dueDate = $row->due_date ? Carbon::parse($row->due_date)->startOfDay() : Carbon::now()->startOfDay();
        $startDate = $dueDate
            ->copy()
            ->addDays((int) ($options->grace_days ?? 0) + (int) ($options->overdue_after_days ?? 0));

        if ($asOf->lessThanOrEqualTo($startDate)) {
            return [
                'installment_id' => $row->id,
                'installment_no' => (int) $row->installment_no,
                'due_date' => $dueDate->toDateString(),
                'days_late' => 0,
                'periods' => 0,
                'base' => 0.0,
                'accrued' => 0.0,
            ];
        }

        $daysLate = $startDate->diffInDays($asOf);
        $base = $this->baseAmount($row, $options);

        if ($base <= 0.0) {
            return [
                'installment_id' => $row->id,
                'installment_no' => (int) $row->installment_no,
                'due_date' => $dueDate->toDateString(),
                'days_late' => $daysLate,
                'periods' => 0,
                'base' => 0.0,
                'accrued' => 0.0,
            ];
        }

        $periods = $this->periodCount($daysLate, $startDate, $asOf, $options);
        if ($periods <= 0) {
            $periods = 1;
        }

        $penaltyValue = (float) $options->penalty_value;

        if ($options->penalty_type === PenaltyOption::TYPE_PERCENT) {
            $raw = $base * ($penaltyValue / 100.0) * $periods;
        } else {
            $raw = $penaltyValue * $periods;
        }

        // Caps
        if ($options->penalty_cap_amount !== null) {
            $raw = min($raw, (float) $options->penalty_cap_amount);
        }

        if ($options->penalty_cap_percent !== null && $options->penalty_cap_percent > 0 && $base > 0) {
            $raw = min($raw, $base * ((float) $options->penalty_cap_percent / 100.0));
        }

        $accrued = $this->roundValue(max(0.0, $raw), $options);

        return [
            'installment_id' => $row->id,
            'installment_no' => (int) $row->installment_no,
            'due_date' => $dueDate->toDateString(),
            'days_late' => $daysLate,
            'periods' => $periods,
            'base' => $base,
            'accrued' => $accrued,
            'status' => $row->status,
            'due_amount' => (float) $row->due_amount,
            'paid_amount' => (float) $row->paid_amount,
        ];
    }

    private function baseAmount(Amortization $row, PenaltyOption $options): float
    {
        $dueRem = max(0.0, (float) $row->due_amount - (float) $row->paid_amount);
        $principalRem = max(0.0, (float) ($row->principal_amount ?? 0) - (float) ($row->paid_principal ?? 0));

        return match ($options->apply_on) {
            PenaltyOption::APPLY_TOTAL_INSTALLMENT => (float) $row->due_amount,
            PenaltyOption::APPLY_PRINCIPAL_ONLY => $principalRem,
            default => $dueRem,
        };
    }

    private function roundValue(float $value, PenaltyOption $options): float
    {
        $step = (float) ($options->rounding_step ?? 0.01);
        if ($step <= 0) {
            $step = 0.01;
        }

        $mode = (string) ($options->rounding_mode ?? PenaltyOption::ROUND_NEAREST);
        $div = $value / $step;

        return match ($mode) {
            PenaltyOption::ROUND_UP => ceil($div) * $step,
            PenaltyOption::ROUND_DOWN => floor($div) * $step,
            default => round($div) * $step,
        };
    }

    private function periodCount(int $daysLate, Carbon $startDate, Carbon $asOf, PenaltyOption $options): int
    {
        return match ($options->penalty_frequency) {
            PenaltyOption::FREQ_DAILY => $daysLate,
            PenaltyOption::FREQ_MONTHLY => $startDate->diffInMonths($asOf) + 1,
            default => 1,
        };
    }

    private function paidPenalties(BhphAccount $account, Carbon $asOf): float
    {
        return (float) Payment::query()
            ->where('company_id', (int) $account->company_id)
            ->where('bhph_account_id', (int) $account->id)
            ->where('status', Payment::STATUS_CONFIRMED)
            ->whereDate('paid_date', '<=', $asOf->toDateString())
            ->sum('penalty_amount');
    }
}
