<?php

namespace App\Services;

use App\Models\User;
use App\Models\Payment;
use Carbon\Carbon;

class PayrollService
{
    public function calculate(User $user, Carbon $from, Carbon $to): array
    {
        $base = (float) ($user->base_salary ?? 0);
        $commission = 0.0;
        $commissionCount = 0;

        $type = $user->commission_type;
        $rate = (float) ($user->commission_rate ?? 0);

        $payments = Payment::query()
            ->where('received_by_user_id', $user->id)
            ->whereBetween('paid_date', [$from->copy()->startOfDay(), $to->copy()->endOfDay()])
            ->where('status', Payment::STATUS_CONFIRMED)
            ->get();

        if ($type === 'percent_per_vehicle') {
            $commission = $payments->sum('amount') * ($rate / 100);
            $commissionCount = $payments->count();
        } elseif ($type === 'fixed_per_vehicle') {
            $commissionCount = $payments->count();
            $commission = $commissionCount * $rate;
        }

        return [
            'base_salary' => $base,
            'commission' => $commission,
            'commission_count' => $commissionCount,
            'total' => $base + $commission,
            'currency' => $user->salary_currency ?? 'AZN',
        ];
    }
}
