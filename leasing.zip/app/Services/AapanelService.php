<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class AapanelService
{
    public function isEnabled(): bool
    {
        return (bool) config('services.aapanel.enabled', false)
            && (bool) $this->baseUrl()
            && (bool) $this->apiKey()
            && (bool) $this->siteName();
    }

    /**
     * Park/BIND domain(s) to site (alias domain).
     * @param string|array $domains  "a.com" OR ["a.com","www.a.com","b.com:81"]
     */
    public function addDomainToSite(string|array $domains): array
    {
        if (!$this->isEnabled()) {
            return $this->fail('aaPanel is not configured.');
        }

        $domainStr = $this->normalizeDomainsForAdd($domains);
        if ($domainStr === '') {
            return $this->fail('Domain is empty.');
        }

        $site = $this->resolveSite();
        if (!$site['ok']) {
            return $site;
        }

        $payload = [
            'id'      => (string) $site['id'],
            'webname' => (string) $site['name'],
            'domain'  => $domainStr, // newline supported
        ];

        $res = $this->postSigned('/site?action=AddDomain', $payload);

        // aaPanel bəzən status=false ama msg-də exist yazır (idempotent qəbul edirik)
        if (!$res['ok'] && $this->looksLikeAlreadyExists($res['message'] ?? '')) {
            return ['ok' => true, 'message' => $res['message'] ?: 'Already exists', 'context' => $res];
        }

        return $res;
    }

    /**
     * Unpark/UNBIND domain from site.
     * @param string $domain "a.com" OR "a.com:81"
     */
    public function removeDomainFromSite(string $domain): array
    {
        if (!$this->isEnabled()) {
            return $this->fail('aaPanel is not configured.');
        }

        $domain = trim($domain);
        if ($domain === '') {
            return $this->fail('Domain is empty.');
        }

        [$host, $port] = $this->splitHostPort($domain);

        $site = $this->resolveSite();
        if (!$site['ok']) {
            return $site;
        }

        $payload = [
            'id'      => (string) $site['id'],
            'webname' => (string) $site['name'],
            'domain'  => (string) $host,
            'port'    => (string) $port, // REQUIRED
        ];

        $res = $this->postSigned('/site?action=DelDomain', $payload);

        if (!$res['ok'] && $this->looksLikeNotExists($res['message'] ?? '')) {
            return ['ok' => true, 'message' => $res['message'] ?: 'Not exists', 'context' => $res];
        }

        return $res;
    }

    /**
     * -----------------------
     * Core signed POST helper
     * -----------------------
     * Tries seconds signature first, then milliseconds (some panels behave differently).
     */
    private function postSigned(string $path, array $payload): array
    {
        // seconds first
        $res = $this->post($path, $this->signPayload($payload, false));

        // If key verification/time mismatch, retry with ms timestamp
        $msg = strtolower((string)($res['message'] ?? ''));
        if (!$res['ok'] && str_contains($msg, 'verification failed')) {
            $res2 = $this->post($path, $this->signPayload($payload, true));
            // if second attempt succeeds, return it; else return first (more relevant usually)
            return $res2['ok'] ? $res2 : $res;
        }

        return $res;
    }

    /**
     * POST with form-encoding RFC3986 (curl --data-urlencode equivalent).
     */
    private function post(string $path, array $payload): array
    {
        $last = null;

        foreach ($this->candidateBaseUrls() as $baseUrl) {
            $url = rtrim($baseUrl, '/') . $path;

            try {
                // Ensure RFC3986 encoding (important for newline and special chars)
                $body = http_build_query($payload, '', '&', PHP_QUERY_RFC3986);

                $resp = Http::withOptions(['verify' => $this->sslVerify()])
                    ->timeout((int) config('services.aapanel.timeout', 12))
                    ->withHeaders(['Content-Type' => 'application/x-www-form-urlencoded'])
                    ->withBody($body, 'application/x-www-form-urlencoded')
                    ->post($url);

                $status = $resp->status();
                $json = $resp->json();

                if (!is_array($json)) {
                    $snippet = mb_substr(trim(strip_tags((string)$resp->body())), 0, 300);
                    $last = [
                        'ok' => false,
                        'message' => "Non-JSON response (HTTP {$status}): {$snippet}",
                        'status_code' => $status,
                        'data' => null,
                        'url' => $url,
                        'raw' => (string) $resp->body(),
                    ];

                    // wrong endpoint -> try next baseUrl
                    if (in_array($status, [404, 405], true)) continue;

                    return $last;
                }

                // ok calculation:
                // - status varsa status-a bax
                // - status yoxdursa, amma data arraydırsa (getData tipli) OK say
                $ok = isset($json['status'])
                    ? (bool) $json['status']
                    : (isset($json['data']) && is_array($json['data']));

                $msg = (string) ($json['msg'] ?? $json['message'] ?? '');

                return [
                    'ok' => $ok,
                    'message' => $msg,
                    'status_code' => $status,
                    'data' => $json,
                    'url' => $url,
                ];
            } catch (\Throwable $e) {
                $last = [
                    'ok' => false,
                    'message' => 'aaPanel exception: ' . $e->getMessage(),
                    'status_code' => 0,
                    'data' => null,
                    'url' => $url,
                ];
            }
        }

        return $last ?: $this->fail('aaPanel request failed.');
    }

    /**
     * -----------------------
     * Resolve site id/name
     * -----------------------
     */
    private function resolveSite(): array
    {
        $webname = $this->siteName();
        if (!$webname) {
            return $this->fail('services.aapanel.site is missing.');
        }
        $webname = $this->sanitizeDomain($webname);

        // Most stable: set in .env => AAPANEL_SITE_ID
        $cfgId = config('services.aapanel.site_id');
        if (is_numeric($cfgId) && (int)$cfgId > 0) {
            return ['ok' => true, 'id' => (int)$cfgId, 'name' => $webname];
        }

        // Fetch sites list
        $payload = [
            'p'      => '1',
            'limit'  => '200',
            'search' => $webname,
            'order'  => 'id desc',
            'type'   => '-1',
        ];

        $res = $this->postSigned('/data?action=getData&table=sites', $payload);
        if (!$res['ok']) {
            return $this->fail('Failed to fetch sites list from aaPanel.', $res);
        }

        $json = $res['data'] ?? [];
        $list = $this->extractSitesList($json);
        $target = $this->normalizeMatchDomain($webname);

        foreach ($list as $row) {
            if (!is_array($row)) continue;
            $id = (int)($row['id'] ?? 0);
            if ($id <= 0) continue;

            $candidates = [];
            foreach (['name', 'site_name', 'rname', 'server_name', 'domain', 'ps'] as $key) {
                $val = $row[$key] ?? null;
                if (is_string($val) && $val !== '') {
                    $candidates[] = $val;
                } elseif (is_array($val)) {
                    $candidates = array_merge($candidates, $val);
                }
            }

            $sslDns = $row['ssl']['dns'] ?? null;
            if (is_array($sslDns)) {
                $candidates = array_merge($candidates, $sslDns);
            }

            foreach ($candidates as $candidate) {
                $candidate = (string) $candidate;
                if ($this->normalizeMatchDomain($candidate) === $target) {
                    return ['ok' => true, 'id' => $id, 'name' => $webname];
                }
            }
        }

        // Fallback: try domain table to map domain -> site id (pid)
        $domainRows = $this->fetchDomainRows($webname);
        foreach ($domainRows as $row) {
            if (!is_array($row)) continue;

            $candidates = [];
            foreach (['name', 'domain', 'rname', 'server_name', 'site_name'] as $key) {
                if (!empty($row[$key]) && is_string($row[$key])) {
                    $candidates[] = $row[$key];
                }
            }

            foreach ($candidates as $candidate) {
                if ($this->normalizeMatchDomain((string) $candidate) !== $target) continue;
                $pid = $this->extractSiteIdFromDomainRow($row);
                if ($pid !== null) {
                    return ['ok' => true, 'id' => $pid, 'name' => $webname];
                }
            }
        }

        return $this->fail("Site not found in aaPanel sites list or domain list: {$webname}", $res);
    }

    private function extractSitesList(array $json): array
    {
        // Your panel returns: { where, page, data: [ ... ] }
        if (isset($json['data']) && is_array($json['data'])) {
            // Some panels: data.data nested
            if (isset($json['data']['data']) && is_array($json['data']['data'])) {
                return $json['data']['data'];
            }
            return $json['data'];
        }
        if (isset($json['list']) && is_array($json['list'])) {
            return $json['list'];
        }
        return [];
    }

    private function fetchDomainRows(string $search): array
    {
        $search = trim($search);
        if ($search === '') return [];

        $payloads = [
            ['p' => 1, 'limit' => 500, 'search' => $search, 'list' => 'true'],
            ['p' => 1, 'limit' => 500, 'search' => $search],
            ['p' => 1, 'limit' => 500, 'search' => $search, 'list' => 'True'],
        ];

        foreach ($payloads as $base) {
            $payload = $base + ['table' => 'domain'];
            $res = $this->postSigned('/data?action=getData&table=domain', $payload);
            if (!$res['ok']) continue;

            $json = $res['data'] ?? [];
            $list = $this->extractSitesList($json);
            if (!empty($list)) {
                return $list;
            }
        }

        return [];
    }

    private function extractSiteIdFromDomainRow(array $row): ?int
    {
        foreach (['pid', 'site_id', 'sid', 'siteid', 'web_id'] as $key) {
            $val = $row[$key] ?? null;
            if (is_numeric($val) && (int)$val > 0) {
                return (int) $val;
            }
        }
        return null;
    }

    /**
     * -----------------------
     * Signing
     * -----------------------
     * seconds or milliseconds, depending on $useMs.
     */
    private function signPayload(array $payload, bool $useMs): array
    {
        $t = $useMs ? (string) ((int) floor(microtime(true) * 1000)) : (string) time();
        $sk = (string) $this->apiKey();
        $token = md5($t . md5($sk));

        return $payload + [
            'request_time'  => $t,
            'request_token' => $token,
        ];
    }

    /**
     * -----------------------
     * BaseUrl candidates
     * -----------------------
     */
    private function candidateBaseUrls(): array
    {
        $url = $this->baseUrl();
        if (!$url) return [];

        $urls = [rtrim($url, '/')];

        $adminPath = $this->adminPath();
        if ($adminPath) {
            $adminPath = '/' . ltrim($adminPath, '/');

            // If given baseUrl doesn't include adminPath, try adding it
            $urls[] = rtrim($url, '/') . $adminPath;

            // If baseUrl includes adminPath, also try trimming it
            $path = parse_url($url, PHP_URL_PATH) ?: '';
            if ($path && str_ends_with($path, $adminPath)) {
                $trimmed = rtrim(substr(rtrim($url, '/'), 0, -strlen($adminPath)), '/');
                if ($trimmed !== '') $urls[] = $trimmed;
            }
        }

        $urls = array_values(array_unique(array_filter($urls)));
        return $urls;
    }

    private function adminPath(): ?string
    {
        $pathFile = '/www/server/panel/data/admin_path.pl';
        if (!is_file($pathFile)) return null;

        $raw = @file_get_contents($pathFile);
        if ($raw === false) return null;

        $raw = trim($raw);
        if ($raw === '') return null;

        return str_starts_with($raw, '/') ? $raw : '/' . $raw;
    }

    /**
     * -----------------------
     * Helpers
     * -----------------------
     */
    private function normalizeDomainsForAdd(string|array $domains): string
    {
        $arr = is_array($domains) ? $domains : [$domains];
        $out = [];

        foreach ($arr as $d) {
            $d = $this->sanitizeDomain((string)$d);
            if ($d === '') continue;
            $out[] = $d;
        }

        $out = array_values(array_unique($out));
        return implode("\n", $out);
    }

    private function splitHostPort(string $domain): array
    {
        $domain = $this->sanitizeDomain($domain);

        $pos = strrpos($domain, ':');
        if ($pos !== false) {
            $host = substr($domain, 0, $pos);
            $port = substr($domain, $pos + 1);
            if ($host !== '' && ctype_digit($port)) {
                return [trim($host), (int)$port];
            }
        }
        return [$domain, 80];
    }

    private function sanitizeDomain(string $domain): string
    {
        $domain = strtolower(trim($domain));
        $domain = preg_replace('#^https?://#', '', $domain);
        $domain = strtok($domain, '/');
        return $domain ?: '';
    }

    private function normalizeMatchDomain(string $domain): string
    {
        $domain = $this->sanitizeDomain($domain);
        $domain = preg_replace('/:\\d+$/', '', $domain);
        $domain = preg_replace('/^www\\./', '', $domain);
        return $domain ?: '';
    }

    private function looksLikeAlreadyExists(string $msg): bool
    {
        $m = strtolower($msg);
        return $m !== '' && (
            str_contains($m, 'exist') ||
            str_contains($m, 'already') ||
            str_contains($m, 'exists')
        );
    }

    private function looksLikeNotExists(string $msg): bool
    {
        $m = strtolower($msg);
        return $m !== '' && (
            str_contains($m, 'not exist') ||
            str_contains($m, 'no such') ||
            str_contains($m, 'does not exist')
        );
    }

    private function fail(string $message, mixed $context = null): array
    {
        return ['ok' => false, 'message' => $message, 'context' => $context];
    }

    private function baseUrl(): ?string
    {
        $url = config('services.aapanel.url');
        return $url ? rtrim((string)$url, '/') : null;
    }

    private function apiKey(): ?string
    {
        $key = config('services.aapanel.key');
        return $key ? trim((string)$key) : null;
    }

    private function siteName(): ?string
    {
        $site = config('services.aapanel.site');
        return $site ? trim((string)$site) : null;
    }

    private function sslVerify(): bool
    {
        return (bool) config('services.aapanel.ssl_verify', true);
    }
}
