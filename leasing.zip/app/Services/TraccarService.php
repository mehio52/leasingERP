<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Arr;

class TraccarService
{
    private ?array $override = null;

    public function withConfig(array $config): self
    {
        $clone = clone $this;
        $clone->override = $config;
        return $clone;
    }

    public function isConfigured(): bool
    {
        return (bool) $this->baseUrl() && ($this->token() || ($this->username() && $this->password()));
    }

    public function baseUrl(): string
    {
        $base = $this->override['base_url'] ?? null;
        if ($base !== null && $base !== '') {
            return rtrim((string) $base, '/');
        }
        return rtrim((string) config('services.traccar.base_url', env('TRACCAR_BASE_URL', '')), '/');
    }

    public function token(): ?string
    {
        $token = $this->override['token'] ?? null;
        if ($token !== null && $token !== '') {
            return $token;
        }
        return config('services.traccar.token', env('TRACCAR_TOKEN'));
    }

    public function username(): ?string
    {
        $username = $this->override['username'] ?? null;
        if ($username !== null && $username !== '') {
            return $username;
        }
        return config('services.traccar.username', env('TRACCAR_USERNAME'));
    }

    public function password(): ?string
    {
        $password = $this->override['password'] ?? null;
        if ($password !== null && $password !== '') {
            return $password;
        }
        return config('services.traccar.password', env('TRACCAR_PASSWORD'));
    }

    public function wsUrl(): ?string
    {
        $base = $this->baseUrl();
        if (!$base) return null;
        $ws = preg_replace('#^http#', 'ws', $base);
        return rtrim($ws, '/') . '/api/socket';
    }

    public function findDeviceByUniqueId(string $uniqueId): ?array
    {
        if (!$this->isConfigured()) return null;

        try {
            $url = $this->baseUrl() . '/api/devices';
            $res = $this->client()->get($url, ['uniqueId' => $uniqueId, 'all' => 'true']);
            if ($res->failed()) return null;

            $devices = $res->json();
            if (!is_array($devices) || empty($devices)) return null;

            return $devices[0];
        } catch (\Throwable) {
            return null;
        }
    }

    public function createDevice(string $uniqueId, string $name, ?int $groupId = null): ?array
    {
        if (!$this->isConfigured()) return null;

        try {
            $payload = [
                'name' => $name,
                'uniqueId' => $uniqueId,
            ];
            if ($groupId) {
                $payload['groupId'] = $groupId;
            }

            $res = $this->client()->post($this->baseUrl() . '/api/devices', $payload);
            if ($res->failed()) return null;
            $device = $res->json();
            return is_array($device) ? $device : null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function ensureDevice(string $uniqueId, string $name, ?int $groupId = null): ?array
    {
        $existing = $this->findDeviceByUniqueId($uniqueId);
        if ($existing) return $existing;
        return $this->createDevice($uniqueId, $name, $groupId);
    }

    public function listCommandTypes(?string $uniqueId = null): array
    {
        if (!$this->isConfigured()) return [];

        try {
            $params = [];
            if ($uniqueId) {
                $device = $this->findDeviceByUniqueId($uniqueId);
                if ($device && isset($device['id'])) {
                    $params['deviceId'] = $device['id'];
                }
            }

            $res = $this->client()->get($this->baseUrl() . '/api/commands/types', $params);
            if ($res->failed()) return [];

            $types = $res->json();
            return is_array($types) ? $types : [];
        } catch (\Throwable) {
            return [];
        }
    }

    public function sendCommand(string $uniqueId, string $type, array $attributes = []): bool
    {
        if (!$this->isConfigured()) return false;
        try {
            $device = $this->findDeviceByUniqueId($uniqueId);
            if (!$device || empty($device['id'])) return false;

            $payload = [
                'deviceId' => $device['id'],
                'type' => $type,
            ];
            if (!empty($attributes)) {
                $payload['attributes'] = $attributes;
            }

            $res = $this->client()->post($this->baseUrl() . '/api/commands/send', $payload);
            return $res->successful();
        } catch (\Throwable) {
            return false;
        }
    }

    public function getLastPosition(string $deviceId): ?array
    {
        if (!$this->isConfigured()) {
            return null;
        }

        try {
            // Traccar positions endpoint deviceId param tələb edir (numeric ID). Bizdə uniqueId saxlanırsa, əvvəlcə tapıb ID-yə çevirək.
            $lookupId = $this->resolveDeviceId($deviceId);
            if (!$lookupId) {
                return null;
            }

            $url = $this->baseUrl() . '/api/positions';
            $response = $this->client()->get($url, ['deviceId' => $lookupId, 'limit' => 1]);

            if ($response->failed()) {
                return null;
            }

            $positions = $response->json();
            if (!is_array($positions) || empty($positions)) {
                return null;
            }

            $pos = Arr::first($positions);
            if (!is_array($pos)) {
                return null;
            }

            return [
                'device_id' => $pos['deviceId'] ?? $deviceId,
                'latitude' => (float) ($pos['latitude'] ?? 0),
                'longitude' => (float) ($pos['longitude'] ?? 0),
                'speed' => $pos['speed'] ?? null,
                'course' => $pos['course'] ?? null,
                'device_time' => $pos['deviceTime'] ?? null,
                'server_time' => $pos['serverTime'] ?? null,
                'address' => $pos['address'] ?? null,
            ];
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * Bizdə saxlanılan string deviceId uniqueId ola bilər; Traccar API üçün numeric id lazımdır.
     */
    private function resolveDeviceId(string $deviceId): ?int
    {
        // already numeric id?
        if (is_numeric($deviceId)) {
            return (int)$deviceId;
        }
        $device = $this->findDeviceByUniqueId($deviceId);
        if ($device && isset($device['id'])) {
            return (int)$device['id'];
        }
        return null;
    }

    private function client()
    {
        $http = Http::timeout(8);

        if ($token = $this->token()) {
            return $http->withToken($token);
        }

        return $http->withBasicAuth((string) $this->username(), (string) $this->password());
    }
}
