<?php

namespace App\Services;

use App\Models\BhphAccount;
use App\Services\PenaltyService;
use Carbon\Carbon;

class AccountStatusService
{
    private ?Carbon $today = null;
    private array $gapCache = [];

    public function __construct(private PenaltyService $penaltyService)
    {
    }

    public function syncStatus(BhphAccount $account): bool
    {
        $current = $account->status;

        if ($current === BhphAccount::STATUS_LEGAL || $current === BhphAccount::STATUS_INACTIVE) {
            return false;
        }

        $target = $this->determineStatus($account);

        if ($current === $target) {
            return false;
        }

        $account->status = $target;
        $account->save();

        return true;
    }

    public function determineStatus(BhphAccount $account): string
    {
        if ($account->status === BhphAccount::STATUS_LEGAL || $account->status === BhphAccount::STATUS_INACTIVE) {
            return $account->status;
        }

        return $this->hasOverdueInstallment($account)
            ? BhphAccount::STATUS_OVERDUE
            : BhphAccount::STATUS_ACTIVE;
    }

    public function hasOverdueInstallment(BhphAccount $account): bool
    {
        $threshold = $this->overdueThresholdForCompany((int) $account->company_id);

        return $account->amortizations()
            ->whereColumn('paid_amount', '<', 'due_amount')
            ->whereNotNull('due_date')
            ->whereDate('due_date', '<', $threshold->toDateString())
            ->exists();
    }

    private function overdueThresholdForCompany(int $companyId): Carbon
    {
        $gap = $this->overdueGapDaysForCompany($companyId);
        $threshold = $this->today()->copy();

        if ($gap > 0) {
            $threshold->subDays($gap);
        }

        return $threshold;
    }

    private function overdueGapDaysForCompany(int $companyId): int
    {
        if (!array_key_exists($companyId, $this->gapCache)) {
            $options = $this->penaltyService->optionsForCompany($companyId);
            $gap = max(0, (int) ($options->grace_days ?? 0) + (int) ($options->overdue_after_days ?? 0));
            $this->gapCache[$companyId] = $gap;
        }

        return $this->gapCache[$companyId];
    }

    private function today(): Carbon
    {
        return $this->today ??= now()->startOfDay();
    }
}
