<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

class WialonService
{
    private ?array $override = null;
    private ?string $cacheKey = null;

    public function withConfig(array $config, ?string $cacheKey = null): self
    {
        $clone = clone $this;
        $clone->override = $config;
        $clone->cacheKey = $cacheKey;
        return $clone;
    }

    public function isConfigured(): bool
    {
        return (bool) $this->baseUrl() && ((bool) $this->token() || ((bool) $this->username() && (bool) $this->password()));
    }

    public function baseUrl(): string
    {
        $base = $this->override['base_url'] ?? null;
        if ($base !== null && $base !== '') {
            return rtrim((string) $base, '/');
        }
        return rtrim((string) config('services.wialon.base_url', env('WIALON_BASE_URL', 'https://hst-api.wialon.com')), '/');
    }

    public function token(): ?string
    {
        $token = $this->override['token'] ?? null;
        if ($token !== null && $token !== '') {
            return $token;
        }
        return config('services.wialon.token', env('WIALON_TOKEN')) ?: null;
    }

    public function username(): ?string
    {
        $username = $this->override['username'] ?? null;
        if ($username !== null && $username !== '') {
            return $username;
        }
        return null;
    }

    public function password(): ?string
    {
        $password = $this->override['password'] ?? null;
        if ($password !== null && $password !== '') {
            return $password;
        }
        return null;
    }

    public function testConnection(): bool
    {
        $sid = $this->login();
        if (!$sid) return false;

        $resp = $this->call('core/get_account_data', []);
        return is_array($resp);
    }

    public function searchItems(string $itemsType, int $flags = 1, int $from = 0, int $to = 0, string $propName = 'sys_name', string $propValueMask = '*'): array
    {
        if (!$this->isConfigured()) return [];

        $resp = $this->call('core/search_items', [
            'spec' => [
                'itemsType' => $itemsType,
                'propName' => $propName,
                'propValueMask' => $propValueMask,
                'sortType' => $propName,
            ],
            'force' => 1,
            'flags' => $flags,
            'from' => $from,
            'to' => $to,
        ]);

        if (!is_array($resp)) return [];
        $items = $resp['items'] ?? [];
        return is_array($items) ? $items : [];
    }

    public function searchItemsByProperty(string $itemsType, string $propName, string $propValueMask, int $flags = 1): array
    {
        return $this->searchItems($itemsType, $flags, 0, 0, $propName, $propValueMask);
    }

    public function searchUnits(int $flags = 1): array
    {
        return $this->searchItems('avl_unit', $flags);
    }

    public function searchUnitGroups(int $flags = 1): array
    {
        return $this->searchItems('avl_unit_group', $flags);
    }

    public function getLastPosition(string $unitId): ?array
    {
        if (!$this->isConfigured()) return null;

        $id = (int) $unitId;
        if ($id <= 0) return null;

        $resp = $this->call('unit/get_last_message', ['unitId' => $id]);
        if (!is_array($resp)) return null;

        $pos = $resp['pos'] ?? null;
        if (!is_array($pos)) return null;

        return [
            'device_id' => $unitId,
            'latitude' => (float) ($pos['y'] ?? 0),
            'longitude' => (float) ($pos['x'] ?? 0),
            'speed' => $pos['s'] ?? null,
            'course' => $pos['c'] ?? null,
            'device_time' => isset($pos['t']) ? date('c', (int) $pos['t']) : null,
            'server_time' => isset($resp['tm']) ? date('c', (int) $resp['tm']) : null,
            'address' => $resp['pos']['a'] ?? null,
        ];
    }

    public function loadMessagesInterval(int $unitId, int $timeFrom, int $timeTo, int $flags = 0): array
    {
        if (!$this->isConfigured()) return [];

        $id = (int) $unitId;
        if ($id <= 0) return [];

        $resp = $this->call('messages/load_interval', [
            'itemId' => $id,
            'timeFrom' => $timeFrom,
            'timeTo' => $timeTo,
            'flags' => (int) $flags,
        ]);

        if (!is_array($resp)) return [];

        $messages = $resp['messages'] ?? $resp['data'] ?? $resp['items'] ?? [];
        return is_array($messages) ? $messages : [];
    }

    public function listCommandTypes(string $unitId): array
    {
        if (!$this->isConfigured()) return [];

        $id = (int) $unitId;
        if ($id <= 0) return [];

        $resp = $this->call('core/get_hw_cmds', [
            'deviceTypeId' => 0,
            'unitId' => $id,
            'template' => 0,
            'lang' => 'en',
        ]);

        if (!is_array($resp)) return [];

        $typeMap = [];
        foreach ($resp as $linkType => $cmds) {
            if (!is_array($cmds)) continue;
            foreach ($cmds as $cmd) {
                if (!is_string($cmd) || $cmd === '') continue;
                $typeMap[$cmd] ??= [];
                $typeMap[$cmd][] = $linkType;
            }
        }

        $list = [];
        foreach ($typeMap as $type => $links) {
            $links = array_values(array_unique(array_map('strtolower', $links)));
            sort($links);
            $list[] = [
                'type' => $type,
                'link_types' => $links,
                'label' => $links ? ($type . ' (' . implode(',', $links) . ')') : $type,
            ];
        }

        usort($list, fn($a, $b) => strcmp((string) $a['type'], (string) $b['type']));
        return $list;
    }

    public function getHardwareTypes(): array
    {
        if (!$this->isConfigured()) return [];

        $resp = $this->call('core/get_hw_types', []);
        if (!is_array($resp)) return [];

        $types = $resp['hwTypes'] ?? $resp['items'] ?? $resp;
        return is_array($types) ? $types : [];
    }

    public function createUnit(string $name, string $uniqueId, ?int $hwTypeId = null): ?array
    {
        if (!$this->isConfigured()) return null;

        $payload = [
            'name' => $name,
            'uniqueId' => $uniqueId,
        ];
        if ($hwTypeId) {
            $payload['hwTypeId'] = $hwTypeId;
            $payload['hwType'] = $hwTypeId;
        }

        $resp = $this->call('core/create_unit', $payload);
        return is_array($resp) ? $resp : null;
    }

    public function sendCommand(
        string $unitId,
        string $commandType,
        string $linkType = '',
        string $param = '',
        int $timeout = 60,
        int $flags = 0,
        ?string $commandName = null
    ): bool {
        if (!$this->isConfigured()) return false;

        $id = (int) $unitId;
        if ($id <= 0 || $commandType === '') return false;

        $payload = [
            'itemId' => $id,
            'commandType' => $commandType,
            'commandName' => $commandName ?: $commandType,
            'linkType' => $linkType,
            'param' => $param,
            'timeout' => max(1, (int) $timeout),
            'flags' => (int) $flags,
        ];

        $resp = $this->call('unit/send_cmd', $payload);
        return is_array($resp);
    }

    private function call(string $svc, array $params): ?array
    {
        try {
            $sid = $this->login();
            if (!$sid) return null;

            $url = $this->baseUrl() . '/wialon/ajax.html';
            $res = Http::timeout(8)->get($url, [
                'svc' => $svc,
                'params' => json_encode($params, JSON_UNESCAPED_UNICODE),
                'sid' => $sid,
            ]);

            if ($res->failed()) return null;
            $data = $res->json();
            return is_array($data) ? $data : null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function login(): ?string
    {
        $token = $this->token();
        $username = $this->username();
        $password = $this->password();

        if (!$token && (!$username || !$password)) return null;

        $cacheSuffix = $token ? 'token' : 'userpass';
        $cacheKey = $this->cacheKey
            ? 'wialon.sid.' . $cacheSuffix . '.' . $this->cacheKey
            : 'wialon.sid.' . $cacheSuffix . '.global';

        return Cache::remember($cacheKey, now()->addMinutes(50), function () use ($token, $username, $password) {
            $url = $this->baseUrl() . '/wialon/ajax.html';
            if ($token) {
                $res = Http::timeout(8)->get($url, [
                    'svc' => 'token/login',
                    'params' => json_encode(['token' => $token], JSON_UNESCAPED_UNICODE),
                ]);
            } else {
                $res = Http::timeout(8)->get($url, [
                    'svc' => 'core/login',
                    'params' => json_encode([
                        'user' => $username,
                        'password' => $password,
                    ], JSON_UNESCAPED_UNICODE),
                ]);
            }

            if ($res->failed()) return null;
            $data = $res->json();
            if (!is_array($data)) return null;
            return $data['eid'] ?? null;
        });
    }
}
