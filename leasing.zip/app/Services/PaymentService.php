<?php

namespace App\Services;

use App\Models\Amortization;
use App\Models\BhphAccount;
use App\Models\LeasingOption;
use App\Models\Payment;
use App\Models\PaymentOption;
use App\Models\User;
use App\Services\AccountStatusService;
use App\Services\AmortizationService;
use App\Services\PenaltyService;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PaymentService
{
    public function __construct(
        private AmortizationService $amortService,
        private PenaltyService $penaltyService,
        private AccountStatusService $accountStatusService
    ) {}

    public function previewPayment(BhphAccount $account, string $paidDate, float $amount, ?string $overpayAction = null): array
    {
        $companyId = (int) $account->company_id;

        $opt = PaymentOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            [
                'allow_payment_gateway' => false,
                'allow_overpayment' => true,
                'allow_partial_payment' => true,
                'allow_principal_only_payment' => true,
                'apply_to' => PaymentOption::APPLY_OLDEST_DUE_FIRST,
                'allocation_order' => PaymentOption::ALLOC_INTEREST_THEN_PRINCIPAL,
                'overpayment_behavior' => PaymentOption::OVERPAY_KEEP_AS_CREDIT,
                'allow_advance_payment' => true,
                'settings' => [],
            ]
        );

        $penaltySummary = $this->penaltyService->summarizeAccount($account, Carbon::parse($paidDate));
        $penaltyDue = (float) ($penaltySummary['outstanding'] ?? 0);
        $penaltyCharge = min($penaltyDue, $amount);
        $amountForSchedule = max(0.0, $amount - $penaltyCharge);

        $plan = ['items' => [], 'remainder' => 0];
        if ($amountForSchedule > 0) {
            $plan = $this->buildPlan($account, $opt, $paidDate, $amountForSchedule, $overpayAction);
        }

        if (($plan['remainder'] ?? 0) > 0.0001 && !$overpayAction) {
            $allowed = [];
            if ($opt->allow_overpayment && $opt->allow_advance_payment) {
                $allowed[] = 'apply_next_installments';
            }
            if ($opt->allow_overpayment && $opt->allow_principal_only_payment) {
                $allowed[] = 'reduce_principal';
            }
            if ($opt->allow_overpayment) {
                $allowed[] = 'keep_as_credit';
            }

            return [
                'needs_choice' => true,
                'remainder' => (float) $plan['remainder'],
                'allowed_actions' => $allowed,
                'payment_option' => $opt,
                'penalty_summary' => $penaltySummary,
                'penalty_charge' => $penaltyCharge,
                'amount_for_schedule' => $amountForSchedule,
                'plan' => $plan,
            ];
        }

        return [
            'needs_choice' => false,
            'remainder' => (float) ($plan['remainder'] ?? 0),
            'payment_option' => $opt,
            'penalty_summary' => $penaltySummary,
            'penalty_charge' => $penaltyCharge,
            'amount_for_schedule' => $amountForSchedule,
            'plan' => $plan,
        ];
    }

    /**
     * Nağd ödəniş tətbiq et:
     * - əvvəlcə bu günə qədər ödənməli olan taksitlərə tətbiq edir (due_date <= paid_date)
     * - əgər artıq məbləğ qalırsa:
     *   - overpay_action yoxdursa -> needs_choice qaytarır (UI soruşsun)
     *   - overpay_action varsa -> seçilən davranışa görə tətbiq edir
     */
    public function applyCashPayment(BhphAccount $account, ?User $user, array $data, ?string $overpayAction = null, float $balanceDraw = 0.0): array
    {
        $companyId = (int) $account->company_id;

        $opt = PaymentOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            [
                'allow_payment_gateway' => false,
                'allow_overpayment' => true,
                'allow_partial_payment' => true,
                'allow_principal_only_payment' => true,
                'apply_to' => PaymentOption::APPLY_OLDEST_DUE_FIRST,
                'allocation_order' => PaymentOption::ALLOC_INTEREST_THEN_PRINCIPAL,
                'overpayment_behavior' => PaymentOption::OVERPAY_KEEP_AS_CREDIT,
                'allow_advance_payment' => true,
                'settings' => [],
            ]
        );

        $paidDate = Carbon::parse($data['paid_date'])->toDateString();
        $amount   = (float) $data['amount'];

        // Cərimə (penalty) hesabla və ödəniş məbləğindən ayır
        $penaltySummary = $this->penaltyService->summarizeAccount($account, Carbon::parse($paidDate));
        $penaltyDue     = (float) ($penaltySummary['outstanding'] ?? 0);
        $penaltyCharge  = min($penaltyDue, $amount);

        $amountForSchedule = max(0.0, $amount - $penaltyCharge);

        // 1) DB yazmadan plan çıxar (seçim lazımdırsa, heç nə yazmadan geri dönək)
        $plan = ['items' => [], 'remainder' => 0];
        if ($amountForSchedule > 0) {
            $plan = $this->buildPlan($account, $opt, $paidDate, $amountForSchedule, null);
        }

        // Artıq məbləğ var və seçim verilməyib -> UI üçün sual qaytar
        if (($plan['remainder'] ?? 0) > 0.0001 && !$overpayAction) {
            $allowed = [];

            if ($opt->allow_overpayment && $opt->allow_advance_payment)        $allowed[] = 'apply_next_installments';
            if ($opt->allow_overpayment && $opt->allow_principal_only_payment) $allowed[] = 'reduce_principal';
            if ($opt->allow_overpayment)                                        $allowed[] = 'keep_as_credit';

            return [
                'needs_choice' => true,
                'remainder' => (float) $plan['remainder'],
                'allowed_actions' => $allowed,
                'message' => 'Ödənən məbləğ bu günə qədər ödənməli olan məbləğdən artıqdır. Artıq məbləğlə nə edək?',
            ];
        }

        // Seçim gəlibsə, planı ona görə yenilə
        if ($overpayAction && $amountForSchedule > 0) {
            if (!$opt->allow_overpayment) {
                throw ValidationException::withMessages(['amount' => 'Artıq ödənişə icazə verilmir.']);
            }
            $plan = $this->buildPlan($account, $opt, $paidDate, $amountForSchedule, $overpayAction);
        }

        // 2) Real tətbiq (transaction)
        return DB::transaction(function () use ($account, $user, $opt, $paidDate, $data, $plan, $overpayAction, $balanceDraw, $penaltyCharge) {

            // Account-u lock et (eyni anda iki ödəniş vurulmasın)
            $account = BhphAccount::query()
                ->where('id', $account->id)
                ->lockForUpdate()
                ->firstOrFail();

            // Balansdan istifadə (əgər varsa)
            $balanceDraw = max(0.0, $balanceDraw);
            if ($balanceDraw > 0.0001) {
                if (!isset($account->credit_balance)) {
                    throw ValidationException::withMessages([
                        'amount' => 'Balans sütunu tapılmadı (credit_balance).',
                    ]);
                }
                if ((float)$account->credit_balance + 0.0001 < $balanceDraw) {
                    throw ValidationException::withMessages([
                        'amount' => 'Balans kifayət etmir.',
                    ]);
                }
                $account->credit_balance = max(0.0, (float)$account->credit_balance - $balanceDraw);
            }

            // Plan edilən amort row-ları lock et
            $rowIds = collect($plan['items'] ?? [])->pluck('id')->all();
            $locked = [];

            if (!empty($rowIds)) {
                $locked = Amortization::query()
                    ->where('company_id', (int)$account->company_id)
                    ->where('bhph_account_id', (int)$account->id)
                    ->whereIn('id', $rowIds)
                    ->lockForUpdate()
                    ->get()
                    ->keyBy('id')
                    ->all();
            }

            $sumInterest  = 0.0;
            $sumPrincipal = 0.0;

            // 2.1) Planı amortization-a yaz
            foreach (($plan['items'] ?? []) as $it) {
                /** @var Amortization $row */
                $row = $locked[$it['id']] ?? null;
                if (!$row) continue;

                $pay = (float) $it['pay'];
                if ($pay <= 0) continue;

                $oldPaid = (float) $row->paid_amount;
                $newPaid = $oldPaid + $pay;

                $schedInterest = (float) ($row->interest_amount ?? $row->paid_interest ?? 0);
                $schedPrincipal = (float) ($row->principal_amount ?? $row->paid_principal ?? 0);

                // delta interest/principal hesabla (schedule breakdown əsasında)
                [$oldI, $oldP] = $this->allocForPaid(
                    $oldPaid,
                    $schedInterest,
                    $schedPrincipal,
                    (string)$opt->allocation_order
                );

                [$newI, $newP] = $this->allocForPaid(
                    $newPaid,
                    $schedInterest,
                    $schedPrincipal,
                    (string)$opt->allocation_order
                );

                $sumInterest  += max(0.0, $newI - $oldI);
                $sumPrincipal += max(0.0, $newP - $oldP);

                $row->paid_amount = $newPaid;
                $row->paid_interest = $newI;
                $row->paid_principal = $newP;
                $row->paid_date   = $paidDate; // son ödəniş tarixi kimi saxlayırıq
                $row->status      = $this->computeRowStatus($row);
                $row->save();
            }

            $remainder      = (float)($plan['remainder'] ?? 0);
            $extraPrincipal = 0.0;
            $noteAppend     = '';

            // 2.2) Artıq məbləğ davranışları
            if ($remainder > 0.0001) {

                if ($overpayAction === 'keep_as_credit') {
                    if (!$opt->allow_overpayment) {
                        throw ValidationException::withMessages(['amount' => 'Artıq ödəniş (overpayment) qadağandır.']);
                    }

                    // credit_balance sütunu yoxdursa, keep_as_credit işləyə bilməz
                    if (!isset($account->credit_balance)) {
                        throw ValidationException::withMessages([
                            'amount' => 'keep_as_credit üçün bhph_accounts.credit_balance sütunu lazımdır.',
                        ]);
                    }

                    $account->credit_balance = (float)$account->credit_balance + $remainder;
                    $noteAppend = ' | Kreditə yazıldı: '.number_format($remainder,2).' AZN';
                }

                if ($overpayAction === 'reduce_principal') {
                    if (!$opt->allow_principal_only_payment) {
                        throw ValidationException::withMessages(['overpay_action' => 'Yalniz esas borc odemesi baglidir.']);
                    }

                    if (!$opt->allow_overpayment) {
                        throw ValidationException::withMessages(['overpay_action' => 'Overpayment qadaqandir.']);
                    }

                    $leasing = LeasingOption::query()
                        ->where('company_id', (int)$account->company_id)
                        ->first();

                    if (!$leasing) {
                        throw ValidationException::withMessages(['overpay_action' => 'Leasing options yoxdur. reduce_principal ucun lazimdir.']);
                    }

                    // Novbeti unpaid taksit
                    $next = $account->amortizations()
                        ->whereColumn('paid_amount', '<', 'due_amount')
                        ->orderBy('installment_no')
                        ->first();

                    if ($next) {
                        $fromNo = (int)$next->installment_no;

                        // outstanding principal: əvvəlki taksitin remaining_balance-ı (yoxdursa financedPrincipal)
                        $prev = $account->amortizations()
                            ->where('installment_no', $fromNo - 1)
                            ->first();

                        $outstanding = $prev
                            ? (float)$prev->remaining_balance
                            : (float)$this->amortService->financedPrincipal($account);

                        $newOutstanding = max(0.0, $outstanding - $remainder);

                        // ⚠️ Bu metod səndə AmortizationService-də olmalıdır
                        // (mən sənə ayrıca vermişdim)
                        $this->amortService->rebuildRemainingScheduleAfterPrincipalReduction(
                            $account,
                            $leasing,
                            $fromNo,
                            $newOutstanding
                        );

                        // schedule totals yenilə (sadə yanaşma)
                        $account->total_interest_amount  = (float) $account->amortizations()->sum('interest_amount');
                        $account->total_principal_amount = (float) $account->amortizations()->sum('principal_amount');
                    }

                    $extraPrincipal = $remainder;
                    $noteAppend = ' | Əsas borcdan çıxıldı: '.number_format($remainder,2).' AZN';
                }

                // apply_next_installments: plan artıq gələcək taksitlərə paylayıb bitirməli idi.
                // Əgər yenə qalıbsa və schedule bitibsə -> kreditə atırıq (icazə varsa), yoxsa error.
                if ($overpayAction === 'apply_next_installments') {
                    if ($remainder > 0.0001) {
                        if ($opt->allow_overpayment && isset($account->credit_balance)) {
                            $account->credit_balance = (float)$account->credit_balance + $remainder;
                            $noteAppend = ' | Schedule bitdi, artıq məbləğ kreditə yazıldı: '.number_format($remainder,2).' AZN';
                        } else {
                            throw ValidationException::withMessages([
                                'amount' => 'Schedule bitdi, artıq məbləğ üçün keep_as_credit icazəsi yoxdur.',
                            ]);
                        }
                    }
                }
            }

            // 2.3) Payment record yaz
            $note = (string)($data['note'] ?? '');
            if ($penaltyCharge > 0.0001) {
                $noteAppend .= ' | Cərimə tutuldu: '.number_format($penaltyCharge,2).' AZN';
            }
            if ($noteAppend !== '') {
                $note = trim($note.' '.$noteAppend);
            }

            $cashComponent = max(0.0, (float)$data['amount'] - $balanceDraw);

            $method = (string)($data['method'] ?? Payment::METHOD_CASH);
            if (!in_array($method, [
                Payment::METHOD_CASH,
                Payment::METHOD_CARD,
                Payment::METHOD_BANK,
                Payment::METHOD_TRANSFER,
                Payment::METHOD_OTHER,
            ], true)) {
                $method = Payment::METHOD_CASH;
            }

            Payment::create([
                'company_id' => (int)$account->company_id,
                'bhph_account_id' => (int)$account->id,
                'received_by_user_id' => $user?->id,

                'paid_date' => $paidDate,
                'amount' => (float)$data['amount'],
                'currency' => 'AZN',

                'interest_amount' => (float)$sumInterest,
                'principal_amount' => (float)$sumPrincipal + (float)$extraPrincipal,
                'penalty_amount' => (float) $penaltyCharge,

                'method' => $method,
                'status' => Payment::STATUS_CONFIRMED,

                'reference' => $data['reference'] ?? null,
                'note' => $note ?: null,
            ]);

            // 2.4) Account remaining (schedule-dən)
            $totalDue  = (float) $account->amortizations()->sum('due_amount');
            $paidSched = (float) $account->amortizations()->sum('paid_amount');
            $account->remaining_amount = max(0.0, $totalDue - $paidSched);

            // 2.5) Account paid totals (payments-dən) - sənin istədiyin “tək mənbə”
            $sum = Payment::query()
                ->where('company_id', (int)$account->company_id)
                ->where('bhph_account_id', (int)$account->id)
                ->where('status', Payment::STATUS_CONFIRMED)
                ->selectRaw('
                    COALESCE(SUM(amount),0) as t,
                    COALESCE(SUM(interest_amount),0) as i,
                    COALESCE(SUM(principal_amount),0) as p,
                    COALESCE(SUM(penalty_amount),0) as pen
                ')
                ->first();

            $account->paid_total_amount     = (float)($sum->t ?? 0);
            $account->paid_interest_amount  = (float)($sum->i ?? 0);
            $account->paid_principal_amount = (float)($sum->p ?? 0);

            $account->save();

            $this->accountStatusService->syncStatus($account);

            return [
                'needs_choice' => false,
                'remainder' => 0,
            ];
        });
    }

    /**
     * ✅ Əsas düzəliş BURADADIR:
     * - Bazada seçilmiş allow_advance_payment=true olsa belə,
     *   gələcək aylara keçmək YALNIZ overpay_action=apply_next_installments olanda olacaq.
     * - Default tətbiq həmişə due_date <= paid_date olanlara gedir.
     */
    private function buildPlan(BhphAccount $account, PaymentOption $opt, string $paidDate, float $amount, ?string $overpayAction): array
    {
        // 1) ƏVVƏLCƏ yalnız bu günə qədər ödənməli olanlar (due_date <= paid_date)
        $dueQ = $account->amortizations()
            ->whereColumn('paid_amount', '<', 'due_amount')
            ->whereDate('due_date', '<=', $paidDate);

        if ($opt->apply_to === PaymentOption::APPLY_NEWEST_FIRST) {
            $dueQ->orderByDesc('due_date')->orderByDesc('installment_no');
        } else {
            // oldest_due_first default
            $dueQ->orderBy('due_date')->orderBy('installment_no');
        }

        $rows = $dueQ->get();

        // current_due_only -> yalnız 1 taksit
        if ($opt->apply_to === PaymentOption::APPLY_CURRENT_DUE_ONLY && $rows->count() > 1) {
            $rows = collect([$rows->first()]);
        }

        // Hissəvi ödəniş qadağandırsa: ilk due taksit tam ödənməlidir
        if (!$opt->allow_partial_payment && $rows->isNotEmpty()) {
            $r0 = $rows->first();
            $outstanding = max(0.0, (float)$r0->due_amount - (float)$r0->paid_amount);
            if ($amount + 0.0001 < $outstanding) {
                throw ValidationException::withMessages([
                    'amount' => 'Hissəvi ödəniş qadağandır. İlk taksit tam ödənməlidir: '.number_format($outstanding,2).' AZN',
                ]);
            }
        }

        // min partial (opsional)
        if ($opt->allow_partial_payment && $opt->min_partial_payment_amount !== null) {
            $min = (float)$opt->min_partial_payment_amount;
            if ($amount + 0.0001 < $min) {
                throw ValidationException::withMessages([
                    'amount' => 'Minimum hissəvi ödəniş: '.number_format($min,2).' AZN',
                ]);
            }
        }

        $items = [];
        $remain = $amount;

        // 2) Default apply (yalnız due olanlara)
        foreach ($rows as $r) {
            if ($remain <= 0.0001) break;

            $dueRem = max(0.0, (float)$r->due_amount - (float)$r->paid_amount);
            if ($dueRem <= 0.0001) continue;

            $pay = min($remain, $dueRem);
            $items[] = ['id' => (int)$r->id, 'pay' => (float)$pay];
            $remain -= $pay;
        }

        // 3) GƏLƏCƏK AYLARA KEÇİD YALNIZ apply_next_installments seçiləndə
        if ($overpayAction === 'apply_next_installments' && $remain > 0.0001) {

            if (!$opt->allow_advance_payment) {
                throw ValidationException::withMessages([
                    'overpay_action' => 'Qabaqcadan ödəniş (advance payment) bağlıdır.',
                ]);
            }
            if (!$opt->allow_overpayment) {
                throw ValidationException::withMessages([
                    'overpay_action' => 'Artıq ödəniş qadağandır.',
                ]);
            }

            $future = $account->amortizations()
                ->whereColumn('paid_amount', '<', 'due_amount')
                ->whereDate('due_date', '>', $paidDate)
                ->orderBy('due_date')
                ->orderBy('installment_no')
                ->get();

            foreach ($future as $r) {
                if ($remain <= 0.0001) break;

                $dueRem = max(0.0, (float)$r->due_amount - (float)$r->paid_amount);
                if ($dueRem <= 0.0001) continue;

                $pay = min($remain, $dueRem);
                $items[] = ['id' => (int)$r->id, 'pay' => (float)$pay];
                $remain -= $pay;
            }
        }

        // 4) Artıq məbləğ qaydaları
        if ($remain > 0.0001 && $overpayAction !== 'apply_next_installments') {
            if (!$opt->allow_overpayment) {
                throw ValidationException::withMessages([
                    'amount' => 'Artıq ödəniş (overpayment) qadağandır. Məbləği azalt.',
                ]);
            }

            $minOver = $opt->min_overpayment_amount;
            if ($minOver !== null && $remain + 0.0001 < (float) $minOver) {
                throw ValidationException::withMessages([
                    'amount' => 'Minimum overpayment: '.number_format((float)$minOver,2).' AZN',
                ]);
            }
        }

        return [
            'items' => $items,
            'remainder' => max(0.0, $remain),
        ];
    }

    private function allocForPaid(float $paid, float $schedInt, float $schedPrin, string $order): array
    {
        $paid = max(0.0, $paid);

        if ($order === PaymentOption::ALLOC_PRINCIPAL_THEN_INTEREST) {
            $p = min($paid, $schedPrin);
            $i = min(max(0.0, $paid - $p), $schedInt);
            return [$i, $p];
        }

        // default: interest_then_principal
        $i = min($paid, $schedInt);
        $p = min(max(0.0, $paid - $i), $schedPrin);
        return [$i, $p];
    }

    private function computeRowStatus(Amortization $row): string
    {
        $due = (float) $row->due_amount;
        $paid = (float) $row->paid_amount;

        $today = Carbon::now()->startOfDay();
        $dueDate = Carbon::parse($row->due_date)->startOfDay();

        if ($paid >= $due && $due > 0) return Amortization::STATUS_PAID;

        if ($paid > 0 && $paid < $due) {
            return ($dueDate->lt($today)) ? Amortization::STATUS_OVERDUE : Amortization::STATUS_PARTIAL;
        }

        return ($dueDate->lt($today)) ? Amortization::STATUS_OVERDUE : Amortization::STATUS_PENDING;
    }
}
