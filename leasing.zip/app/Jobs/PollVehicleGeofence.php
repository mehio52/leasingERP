<?php

namespace App\Jobs;

use App\Events\NotificationCreated;
use App\Models\Contract;
use App\Models\Customer;
use App\Models\Notification;
use App\Models\NotificationOption;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\Gps\GpsManager;
use App\Services\WhatsAppService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class PollVehicleGeofence implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 25;

    public function handle(GpsManager $gpsManager, WhatsAppService $wa): void
    {
        Vehicle::whereNotNull('traccar_device_id')
            ->where('geofence_enabled', true)
            ->whereNotNull('geofence_lat')
            ->whereNotNull('geofence_lng')
            ->whereNotNull('geofence_radius_m')
            ->chunkById(50, function ($vehicles) use ($gpsManager, $wa) {
                foreach ($vehicles as $vehicle) {
                    $this->checkVehicle($vehicle, $gpsManager, $wa);
                }
            });
    }

    private function checkVehicle(Vehicle $vehicle, GpsManager $gpsManager, WhatsAppService $wa): void
    {
        $company = $vehicle->company;
        if (!$company || $gpsManager->providerForCompany($company) !== 'traccar') {
            return;
        }

        $traccar = $gpsManager->traccarForCompany($company);
        if (!$traccar->isConfigured()) {
            return;
        }

        $pos = $traccar->getLastPosition((string) $vehicle->traccar_device_id);
        if (!$pos || $pos['latitude'] === null || $pos['longitude'] === null) {
            return;
        }

        $inside = $this->isInside(
            (float) $pos['latitude'],
            (float) $pos['longitude'],
            (float) $vehicle->geofence_lat,
            (float) $vehicle->geofence_lng,
            (int) $vehicle->geofence_radius_m
        );

        $currentState = $inside ? 'inside' : 'outside';
        $prevState = $vehicle->geofence_state;

        if (!$prevState) {
            $vehicle->geofence_state = $currentState;
            $vehicle->save();
            return;
        }

        if ($prevState !== $currentState) {
            if ($currentState === 'outside') {
                $this->handleExit($vehicle, $pos, $wa);
                $vehicle->geofence_last_exit_at = now();
                $vehicle->geofence_last_reminder_at = now();
            } else {
                $this->handleEnter($vehicle, $pos, $wa);
                $vehicle->geofence_last_enter_at = now();
                $vehicle->geofence_last_reminder_at = null;
            }
            $vehicle->geofence_state = $currentState;
            $vehicle->save();
            return;
        }

        if ($currentState === 'outside') {
            $this->handleReminder($vehicle, $pos, $wa);
        }
    }

    private function handleExit(Vehicle $vehicle, array $pos, WhatsAppService $wa): void
    {
        $opt = $this->loadOption($vehicle->company_id);
        $geofence = $opt?->settings['geofence'] ?? [];

        if (!empty($geofence['admin_panel'])) {
            $title = ___('Vehicle left alarm area');
            $body = $this->renderTemplate(
                $geofence['template_admin_exit'] ?? 'Vehicle {vehicle} ({plate}) left the alarm area. Lat:{lat} Lng:{lng} Radius:{radius}m',
                $vehicle,
                $pos
            );

            $notif = Notification::create([
                'company_id' => $vehicle->company_id,
                'sender_id' => null,
                'target_scope' => 'company',
                'title' => $title,
                'body' => $body,
                'data' => [
                    'type' => 'geofence_exit',
                    'vehicle_id' => $vehicle->id,
                    'lat' => $pos['latitude'] ?? null,
                    'lng' => $pos['longitude'] ?? null,
                ],
            ]);

            NotificationCreated::dispatch($notif);
        }

        if (!empty($geofence['admin_whatsapp'])) {
            $message = $this->renderTemplate(
                $geofence['template_admin_exit'] ?? 'Vehicle {vehicle} ({plate}) left the alarm area. Lat:{lat} Lng:{lng} Radius:{radius}m',
                $vehicle,
                $pos
            );
            $this->sendAdminWhatsApp($vehicle->company_id, $message, $wa);
        }
    }

    private function handleEnter(Vehicle $vehicle, array $pos, WhatsAppService $wa): void
    {
        $opt = $this->loadOption($vehicle->company_id);
        $geofence = $opt?->settings['geofence'] ?? [];

        if (empty($geofence['customer_enter_whatsapp'])) {
            return;
        }

        $customer = $this->resolveCustomer($vehicle);
        if (!$customer || !$this->validPhone($customer->phone) || !$customer->whatsapp_opt_in) {
            return;
        }

        $message = $this->renderTemplate(
            $geofence['template_customer_enter'] ?? 'Vehicle {vehicle} ({plate}) returned to the alarm area.',
            $vehicle,
            $pos,
            $customer
        );

        $this->sendCustomerWhatsApp($vehicle->company_id, $customer->phone, $message, $wa);
    }

    private function handleReminder(Vehicle $vehicle, array $pos, WhatsAppService $wa): void
    {
        $opt = $this->loadOption($vehicle->company_id);
        $geofence = $opt?->settings['geofence'] ?? [];

        if (empty($geofence['customer_reminder_whatsapp'])) {
            return;
        }

        $interval = (int) ($geofence['customer_reminder_interval_minutes'] ?? 60);
        $last = $vehicle->geofence_last_reminder_at;
        if ($last && $last->diffInMinutes(now()) < max(5, $interval)) {
            return;
        }

        $customer = $this->resolveCustomer($vehicle);
        if (!$customer || !$this->validPhone($customer->phone) || !$customer->whatsapp_opt_in) {
            return;
        }

        $message = $this->renderTemplate(
            $geofence['template_customer_reminder'] ?? 'Reminder: Vehicle {vehicle} ({plate}) is outside the alarm area. Lat:{lat} Lng:{lng}',
            $vehicle,
            $pos,
            $customer
        );

        $sent = $this->sendCustomerWhatsApp($vehicle->company_id, $customer->phone, $message, $wa);
        if ($sent) {
            $vehicle->geofence_last_reminder_at = now();
            $vehicle->save();
        }
    }

    private function loadOption(int $companyId): ?NotificationOption
    {
        return NotificationOption::firstOrCreate(
            ['company_id' => $companyId],
            ['is_active' => false, 'settings' => []]
        );
    }

    private function resolveCustomer(Vehicle $vehicle): ?Customer
    {
        $contract = Contract::query()
            ->where('company_id', $vehicle->company_id)
            ->where('vehicle_id', $vehicle->id)
            ->where('status', Contract::STATUS_ACTIVE)
            ->latest('id')
            ->first();

        return $contract?->customer;
    }

    private function sendAdminWhatsApp(int $companyId, string $message, WhatsAppService $wa): void
    {
        $opt = NotificationOption::where('company_id', $companyId)
            ->where('is_active', true)
            ->first();
        if (!$opt || !$opt->wp_api_secret) {
            return;
        }

        $users = User::where('company_id', $companyId)
            ->where(function ($q) {
                $q->where('role', 'owner')->orWhere('is_owner', true);
            })
            ->get();

        foreach ($users as $u) {
            if (!$this->validPhone($u->phone)) {
                continue;
            }
            $wa->send($opt, trim($u->phone), $message);
        }
    }

    private function sendCustomerWhatsApp(int $companyId, string $phone, string $message, WhatsAppService $wa): bool
    {
        $opt = NotificationOption::where('company_id', $companyId)
            ->where('is_active', true)
            ->first();
        if (!$opt || !$opt->wp_api_secret) {
            return false;
        }

        [$ok] = $wa->send($opt, trim($phone), $message);
        return (bool) $ok;
    }

    private function renderTemplate(string $template, Vehicle $vehicle, array $pos, ?Customer $customer = null): string
    {
        $company = $vehicle->company;
        $replacements = [
            '{vehicle}' => $vehicle->display_name ?? $vehicle->plate_number ?? $vehicle->id,
            '{plate}' => $vehicle->plate_number ?? '-',
            '{company}' => $company?->name ?? '-',
            '{lat}' => $pos['latitude'] ?? '-',
            '{lng}' => $pos['longitude'] ?? '-',
            '{radius}' => $vehicle->geofence_radius_m ?? '-',
            '{customer_name}' => $customer?->full_name ?? '-',
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $template);
    }

    private function validPhone(?string $phone): bool
    {
        $phone = trim((string) $phone);
        return $phone !== '' && $phone[0] === '+';
    }

    private function isInside(float $lat, float $lng, float $centerLat, float $centerLng, int $radiusM): bool
    {
        return $this->distanceMeters($lat, $lng, $centerLat, $centerLng) <= $radiusM;
    }

    private function distanceMeters(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $earth = 6371000.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2
            + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return $earth * $c;
    }
}
