<?php

namespace App\Jobs;

use App\Models\NotificationOption;
use App\Models\Customer;
use App\Models\WhatsAppCampaign;
use App\Services\SubscriptionService;
use App\Services\WhatsAppService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendWhatsAppCampaign implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1;
    public int $timeout = 120;

    public function __construct(public int $campaignId)
    {
    }

    public function handle(WhatsAppService $wa, SubscriptionService $subs): void
    {
        $campaign = WhatsAppCampaign::find($this->campaignId);
        if (!$campaign) {
            return;
        }

        $company = $campaign->company;
        if (!$company) {
            $campaign->update(['status' => 'failed']);
            return;
        }

        // Plan feature check (avoid sending if plan deactivates later)
        if (!$subs->hasFeature($company, 'whatsapp_campaigns')) {
            $campaign->update(['status' => 'failed', 'meta' => ['error' => 'feature_blocked']]);
            return;
        }

        $opt = NotificationOption::where('company_id', $company->id)
            ->where('is_active', true)
            ->first();

        if (!$opt || !$opt->wp_api_secret) {
            $campaign->update(['status' => 'failed', 'meta' => ['error' => 'missing_whatsapp_api']]);
            return;
        }

        $campaign->update(['status' => 'sending']);

        $sent = 0;
        $failed = 0;
        $total = 0;
        $lastError = null;
        $lastHttp = null;

        Customer::forCompany($company->id)
            ->whereNotNull('phone')
            ->chunkById(100, function ($customers) use (&$sent, &$failed, &$total, &$lastError, &$lastHttp, $wa, $opt, $campaign) {
                foreach ($customers as $customer) {
                    $phone = trim((string) $customer->phone);
                    $total++;
                    if ($phone === '' || $phone[0] !== '+') {
                        $failed++;
                        $lastError = 'invalid_phone';
                        continue;
                    }

                    [$ok, $resp, $http] = $wa->send($opt, $phone, $campaign->message);
                    if ($ok) {
                        $sent++;
                    } else {
                        $failed++;
                        $lastError = $resp['error'] ?? ($resp['status'] ?? 'send_failed');
                        $lastHttp = $http;
                    }
                }
            });

        if ($total === 0) {
            $campaign->update([
                'status' => 'failed',
                'meta' => ['error' => 'no_customers'],
            ]);
            return;
        }

        $campaign->update([
            'status' => $failed > 0 && $sent === 0 ? 'failed' : 'sent',
            'recipients_count' => $total,
            'sent_count' => $sent,
            'failed_count' => $failed,
            'last_sent_at' => now(),
            'meta' => $lastError ? ['error' => $lastError, 'http' => $lastHttp] : null,
        ]);
    }
}
