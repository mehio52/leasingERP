<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Artisan;

class RunForecastJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $companyId;
    public int $months;
    public string $metric;

    /**
     * @param int $companyId
     * @param int $months
     * @param string $metric
     */
    public function __construct(int $companyId, int $months = 6, string $metric = 'turnover')
    {
        $this->companyId = $companyId;
        $this->months = $months;
        $this->metric = $metric;
        $this->onQueue('analytics');
    }

    public function handle(): void
    {
        // Silence output; we rely on command to return gracefully.
        Artisan::call('analytics:forecast', [
            'company_id' => $this->companyId,
            '--months' => $this->months,
            '--metric' => $this->metric,
        ]);
    }
}
