<?php

namespace App\Jobs;

use App\Events\NotificationCreated;
use App\Models\Notification;
use App\Models\NotificationOption;
use App\Models\User;
use App\Models\VehicleAuthorization;
use App\Services\WhatsAppService;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class PollVehicleAuthorizationExpiry implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 20;

    public function handle(WhatsAppService $wa): void
    {
        VehicleAuthorization::query()
            ->whereNotNull('end_date')
            ->chunkById(200, function ($rows) use ($wa) {
                foreach ($rows as $auth) {
                    $this->checkAuthorization($auth, $wa);
                }
            });
    }

    private function checkAuthorization(VehicleAuthorization $auth, WhatsAppService $wa): void
    {
        $opt = $this->loadOption($auth->company_id);
        $settings = $opt?->settings['authorization'] ?? [];
        $daysBefore = (int) ($settings['days_before'] ?? 0);
        if ($daysBefore <= 0) {
            return;
        }

        $end = $auth->end_date ? Carbon::parse($auth->end_date)->startOfDay() : null;
        if (!$end) {
            return;
        }

        $today = now()->startOfDay();
        $daysRemaining = $today->diffInDays($end, false);
        if ($daysRemaining < 0 || $daysRemaining !== $daysBefore) {
            return;
        }

        if ($auth->last_notified_days === $daysRemaining) {
            return;
        }

        $vehicle = $auth->vehicle;
        $vehicleName = $vehicle?->display_name ?? ('#' . $auth->vehicle_id);
        $plate = $vehicle?->plate_number ?? '-';

        $template = $settings['template_admin_expire'] ?? 'Authorization for {person} ({vehicle} / {plate}) ends in {days} day(s). End: {end_date}';
        $message = $this->renderTemplate($template, $auth, $vehicleName, $plate, $daysRemaining, $end->toDateString());

        if (!empty($settings['admin_panel'])) {
            $notif = Notification::create([
                'company_id' => $auth->company_id,
                'sender_id' => null,
                'target_scope' => 'company',
                'title' => ___('Authorization expiring soon'),
                'body' => $message,
                'data' => [
                    'type' => 'authorization_expiring',
                    'vehicle_id' => $auth->vehicle_id,
                    'authorization_id' => $auth->id,
                    'end_date' => $end->toDateString(),
                    'days_remaining' => $daysRemaining,
                ],
            ]);

            NotificationCreated::dispatch($notif);
        }

        if (!empty($settings['admin_whatsapp'])) {
            $this->sendAdminWhatsApp($auth->company_id, $message, $wa);
        }

        $auth->last_notified_at = now();
        $auth->last_notified_days = $daysRemaining;
        $auth->save();
    }

    private function loadOption(int $companyId): ?NotificationOption
    {
        return NotificationOption::firstOrCreate(
            ['company_id' => $companyId],
            ['is_active' => false, 'settings' => []]
        );
    }

    private function sendAdminWhatsApp(int $companyId, string $message, WhatsAppService $wa): void
    {
        $opt = NotificationOption::where('company_id', $companyId)
            ->where('is_active', true)
            ->first();
        if (!$opt || !$opt->wp_api_secret) {
            return;
        }

        $users = User::where('company_id', $companyId)
            ->where(function ($q) {
                $q->where('role', 'owner')->orWhere('is_owner', true);
            })
            ->get();

        foreach ($users as $u) {
            if (!$this->validPhone($u->phone)) {
                continue;
            }
            $wa->send($opt, trim($u->phone), $message);
        }
    }

    private function renderTemplate(string $template, VehicleAuthorization $auth, string $vehicleName, string $plate, int $days, string $endDate): string
    {
        $replacements = [
            '{person}' => $auth->authorized_name ?? '-',
            '{vehicle}' => $vehicleName,
            '{plate}' => $plate,
            '{days}' => (string) $days,
            '{end_date}' => $endDate,
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $template);
    }

    private function validPhone(?string $phone): bool
    {
        $phone = trim((string) $phone);
        return $phone !== '' && $phone[0] === '+';
    }
}
