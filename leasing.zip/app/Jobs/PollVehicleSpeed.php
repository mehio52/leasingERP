<?php

namespace App\Jobs;

use App\Events\NotificationCreated;
use App\Models\Notification;
use App\Models\Vehicle;
use App\Services\Gps\GpsManager;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;

class PollVehicleSpeed implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 20;

    public function handle(GpsManager $gpsManager): void
    {
        Vehicle::whereNotNull('traccar_device_id')
            ->chunkById(50, function ($vehicles) use ($gpsManager) {
                foreach ($vehicles as $vehicle) {
                    $this->checkVehicle($vehicle, $gpsManager);
                }
            });
    }

    private function checkVehicle(Vehicle $vehicle, GpsManager $gpsManager): void
    {
        $company = $vehicle->company;
        if (!$company || $gpsManager->providerForCompany($company) !== 'traccar') {
            return;
        }

        $traccar = $gpsManager->traccarForCompany($company);
        if (!$traccar->isConfigured()) {
            return;
        }

        // limit mənbəyi: Traccar device attributes -> speedLimit, tapılmazsa default (km/saat)
        $device = $traccar->findDeviceByUniqueId((string) $vehicle->traccar_device_id) ?? [];
        $attrs = $device['attributes'] ?? [];
        $limit = $attrs['speedLimit'] ?? config('services.traccar.default_speed_limit', env('TRACCAR_DEFAULT_SPEED_LIMIT', null));
        if (!$limit) {
            return;
        }

        $pos = $traccar->getLastPosition((string) $vehicle->traccar_device_id);
        if (!$pos || $pos['speed'] === null) {
            return;
        }

        // Traccar speed dəyəri knotta olur; km/saat-a çevirək
        $speedKph = round(((float) $pos['speed']) * 1.852, 2);
        if ($speedKph <= (float) $limit) {
            return;
        }

        // təkrar bildirişin qarşısını alaq (10 dəq)
        $cacheKey = 'overspeed:vehicle:' . $vehicle->id;
        if (Cache::get($cacheKey)) {
            return;
        }
        Cache::put($cacheKey, now()->timestamp, now()->addMinutes(10));

        $title = ___('Speed limit exceeded');
        $body = ___(':vehicle sürət limitini aşdı. Limit: :limit km/s, sürət: :speed km/s. Yer: :lat,:lng', [
            'vehicle' => $vehicle->display_name ?? $vehicle->plate_number ?? $vehicle->id,
            'limit' => $limit,
            'speed' => $speedKph,
            'lat' => $pos['latitude'] ?? '—',
            'lng' => $pos['longitude'] ?? '—',
        ]);

        $notif = Notification::create([
            'company_id' => $vehicle->company_id,
            'sender_id' => null,
            'target_scope' => 'company',
            'title' => $title,
            'body' => $body,
            'data' => [
                'type' => 'overspeed',
                'vehicle_id' => $vehicle->id,
                'speed_kph' => $speedKph,
                'limit_kph' => $limit,
                'lat' => $pos['latitude'] ?? null,
                'lng' => $pos['longitude'] ?? null,
            ],
        ]);

        NotificationCreated::dispatch($notif);
    }
}
