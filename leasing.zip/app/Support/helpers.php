<?php

use Illuminate\Support\Str;

if (!function_exists('normalizeAzPhone')) {
    /**
     * Azərbaycan nömrəsini E.164 formatına çevirir: +994XXXXXXXXX
     *
     * Qəbul edir:
     *  - 0501234567
     *  - 501234567
     *  - 994501234567
     *  - +994501234567
     *  - 00 994 50 123 45 67
     *
     * Qaytarır: +994501234567
     * Uğursuz olsa: null
     */
    function normalizeAzPhone(?string $input): ?string
    {
        $input = trim((string) $input);
        if ($input === '') return null;

        // yalnız rəqəmlər + başlanğıcda + saxla
        $hasPlus = str_starts_with($input, '+');

        $digits = preg_replace('/\D+/', '', $input); // hamısını rəqəmə çevir
        if ($digits === '') return null;

        // 00 ilə başlayırsa (00 994...) -> 994 kimi götür
        if (str_starts_with($digits, '00')) {
            $digits = substr($digits, 2);
        }

        // artıq +994... formatında ola bilər
        if ($hasPlus && str_starts_with($digits, '994')) {
            // ok
        }

        // 994... (plus olmadan)
        if (str_starts_with($digits, '994')) {
            $digits = '994' . substr($digits, 3);
        }
        // 0 ilə başlayan local (050...)
        elseif (str_starts_with($digits, '0')) {
            $digits = '994' . substr($digits, 1);
        }
        // 9 rəqəmli local (501234567)
        elseif (strlen($digits) === 9) {
            $digits = '994' . $digits;
        } else {
            // başqa format - qəbul etmirik
            return null;
        }

        // AZ üçün standart uzunluq: 994 + 9 rəqəm = 12 rəqəm
        if (!preg_match('/^994\d{9}$/', $digits)) {
            return null;
        }

        return '+' . $digits;
    }
}

if (!function_exists('___')) {
    /**
     * Qısa tərcümə helper-i. Məs: {{ ___('hello world') }}
     * - app.{slug} açarını yoxlayır, tapmasa mətni olduğu kimi qaytarır.
     */
    function ___(string $text, array $replace = [], ?string $locale = null): string
    {
        $key = 'app.' . Str::slug($text, '_');
        if (\Illuminate\Support\Facades\Lang::has($key, $locale)) {
            return \Illuminate\Support\Facades\Lang::get($key, $replace, $locale);
        }

        // Əgər açar tapılmadısa, cari dil faylına avtomatik əlavə et (app.php)
        $loc = $locale ?? app()->getLocale();
        saveMissingTranslation($loc, $key, $text);

        // Fallback dilə də əlavə et (məs: en)
        $fallback = config('app.fallback_locale', 'en');
        if ($fallback !== $loc) {
            saveMissingTranslation($fallback, $key, $text);
        }

        return \Illuminate\Support\Facades\Lang::get($text, $replace, $locale);
    }
}

if (!function_exists('saveMissingTranslation')) {
    function saveMissingTranslation(string $locale, string $dotKey, string $value): void
    {
        // yalnız app.* açarları üçün
        if (!str_starts_with($dotKey, 'app.')) {
            return;
        }

        $key = substr($dotKey, 4);
        $path = resource_path("lang/{$locale}/app.php");
        if (!is_dir(dirname($path))) {
            @mkdir(dirname($path), 0777, true);
        }

        $existing = [];
        if (file_exists($path)) {
            $existing = include $path;
            if (!is_array($existing)) {
                $existing = [];
            }
        }

        if (array_key_exists($key, $existing)) {
            return; // artıq var
        }

        $existing[$key] = $value;
        $export = var_export($existing, true);
        $content = "<?php\n\nreturn {$export};\n";
        @file_put_contents($path, $content);
    }
}
