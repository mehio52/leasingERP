<?php

namespace App\Events;

use App\Models\Notification;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class NotificationCreated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Notification $notification;

    public function __construct(Notification $notification)
    {
        $this->notification = $notification;
    }

    public function broadcastOn(): array
    {
        $channels = [];
        if ($this->notification->target_scope === 'user' && $this->notification->target_user_id) {
            $channels[] = new PrivateChannel('notifications.'.$this->notification->target_user_id);
        }
        if ($this->notification->target_scope === 'company' && $this->notification->company_id) {
            $channels[] = new PrivateChannel('company.'.$this->notification->company_id);
        }
        if ($this->notification->target_scope === 'role' && $this->notification->target_role) {
            $channels[] = new PrivateChannel('role.'.$this->notification->target_role);
        }
        if ($this->notification->target_scope === 'global') {
            $channels[] = new Channel('global.notifications');
        }
        return $channels;
    }

    public function broadcastWith(): array
    {
        return [
            'id' => $this->notification->id,
            'title' => $this->notification->title,
            'body' => $this->notification->body,
            'data' => $this->notification->data,
            'read_at' => $this->notification->read_at,
            'created_at' => optional($this->notification->created_at)->toIso8601String(),
        ];
    }
}
