<?php

namespace App\Console\Commands;

use App\Models\AnalyticsForecast;
use App\Models\Payment;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;

class RunAnalyticsForecast extends Command
{
    protected $signature = 'analytics:forecast {company_id} {--months=6} {--metric=turnover}';
    protected $description = 'Run Prophet-based forecast for a company and store results.';

    public function handle(): int
    {
        $companyId = (int) $this->argument('company_id');
        $months = (int) $this->option('months');
        $metric = (string) $this->option('metric');

        if ($months < 1) {
            $this->error('Months must be positive.');
            return self::FAILURE;
        }

        // Source data: confirmed payments as turnover
        $dateExpr = DB::raw("COALESCE(payments.paid_date, payments.created_at)");
        $confirmedStatus = defined(Payment::class . '::STATUS_CONFIRMED') ? Payment::STATUS_CONFIRMED : 'confirmed';

        $rows = Payment::query()
            ->selectRaw("DATE($dateExpr) as ds, COALESCE(SUM(payments.amount),0) as y")
            ->join('bhph_accounts as a', function ($join) use ($companyId) {
                $join->on('a.id', '=', 'payments.bhph_account_id')
                    ->where('a.company_id', $companyId)
                    ->whereNull('a.deleted_at');
            })
            ->where('payments.status', $confirmedStatus)
            ->groupBy('ds')
            ->orderBy('ds')
            ->get()
            ->map(fn ($r) => ['ds' => $r->ds, 'y' => (float) $r->y])
            ->values()
            ->all();

        if (empty($rows)) {
            $this->warn('No data to forecast.');
            return self::SUCCESS;
        }

        $python = env('ANALYTICS_PYTHON', '/opt/prophet-env/bin/python');
        if (!is_file($python)) {
            $python = 'python3';
        }

        $scriptPath = base_path('resources/python/forecast_prophet.py');
        if (!is_file($scriptPath)) {
            $this->error('Python script not found: ' . $scriptPath);
            return self::FAILURE;
        }

        $tmpDir = storage_path('app/analytics');
        if (!is_dir($tmpDir)) {
            @mkdir($tmpDir, 0775, true);
        }
        $inputFile = $tmpDir . '/input_' . $companyId . '_' . uniqid() . '.json';
        $outputFile = $tmpDir . '/output_' . $companyId . '_' . uniqid() . '.json';

        file_put_contents($inputFile, json_encode([
            'data' => $rows,
            'months' => $months,
        ]));

        $process = new Process([$python, $scriptPath, $inputFile, $outputFile]);
        $process->setTimeout(180);
        $process->run();

        if (!$process->isSuccessful()) {
            @unlink($inputFile);
            @unlink($outputFile);
            throw new ProcessFailedException($process);
        }

        if (!is_file($outputFile)) {
            $this->error('No output file produced.');
            return self::FAILURE;
        }

        $json = json_decode(file_get_contents($outputFile), true);
        @unlink($inputFile);
        @unlink($outputFile);

        if (empty($json['forecast'])) {
            $this->warn('No forecast rows returned.');
            return self::SUCCESS;
        }

        foreach ($json['forecast'] as $row) {
            AnalyticsForecast::updateOrCreate(
                [
                    'company_id' => $companyId,
                    'metric' => $metric,
                    'period' => 'monthly',
                    'forecast_date' => $row['ds'] ?? null,
                ],
                [
                    'value' => $row['yhat'] ?? 0,
                    'meta' => [
                        'yhat_lower' => $row['yhat_lower'] ?? null,
                        'yhat_upper' => $row['yhat_upper'] ?? null,
                        'model' => 'prophet',
                    ],
                ]
            );
        }

        $this->info('Forecast saved for company ' . $companyId);
        return self::SUCCESS;
    }
}
