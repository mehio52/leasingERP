<?php

namespace App\Console\Commands;

use App\Models\BhphAccount;
use App\Services\AccountStatusService;
use Illuminate\Console\Command;

class SyncOverdueAccounts extends Command
{
    protected $signature = 'accounts:sync-overdue';
    protected $description = 'Overdue və active hesabların statuslarını cari amortizasiya tarixlərinə görə yoxlayır.';

    public function __construct(private AccountStatusService $statusService)
    {
        parent::__construct();
    }

    public function handle(): int
    {
        $total = 0;
        $updated = 0;

        BhphAccount::query()
            ->whereIn('status', [
                BhphAccount::STATUS_ACTIVE,
                BhphAccount::STATUS_OVERDUE,
            ])
            ->orderBy('id')
            ->chunkById(200, function ($accounts) use (&$total, &$updated) {
                foreach ($accounts as $account) {
                    $total++;
                    if ($this->statusService->syncStatus($account)) {
                        $updated++;
                    }
                }
            });

        $this->info(sprintf('%d/%d hesabın statusu yeniləndi.', $updated, $total));
        return self::SUCCESS;
    }
}
