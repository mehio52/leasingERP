<?php

namespace App\Console\Commands;

use App\Models\BhphAccount;
use App\Models\NotificationLog;
use App\Models\NotificationOption;
use App\Models\PenaltyOption;
use App\Services\PenaltyService;
use Carbon\Carbon;
use Illuminate\Console\Command;

class SendCompanyNotifications extends Command
{
    protected $signature = 'notifications:send';
    protected $description = 'Aktiv bildiriÅŸ ayarlarÄ± olan ÅŸirkÉ™tlÉ™r Ã¼Ã§Ã¼n WhatsApp bildiriÅŸlÉ™rini gÃ¶ndÉ™r';

    public function __construct(private PenaltyService $penaltyService)
    {
        parent::__construct();
    }

    public function handle(): int
    {
        $options = NotificationOption::query()
            ->where('is_active', true)
            ->get();

        if ($options->isEmpty()) {
            $this->info('Aktiv bildiriÅŸ ayarÄ± yoxdur.');
            return self::SUCCESS;
        }

        foreach ($options as $opt) {
            $this->sendForCompany($opt);
        }

        return self::SUCCESS;
    }

    protected function sendForCompany(NotificationOption $opt): void
    {
        if (!$this->shouldSendForOption($opt)) {
            $this->line("Şirkət #{$opt->company_id}: göndərilmə planı bu vaxt üçün uyğun deyil.");
            return;
        }
        $companyId = $opt->company_id;
        $penalty = PenaltyOption::query()->where('company_id', $companyId)->first();

        $accounts = BhphAccount::query()
            ->where('company_id', $companyId)
            ->where('status', BhphAccount::STATUS_OVERDUE)
            ->with(['customer'])
            ->get();

        if ($accounts->isEmpty()) {
            $this->line("ÅžirkÉ™t #{$companyId}: gecikmiÅŸ hesab yoxdur.");
            $this->recordScheduleSent($opt);
            return;
        }

        foreach ($accounts as $acc) {
            $customer = $acc->customer;
            $phone = trim((string)($customer->phone ?? ''));
            if ($phone === '' || $phone[0] !== '+') {
                $this->warn("Hesab #{$acc->id}: telefon uyÄŸun deyil, Ã¶tÃ¼rÃ¼lÃ¼r.");
                $this->log($opt->company_id, $acc->id, $customer?->id, $phone, 'skipped', 'invalid_phone', null, null, null);
                continue;
            }

            $summary = $this->penaltyService->summarizeAccount($acc);
            $options = $summary['options'] ?? $penalty;
            $penaltyAmount = (float) ($summary['total_accrued'] ?? 0);
            $remainingAmount = (float) ($acc->remaining_amount ?? $acc->balance ?? 0);
            $totalDueValue = max(0.0, $remainingAmount + $penaltyAmount);

            $payload = [
                'customer_name' => trim(($customer->first_name ?? '') . ' ' . ($customer->last_name ?? '')),
                'days_overdue' => $this->guessDaysOverdue($acc),
                'penalty_type' => $options?->penalty_type ?? '-',
                'penalty_value' => $this->formatMoney($options?->penalty_value ?? 0),
                'penalty_frequency' => $options?->penalty_frequency ?? '-',
                'apply_on' => $options?->apply_on ?? '-',
                'penalty_cap_amount' => $this->formatMoney($options?->penalty_cap_amount, true),
                'penalty_cap_percent' => $this->formatMoney($options?->penalty_cap_percent, true),
                'penalty_amount' => $this->formatMoney($penaltyAmount),
                'total_due' => $this->formatMoney($totalDueValue),
                'amount_due' => $this->formatMoney($remainingAmount),
                'account_id' => $acc->id,
            ];

            $message = $this->renderTemplate($opt->template_overdue ?? 'HÃ¶rmÉ™tli {customer_name}, hesabÄ±nÄ±z {days_overdue} gÃ¼ndÃ¼r gecikir.', $payload);

            [$sent, $resp, $http] = $this->sendWhatsApp($opt, $phone, $message);
            if ($sent) {
                $this->info("GÃ¶ndÉ™rildi: hesab #{$acc->id} -> {$phone}");
                $this->log($opt->company_id, $acc->id, $customer?->id, $phone, 'sent', null, $message, $resp, $resp['status'] ?? null);
            } else {
                $reason = 'http_'.$http;
                $this->error("AlÄ±nmadÄ±: hesab #{$acc->id} -> {$phone}");
                $this->log($opt->company_id, $acc->id, $customer?->id, $phone, 'failed', $reason, $message, $resp, $resp['status'] ?? null);
            }
        }

        $this->recordScheduleSent($opt);
    }

    protected function shouldSendForOption(NotificationOption $opt): bool
    {
        $schedule = $opt->settings['schedule'] ?? [];
        $interval = max(5, (int) ($schedule['interval_minutes'] ?? 60));
        $lastSent = isset($schedule['last_sent_at']) ? Carbon::parse($schedule['last_sent_at']) : null;

        $now = now();
        if ($lastSent && $now->lessThan($lastSent->copy()->addMinutes($interval))) {
            return false;
        }

        $ranges = $schedule['allowed_time_ranges'] ?? [];
        if (empty($ranges)) {
            return true;
        }

        $nowMinutes = $now->hour * 60 + $now->minute;
        foreach ($ranges as $range) {
            $parts = array_map('trim', explode('-', $range));
            if (count($parts) !== 2) {
                continue;
            }

            $startMinutes = $this->timeToMinutes($parts[0]);
            $endMinutes = $this->timeToMinutes($parts[1]);
            if ($startMinutes === null || $endMinutes === null) {
                continue;
            }

            if ($startMinutes <= $endMinutes) {
                if ($nowMinutes >= $startMinutes && $nowMinutes < $endMinutes) {
                    return true;
                }
            } else {
                if ($nowMinutes >= $startMinutes || $nowMinutes < $endMinutes) {
                    return true;
                }
            }
        }

        return false;
    }

    protected function recordScheduleSent(NotificationOption $opt): void
    {
        $settings = $opt->settings ?? [];
        $schedule = $settings['schedule'] ?? [];
        $schedule['last_sent_at'] = now()->toIso8601String();
        $settings['schedule'] = $schedule;
        $opt->settings = $settings;
        $opt->saveQuietly();
    }

    protected function timeToMinutes(string $value): ?int
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $parts = explode(':', $value);
        if (count($parts) < 2) {
            return null;
        }

        $hour = (int) $parts[0];
        $minute = (int) $parts[1];
        if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
            return null;
        }

        return $hour * 60 + $minute;
    }

    protected function guessDaysOverdue(BhphAccount $acc): int
    {
        $installment = $acc->amortizations()
            ->whereColumn('paid_amount', '<', 'due_amount')
            ->whereNotNull('due_date')
            ->whereDate('due_date', '<', Carbon::now()->toDateString())
            ->orderBy('due_date')
            ->orderBy('installment_no')
            ->first();

        if (!$installment || !$installment->due_date) {
            return 0;
        }

        $dueDate = Carbon::parse($installment->due_date)->startOfDay();
        $today = Carbon::now()->startOfDay();

        if ($dueDate->greaterThan($today)) {
            return 0;
        }

        return $dueDate->diffInDays($today);
    }

    protected function formatMoney(mixed $value, bool $allowEmpty = false): string
    {
        if ($value === null || $value === '') {
            return $allowEmpty ? '' : '0.00';
        }

        return number_format((float)$value, 2, '.', '');
    }

    protected function renderTemplate(string $tpl, array $data): string
    {
        $out = $tpl;
        foreach ($data as $k => $v) {
            $out = str_replace('{' . $k . '}', (string)$v, $out);
        }
        return $out;
    }

    protected function sendWhatsApp(NotificationOption $opt, string $phone, string $message): array
    {
        $url = $opt->wp_api_url ?: 'https://whatsotp.az/api/send/otp';
        $fields = [
            'secret' => $opt->wp_api_secret,
            'type' => 'whatsapp',
            'message' => $message,
            'phone' => $phone,
        ];
        if ($opt->wp_api_key) {
            $fields['account'] = $opt->wp_api_key;
            $fields['priority'] = 1;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $fields,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
        ]);

        $resp = curl_exec($ch);
        if ($resp === false) {
            $err = curl_error($ch);
            $this->error('cURL error: ' . $err);
            curl_close($ch);
            return [false, ['error' => $err], 0];
        }
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $data = json_decode($resp, true);
        $status = (int)($data['status'] ?? 0);
        return [($http === 200 && $status === 200), ($data ?: ['raw' => $resp]), $http];
    }

    protected function log(int $companyId, ?int $accountId, ?int $customerId, ?string $phone, string $status, ?string $reason, ?string $message, $response, $providerStatus): void
    {
        NotificationLog::create([
            'company_id' => $companyId,
            'bhph_account_id' => $accountId,
            'customer_id' => $customerId,
            'phone' => $phone,
            'status' => $status,
            'reason' => $reason,
            'message' => $message,
            'response' => $response,
            'provider_status' => $providerStatus,
            'sent_at' => now(),
        ]);
    }
}
