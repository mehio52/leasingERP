<?php

namespace App\Console\Commands;

use App\Models\EpointTransaction;
use Illuminate\Console\Command;

class ExpirePendingGatewayTransactions extends Command
{
    protected $signature = 'payments:expire-pending {--minutes=}';
    protected $description = 'Mark stale pending gateway transactions as failed.';

    public function handle(): int
    {
        $defaultMinutes = (int) config('services.payment_gateway.pending_ttl_minutes', 120);
        $minutes = (int) ($this->option('minutes') ?? $defaultMinutes);
        if ($minutes <= 0) {
            $minutes = 120;
        }

        $cutoff = now()->subMinutes($minutes);

        $query = EpointTransaction::query()
            ->where('status', EpointTransaction::STATUS_PENDING)
            ->whereIn('type', [
                EpointTransaction::TYPE_PLAN,
                EpointTransaction::TYPE_ADDON,
                EpointTransaction::TYPE_LOAN_PAYMENT,
                EpointTransaction::TYPE_PAYOUT_CARD,
            ])
            ->where('created_at', '<', $cutoff);

        $count = (clone $query)->count();

        if ($count > 0) {
            $query->update([
                'status' => EpointTransaction::STATUS_FAILED,
                'message' => 'Expired (no payment confirmation).',
                'processed_at' => now(),
            ]);
        }

        $this->info("Expired {$count} pending transactions.");

        return Command::SUCCESS;
    }
}
