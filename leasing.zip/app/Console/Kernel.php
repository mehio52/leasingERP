<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        // Gecikmiş hesablar üçün WA bildirişləri
        $schedule->command('notifications:send')
            ->everyThirtyMinutes()
            ->withoutOverlapping()
            ->onOneServer();

        // Hesab statuslarını overdue/active olaraq yenilə
        $schedule->command('accounts:sync-overdue')
            ->everyThirtyMinutes()
            ->withoutOverlapping()
            ->onOneServer();

        // Traccar sürət aşımlarını polling ilə yoxla
        $schedule->job(new \App\Jobs\PollVehicleSpeed())
            ->everyFiveMinutes()
            ->withoutOverlapping()
            ->onOneServer();

        // Prophet forecast: plan və ya aktiv addon analytics/advanced_reports varsa
        $companyIds = \App\Models\Company::query()
            ->where(function ($q) {
                $q->whereJsonContains('settings->features->advanced_reports', true)
                    ->orWhereJsonContains('settings->features->analytics', true)
                    ->orWhereIn('id', function ($sub) {
                        $sub->select('company_id')
                            ->from('subscription_addons')
                            ->where(function ($s) {
                                $s->whereNull('ends_at')->orWhere('ends_at', '>', now());
                            });
                    });
            })
            ->pluck('id');

        foreach ($companyIds as $cid) {
            $schedule->command('analytics:forecast', [
                'company_id' => $cid,
                '--months' => 6,
                '--metric' => 'turnover',
            ])->dailyAt('03:15')->withoutOverlapping()->onOneServer();
        }

        // Expire stale pending gateway transactions
        $schedule->command('payments:expire-pending')
            ->hourly()
            ->withoutOverlapping()
            ->onOneServer();
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__ . '/Commands');
    }
}
