<?php

namespace App\Http\Controllers;

use App\Models\BhphAccount;
use App\Models\DocumentTemplate;
use App\Services\DocumentAutomationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class DocumentTemplateController extends Controller
{
    public function __construct(private DocumentAutomationService $automationService)
    {
    }

    public function index(Request $request)
    {
        $companyId = (int) $request->user()?->company_id;
        $templates = DocumentTemplate::query()
            ->where('company_id', $companyId)
            ->orderByDesc('created_at')
            ->get();
        $accounts = BhphAccount::query()
            ->with('customer')
            ->where('company_id', $companyId)
            ->orderByDesc('id')
            ->limit(50)
            ->get();

        return view('company.document_templates.index', compact('templates', 'accounts'));
    }

    public function store(Request $request)
    {
        $companyId = (int) $request->user()?->company_id;
        $data = $request->validate([
            'name' => ['required','string','max:191'],
            'description' => ['nullable','string','max:400'],
            'contract_type' => ['required','in:two,three'],
            'file' => ['required','file','mimes:txt,doc,docx,pdf'],
        ]);

        $path = $request->file('file')->store('document_templates');
        $keywords = $this->automationService->keywordList();

        DocumentTemplate::create([
            'company_id' => $companyId,
            'uploaded_by_user_id' => $request->user()->id,
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'file_path' => $path,
            'keywords' => $keywords ?: null,
            'is_active' => true,
            'contract_type' => $data['contract_type'],
        ]);

        return redirect()->route('company.document_templates.index')
            ->with('status', 'Template uploaded.');
    }

    public function destroy(DocumentTemplate $template, Request $request)
    {
        $companyId = (int) $request->user()?->company_id;
        abort_unless($template->company_id === $companyId, 403);

        if ($template->file_path) {
            Storage::delete($template->file_path);
        }
        $template->delete();

        return redirect()->route('company.document_templates.index')
            ->with('status', 'Template deleted.');
    }

    public function preview(DocumentTemplate $template, BhphAccount $account, DocumentAutomationService $service)
    {
        $companyId = request()->user()->company_id;
        abort_if($template->company_id !== $companyId || $account->company_id !== $companyId, 403);

        $extension = pathinfo($template->file_path, PATHINFO_EXTENSION) ?: 'docx';
        $filename = Str::slug($template->name ?: 'document', '-') . '-' . $account->id . '-' . now()->format('YmdHis') . '.' . $extension;

        $content = $service->render($template, $account);
        if ($content === '') {
            return Storage::download($template->file_path, $filename);
        }

        return Response::streamDownload(function () use ($content) {
            echo $content;
        }, $filename, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ]);
    }
}
