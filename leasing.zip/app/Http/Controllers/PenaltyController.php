<?php

namespace App\Http\Controllers;

use App\Models\BhphAccount;
use App\Services\PenaltyService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PenaltyController extends Controller
{
    public function __construct(private PenaltyService $penaltyService) {}

    public function index(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId, 403, 'User şirkətlə bağlı deyil.');

        $q = trim((string) $request->query('q', ''));
        $showAll = (bool) $request->boolean('show_all', false);

        $accounts = BhphAccount::query()
            ->where('company_id', $companyId)
            ->with(['customer','vehicle'])
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($w) use ($q) {
                    if (ctype_digit($q)) {
                        $w->orWhere('id', (int) $q);
                    }

                    $w->orWhereHas('customer', function ($c) use ($q) {
                        $c->where('first_name', 'like', "%{$q}%")
                          ->orWhere('last_name', 'like', "%{$q}%")
                          ->orWhere('father_name', 'like', "%{$q}%")
                          ->orWhere('phone', 'like', "%{$q}%");
                    });

                    $w->orWhereHas('vehicle', function ($v) use ($q) {
                        $v->where('brand', 'like', "%{$q}%")
                          ->orWhere('model', 'like', "%{$q}%")
                          ->orWhere('plate_number', 'like', "%{$q}%");
                    });
                });
            })
            ->latest('id')
            ->get();

        $rows = [];
        $totals = ['accrued' => 0.0, 'paid' => 0.0, 'outstanding' => 0.0];

        foreach ($accounts as $account) {
            $summary = $this->penaltyService->summarizeAccount($account, Carbon::now());

            $accrued = (float) ($summary['total_accrued'] ?? 0);
            $paid = (float) ($summary['total_paid'] ?? 0);
            $outstanding = (float) ($summary['outstanding'] ?? 0);

            if (!$showAll && $accrued <= 0 && $outstanding <= 0) {
                continue;
            }

            $rows[] = [
                'account' => $account,
                'summary' => $summary,
            ];

            $totals['accrued'] += $accrued;
            $totals['paid'] += $paid;
            $totals['outstanding'] += $outstanding;
        }

        return view('penalties.index', [
            'user' => $user,
            'rows' => $rows,
            'q' => $q,
            'totals' => $totals,
            'showAll' => $showAll,
        ]);
    }
}
