<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ImpersonationController extends Controller
{
    public function start(Request $request, User $user)
    {
        $current = $request->user();
        if (!$current) {
            abort(403);
        }

        $isSuper = method_exists($current, 'isSuperAdmin')
            ? $current->isSuperAdmin()
            : ($current->role === 'superadmin');

        if (!$isSuper) {
            if (!($current->is_owner || $current->role === 'owner')) {
                abort(403);
            }
            if ((int) $current->company_id !== (int) $user->company_id) {
                abort(403);
            }
            if ($user->is_owner || $user->role === 'owner') {
                abort(403, 'Cannot impersonate owner accounts.');
            }
        }

        if ($current->id === $user->id) {
            return back()->with('error', 'You are already logged in as this user.');
        }

        session(['impersonator_id' => $current->id]);
        Auth::login($user);
        $request->session()->regenerate();

        return redirect()->route('dashboard')->with('status', 'Impersonation started as ' . $user->full_name);
    }

    public function stop(Request $request)
    {
        $impersonatorId = session()->pull('impersonator_id');
        if ($impersonatorId) {
            $orig = User::find($impersonatorId);
            if ($orig) {
                Auth::login($orig);
                $request->session()->regenerate();
                return redirect()->route('dashboard')->with('status', 'Impersonation stopped.');
            }
        }

        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
