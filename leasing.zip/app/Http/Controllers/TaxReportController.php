<?php

namespace App\Http\Controllers;

use App\Models\TaxReport;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TaxReportController extends Controller
{
    public function index(Request $request)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $reports = TaxReport::forCompany($company->id)
            ->orderByDesc('period_end')
            ->orderByDesc('id')
            ->paginate(12)
            ->withQueryString();

        return view('taxes.index', compact('reports'));
    }

    public function store(Request $request)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $data = $request->validate([
            'period_start' => ['nullable','date'],
            'period_end'   => ['nullable','date','after_or_equal:period_start'],
            'gross_revenue' => ['required','numeric','min:0'],
            'deductible_expenses' => ['required','numeric','min:0'],
            'tax_rate' => ['required','numeric','min:0','max:100'],
            'note' => ['nullable','string','max:255'],
        ]);

        $taxable = (float)$data['gross_revenue'] - (float)$data['deductible_expenses'];
        if ($taxable < 0) $taxable = 0;
        $taxAmount = $taxable * ((float)$data['tax_rate'] / 100);

        TaxReport::create([
            'company_id' => $company->id,
            'period_start' => $data['period_start'] ?? null,
            'period_end' => $data['period_end'] ?? null,
            'gross_revenue' => $data['gross_revenue'],
            'deductible_expenses' => $data['deductible_expenses'],
            'taxable_income' => $taxable,
            'tax_rate' => $data['tax_rate'],
            'tax_amount' => $taxAmount,
            'note' => $data['note'] ?? null,
        ]);

        return back()->with('status', __('Tax report saved.'));
    }
}
