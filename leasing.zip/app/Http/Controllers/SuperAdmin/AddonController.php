<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Addon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AddonController extends Controller
{
    public function index()
    {
        $addons = Addon::orderBy('sort_order')->orderBy('id')->get();
        return view('superadmin.addons.index', compact('addons'));
    }

    public function create()
    {
        $addon = new Addon(['currency' => 'AZN', 'is_active' => true, 'sort_order' => 0]);
        return view('superadmin.addons.form', [
            'addon' => $addon,
            'mode' => 'create',
            'featureOptions' => $this->featureOptions(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validatedData($request);
        $data['features'] = $this->buildFeatures($request);

        Addon::create($data);

        return redirect()->route('superadmin.addons.index')->with('status', 'Addon yaradıldı.');
    }

    public function edit(Addon $addon)
    {
        return view('superadmin.addons.form', [
            'addon' => $addon,
            'mode' => 'edit',
            'featureOptions' => $this->featureOptions(),
        ]);
    }

    public function update(Request $request, Addon $addon)
    {
        $data = $this->validatedData($request, $addon->id);
        $data['features'] = $this->buildFeatures($request);

        $addon->update($data);

        return redirect()->route('superadmin.addons.index')->with('status', 'Addon yeniləndi.');
    }

    public function destroy(Addon $addon)
    {
        if ($addon->subscriptionAddons()->exists()) {
            return back()->with('error', 'Aktiv abunə əlavələri var, silmək olmaz.');
        }

        $addon->delete();

        return redirect()->route('superadmin.addons.index')->with('status', 'Addon silindi.');
    }

    private function validatedData(Request $request, ?int $id = null): array
    {
        return $request->validate([
            'code' => ['required','string','max:64', Rule::unique('addons','code')->ignore($id)],
            'name' => ['required','string','max:190'],
            'description' => ['nullable','string','max:5000'],
            'currency' => ['required','string','max:8'],
            'price_monthly' => ['nullable','numeric','min:0'],
            'price_yearly' => ['nullable','numeric','min:0'],
            'sort_order' => ['nullable','integer','min:0'],
            'is_active' => ['sometimes','boolean'],
            'module' => ['nullable', Rule::in(['leasing','rentacar','taxipark'])],
        ]) + [
            'is_active' => $request->boolean('is_active'),
            'sort_order' => (int) $request->input('sort_order', 0),
        ];
    }

    private function buildFeatures(Request $request): array
    {
        $features = [];
        $keys = $request->input('features_k', []);
        $vals = $request->input('features_v', []);

        if (is_array($keys)) {
            foreach ($keys as $i => $k) {
                $k = trim((string)$k);
                if ($k === '') continue;
                $features[$k] = (bool) (($vals[$i] ?? '1') !== '0');
            }
        }

        return $features;
    }

    private function featureOptions(): array
    {
        return [
            'vehicles' => 'Vehicles',
            'customers' => 'Customers & assets',
            'contracts' => 'Contracts / Accounts',
            'bhph' => 'BHPH Accounts',
            'payments' => 'Payments / Billing',
            'gps' => 'GPS / Fleet map',
            'notifications' => 'Notifications (auto)',
            'whatsapp_campaigns' => 'WhatsApp campaigns (manual)',
            'risk' => 'Risk module',
            'document_automation' => 'Document automation',
            'advanced_reports' => 'Advanced reports',
            'export_watermark' => 'Export watermark',
            'public_theme' => 'Public site / theme',
            'users' => 'Users / Permissions',
            'taxi' => 'Taxi park',
        ];
    }
}
