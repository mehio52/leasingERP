<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\SystemSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SettingController extends Controller
{
    public function edit()
    {
        $settings = SystemSetting::query()->first() ?? new SystemSetting();
        return view('superadmin.settings', compact('settings'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'wa_api_url' => ['nullable','string','max:255'],
            'wa_api_key' => ['nullable','string','max:255'],
            'wa_api_secret' => ['nullable','string','max:255'],
            'epoint_public_key' => ['nullable','string','max:255'],
            'epoint_private_key' => ['nullable','string','max:255'],
            'payment_gateway_provider' => ['nullable','in:auto,epoint,iyzico,stripe'],
            'stripe_public_key' => ['nullable','string','max:255'],
            'stripe_secret_key' => ['nullable','string','max:255'],
            'stripe_webhook_secret' => ['nullable','string','max:255'],
            'iyzico_api_key' => ['nullable','string','max:255'],
            'iyzico_secret_key' => ['nullable','string','max:255'],
            'iyzico_base_url' => ['nullable','string','max:255'],
            'saas_logo' => ['nullable','string','max:255'],
            'saas_logo_file' => ['nullable','image','max:2048'],
            'remove_saas_logo' => ['nullable','boolean'],
            'mail_host' => ['nullable','string','max:255'],
            'mail_port' => ['nullable','integer','min:1','max:65535'],
            'mail_username' => ['nullable','string','max:255'],
            'mail_password' => ['nullable','string','max:255'],
            'mail_encryption' => ['nullable','string','max:50'],
            'mail_from_address' => ['nullable','email','max:255'],
            'mail_from_name' => ['nullable','string','max:255'],
        ]);

        $settings = SystemSetting::singleton();

        if ($request->boolean('remove_saas_logo')) {
            $this->deleteLogo($settings->saas_logo);
            $data['saas_logo'] = null;
        }

        if ($request->hasFile('saas_logo_file')) {
            $this->deleteLogo($settings->saas_logo);
            $path = $request->file('saas_logo_file')->store('branding', 'public');
            $data['saas_logo'] = Storage::disk('public')->url($path);
        }

        $settings->fill($data);
        $settings->save();

        SystemSetting::applyToConfig($settings);

        return redirect()->route('superadmin.settings.edit')
            ->with('status', ___('Settings saved.'));
    }

    private function deleteLogo(?string $logoUrl): void
    {
        if (!$logoUrl) {
            return;
        }

        $path = parse_url($logoUrl, PHP_URL_PATH);
        if (!$path || !str_starts_with($path, '/storage/')) {
            return;
        }

        $relative = ltrim(substr($path, strlen('/storage/')), '/');
        if ($relative !== '') {
            Storage::disk('public')->delete($relative);
        }
    }
}
