<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Events\NotificationCreated;
use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Ticket;
use App\Models\TicketMessage;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    private array $priorities = [
        'low' => 'Təcili deyil',
        'normal' => 'Vacib',
        'urgent' => 'Çox vacib',
    ];

    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user?->isSuperAdmin(), 403);

        $status = $request->query('status', '');

        $tickets = Ticket::query()
            ->when($status !== '', fn($q) => $q->where('status', $status))
            ->orderByDesc('updated_at')
            ->paginate(30)
            ->withQueryString();

        return view('superadmin.tickets.index', [
            'tickets' => $tickets,
            'priorities' => $this->priorities,
            'status' => $status,
        ]);
    }

    public function show(Request $request, Ticket $ticket)
    {
        $user = $request->user();
        abort_unless($user?->isSuperAdmin(), 403);

        $ticket->load(['messages.user','company','user']);

        return view('superadmin.tickets.show', [
            'ticket' => $ticket,
            'priorities' => $this->priorities,
        ]);
    }

    public function reply(Request $request, Ticket $ticket)
    {
        $user = $request->user();
        abort_unless($user?->isSuperAdmin(), 403);

        $data = $request->validate([
            'body' => ['required','string','max:5000'],
            'status' => ['nullable','in:open,closed'],
        ]);

        TicketMessage::create([
            'ticket_id' => $ticket->id,
            'user_id' => $user->id,
            'body' => $data['body'],
        ]);

        if (!empty($data['status'])) {
            $ticket->status = $data['status'];
        } else {
            $ticket->status = 'open';
        }
        $ticket->save();

        $this->notifyCompany($ticket, 'Ticket cavabı: '.$ticket->subject, $data['body'], $user->id);

        return redirect()->route('superadmin.tickets.show', $ticket)->with('status', 'Cavab göndərildi.');
    }

    private function notifyCompany(Ticket $ticket, string $title, ?string $body = null, ?int $senderId = null): void
    {
        $notification = Notification::create([
            'company_id' => $ticket->company_id,
            'sender_id' => $senderId ?? $ticket->user_id,
            'target_scope' => 'company',
            'title' => $title,
            'body' => $body,
            'data' => ['ticket_id' => $ticket->id],
        ]);

        try {
            NotificationCreated::dispatch($notification);
        } catch (\Throwable $e) {
            // ignore broadcast failure
        }
    }
}
