<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\EpointTransaction;
use Illuminate\Http\Request;

class EpointTransactionController extends Controller
{
    public function index(Request $request)
    {
        $status = (string) $request->query('status', '');
        $type = (string) $request->query('type', '');
        $q = trim((string) $request->query('q', ''));

        $query = EpointTransaction::query()->with('company');

        if ($status !== '') {
            $query->where('status', $status);
        }

        if ($type !== '') {
            $query->where('type', $type);
        }

        if ($q !== '') {
            $query->where(function ($w) use ($q) {
                $w->where('order_id', 'like', "%{$q}%")
                    ->orWhere('gateway_transaction', 'like', "%{$q}%")
                    ->orWhere('epoint_transaction', 'like', "%{$q}%")
                    ->orWhere('bank_transaction', 'like', "%{$q}%")
                    ->orWhere('message', 'like', "%{$q}%")
                    ->orWhereHas('company', function ($c) use ($q) {
                        $c->where('name', 'like', "%{$q}%")
                            ->orWhere('slug', 'like', "%{$q}%")
                            ->orWhere('email', 'like', "%{$q}%");
                    });
            });
        }

        $transactions = $query->latest('id')->paginate(30)->withQueryString();

        return view('superadmin.epoint_transactions.index', [
            'transactions' => $transactions,
            'status' => $status,
            'type' => $type,
            'q' => $q,
        ]);
    }
}
