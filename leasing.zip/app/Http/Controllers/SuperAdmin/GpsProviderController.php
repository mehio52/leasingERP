<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\GpsProvider;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class GpsProviderController extends Controller
{
    public function index()
    {
        $providers = GpsProvider::query()->orderBy('name')->paginate(20);
        return view('superadmin.gps_providers.index', compact('providers'));
    }

    public function create()
    {
        return view('superadmin.gps_providers.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required','string','max:120'],
            'slug' => ['nullable','string','max:120', Rule::unique('gps_providers','slug')],
            'is_active' => ['nullable','boolean'],
            'admin_first_name' => ['nullable','string','max:255'],
            'admin_last_name' => ['nullable','string','max:255'],
            'admin_phone' => ['nullable','string','max:32','regex:/^\+994\d{9}$/', Rule::unique('users','phone')],
            'admin_email' => ['nullable','email','max:255', Rule::unique('users','email')],
            'admin_password' => ['nullable','string','min:8','confirmed'],
        ]);

        $provider = GpsProvider::create([
            'name' => $data['name'],
            'slug' => $data['slug'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
            'settings' => [
                'platforms' => ['traccar'],
                'active_platform' => 'traccar',
                'traccar' => [
                    'base_url' => '',
                    'token' => '',
                    'username' => '',
                    'password' => '',
                ],
                'wialon' => [
                    'base_url' => '',
                    'token' => '',
                    'username' => '',
                    'password' => '',
                ],
            ],
            'created_by' => $request->user()?->id,
        ]);

        if (!empty($data['admin_phone']) && !empty($data['admin_password'])) {
            User::create([
                'first_name' => $data['admin_first_name'] ?? 'Admin',
                'last_name' => $data['admin_last_name'] ?? 'User',
                'phone' => $data['admin_phone'],
                'email' => $data['admin_email'] ?? null,
                'password' => $data['admin_password'],
                'role' => 'gps_provider_admin',
                'is_active' => true,
                'permissions' => [],
                'gps_provider_id' => $provider->id,
                'company_id' => null,
                'created_by' => $request->user()?->id,
            ]);
        }

        return redirect()->route('superadmin.gps_providers.edit', $provider)->with('status', 'GPS provayderi yaradildi.');
    }

    public function edit(GpsProvider $gpsProvider)
    {
        $users = User::query()
            ->where('gps_provider_id', $gpsProvider->id)
            ->orderByDesc('id')
            ->get();

        return view('superadmin.gps_providers.edit', compact('gpsProvider', 'users'));
    }

    public function update(Request $request, GpsProvider $gpsProvider)
    {
        $data = $request->validate([
            'name' => ['required','string','max:120'],
            'slug' => ['nullable','string','max:120', Rule::unique('gps_providers','slug')->ignore($gpsProvider->id)],
            'is_active' => ['nullable','boolean'],
        ]);

        $gpsProvider->name = $data['name'];
        if (!empty($data['slug'])) {
            $gpsProvider->slug = $data['slug'];
        }
        $gpsProvider->is_active = (bool) ($data['is_active'] ?? true);
        $gpsProvider->save();

        return redirect()->route('superadmin.gps_providers.edit', $gpsProvider)->with('status', 'Yadda saxlanildi.');
    }

    public function storeUser(Request $request, GpsProvider $gpsProvider)
    {
        $data = $request->validate([
            'first_name' => ['required','string','max:255'],
            'last_name'  => ['required','string','max:255'],
            'phone'      => ['required','string','max:32','regex:/^\+994\d{9}$/', Rule::unique('users','phone')],
            'email'      => ['nullable','email','max:255', Rule::unique('users','email')],
            'password'   => ['required','string','min:8','confirmed'],
            'role'       => ['required','in:gps_provider_admin,gps_provider_staff'],
        ]);

        User::create([
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'phone' => $data['phone'],
            'email' => $data['email'] ?? null,
            'password' => $data['password'],
            'role' => $data['role'],
            'is_active' => true,
            'permissions' => [],
            'gps_provider_id' => $gpsProvider->id,
            'company_id' => null,
            'created_by' => $request->user()?->id,
        ]);

        return redirect()->route('superadmin.gps_providers.edit', $gpsProvider)->with('status', 'Provayder istifadəçisi yaradildi.');
    }
}
