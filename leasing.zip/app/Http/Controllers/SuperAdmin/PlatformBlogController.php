<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\PlatformBlogPost;
use App\Models\PlatformBlogImage;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PlatformBlogController extends Controller
{
    public function index()
    {
        $posts = PlatformBlogPost::query()
            ->latest('published_at')
            ->latest('id')
            ->paginate(20);

        return view('superadmin.blogs.index', compact('posts'));
    }

    public function create()
    {
        return view('superadmin.blogs.form', [
            'post' => new PlatformBlogPost(),
            'mode' => 'create',
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validatePayload($request);
        $images = $this->validateImages($request, false);

        $post = new PlatformBlogPost();
        $post->fill($data);
        if ($post->status === 'published') {
            $post->published_at = $post->published_at ?? now();
        } else {
            $post->published_at = null;
        }
        $post->save();

        if ($images) {
            $this->saveUploadedImages($post, $images);
        }

        return redirect()
            ->route('superadmin.blogs.index')
            ->with('status', 'Blog post created.');
    }

    public function edit(PlatformBlogPost $post)
    {
        $post->load('images');
        return view('superadmin.blogs.form', [
            'post' => $post,
            'mode' => 'edit',
        ]);
    }

    public function update(Request $request, PlatformBlogPost $post)
    {
        $data = $this->validatePayload($request);

        $post->fill($data);
        if ($post->status === 'published') {
            $post->published_at = $post->published_at ?? now();
        } else {
            $post->published_at = null;
        }
        $post->save();

        return redirect()
            ->route('superadmin.blogs.index')
            ->with('status', 'Blog post updated.');
    }

    public function destroy(PlatformBlogPost $post)
    {
        $post->load('images');
        foreach ($post->images as $image) {
            $image->delete();
        }
        $post->delete();

        return redirect()
            ->route('superadmin.blogs.index')
            ->with('status', 'Blog post deleted.');
    }

    public function storeImages(Request $request, PlatformBlogPost $post)
    {
        $images = $this->validateImages($request, true);
        $this->saveUploadedImages($post, $images);

        return redirect()
            ->route('superadmin.blogs.edit', $post)
            ->with('status', 'Images uploaded.');
    }

    public function updateImages(Request $request, PlatformBlogPost $post)
    {
        $data = $request->validate([
            'images' => ['nullable','array'],
            'images.*.keyword' => ['nullable','string','max:60'],
            'images.*.alt_text' => ['nullable','string','max:255'],
        ]);

        $post->load('images');
        $images = $post->images->keyBy('id');

        $keywords = [];
        foreach (($data['images'] ?? []) as $id => $meta) {
            if (!isset($images[$id])) {
                continue;
            }

            $keyword = trim((string)($meta['keyword'] ?? ''));
            $keyword = trim($keyword, "{} \t\n\r\0\x0B");

            if ($keyword !== '' && !preg_match('/^[A-Za-z0-9_-]+$/', $keyword)) {
                return back()->withErrors(['keyword' => 'Invalid keyword format.'])->withInput();
            }
            if ($keyword !== '') {
                if (isset($keywords[$keyword])) {
                    return back()->withErrors(['keyword' => 'Duplicate keyword: ' . $keyword])->withInput();
                }
                $existing = $post->images
                    ->first(function ($img) use ($keyword, $id) {
                        return $img->keyword === $keyword && (string)$img->id !== (string)$id;
                    });
                if ($existing) {
                    return back()->withErrors(['keyword' => 'Keyword already used: ' . $keyword])->withInput();
                }
                $keywords[$keyword] = true;
            }

            $image = $images[$id];
            $image->keyword = $keyword !== '' ? $keyword : null;
            $image->alt_text = $meta['alt_text'] ?? null;
            $image->save();
        }

        return redirect()
            ->route('superadmin.blogs.edit', $post)
            ->with('status', 'Images updated.');
    }

    public function destroyImage(PlatformBlogPost $post, PlatformBlogImage $image)
    {
        if ($image->platform_blog_post_id !== $post->id) {
            abort(404);
        }
        $image->delete();

        return redirect()
            ->route('superadmin.blogs.edit', $post)
            ->with('status', 'Image removed.');
    }

    private function validatePayload(Request $request): array
    {
        return $request->validate([
            'title' => ['required','string','max:255'],
            'slug' => ['nullable','string','max:255'],
            'excerpt' => ['nullable','string','max:2000'],
            'content' => ['nullable','string'],
            'status' => ['nullable','in:published,draft'],
        ]);
    }

    private function nextImageNumber(PlatformBlogPost $post): int
    {
        $max = 0;
        foreach ($post->images as $image) {
            if (preg_match('/^image_(\d+)$/', (string)$image->keyword, $m)) {
                $num = (int) $m[1];
                if ($num > $max) {
                    $max = $num;
                }
            }
        }
        return $max + 1;
    }

    private function validateImages(Request $request, bool $required): array
    {
        $rule = $required ? ['required','array'] : ['nullable','array'];
        $data = $request->validate([
            'images' => $rule,
            'images.*' => ['image','max:5120'],
        ]);

        return $data['images'] ?? [];
    }

    private function saveUploadedImages(PlatformBlogPost $post, array $images): void
    {
        if (!$images) {
            return;
        }

        $post->load('images');
        $nextNumber = $this->nextImageNumber($post);

        foreach ($images as $file) {
            $ext = $file->getClientOriginalExtension() ?: 'jpg';
            $filename = Str::random(20) . '.' . $ext;
            $path = $file->storeAs('platform-blogs/' . $post->id, $filename, 'public');

            $keyword = 'image_' . $nextNumber;
            $nextNumber++;

            PlatformBlogImage::create([
                'platform_blog_post_id' => $post->id,
                'path' => $path,
                'keyword' => $keyword,
                'alt_text' => null,
            ]);
        }
    }
}
