<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\Plan;
use App\Models\Subscription;

class DashboardController extends Controller
{
    public function index()
    {
        $companyCounts = [
            'total' => Company::count(),
            'active' => Company::where('is_active', true)->whereNull('suspended_at')->count(),
            'suspended' => Company::whereNotNull('suspended_at')->count(),
            'trialing' => Company::whereNotNull('trial_ends_at')->where('trial_ends_at', '>', now())->count(),
        ];

        $subscriptionCounts = [
            'trial' => Subscription::withoutTenant()->where('status', Subscription::STATUS_TRIAL)->count(),
            'active' => Subscription::withoutTenant()->where('status', Subscription::STATUS_ACTIVE)->count(),
            'past_due' => Subscription::withoutTenant()->where('status', Subscription::STATUS_PAST_DUE)->count(),
        ];

        $recentCompanies = Company::latest('id')->limit(6)->get();
        $recentSubscriptions = Subscription::withoutTenant()
            ->with(['company', 'plan'])
            ->latest('id')
            ->limit(6)
            ->get();

        $plans = Plan::orderBy('sort_order')->orderBy('id')->get();

        return view('superadmin.dashboard', compact(
            'companyCounts',
            'subscriptionCounts',
            'recentCompanies',
            'recentSubscriptions',
            'plans'
        ));
    }
}
