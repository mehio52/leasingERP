<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\CompanyDomainRequest;
use App\Services\AapanelService;
use Illuminate\Http\Request;

class DomainRequestController extends Controller
{
    public function index(Request $request)
    {
        $status = $request->query('status');

        $query = CompanyDomainRequest::query()
            ->with(['company', 'requester', 'approver'])
            ->latest('id');

        if ($status) {
            $query->where('status', $status);
        }

        $requests = $query->paginate(30)->withQueryString();

        return view('superadmin.domain_requests.index', compact('requests', 'status'));
    }

    public function approve(Request $request, CompanyDomainRequest $domainRequest)
    {
        $request->validate([
            'admin_note' => ['nullable', 'string', 'max:2000'],
        ]);

        if ($domainRequest->status !== CompanyDomainRequest::STATUS_PENDING) {
            return back()->withErrors(['status' => ___('Request is already processed.')]);
        }

        $aapanel = app(AapanelService::class);
        if ($aapanel->isEnabled()) {
            $res = $aapanel->addDomainToSite($domainRequest->requested_domain);
            if (!($res['ok'] ?? false)) {
                return back()->withErrors(['status' => $res['message'] ?? 'aaPanel error']);
            }
        }

        $domainRequest->update([
            'status' => CompanyDomainRequest::STATUS_APPROVED,
            'admin_note' => $request->input('admin_note'),
            'approved_by' => $request->user()?->id,
            'approved_at' => now(),
            'rejected_at' => null,
        ]);

        return back()->with('status', ___('Request approved.'));
    }

    public function activate(Request $request, CompanyDomainRequest $domainRequest)
    {
        if ($domainRequest->status !== CompanyDomainRequest::STATUS_APPROVED) {
            return back()->withErrors(['status' => ___('Only approved requests can be activated.')]);
        }

        $conflict = CompanyDomainRequest::query()
            ->where('requested_domain', $domainRequest->requested_domain)
            ->where('is_active', true)
            ->where('id', '!=', $domainRequest->id)
            ->exists();

        if ($conflict) {
            return back()->withErrors(['status' => ___('This domain is already active for another company.')]);
        }

        $aapanel = app(AapanelService::class);
        if ($aapanel->isEnabled()) {
            $res = $aapanel->addDomainToSite($domainRequest->requested_domain);
            if (!($res['ok'] ?? false)) {
                return back()->withErrors(['status' => $res['message'] ?? 'aaPanel error']);
            }
        }

        CompanyDomainRequest::query()
            ->where('company_id', $domainRequest->company_id)
            ->where('is_active', true)
            ->update([
                'is_active' => false,
                'deactivated_at' => now(),
            ]);

        $domainRequest->update([
            'is_active' => true,
            'activated_at' => now(),
            'deactivated_at' => null,
        ]);

        return back()->with('status', ___('Domain routing activated.'));
    }

    public function deactivate(Request $request, CompanyDomainRequest $domainRequest)
    {
        if (!$domainRequest->is_active) {
            return back()->withErrors(['status' => ___('Domain is already inactive.')]);
        }

        $aapanel = app(AapanelService::class);
        if ($aapanel->isEnabled()) {
            $res = $aapanel->removeDomainFromSite($domainRequest->requested_domain);
            if (!($res['ok'] ?? false)) {
                return back()->withErrors(['status' => $res['message'] ?? 'aaPanel error']);
            }
        }

        $domainRequest->update([
            'is_active' => false,
            'deactivated_at' => now(),
        ]);

        return back()->with('status', ___('Domain routing deactivated.'));
    }

    public function reject(Request $request, CompanyDomainRequest $domainRequest)
    {
        $request->validate([
            'admin_note' => ['nullable', 'string', 'max:2000'],
        ]);

        if ($domainRequest->status !== CompanyDomainRequest::STATUS_PENDING) {
            return back()->withErrors(['status' => ___('Request is already processed.')]);
        }

        $domainRequest->update([
            'status' => CompanyDomainRequest::STATUS_REJECTED,
            'admin_note' => $request->input('admin_note'),
            'approved_by' => $request->user()?->id,
            'rejected_at' => now(),
            'approved_at' => null,
        ]);

        return back()->with('status', ___('Request rejected.'));
    }
}
