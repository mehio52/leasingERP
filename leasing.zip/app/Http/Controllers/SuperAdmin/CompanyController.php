<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Addon;
use App\Models\BhphAccount;
use App\Models\Company;
use App\Models\Customer;
use App\Models\Payment;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\SubscriptionAddon;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CompanyController extends Controller
{
    public function index(Request $request)
    {
        $q = trim((string) $request->input('q'));
        $status = $request->input('status');

        $companies = Company::query()
            ->when($q, function ($query) use ($q) {
                $query->where(function ($w) use ($q) {
                    $w->where('name', 'like', "%{$q}%")
                        ->orWhere('slug', 'like', "%{$q}%")
                        ->orWhere('phone', 'like', "%{$q}%")
                        ->orWhere('email', 'like', "%{$q}%");
                });
            })
            ->when($status === 'active', function ($query) {
                $query->where('is_active', true)->whereNull('suspended_at');
            })
            ->when($status === 'suspended', function ($query) {
                $query->whereNotNull('suspended_at');
            })
            ->when($status === 'trial', function ($query) {
                $query->whereNotNull('trial_ends_at')->where('trial_ends_at', '>', now());
            })
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('superadmin.companies.index', compact('companies', 'q', 'status'));
    }

    public function show(Company $company)
    {
        $module = $company->moduleCode();
        $plans = Plan::orderBy('sort_order')
            ->orderBy('id')
            ->where(function ($q) use ($module) {
                $q->whereNull('module')->orWhere('module', $module);
            })
            ->get();
        $subscriptions = Subscription::withoutTenant()
            ->where('company_id', $company->id)
            ->with('plan')
            ->orderByDesc('id')
            ->get();
        $activeAddons = SubscriptionAddon::withoutTenant()
            ->where('company_id', $company->id)
            ->where(function ($q) {
                $q->whereNull('ends_at')->orWhere('ends_at', '>', now());
            })
            ->get();
        $availableAddons = Addon::active()
            ->where(function ($q) use ($module) {
                $q->whereNull('module')->orWhere('module', $module);
            })
            ->orderBy('sort_order')
            ->get()
            ->reject(fn($a) => $activeAddons->contains(fn($aa) => (int)$aa->addon_id === (int)$a->id));
        $owner = User::withoutTenant()
            ->where('company_id', $company->id)
            ->where(function ($q) {
                $q->where('is_owner', true)->orWhere('role', 'owner');
            })
            ->first();

        $stats = [
            'users' => User::withoutTenant()->where('company_id', $company->id)->count(),
            'customers' => Customer::withoutTenant()->where('company_id', $company->id)->count(),
            'vehicles' => Vehicle::withoutTenant()->where('company_id', $company->id)->count(),
            'accounts' => BhphAccount::withoutTenant()->where('company_id', $company->id)->count(),
            'payments' => Payment::withoutTenant()->where('company_id', $company->id)->count(),
        ];

        return view('superadmin.companies.show', compact('company', 'plans', 'subscriptions', 'stats', 'owner', 'activeAddons', 'availableAddons'));
    }

    public function update(Request $request, Company $company)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'is_active' => ['nullable', 'boolean'],
            'suspend' => ['nullable', 'boolean'],
            'suspend_reason' => ['nullable', 'string', 'max:255'],
            'trial_ends_at' => ['nullable', 'date'],
            'subscription_ends_at' => ['nullable', 'date'],
            'plan_code' => ['nullable', 'string', 'max:64'],
            'module' => ['nullable', Rule::in(['leasing','rentacar','taxipark'])],
        ]);

        $company->name = $data['name'];
        $company->is_active = (bool) ($data['is_active'] ?? false);
        $company->plan_code = $data['plan_code'] ?? $company->plan_code;
        if (!empty($data['module'])) {
            $company->module = $data['module'];
        }
        $company->trial_ends_at = $data['trial_ends_at'] ?? null;
        $company->subscription_ends_at = $data['subscription_ends_at'] ?? null;

        if (!empty($data['suspend'])) {
            $company->suspended_at = $company->suspended_at ?: now();
            $company->suspend_reason = $data['suspend_reason'] ?? $company->suspend_reason;
        } else {
            $company->suspended_at = null;
            $company->suspend_reason = null;
        }

        $company->save();

        return back()->with('status', ___('Company updated.'));
    }

    public function createSubscription(Request $request, Company $company, SubscriptionService $subscriptions)
    {
        $data = $request->validate([
            'plan_id' => ['required', 'integer', 'exists:plans,id'],
            'status' => ['required', Rule::in([
                Subscription::STATUS_TRIAL,
                Subscription::STATUS_ACTIVE,
                Subscription::STATUS_PAST_DUE,
            ])],
            'billing_period' => ['required', Rule::in([
                Subscription::PERIOD_MONTHLY,
                Subscription::PERIOD_YEARLY,
            ])],
            'starts_at' => ['nullable', 'date'],
            'trial_days' => ['nullable', 'integer', 'min:0', 'max:365'],
            'trial_ends_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date'],
            'meta_note' => ['nullable', 'string', 'max:500'],
        ]);

        $plan = Plan::where('id', $data['plan_id'])
            ->where(function ($q) use ($company) {
                $mod = $company->moduleCode();
                $q->whereNull('module')->orWhere('module', $mod);
            })
            ->firstOrFail();

        $meta = [];
        if (!empty($data['meta_note'])) {
            $meta['note'] = $data['meta_note'];
        }

        $subscriptions->startSubscription($company, $plan, [
            'status' => $data['status'],
            'billing_period' => $data['billing_period'],
            'starts_at' => $data['starts_at'] ?? null,
            'trial_ends_at' => $data['trial_ends_at'] ?? null,
            'trial_days' => $data['trial_days'] ?? null,
            'ends_at' => $data['ends_at'] ?? null,
            'meta' => $meta,
        ]);

        return back()->with('status', ___('Subscription created for company.'));
    }
}
