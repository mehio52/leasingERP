<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class PlanController extends Controller
{
    public function index()
    {
        $plans = Plan::withCount('subscriptions')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        return view('superadmin.plans.index', compact('plans'));
    }

    public function create()
    {
        $plan = new Plan(['currency' => 'AZN', 'trial_days' => 0, 'is_active' => true]);
        return view('superadmin.plans.form', [
            'plan' => $plan,
            'mode' => 'create',
            'featureOptions' => $this->featureOptions(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validatedData($request);
        Plan::create($data);

        return redirect()->route('superadmin.plans.index')
            ->with('status', ___('Plan created.'));
    }

    public function edit(Plan $plan)
    {
        return view('superadmin.plans.form', [
            'plan' => $plan,
            'mode' => 'edit',
            'featureOptions' => $this->featureOptions(),
        ]);
    }

    public function update(Request $request, Plan $plan)
    {
        $data = $this->validatedData($request, $plan->id);
        $plan->update($data);

        return redirect()->route('superadmin.plans.index')
            ->with('status', ___('Plan updated.'));
    }

    public function destroy(Plan $plan)
    {
        if ($plan->subscriptions()->exists()) {
            return back()->with('error', ___('Plan has subscriptions and cannot be deleted.'));
        }

        $plan->delete();
        return back()->with('status', ___('Plan deleted.'));
    }

    private function validatedData(Request $request, ?int $planId = null): array
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:32', Rule::unique('plans', 'code')->ignore($planId)],
            'name' => ['required', 'string', 'max:128'],
            'description' => ['nullable', 'string', 'max:500'],
            'price_monthly' => ['required', 'numeric', 'min:0'],
            'price_yearly' => ['required', 'numeric', 'min:0'],
            'currency' => ['required', 'string', 'max:8'],
            'trial_days' => ['nullable', 'integer', 'min:0', 'max:365'],
            'limit_users' => ['nullable', 'integer', 'min:0'],
            'limit_active_contracts' => ['nullable', 'integer', 'min:0'],
            'limit_branches' => ['nullable', 'integer', 'min:0'],
            'features' => ['nullable', 'array'],
            'is_active' => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'module' => ['nullable', Rule::in(['leasing','rentacar','taxipark'])],
        ]);

        $limits = [
            'users' => $data['limit_users'] ?? null,
            'active_contracts' => $data['limit_active_contracts'] ?? null,
            'branches' => $data['limit_branches'] ?? null,
        ];
        $limits = array_filter($limits, fn($v) => $v !== null);

        $features = [];
        foreach ($this->featureOptions() as $key => $label) {
            $features[$key] = (bool) $request->boolean("features.$key");
        }

        return [
            'code' => $data['code'],
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'price_monthly' => $data['price_monthly'],
            'price_yearly' => $data['price_yearly'],
            'currency' => $data['currency'],
            'trial_days' => $data['trial_days'] ?? 0,
            'module' => $data['module'] ?? null,
            'limits' => $limits,
            'features' => $features,
            'is_active' => (bool)($data['is_active'] ?? false),
            'sort_order' => $data['sort_order'] ?? 0,
        ];
    }

    private function decodeJson(?string $value, string $field): ?array
    {
        return null;
    }

    private function featureOptions(): array
    {
        return [
            'settings' => 'Company settings',
            'vehicles' => 'Vehicles',
            'customers' => 'Customers & assets',
            'contracts' => 'Contracts / Accounts',
            'bhph' => 'BHPH Accounts',
            'payments' => 'Payments / Billing',
            'gps' => 'GPS / Fleet map',
            'notifications' => 'Notifications (auto)',
            'whatsapp_campaigns' => 'WhatsApp campaigns (manual)',
            'risk' => 'Risk module',
            'document_automation' => 'Document automation',
            'advanced_reports' => 'Advanced reports',
            'export_watermark' => 'Export watermark',
            'public_theme' => 'Public site / theme',
            'custom_domain' => 'Custom domain',
            'users' => 'Users / Permissions',
            'taxi' => 'Taxi park',
        ];
    }
}
