<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Addon;
use App\Models\Company;
use App\Models\SubscriptionAddon;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;

class SuperAdminCompanyAddonController extends Controller
{
    public function store(Request $request, Company $company, SubscriptionService $subs)
    {
        $data = $request->validate([
            'addon_code' => ['required','string'],
        ]);

        $subscription = $subs->current($company);
        if (!$subscription) {
            return back()->withErrors(['addon' => 'Aktiv plan tapılmadı. Əvvəlcə plan seçin.']);
        }

        $addon = Addon::where('code', $data['addon_code'])
            ->where(function ($q) use ($company) {
                $mod = $company->moduleCode();
                $q->whereNull('module')->orWhere('module', $mod);
            })
            ->firstOrFail();
        SubscriptionAddon::withoutTenant()->updateOrCreate(
            ['subscription_id' => $subscription->id, 'addon_id' => $addon->id],
            [
                'company_id' => $company->id,
                'quantity' => 1,
                'starts_at' => now(),
                'ends_at' => null,
                'addon_code_snapshot' => $addon->code,
                'addon_name_snapshot' => $addon->name,
                'price_snapshot' => $addon->price_monthly ?? 0,
                'currency_snapshot' => $addon->currency ?? 'AZN',
                'features_snapshot' => $addon->features ?? [],
            ]
        );

        $subs->syncCompanyFeatures($company);

        return back()->with('status', "{$addon->name} aktiv edildi.");
    }

    public function destroy(Request $request, Company $company, SubscriptionAddon $subscriptionAddon, SubscriptionService $subs)
    {
        if ((int)$subscriptionAddon->company_id !== (int)$company->id) {
            abort(403);
        }

        $subscriptionAddon->update(['ends_at' => now()]);
        $subs->syncCompanyFeatures($company);

        return back()->with('status', "{$subscriptionAddon->addon_name_snapshot} deaktiv edildi.");
    }
}
