<?php

namespace App\Http\Controllers;

use App\Models\PenaltyOption;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class PenaltyOptionController extends Controller
{
    public function edit(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'İstifadəçi şirkətə bağlı deyil.');
        }

        $options = PenaltyOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            PenaltyOption::defaults()
        );

        return view('penalty_options.edit', compact('user', 'options'));
    }

    public function update(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'İstifadəçi şirkətə bağlı deyil.');
        }

        $options = PenaltyOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            PenaltyOption::defaults()
        );

        // Əsas validation
        $v = Validator::make($request->all(), [
            'grace_days' => ['nullable','integer','min:0','max:365'],
            'overdue_after_days' => ['nullable','integer','min:0','max:3650'],

            'penalty_type' => ['required', Rule::in([
                PenaltyOption::TYPE_NONE,
                PenaltyOption::TYPE_FIXED,
                PenaltyOption::TYPE_PERCENT,
            ])],

            'penalty_value' => ['nullable','numeric','min:0','max:1000000'],

            'penalty_frequency' => ['required', Rule::in([
                PenaltyOption::FREQ_ONCE,
                PenaltyOption::FREQ_DAILY,
                PenaltyOption::FREQ_MONTHLY,
            ])],

            'apply_on' => ['required', Rule::in([
                PenaltyOption::APPLY_REMAINING_DUE,
                PenaltyOption::APPLY_PRINCIPAL_ONLY,
                PenaltyOption::APPLY_TOTAL_INSTALLMENT,
            ])],

            'penalty_cap_amount' => ['nullable','numeric','min:0','max:100000000'],
            'penalty_cap_percent' => ['nullable','numeric','min:0','max:100'],

            'rounding_step' => ['nullable','numeric','min:0','max:100'],
            'rounding_mode' => ['required', Rule::in([
                PenaltyOption::ROUND_NEAREST,
                PenaltyOption::ROUND_UP,
                PenaltyOption::ROUND_DOWN,
            ])],

            'notes' => ['nullable','string','max:2000'],

            // settings key/value rows
            'settings_k' => ['nullable','array'],
            'settings_k.*' => ['nullable','string','max:190'],
            'settings_v' => ['nullable','array'],
            'settings_v.*' => ['nullable','string','max:2000'],
        ]);

        // Percent tipində penalty_value max 100 olsun
        $v->after(function($validator) use ($request) {
            $type = $request->input('penalty_type');
            $val  = $request->input('penalty_value');

            if ($type === PenaltyOption::TYPE_PERCENT && $val !== null && $val !== '' && (float)$val > 100) {
                $validator->errors()->add('penalty_value', 'Faiz tipində cərimə dəyəri 0-100 arası olmalıdır.');
            }
        });

        $validated = $v->validate();

        // penalty_value normalize
        if (($validated['penalty_type'] ?? PenaltyOption::TYPE_NONE) === PenaltyOption::TYPE_NONE) {
            $validated['penalty_value'] = 0;
        } else {
            if (!isset($validated['penalty_value'])) $validated['penalty_value'] = 0;
        }

        // caps normalize: boş string-ləri null elə
        foreach (['penalty_cap_amount','penalty_cap_percent','rounding_step'] as $f) {
            if (array_key_exists($f, $validated) && ($validated[$f] === '' || $validated[$f] === null)) {
                $validated[$f] = null;
            }
        }

        // settings => assoc (key/value)
        $settings = [];
        $keys = $request->input('settings_k', []);
        $vals = $request->input('settings_v', []);

        if (is_array($keys) && is_array($vals)) {
            foreach ($keys as $i => $k) {
                $k = trim((string)$k);
                if ($k === '') continue;
                $settings[$k] = (string)($vals[$i] ?? '');
            }
        }

        $validated['company_id'] = $companyId;

        $options->fill($validated);
        $options->settings = $settings ?: null;
        $options->save();

        return redirect()
            ->route('company.penalty_options.edit')
            ->with('status', 'Cərimə ayarları yadda saxlanıldı.');
    }
}
