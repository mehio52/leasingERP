<?php

namespace App\Http\Controllers;

use App\Models\Amortization;
use App\Models\BhphAccount;
use App\Models\CompanyOption;
use App\Models\LeasingOption;
use App\Services\AmortizationService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AmortizationController extends Controller
{
    public function __construct(private AmortizationService $amortService) {}

    private function computeRowStatus(Amortization $row): string
    {
        $due = (float) $row->due_amount;
        $paid = (float) $row->paid_amount;

        $today = Carbon::now()->startOfDay();
        $dueDate = Carbon::parse($row->due_date)->startOfDay();

        if ($paid >= $due && $due > 0) return Amortization::STATUS_PAID;
        if ($paid > 0 && $paid < $due) {
            return ($dueDate->lt($today)) ? Amortization::STATUS_OVERDUE : Amortization::STATUS_PARTIAL;
        }

        return ($dueDate->lt($today)) ? Amortization::STATUS_OVERDUE : Amortization::STATUS_PENDING;
    }

    public function edit(Request $request, BhphAccount $account, Amortization $amortization)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        abort_unless($companyId && (int)$account->company_id === (int)$companyId, 403);
        abort_unless((int)$amortization->bhph_account_id === (int)$account->id, 404);

        $leasing = LeasingOption::where('company_id', $companyId)->first();
        $options = CompanyOption::query()->where('company_id', $companyId)->first();
        $currencyCode = strtoupper((string) ($options?->currency ?? 'AZN'));

        return view('amortization.edit', compact('user','account','amortization','leasing','currencyCode'));
    }

    public function update(Request $request, BhphAccount $account, Amortization $amortization)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        abort_unless($companyId && (int)$account->company_id === (int)$companyId, 403);
        abort_unless((int)$amortization->bhph_account_id === (int)$account->id, 404);

        $data = $request->validate([
            'paid_amount' => ['required','numeric','min:0','max:999999999'],
            'paid_date'   => ['nullable','date'],
            'due_date'    => ['required','date'], // tarix düzəlişi icazəli
        ]);

        return DB::transaction(function () use ($account, $amortization, $data, $companyId) {

            $amortization->paid_amount = (float) $data['paid_amount'];
            $amortization->paid_date   = $data['paid_date'] ? Carbon::parse($data['paid_date'])->toDateString() : null;
            $amortization->due_date    = Carbon::parse($data['due_date'])->toDateString();

            // status avtomatik
            $amortization->status = $this->computeRowStatus($amortization);
            $amortization->save();

            // account totals/remaining
            $leasing = LeasingOption::where('company_id',$companyId)->first();
            $this->amortService->syncAccountPaymentsFromAmortization($account, $leasing);

            return redirect()
                ->route('bhph_accounts.show', $account)
                ->with('status','Ödəniş yeniləndi.');
        });
    }
}