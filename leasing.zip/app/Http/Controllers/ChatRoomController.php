<?php

namespace App\Http\Controllers;

use App\Models\ChatRoom;
use App\Models\User;
use Illuminate\Http\Request;

class ChatRoomController extends Controller
{
    public function store(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);
        if (!($user->is_owner || $user->role === 'owner' || $user->isSuperAdmin())) {
            abort(403);
        }

        $data = $request->validate([
            'name' => ['required','string','max:255'],
            'user_ids' => ['nullable','array'],
            'user_ids.*' => ['integer','exists:users,id'],
        ]);

        $room = new ChatRoom();
        $room->company_id = $user->company_id;
        $room->name = $data['name'];
        $room->is_group = true;
        $room->created_by = $user->id;
        $room->save();

        $ids = $data['user_ids'] ?? [];
        $validIds = User::where('company_id', $user->company_id)->whereIn('id', $ids)->pluck('id')->all();
        $room->users()->sync(array_merge($validIds, [$user->id]));

        return response()->json(['status' => 'ok', 'room_id' => $room->id]);
    }

    public function attachUsers(Request $request, ChatRoom $room)
    {
        $user = $request->user();
        abort_unless($user, 403);
        if (!($user->is_owner || $user->role === 'owner' || $user->isSuperAdmin())) {
            abort(403);
        }
        if ((int)$room->company_id !== (int)$user->company_id) abort(403);

        $data = $request->validate([
            'user_ids' => ['required','array'],
            'user_ids.*' => ['integer','exists:users,id'],
        ]);

        $ids = User::where('company_id', $user->company_id)->whereIn('id', $data['user_ids'])->pluck('id')->all();
        $room->users()->syncWithoutDetaching($ids);

        return response()->json(['status' => 'ok']);
    }
}
