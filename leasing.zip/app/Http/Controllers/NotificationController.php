<?php

namespace App\Http\Controllers;

use App\Events\NotificationCreated;
use App\Models\Company;
use App\Models\Customer;
use App\Models\Notification;
use App\Models\NotificationOption;
use App\Models\SystemSetting;
use App\Models\User;
use App\Services\WhatsAppService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;

class NotificationController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $query = Notification::query()
            ->where(function ($q) use ($user) {
                $q->where(function ($x) use ($user) {
                    $x->where('target_scope', 'user')->where('target_user_id', $user->id);
                })->orWhere(function ($x) use ($user) {
                    $x->where('target_scope', 'company')->where('company_id', $user->company_id);
                })->orWhere(function ($x) use ($user) {
                    $role = $user->isSuperAdmin() ? 'superadmin' : ($user->is_owner || $user->role === 'owner' ? 'owner' : null);
                    if ($role) {
                        $x->where('target_scope', 'role')->where('target_role', $role);
                    }
                })->orWhere('target_scope', 'global');
            })
            ->latest('id');

        $notifications = $query->limit(50)->get();

        return response()->json($notifications);
    }

    public function store(Request $request, WhatsAppService $wa)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $data = $request->validate([
            'scope' => ['required', Rule::in(['user','company','role','global'])],
            'target_user_id' => ['nullable','integer','exists:users,id','required_if:scope,user'],
            'target_role' => ['nullable','string','max:50','required_if:scope,role'],
            'title' => ['required','string','max:255'],
            'body' => ['nullable','string','max:2000'],
            'company_id' => ['nullable','integer','exists:companies,id','required_if:scope,company'],
            'send_whatsapp' => ['nullable','boolean'],
            'wa_message' => ['nullable','string','max:2000'],
        ]);

        // access rules
        if ($user->isSuperAdmin()) {
            // can send global, role (owner/superadmin), user, company
        } elseif ($user->is_owner || $user->role === 'owner') {
            if (!in_array($data['scope'], ['user','company'], true)) {
                abort(403);
            }
            // ensure target user belongs to same company
            if (!empty($data['target_user_id'])) {
                $target = User::find($data['target_user_id']);
                if (!$target || (int)$target->company_id !== (int)$user->company_id) {
                    abort(403);
                }
            }
            $data['company_id'] = $user->company_id;
        } else {
            abort(403);
        }

        $companyId = $data['company_id'] ?? $user->company_id;
        if ($user->isSuperAdmin()) {
            if ($data['scope'] === 'company' && !$companyId) {
                abort(403);
            }
            if (!$companyId && !empty($data['target_user_id'])) {
                $companyId = (int) (User::find($data['target_user_id'])?->company_id);
            }
        }

        $isSuperAdmin = $user->isSuperAdmin();
        $sendWhatsapp = $isSuperAdmin && $request->boolean('send_whatsapp');
        if (!$isSuperAdmin) {
            // Companies cannot trigger WhatsApp from here
            $data['wa_message'] = null;
        }
        $data['send_whatsapp'] = $sendWhatsapp;
        $data['from_superadmin'] = $isSuperAdmin;

        $notification = new Notification();
        $notification->company_id = $companyId;
        $notification->sender_id = $user->id;
        $notification->target_scope = $data['scope'];
        $notification->target_user_id = $data['target_user_id'] ?? null;
        $notification->target_role = $data['target_role'] ?? null;
        $notification->title = $data['title'];
        $notification->body = $data['body'] ?? null;
        $notification->save();

        // Optional WhatsApp delivery (best-effort)
        if ($sendWhatsapp) {
            $this->sendWhatsApp($data + ['company_id' => $companyId], $wa);
        }

        try {
            NotificationCreated::dispatch($notification);
        } catch (\Throwable $e) {
            Log::warning('Notification broadcast failed: '.$e->getMessage(), ['notification_id' => $notification->id]);
        }

        if ($request->wantsJson()) {
            return response()->json(['status' => 'ok', 'id' => $notification->id], 201);
        }
        return back()->with('status', 'Bildiriş göndərildi.');
    }

    public function form(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $companies = collect();
        $companyUsers = $user->company?->users()->orderBy('first_name')->get() ?? collect();
        if ($user->isSuperAdmin()) {
            $companies = Company::orderBy('name')->get();
            $companyUsers = User::orderBy('first_name')->get();
        }

        $scopes = $user->isSuperAdmin()
            ? ['global' => 'Hamısı', 'role' => 'Rol (owner/superadmin)', 'company' => 'Şirkət', 'user' => 'İstifadəçi']
            : ['company' => 'Şirkət', 'user' => 'İstifadəçi'];

        return view('company.notifications.send', [
            'scopes' => $scopes,
            'companyUsers' => $companyUsers,
            'companies' => $companies,
        ]);
    }

    public function markRead(Request $request, Notification $notification)
    {
        $user = $request->user();
        abort_unless($user, 403);

        // only recipient can mark read
        if ($notification->target_scope === 'user' && (int)$notification->target_user_id !== (int)$user->id) {
            abort(403);
        }
        if ($notification->target_scope === 'company' && (int)$notification->company_id !== (int)$user->company_id) {
            abort(403);
        }
        if ($notification->target_scope === 'role') {
            $role = $user->isSuperAdmin() ? 'superadmin' : ($user->is_owner || $user->role === 'owner' ? 'owner' : null);
            if ($notification->target_role !== $role) {
                abort(403);
            }
        }

        $notification->read_at = now();
        $notification->save();

        return response()->json(['status' => 'ok']);
    }

    private function sendWhatsApp(array $data, WhatsAppService $wa): void
    {
        $message = trim((string)($data['wa_message'] ?? $data['body'] ?? ''));
        if ($message === '') {
            return;
        }

        $targets = collect();
        $scope = $data['scope'] ?? null;
        $allowGlobal = (bool)($data['from_superadmin'] ?? false);

        if ($scope === 'user' && !empty($data['target_user_id'])) {
            $u = User::find($data['target_user_id']);
            if ($u) {
                $targets->push(['phone' => $u->phone, 'company_id' => $u->company_id]);
            }
        } elseif ($scope === 'company') {
            $companyId = $data['company_id'] ?? null;
            if ($companyId) {
                $company = Company::find($companyId);
                if ($company) {
                    foreach ($company->users as $u) {
                        $targets->push(['phone' => $u->phone, 'company_id' => $company->id]);
                    }
                    foreach (Customer::where('company_id', $company->id)->where('whatsapp_opt_in', true)->get() as $c) {
                        $targets->push(['phone' => $c->phone, 'company_id' => $company->id]);
                    }
                }
            }
        } elseif ($scope === 'role') {
            $role = $data['target_role'] ?? null;
            if ($role === 'owner') {
                $users = User::where(function ($q) {
                    $q->where('role', 'owner')->orWhere('is_owner', true);
                })->get();
                foreach ($users as $u) {
                    $targets->push(['phone' => $u->phone, 'company_id' => $u->company_id]);
                }
            } elseif ($role === 'superadmin') {
                foreach (User::where('role', 'superadmin')->get() as $u) {
                    $targets->push(['phone' => $u->phone, 'company_id' => $u->company_id]);
                }
            }
        } elseif ($scope === 'global') {
            foreach (User::whereNotNull('company_id')->get() as $u) {
                $targets->push(['phone' => $u->phone, 'company_id' => $u->company_id]);
            }
            foreach (Customer::whereNotNull('company_id')->where('whatsapp_opt_in', true)->get() as $c) {
                $targets->push(['phone' => $c->phone, 'company_id' => $c->company_id]);
            }
        }

        $unique = $targets->filter(function ($item) {
            $phone = trim((string)($item['phone'] ?? ''));
            return $phone !== '' && $phone[0] === '+' && !empty($item['company_id']);
        })->unique(fn ($item) => $item['phone'])->values();

        foreach ($unique as $item) {
            $opt = NotificationOption::where('company_id', $item['company_id'])
                ->where('is_active', true)
                ->first();
            if ((!$opt || !$opt->wp_api_secret) && $allowGlobal) {
                $opt = $this->globalWhatsAppOption();
            }
            if (!$opt || !$opt->wp_api_secret) {
                continue;
            }
            $wa->send($opt, trim($item['phone']), $message);
        }
    }

    private function globalWhatsAppOption(): ?NotificationOption
    {
        static $cached = null;
        if ($cached === false) {
            return null;
        }
        if ($cached instanceof NotificationOption) {
            return $cached;
        }

        $settings = SystemSetting::query()->first();
        if (!$settings || !$settings->wa_api_secret) {
            $cached = false;
            return null;
        }

        $opt = new NotificationOption();
        $opt->wp_api_url = $settings->wa_api_url;
        $opt->wp_api_key = $settings->wa_api_key;
        $opt->wp_api_secret = $settings->wa_api_secret;
        $cached = $opt;

        return $cached;
    }
}