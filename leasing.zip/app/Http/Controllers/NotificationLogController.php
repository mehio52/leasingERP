<?php

namespace App\Http\Controllers;

use App\Models\NotificationLog;
use Illuminate\Http\Request;

class NotificationLogController extends Controller
{
    public function __construct()
    {
        $this->middleware('perm:notify.logs|whatsapp.logs')->only(['index']);
    }

    public function index(Request $request)
    {
        $companyId = $request->user()?->company_id;
        if (!$companyId) {
            abort(403, 'Şirkət tapılmadı.');
        }

        $logs = NotificationLog::query()
            ->where('company_id', $companyId)
            ->orderByDesc('sent_at')
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('company_options.notifications.logs', compact('logs'));
    }
}
