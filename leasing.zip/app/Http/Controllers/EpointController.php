<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\EpointTransaction;
use App\Services\CompanyGatewayConfig;
use App\Services\EpointService;
use App\Services\GatewayTransactionService;
use Illuminate\Http\Request;

class EpointController extends Controller
{
    public function success(Request $request)
    {
        return $this->redirectFromGateway($request, true);
    }

    public function error(Request $request)
    {
        return $this->redirectFromGateway($request, false);
    }

    public function result(
        Request $request,
        EpointService $epoint,
        GatewayTransactionService $transactions
    ) {
        $data = (string) $request->input('data', '');
        $signature = (string) $request->input('signature', '');

        if ($data === '' || $signature === '') {
            return response('missing', 400);
        }

        $initialPayload = $epoint->decodeData($data);
        $orderId = (string) ($initialPayload['order_id'] ?? '');

        $tx = null;
        if ($orderId !== '') {
            $tx = EpointTransaction::query()->where('order_id', $orderId)->first();
        }

        if (!$tx && !empty($initialPayload['card_id'])) {
            $cardId = (string) $initialPayload['card_id'];
            $tx = EpointTransaction::query()
                ->where('type', EpointTransaction::TYPE_PAYOUT_CARD)
                ->where('status', EpointTransaction::STATUS_PENDING)
                ->where('meta->card_id', $cardId)
                ->latest('id')
                ->first();
        }

        if (!$tx) {
            return response('not_found', 404);
        }

        $company = Company::find($tx->company_id);
        if ($company) {
            $gatewayConfig = app(CompanyGatewayConfig::class);
            $epoint = $epoint->withConfig($gatewayConfig->providerConfig('epoint', $company));
        }

        if (!$epoint->verifySignature($data, $signature)) {
            return response('invalid', 400);
        }

        $payload = $epoint->decodeData($data);

        if ($tx->status === EpointTransaction::STATUS_SUCCESS) {
            return response('ok', 200);
        }

        $status = (string)($payload['status'] ?? '');

        if (!$tx->gateway) {
            $tx->gateway = 'epoint';
        }
        if (!$tx->gateway_transaction && !empty($payload['transaction'])) {
            $tx->gateway_transaction = $payload['transaction'];
        }

        $tx->epoint_transaction = $payload['transaction'] ?? $tx->epoint_transaction;
        $tx->bank_transaction = $payload['bank_transaction'] ?? $tx->bank_transaction;
        $tx->code = $payload['code'] ?? $tx->code;
        $tx->message = $payload['message'] ?? $tx->message;
        $tx->rrn = $payload['rrn'] ?? $tx->rrn;
        $tx->bank_response = $payload['bank_response'] ?? $tx->bank_response;
        $tx->payload = $payload;
        $tx->processed_at = now();

        if ($status === 'success') {
            $tx->status = EpointTransaction::STATUS_SUCCESS;
            $tx->save();

            try {
                $transactions->applySuccess($tx, $payload);
            } catch (\Throwable $e) {
                $meta = is_array($tx->meta) ? $tx->meta : [];
                $meta['processing_error'] = $e->getMessage();
                $tx->meta = $meta;
                $tx->save();
            }

            return response('ok', 200);
        }

        $tx->status = EpointTransaction::STATUS_FAILED;
        $tx->save();

        return response('ok', 200);
    }

    private function redirectFromGateway(Request $request, bool $isSuccess)
    {
        $orderId = (string) $request->input('order_id', '');
        if ($orderId === '') {
            return redirect()->route('home');
        }

        $tx = EpointTransaction::query()->where('order_id', $orderId)->first();
        if (!$tx) {
            return redirect()->route('home');
        }

        $status = $isSuccess ? 'success' : 'error';
        $lang = (string) $request->input('lang', '');

        if ($tx->type === EpointTransaction::TYPE_PLAN) {
            return redirect()->route('company.plans.index', [
                'status' => $status,
                'order_id' => $orderId,
            ]);
        }

        if ($tx->type === EpointTransaction::TYPE_ADDON) {
            return redirect()->route('company.addons.index', [
                'status' => $status,
                'order_id' => $orderId,
            ]);
        }

        if ($tx->type === EpointTransaction::TYPE_PAYOUT_CARD || $tx->type === EpointTransaction::TYPE_PAYOUT) {
            return redirect()->route('company.wallet.index', [
                'card' => $status,
                'order_id' => $orderId,
            ]);
        }

        if ($tx->type === EpointTransaction::TYPE_LOAN_PAYMENT) {
            $company = Company::find($tx->company_id);
            if (!$company) {
                return redirect()->route('home');
            }

            $query = [
                'status' => $status,
                'order_id' => $orderId,
            ];
            if ($lang !== '') {
                $query['lang'] = $lang;
            }

            return redirect()->to(url($company->slug . '/pay') . '?' . http_build_query($query));
        }

        return redirect()->route('home');
    }

}
