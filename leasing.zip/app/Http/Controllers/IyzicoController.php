<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\EpointTransaction;
use App\Services\CompanyGatewayConfig;
use App\Services\GatewayTransactionService;
use App\Services\IyzicoService;
use Illuminate\Http\Request;

class IyzicoController extends Controller
{
    public function callback(Request $request, IyzicoService $iyzico, GatewayTransactionService $transactions)
    {
        $token = (string) ($request->input('token') ?? $request->input('checkoutFormToken') ?? '');
        if ($token === '') {
            return response('missing', 400);
        }

        $orderId = (string) $request->query('order_id', '');
        $tx = null;
        if ($orderId !== '') {
            $tx = EpointTransaction::query()->where('order_id', $orderId)->first();
        }

        if (!$tx) {
            $tx = EpointTransaction::query()
                ->where('meta->iyzico_token', $token)
                ->latest('id')
                ->first();
        }

        if (!$tx) {
            return response('not_found', 404);
        }

        $company = Company::find($tx->company_id);
        if ($company) {
            $gatewayConfig = app(CompanyGatewayConfig::class);
            $iyzico = $iyzico->withConfig($gatewayConfig->providerConfig('iyzico', $company));
        }

        $payload = $iyzico->retrieveCheckoutForm($token, $request->input('lang'), $orderId !== '' ? $orderId : null);

        $conversationId = (string) ($payload['conversation_id'] ?? $payload['conversationId'] ?? '');
        if ($orderId === '' && $conversationId !== '') {
            $orderId = $conversationId;
        }

        $tx = null;
        if ($orderId !== '') {
            $tx = EpointTransaction::query()->where('order_id', $orderId)->first();
        }

        if (!$tx) {
            $tx = EpointTransaction::query()
                ->where('meta->iyzico_token', $token)
                ->latest('id')
                ->first();
        }

        if (!$tx) {
            return response('not_found', 404);
        }

        if ($tx->status === EpointTransaction::STATUS_SUCCESS) {
            return response('ok', 200);
        }

        $status = strtolower((string) ($payload['status'] ?? ''));
        $paymentStatus = strtoupper((string) ($payload['payment_status'] ?? $payload['paymentStatus'] ?? ''));
        $success = $status === 'success' && ($paymentStatus === '' || $paymentStatus === 'SUCCESS');

        $tx->gateway = 'iyzico';
        $tx->gateway_transaction = $payload['payment_id']
            ?? $payload['paymentId']
            ?? $tx->gateway_transaction
            ?? $token;
        $tx->code = $payload['errorCode'] ?? $tx->code;
        $tx->message = $payload['errorMessage'] ?? $tx->message;
        $tx->payload = $payload;
        $tx->processed_at = now();

        if ($success) {
            $tx->status = EpointTransaction::STATUS_SUCCESS;
            $tx->save();

            try {
                $transactions->applySuccess($tx, $payload);
            } catch (\Throwable $e) {
                $meta = is_array($tx->meta) ? $tx->meta : [];
                $meta['processing_error'] = $e->getMessage();
                $tx->meta = $meta;
                $tx->save();
            }

            return response('ok', 200);
        }

        $tx->status = EpointTransaction::STATUS_FAILED;
        $tx->save();

        return response('ok', 200);
    }

    public function redirect(Request $request)
    {
        $orderId = (string) $request->query('order_id', '');
        if ($orderId === '') {
            return redirect()->route('home');
        }

        $tx = EpointTransaction::query()->where('order_id', $orderId)->first();
        if (!$tx) {
            return redirect()->route('home');
        }

        $status = $tx->status === EpointTransaction::STATUS_SUCCESS ? 'success' : 'error';
        $lang = (string) $request->query('lang', '');

        if ($tx->type === EpointTransaction::TYPE_PLAN) {
            return redirect()->route('company.plans.index', [
                'status' => $status,
                'order_id' => $orderId,
            ]);
        }

        if ($tx->type === EpointTransaction::TYPE_ADDON) {
            return redirect()->route('company.addons.index', [
                'status' => $status,
                'order_id' => $orderId,
            ]);
        }

        if ($tx->type === EpointTransaction::TYPE_LOAN_PAYMENT) {
            $company = Company::find($tx->company_id);
            if (!$company) {
                return redirect()->route('home');
            }

            $query = [
                'status' => $status,
                'order_id' => $orderId,
            ];
            if ($lang !== '') {
                $query['lang'] = $lang;
            }

            return redirect()->to(url($company->slug . '/pay') . '?' . http_build_query($query));
        }

        return redirect()->route('home');
    }
}
