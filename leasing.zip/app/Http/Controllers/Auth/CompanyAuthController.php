<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Scopes\TenantScope;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class CompanyAuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $phone = normalizeAzPhone($request->input('phone'));
        if (!$phone) {
            throw ValidationException::withMessages([
                'phone' => 'Telefon formatı yanlışdır. Məs: +994501234567',
            ]);
        }

        $data = $request->merge(['phone' => $phone])->validate([
            'phone' => ['required','string','max:32','regex:/^\+994\d{9}$/'],
            'password' => ['required','string'],
            'remember' => ['nullable'],
        ]);

        $key = 'login:'.Str::lower($data['phone']).'|'.$request->ip();
        if (RateLimiter::tooManyAttempts($key, 8)) {
            throw ValidationException::withMessages([
                'phone' => 'Çox cəhd edildi. Bir az sonra yenidən yoxla.',
            ]);
        }

        $user = User::withoutGlobalScope(TenantScope::class)
            ->where('phone', $data['phone'])
            ->first();

        if (!$user || !Hash::check($data['password'], $user->password)) {
            RateLimiter::hit($key, 60);
            throw ValidationException::withMessages([
                'phone' => 'Telefon və ya şifrə yanlışdır.',
            ]);
        }

        if (!$user->is_active) {
            throw ValidationException::withMessages([
                'phone' => 'Hesab deaktivdir.',
            ]);
        }

        $isSuperAdmin = ($user->role === 'superadmin');
        $company = $user->company;
        if (!$isSuperAdmin && (!$company || !$company->is_active || $company->suspended_at)) {
            throw ValidationException::withMessages([
                'phone' => 'Şirkət deaktiv və ya bloklanıb.',
            ]);
        }

        RateLimiter::clear($key);

        Auth::login($user, (bool)($data['remember'] ?? false));
        $request->session()->regenerate();

        $user->forceFill(['last_login_at' => now()])->save();

        return $request->expectsJson()
            ? response()->json(['ok' => true])
            : redirect()->route('dashboard');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return $request->expectsJson()
            ? response()->json(['ok' => true])
            : redirect()->route('login');
    }
}
