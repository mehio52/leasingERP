<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\User;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class CompanyRegisterController extends Controller
{
    public function show()
    {
        return view('auth.register-company');
    }

    public function store(Request $request, SubscriptionService $subs)
    {
        // 1) Normalize
        $companyPhone = normalizeAzPhone($request->input('company_phone'));
        $ownerPhone   = normalizeAzPhone($request->input('owner_phone'));
        if (!$request->filled('module')) {
            $request->merge(['module' => 'leasing']);
        }

        if (!$companyPhone) {
            throw ValidationException::withMessages(['company_phone' => 'Telefon formatı yanlışdır. Məs: +994501234567']);
        }
        if (!$ownerPhone) {
            throw ValidationException::withMessages(['owner_phone' => 'Telefon formatı yanlışdır. Məs: +994501234567']);
        }

        $request->merge([
            'company_phone' => $companyPhone,
            'owner_phone'   => $ownerPhone,
        ]);

        // 2) Validate
        $data = $request->validate([
            'company_name'  => ['required','string','max:255'],
            'company_phone' => ['required','string','max:32','regex:/^\+994\d{9}$/','unique:companies,phone'],
            'module'        => ['required', Rule::in(['leasing','rentacar','taxipark'])],

            'owner_first_name' => ['required','string','max:255'],
            'owner_last_name'  => ['required','string','max:255'],
            'owner_phone'      => ['required','string','max:32','regex:/^\+994\d{9}$/','unique:users,phone'],

            'password' => ['required','string','min:6','confirmed'],
        ]);

        // API çağırışı? (api.php və ya Accept: application/json)
        $isApi = $request->is('api/*') || $request->expectsJson();

        [$company, $owner] = DB::transaction(function () use ($data, $subs) {

            $base = Str::slug($data['company_name']) ?: 'company';
            $slug = $base;
            $i = 2;
            while (Company::where('slug', $slug)->exists()) {
                $slug = $base.'-'.$i;
                $i++;
            }

            $company = Company::create([
                'name'      => $data['company_name'],
                'slug'      => $slug,
                'phone'     => $data['company_phone'],
                'module'    => $data['module'],
                'is_active' => true,
                'timezone'  => 'Asia/Baku',
                'locale'    => 'az',
                'currency'  => 'AZN',
            ]);

            $owner = User::create([
                'company_id' => $company->id,
                'first_name' => $data['owner_first_name'],
                'last_name'  => $data['owner_last_name'],
                'phone'      => $data['owner_phone'],
                'email'      => null,
                'password'   => Hash::make($data['password']),
                'is_owner'   => true,
                'role'       => 'owner',
                'is_active'  => true,
                'created_by' => null,
            ]);

            $subs->assignTrial($company, 'trial');

            return [$company, $owner];
        });

        // ✅ API: sessiya/login YOX
        if ($isApi) {
            return response()->json([
                'ok' => true,
                'company_id' => $company->id,
                'trial_ends_at' => $company->fresh()->trial_ends_at,
            ], 201);
        }

        // ✅ WEB: login + session burda
        Auth::login($owner);
        $request->session()->regenerate();

        return redirect('/'); // və ya route('dashboard')
    }
}
