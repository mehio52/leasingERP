<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Events\NotificationCreated;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;

class ForgotPasswordController extends Controller
{
    public function requestReset(Request $request)
    {
        $data = $request->validate([
            'phone' => ['required','string','max:32'],
        ]);

        $user = User::where('phone', $data['phone'])->first();
        if (!$user) {
            return back()->withErrors(['phone' => 'İstifadəçi tapılmadı']);
        }

        // company owners
        $owners = User::where('company_id', $user->company_id)
            ->where(function ($q) {
                $q->where('is_owner', true)->orWhere('role', 'owner');
            })
            ->get();

        foreach ($owners as $owner) {
            $notif = Notification::create([
                'company_id' => $user->company_id,
                'sender_id' => null,
                'target_scope' => 'user',
                'target_user_id' => $owner->id,
                'title' => 'Şifrə yeniləmə istəyi',
                'body' => 'İstifadəçi '.$user->full_name.' ('.$user->phone.') şifrəni yeniləmək istəyir.',
            ]);
            NotificationCreated::dispatch($notif);
        }

        return back()->with('status', 'İstək göndərildi. Şirkət sahibi şifrəni yeniləyə bilər.');
    }
}
