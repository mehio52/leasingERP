<?php

namespace App\Http\Controllers;

use App\Models\PlatformBlogPost;

class PublicBlogController extends Controller
{
    public function index()
    {
        $posts = PlatformBlogPost::query()
            ->published()
            ->latest('published_at')
            ->latest('id')
            ->paginate(12);

        return view('blog.index', compact('posts'));
    }

    public function show(string $slug)
    {
        $post = PlatformBlogPost::query()
            ->published()
            ->where('slug', $slug)
            ->with('images')
            ->firstOrFail();

        return view('blog.show', compact('post'));
    }
}
