<?php

namespace App\Http\Controllers;

use App\Models\AccountDocument;
use App\Models\BhphAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class AccountDocumentController extends Controller
{
    public function download(Request $request, BhphAccount $account, AccountDocument $document)
    {
        $companyId = $request->user()?->company_id;
        abort_unless($companyId && (int)$companyId === (int)$account->company_id, 403);
        abort_unless((int)$document->bhph_account_id === (int)$account->id, 403);
        abort_unless((int)$document->company_id === (int)$companyId, 403);

        if (!Storage::exists($document->file_path)) {
            abort(404);
        }

        return Storage::download($document->file_path, $document->file_name);
    }
}
