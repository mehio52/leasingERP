<?php

namespace App\Http\Controllers;

use App\Models\AccountDocument;
use App\Models\BhphAccount;
use App\Models\Contract;
use App\Models\Customer;
use App\Models\DocumentTemplate;
use App\Models\LeasingOption;
use App\Models\Payment;
use App\Models\PaymentOption;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\AmortizationService;
use App\Services\DocumentAutomationService;
use App\Services\PenaltyService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BhphAccountController extends Controller
{
    public function __construct(
        private AmortizationService $amortService,
        private PenaltyService $penaltyService,
        private DocumentAutomationService $documentAutomationService
    ) {
        $this->middleware('perm:bhph.view')->only(['index','show']);
        $this->middleware('perm:bhph.create')->only(['create','store']);
        $this->middleware('perm:bhph.edit')->only(['edit','update']);
        $this->middleware('perm:bhph.delete')->only(['destroy']);
    }

    private function freqLabel(?string $freq): string
    {
        return match ($freq) {
            LeasingOption::FREQ_WEEKLY   => 'Həftəlik',
            LeasingOption::FREQ_BIWEEKLY => '2 həftədə 1',
            default                      => 'Aylıq',
        };
    }

    private function methodLabel(?string $m): string
    {
        return match ($m) {
            LeasingOption::AMORT_REDUCING_BALANCE => 'Reducing balance',
            LeasingOption::AMORT_FLAT             => 'Flat',
            default                               => 'Annuity',
        };
    }

    private function allocLabel(?string $a): string
    {
        return match ($a) {
            LeasingOption::ALLOC_PRINCIPAL_FIRST => 'Əsas borc əvvəl',
            default                              => 'Faiz əvvəl',
        };
    }

    public function index(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId, 403, 'User şirkətə bağlı deyil.');

        $statuses = [
            BhphAccount::STATUS_ACTIVE   => 'Aktiv',
            BhphAccount::STATUS_OVERDUE  => 'Gecikmiş',
            BhphAccount::STATUS_LEGAL    => 'Məhkəmət',
            BhphAccount::STATUS_INACTIVE => 'Deaktiv',
        ];

        $q = trim((string)$request->query('q', ''));
        $status = (string)$request->query('status', '');
        $today = now()->toDateString();

        $query = BhphAccount::query()
            ->where('company_id', $companyId)
            ->with(['customer','vehicle','contract'])
            ->withCount(['amortizations as overdue_installments_count' => function ($q) use ($today) {
                $q->whereColumn('paid_amount', '<', 'due_amount')
                    ->whereDate('due_date', '<', $today);
            }])
            ->latest('id');

        if ($status !== '' && isset($statuses[$status])) {
            if ($status === BhphAccount::STATUS_OVERDUE) {
                $query->where(function ($w) use ($today) {
                    $w->where('status', BhphAccount::STATUS_OVERDUE)
                        ->orWhere(function ($w) use ($today) {
                            $w->where('status', BhphAccount::STATUS_ACTIVE)
                                ->whereHas('amortizations', function ($a) use ($today) {
                                    $a->whereColumn('paid_amount', '<', 'due_amount')
                                        ->whereDate('due_date', '<', $today);
                                });
                        });
                });
            } elseif ($status === BhphAccount::STATUS_ACTIVE) {
                $query->where('status', BhphAccount::STATUS_ACTIVE)
                    ->whereDoesntHave('amortizations', function ($a) use ($today) {
                        $a->whereColumn('paid_amount', '<', 'due_amount')
                            ->whereDate('due_date', '<', $today);
                    });
            } else {
                $query->where('status', $status);
            }
        }

        if ($q !== '') {
            $query->where(function ($w) use ($q) {
                if (ctype_digit($q)) {
                    $w->orWhere('id', (int)$q);
                }

                $w->orWhereHas('customer', function ($c) use ($q) {
                    $c->where('first_name', 'like', "%{$q}%")
                      ->orWhere('last_name', 'like', "%{$q}%")
                      ->orWhere('father_name', 'like', "%{$q}%")
                      ->orWhere('phone', 'like', "%{$q}%");
                });

                $w->orWhereHas('vehicle', function ($v) use ($q) {
                    $v->where('brand', 'like', "%{$q}%")
                      ->orWhere('model', 'like', "%{$q}%")
                      ->orWhere('plate_number', 'like', "%{$q}%");
                });
            });
        }

        $accounts = $query->paginate(15)->withQueryString();

        return view('bhph_accounts.index', compact('user', 'accounts', 'q', 'status', 'statuses'));
    }

    public function create(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId, 403, 'User şirkətə bağlı deyil.');

        $leasing = LeasingOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            [
                'amortization_method' => LeasingOption::AMORT_ANNUITY,
                'payment_frequency'   => LeasingOption::FREQ_MONTHLY,
                'allocation_order'    => LeasingOption::ALLOC_INTEREST_FIRST,
                'grace_days'          => 0,
                'late_fee_type'       => LeasingOption::LATE_FEE_NONE,
                'late_fee_value'      => 0,
                'rounding_step'       => 0.01,
                'allow_partial_payments' => true,
                'settings'            => [],
            ]
        );

        $customers = Customer::query()->where('company_id', $companyId)->orderByDesc('id')->get();

        $vehicles = Vehicle::query()
            ->where('company_id', $companyId)
            ->where('status', 'available')
            ->orderByDesc('id')
            ->get();

        $freqLabel   = $this->freqLabel($leasing->payment_frequency);
        $methodLabel = $this->methodLabel($leasing->amortization_method);
        $allocLabel  = $this->allocLabel($leasing->allocation_order);

        return view('bhph_accounts.create', compact('user','leasing','customers','vehicles','freqLabel','methodLabel','allocLabel'));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId, 403, 'User sirketle bagli deyil.');

        $data = $request->validate([
            'customer_id' => ['required','integer'],
            'vehicle_id'  => ['required','integer'],
            'contract_id' => ['nullable','integer'],
            'contract_no' => ['required','string','max:64'],
            'contract_type' => ['required','in:two,three'],

            'seller_name' => ['nullable','string','max:255'],
            'seller_phone' => ['nullable','string','max:64'],
            'seller_id_number' => ['nullable','string','max:128'],

            'loan_amount' => ['required','numeric','min:0.01','max:999999999'],
            'annual_interest_rate' => ['required','numeric','min:0','max:999.99'],
            'term_months' => ['required','integer','min:1','max:360'],

            'down_payment'    => ['nullable','numeric','min:0','max:999999999'],
            'insurance_fee'   => ['nullable','numeric','min:0','max:999999999'],
            'commission_fee'  => ['nullable','numeric','min:0','max:999999999'],
            'gps_fee'         => ['nullable','numeric','min:0','max:999999999'],
            'third_party_seller_fullname' => ['nullable','string','max:255'],
            'document_metadata' => ['nullable','array'],
            'document_metadata.*' => ['nullable','string','max:500'],

            'payment_start_date' => ['required','date'],
        ]);

        foreach (['down_payment','insurance_fee','commission_fee','gps_fee'] as $k) {
            $data[$k] = (float)($data[$k] ?? 0);
        }

        $metadata = array_filter($request->input('document_metadata', []), fn($value) => $value !== null && $value !== '');
        $data['document_metadata'] = $metadata ?: null;

        $metadata = array_filter($request->input('document_metadata', []), fn($value) => $value !== null && $value !== '');
        $data['document_metadata'] = $metadata ?: null;

        abort_unless(
            Customer::where('id',$data['customer_id'])->where('company_id',$companyId)->exists(),
            403, 'Customer bu sirkete aid deyil.'
        );

        $contractExists = Contract::query()
            ->where('company_id', $companyId)
            ->where('contract_no', $data['contract_no'])
            ->exists();
        if ($contractExists) {
            throw ValidationException::withMessages([
                'contract_no' => 'Bu contract nomresi artiq movcuddur.',
            ]);
        }

        if ($data['contract_type'] === 'three') {
            $request->validate([
                'seller_name' => ['required','string','max:255'],
                'seller_phone' => ['required','string','max:64'],
                'seller_id_number' => ['nullable','string','max:128'],
            ]);
        } else {
            $data['seller_name'] = null;
            $data['seller_phone'] = null;
            $data['seller_id_number'] = null;
        }

        $leasing = LeasingOption::query()->where('company_id', $companyId)->first();
        if (!$leasing) {
            return redirect()->route('company.leasing_options.edit')
                ->with('status','Leasing options yoxdur. Evvel leasing options yarat/yadda saxla.');
        }

        return DB::transaction(function () use ($companyId, $data, $leasing) {

            $vehicle = Vehicle::query()
                ->where('company_id', $companyId)
                ->where('id', $data['vehicle_id'])
                ->lockForUpdate()
                ->firstOrFail();

            if ($vehicle->status !== 'available') {
                throw ValidationException::withMessages([
                    'vehicle_id' => 'Bu avtomobil artiq satisda deyil. Status: '.$vehicle->status,
                ]);
            }

            $vehicle->status = 'leasing';
            $vehicle->save();

            $account = new BhphAccount();
            $account->fill($data);
            $account->company_id = $companyId;
            $account->status = BhphAccount::STATUS_ACTIVE;

            $account->paid_total_amount     = 0;
            $account->paid_interest_amount  = 0;
            $account->paid_principal_amount = 0;
            $account->credit_balance        = 0;

            $account->save();

            $contract = Contract::query()->create([
                'company_id'      => $companyId,
                'customer_id'     => $data['customer_id'],
                'vehicle_id'      => $data['vehicle_id'],
                'bhph_account_id' => $account->id,
                'contract_no'     => $data['contract_no'],
                'contract_type'   => $data['contract_type'],
                'seller_name'     => $data['seller_name'],
                'seller_phone'    => $data['seller_phone'],
                'seller_id_number'=> $data['seller_id_number'],
                'signed_date'     => $data['payment_start_date'],
                'start_date'      => $data['payment_start_date'],
                'status'          => Contract::STATUS_ACTIVE,
            ]);

            $account->contract_id = $contract->id;
            $account->save();

            $this->amortService->generateForAccount($account, $leasing);

            $template = DocumentTemplate::query()
                ->where('company_id', $companyId)
                ->where('contract_type', $data['contract_type'])
                ->where('is_active', true)
                ->orderByDesc('id')
                ->first();

            if ($template) {
                $this->documentAutomationService->exportForAccount($account, $template);
            }

            return redirect()
                ->route('bhph_accounts.show', $account)
                ->with('status', 'Hesab yaradildi, amortizasiya quruldu, avtomobil leasinge kecdi.');
        });
    }

    public function show(Request $request, BhphAccount $account)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId && (int)$account->company_id === (int)$companyId, 403);

        $account->load(['customer','vehicle','contract']);

        $leasing = LeasingOption::query()->where('company_id', $companyId)->first();

        $freqLabel   = $this->freqLabel($leasing?->payment_frequency);
        $methodLabel = $this->methodLabel($leasing?->amortization_method);
        $allocLabel  = $this->allocLabel($leasing?->allocation_order);

        $financedPrincipal = $this->amortService->financedPrincipal($account);
        $estimatedN = $leasing ? $this->amortService->estimateInstallments((int)$account->term_months, (string)$leasing->payment_frequency) : (int)$account->term_months;
        $paymentOption = PaymentOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            PaymentOption::defaults()
        );
        $penaltySummary = $this->penaltyService->summarizeAccount($account, Carbon::now());

        $payments = Payment::query()
            ->where('company_id', $companyId)
            ->where('bhph_account_id', $account->id)
            ->latest('id')
            ->limit(20)
            ->get();

        $paymentSummary = Payment::query()
            ->where('company_id', $companyId)
            ->where('bhph_account_id', $account->id)
            ->where('status', Payment::STATUS_CONFIRMED)
            ->selectRaw('
                COALESCE(SUM(amount),0) as total_paid,
                COALESCE(SUM(principal_amount),0) as principal_paid,
                COALESCE(SUM(interest_amount),0) as interest_paid,
                COALESCE(SUM(penalty_amount),0) as penalty_paid
            ')
            ->first();

        $currentDue = $account->amortizations()
            ->whereColumn('paid_amount', '<', 'due_amount')
            ->whereDate('due_date', '<=', now()->toDateString())
            ->selectRaw('COALESCE(SUM(due_amount - paid_amount),0) as due')
            ->value('due') ?? 0;

        $rows = $account->amortizations()
            ->orderBy('installment_no')
            ->paginate(20)
            ->withQueryString();

        $amortSummary = $account->amortizations()
            ->selectRaw('
                COALESCE(SUM(principal_amount),0)  as principal_due,
                COALESCE(SUM(interest_amount),0)   as interest_due,
                COALESCE(SUM(paid_principal),0)    as principal_paid,
                COALESCE(SUM(paid_interest),0)     as interest_paid,
                COALESCE(SUM(paid_amount),0)       as total_paid,
                COALESCE(SUM(due_amount),0)        as total_due
            ')
            ->first();

        $documents = $account->documents()
            ->with('template')
            ->orderByDesc('id')
            ->get();

        $previewTemplate = DocumentTemplate::query()
            ->where('company_id', $companyId)
            ->where('contract_type', $account->contract_type ?? 'two')
            ->where('is_active', true)
            ->orderByDesc('id')
            ->first();

        return view('bhph_accounts.show', compact(
            'account','leasing','rows',
            'freqLabel','methodLabel','allocLabel',
            'financedPrincipal','estimatedN',
            'paymentOption','payments','amortSummary','paymentSummary','currentDue','penaltySummary','documents','previewTemplate'
        ));
    }

    /**
     * 3-tərəfli müqavilə üçün tərəflərin məlumatını toplayır.
     */
    private function buildThreePartyContractData(BhphAccount $account): array
    {
        $company = $account->company;
        $customer = $account->customer;
        $vehicle = $account->vehicle;

        return [
            'seller' => [
                'name' => $account->seller_name ?? $account->contract?->seller_name,
                'phone' => $account->seller_phone ?? $account->contract?->seller_phone,
                'id_number' => $account->seller_id_number ?? $account->contract?->seller_id_number,
            ],
            'buyer' => [
                'id' => $customer?->id,
                'name' => $customer?->full_name,
                'phone' => $customer?->phone,
                'fin' => $customer?->fin_code,
                'voen' => $customer?->voen,
            ],
            'lessor' => [
                'id' => $company?->id,
                'name' => $company?->name,
                'voen' => $company?->voen,
                'address' => $company?->address,
                'phone' => $company?->phone,
            ],
            'vehicle' => [
                'id' => $vehicle?->id,
                'brand' => $vehicle?->brand,
                'model' => $vehicle?->model,
                'sub_model' => $vehicle?->sub_model,
                'year' => $vehicle?->year,
                'vin' => $vehicle?->vin_code,
                'plate' => $vehicle?->plate_number,
                'color' => $vehicle?->color,
            ],
            'contract' => [
                'id' => $account->contract?->id,
                'no' => $account->contract?->contract_no,
                'type' => $account->contract?->contract_type ?? $account->contract_type,
                'signed_date' => $account->contract?->signed_date,
                'start_date' => $account->contract?->start_date,
            ],
        ];
    }

    public function edit(Request $request, BhphAccount $account)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId && (int)$account->company_id === (int)$companyId, 403);

        $leasing = LeasingOption::query()->where('company_id', $companyId)->firstOrFail();

        $customers = Customer::query()->where('company_id', $companyId)->orderByDesc('id')->get();

        $vehicles = Vehicle::query()
            ->where('company_id', $companyId)
            ->where('id', $account->vehicle_id)
            ->get();

        $freqLabel = $this->freqLabel($leasing->payment_frequency);
        $methodLabel = $this->methodLabel($leasing->amortization_method);
        $allocLabel = $this->allocLabel($leasing->allocation_order);

        return view('bhph_accounts.edit', compact('user','account','leasing','customers','vehicles','freqLabel','methodLabel','allocLabel'));
    }

    public function update(Request $request, BhphAccount $account)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId && (int)$account->company_id === (int)$companyId, 403);

        $data = $request->validate([
            'customer_id' => ['required','integer'],
            'contract_id' => ['nullable','integer'],
            'contract_type' => ['required','in:two,three'],

            'seller_name' => ['nullable','string','max:255'],
            'seller_phone' => ['nullable','string','max:64'],
            'seller_id_number' => ['nullable','string','max:128'],

            'loan_amount' => ['required','numeric','min:0.01','max:999999999'],
            'annual_interest_rate' => ['required','numeric','min:0','max:999.99'],
            'term_months' => ['required','integer','min:1','max:360'],

            'down_payment'    => ['nullable','numeric','min:0','max:999999999'],
            'insurance_fee'   => ['nullable','numeric','min:0','max:999999999'],
            'commission_fee'  => ['nullable','numeric','min:0','max:999999999'],
            'gps_fee'         => ['nullable','numeric','min:0','max:999999999'],
            'third_party_seller_fullname' => ['nullable','string','max:255'],
            'document_metadata' => ['nullable','array'],
            'document_metadata.*' => ['nullable','string','max:500'],

            'payment_start_date' => ['required','date'],

            'status' => ['required','in:active,overdue,legal,inactive'],
            'regenerate_schedule' => ['nullable','boolean'],
        ]);

        foreach (['down_payment','insurance_fee','commission_fee','gps_fee'] as $k) {
            $data[$k] = (float)($data[$k] ?? 0);
        }

        if ($data['contract_type'] === 'three') {
            $request->validate([
                'seller_name' => ['required','string','max:255'],
                'seller_phone' => ['required','string','max:64'],
                'seller_id_number' => ['nullable','string','max:128'],
            ]);
        } else {
            $data['seller_name'] = null;
            $data['seller_phone'] = null;
            $data['seller_id_number'] = null;
        }

        abort_unless(
            Customer::where('id',$data['customer_id'])->where('company_id',$companyId)->exists(),
            403, 'Customer bu şirkətə aid deyil.'
        );

        $regenerate = (bool) $request->boolean('regenerate_schedule', false);

        if ($regenerate) {
            $hasPayments = $account->amortizations()->where('paid_amount','>',0)->exists();
            if ($hasPayments) {
                throw ValidationException::withMessages([
                    'regenerate_schedule' => 'Bu hesabda artıq ödəniş var. Amortizasiyanı yenidən qurmaq olmaz.',
                ]);
            }
        }

        $leasing = LeasingOption::query()->where('company_id', $companyId)->firstOrFail();

        return DB::transaction(function () use ($account, $data, $regenerate, $leasing, $companyId) {

            $oldStatus = (string) $account->status;

            $account->fill($data);
            $account->save();

            if ($account->contract_id) {
                Contract::query()
                    ->where('id', $account->contract_id)
                    ->where('company_id', $companyId)
                    ->update([
                        'contract_type'   => $data['contract_type'],
                        'seller_name'     => $data['seller_name'],
                        'seller_phone'    => $data['seller_phone'],
                        'seller_id_number'=> $data['seller_id_number'],
                    ]);
            }

            if ($oldStatus !== BhphAccount::STATUS_INACTIVE && $account->status === BhphAccount::STATUS_INACTIVE) {
                $vehicle = Vehicle::where('company_id',$companyId)->where('id',$account->vehicle_id)->lockForUpdate()->first();
                if ($vehicle && $vehicle->status === 'leasing') {
                    $vehicle->status = 'available';
                    $vehicle->save();
                }
            }

            if ($regenerate) {
                $this->amortService->generateForAccount($account, $leasing);
            }

            return redirect()
                ->route('bhph_accounts.show', $account)
                ->with('status','Hesab yeniləndi.');
        });
    }

    public function destroy(Request $request, BhphAccount $account)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        abort_unless($companyId && (int)$account->company_id === (int)$companyId, 403);

        return DB::transaction(function () use ($account, $companyId) {

            $vehicle = Vehicle::query()
                ->where('company_id', $companyId)
                ->where('id', $account->vehicle_id)
                ->lockForUpdate()
                ->first();

            if ($vehicle && $vehicle->status === 'leasing') {
                $vehicle->status = 'available';
                $vehicle->save();
            }

            $account->status = BhphAccount::STATUS_INACTIVE;
            $account->save();

            $account->delete();

            return redirect()
                ->route('bhph_accounts.index')
                ->with('status', 'Hesab arxivləndi (bazada saxlanıldı).');
        });
    }
}
