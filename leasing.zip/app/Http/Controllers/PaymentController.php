<?php

namespace App\Http\Controllers;

use App\Models\BhphAccount;
use App\Services\PaymentService;
use App\Services\AmortizationService;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function __construct(
        private PaymentService $paymentService,
        private AmortizationService $amortService
    ) {
        $this->middleware('perm:payments.create')->only(['storeCash']);
    }

    public function storeCash(Request $request, BhphAccount $account)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        abort_unless($companyId && (int)$account->company_id === (int)$companyId, 403);

        $data = $request->validate([
            'paid_date' => ['required','date'],
            'amount'    => ['required','numeric','min:0.01','max:999999999'],
            'reference' => ['nullable','string','max:128'],
            'note'      => ['nullable','string','max:2000'],

            // UI soruşanda gələcək
            'overpay_action' => ['nullable','in:apply_next_installments,reduce_principal,keep_as_credit'],
            'use_balance'    => ['nullable','in:auto,partial,topup,none'],
            'balance_draw'   => ['nullable','numeric','min:0','max:999999999'],
        ]);

        $overpayAction = $request->input('overpay_action');
        $useBalance = $request->input('use_balance', 'none');
        $balanceDraw = (float) ($request->input('balance_draw') ?? 0);
        $creditBalance = (float) ($account->credit_balance ?? 0);

        if ($useBalance === 'auto') {
            if ($creditBalance >= (float)$data['amount']) {
                $balanceDraw = (float)$data['amount'];
                // hamısı balansdan gəlir, nağd tələb olunmur
            } elseif ($creditBalance > 0) {
                return redirect()
                    ->route('bhph_accounts.show', $account)
                    ->with('need_balance_choice', [
                        'draft' => $data,
                        'balance' => $creditBalance,
                        'message' => 'Balans ödənişi tamamlamağa yetmir. Balans qədər ödəyək, yoxsa üstünü nağd tamamlayırsınız?',
                    ])
                    ->withInput($data);
            }
        } elseif ($useBalance === 'partial') {
            $balanceDraw = min($creditBalance, (float)$data['amount']);
            $data['amount'] = $balanceDraw; // yalniz balans qədər ödə
            if ($balanceDraw <= 0) {
                return redirect()
                    ->route('bhph_accounts.show', $account)
                    ->withErrors(['amount' => 'Balans boşdur, yalnız balansla ödəniş mümkün deyil.'])
                    ->withInput($data);
            }
        } elseif ($useBalance === 'topup') {
            $balanceDraw = min($creditBalance, (float)$data['amount']);
        } else {
            $balanceDraw = 0.0;
        }

        if ($balanceDraw > $creditBalance + 0.0001) {
            return redirect()
                ->route('bhph_accounts.show', $account)
                ->withErrors(['amount' => 'Balans kifayət etmir.'])
                ->withInput($data);
        }

        $result = $this->paymentService->applyCashPayment($account, $user, $data, $overpayAction, $balanceDraw);

        // UI choice lazımdırsa show-da soruşacağıq
        if (!empty($result['needs_choice'])) {
            return redirect()
                ->route('bhph_accounts.show', $account)
                ->with('need_overpay_choice', [
                    'draft' => $data,
                    'remainder' => $result['remainder'] ?? 0,
                    'message' => $result['message'] ?? 'Qərar lazımdır.',
                    'allowed_actions' => $result['allowed_actions'] ?? [],
                ])
                ->withInput($data);
        }

        // ✅ MƏHZ BURADA: payment yaradılıb + amortizasiya tətbiq olunub, indi totals-ları yenilə
        $this->amortService->syncAccountTotalsFromPayments($account->fresh());

        return redirect()
            ->route('bhph_accounts.show', $account)
            ->with('status', 'Ödəniş qəbul edildi (cash).');
    }
}
