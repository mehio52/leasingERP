<?php

namespace App\Http\Controllers;

use App\Models\EpointTransaction;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\CompanyOption;
use App\Services\CompanyGatewayConfig;
use App\Services\EpointService;
use App\Services\IyzicoService;
use App\Services\PaymentGatewayService;
use App\Services\StripeService;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;

class CompanyPlanController extends Controller
{
    public function index(Request $request, SubscriptionService $subscriptions)
    {
        $user = $request->user();
        if (!$user) abort(403);

        $company = $user->company;
        if (!$company) abort(403);

        if (!$user->is_owner && $user->role !== 'owner' && !$user->hasPermission('settings.edit')) {
            abort(403);
        }

        $module = $company?->moduleCode();
        $plans = Plan::active()
            ->where(function ($q) use ($module) {
                $q->whereNull('module')->orWhere('module', $module);
            })
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $currentSubscription = $subscriptions->current($company);
        $currentPlanCode = $currentSubscription?->plan?->code
            ?? $currentSubscription?->plan_code_snapshot
            ?? $company->plan_code;

        return view('company.plans.index', [
            'plans' => $plans,
            'company' => $company,
            'currentSubscription' => $currentSubscription,
            'currentPlanCode' => $currentPlanCode,
            'gatewayEnabled' => app(PaymentGatewayService::class)->activeProvider($company) !== null,
            'featuresAreOpen' => $subscriptions->featuresAreUnlimited($company)
                || !empty($subscriptions->activeAddonFeatures($company))
                || $subscriptions->activeAddonCount($company) > 0,
        ]);
    }

    public function checkout(Request $request, PaymentGatewayService $gateway, EpointService $epoint, StripeService $stripe, IyzicoService $iyzico)
    {
        $user = $request->user();
        if (!$user) abort(403);

        $company = $user->company;
        if (!$company) abort(403);

        if (!$user->is_owner && $user->role !== 'owner' && !$user->hasPermission('settings.edit')) {
            abort(403);
        }

        $provider = $gateway->activeProvider($company);
        if (!$provider) {
            return back()->withErrors(['payment' => ___('Payment gateway is not configured.')]);
        }

        $gatewayConfig = app(CompanyGatewayConfig::class);

        $data = $request->validate([
            'plan_id' => ['required','integer','exists:plans,id'],
            'billing_period' => ['required','in:monthly,yearly'],
        ]);

        $plan = Plan::query()
            ->active()
            ->where(function ($q) use ($company) {
                $mod = $company?->moduleCode();
                $q->whereNull('module')->orWhere('module', $mod);
            })
            ->findOrFail($data['plan_id']);
        $period = $data['billing_period'] === 'yearly'
            ? Subscription::PERIOD_YEARLY
            : Subscription::PERIOD_MONTHLY;

        $amount = $period === Subscription::PERIOD_YEARLY
            ? (float) $plan->price_yearly
            : (float) $plan->price_monthly;

        if ($amount <= 0) {
            return back()->withErrors(['payment' => ___('Plan price is not set.')]);
        }

        $orderId = EpointTransaction::generateOrderId('plan');
        $description = "Plan {$plan->name} ({$period})";

        $currency = $gateway->providerCurrency($provider, $company, $plan->currency ?? null);

        $tx = EpointTransaction::create([
            'company_id' => $company->id,
            'requested_by_user_id' => $user->id,
            'type' => EpointTransaction::TYPE_PLAN,
            'gateway' => $provider,
            'status' => EpointTransaction::STATUS_PENDING,
            'amount' => $amount,
            'currency' => $currency,
            'order_id' => $orderId,
            'description' => $description,
            'meta' => [
                'plan_id' => $plan->id,
                'billing_period' => $period,
            ],
        ]);

        $successUrl = route('epoint.success', ['order_id' => $orderId]);
        $errorUrl = route('epoint.error', ['order_id' => $orderId]);

        if ($provider === 'stripe') {
            $stripe = $stripe->withConfig($gatewayConfig->providerConfig('stripe', $company));
            $resp = $stripe->createCheckoutSession([
                'amount' => $amount,
                'currency' => strtolower($currency),
                'order_id' => $orderId,
                'description' => $description,
                'success_url' => $successUrl,
                'cancel_url' => $errorUrl,
            ]);

            if (($resp['status'] ?? '') === 'success' && !empty($resp['url'])) {
                $tx->gateway_transaction = $resp['id'] ?? null;
                $tx->payload = $resp['payload'] ?? null;
                $tx->save();
                return redirect()->away($resp['url']);
            }

            $tx->status = EpointTransaction::STATUS_FAILED;
            $tx->message = $resp['message'] ?? 'Payment request failed';
            $tx->payload = $resp;
            $tx->save();

            return back()->withErrors(['payment' => ___('Payment gateway error. Please try again.')]);
        }

        if ($provider === 'iyzico') {
            $options = CompanyOption::query()->where('company_id', $company->id)->first();

            $iyzico = $iyzico->withConfig($gatewayConfig->providerConfig('iyzico', $company));

            $buyer = [
                'id' => 'company_' . $company->id,
                'name' => $company->name ?? 'Company',
                'surname' => $company->legal_name ?? $company->name ?? 'Company',
                'gsm' => $options?->contact_phone ?? $company->phone ?? '',
                'email' => $options?->contact_email ?? $company->email ?? '',
                'identity_number' => $company->voen ?? '',
                'address' => $options?->address ?? $company->address ?? '',
                'city' => $options?->city ?? '',
                'country' => $options?->country ?? '',
                'zip' => '',
                'ip' => $request->ip(),
            ];

            if (($buyer['email'] ?? '') === '' || ($buyer['gsm'] ?? '') === '' || ($buyer['address'] ?? '') === '') {
                return back()->withErrors(['payment' => ___('Company contact details are required for Iyzico payments.')]);
            }

            $callbackUrl = route('iyzico.callback', ['order_id' => $orderId]);
            $resp = $iyzico->createCheckoutForm([
                'amount' => $amount,
                'currency' => $currency,
                'order_id' => $orderId,
                'callback_url' => $callbackUrl,
                'locale' => app()->getLocale(),
                'buyer' => $buyer,
                'item_name' => $description,
                'item_category' => 'Plan',
            ]);

            if (($resp['status'] ?? '') === 'success' && !empty($resp['content'])) {
                $meta = is_array($tx->meta) ? $tx->meta : [];
                if (!empty($resp['token'])) {
                    $meta['iyzico_token'] = $resp['token'];
                    $tx->gateway_transaction = $resp['token'];
                }
                $tx->meta = $meta;
                $tx->payload = $resp['raw'] ?? null;
                $tx->save();

                return view('payments.iyzico', [
                    'title' => ___('Complete payment'),
                    'checkoutFormContent' => $resp['content'],
                    'returnUrl' => route('iyzico.redirect', ['order_id' => $orderId]),
                ]);
            }

            $tx->status = EpointTransaction::STATUS_FAILED;
            $tx->message = $resp['message'] ?? 'Payment request failed';
            $tx->payload = $resp;
            $tx->save();

            return back()->withErrors(['payment' => ___('Payment gateway error. Please try again.')]);
        }

        $epoint = $epoint->withConfig($gatewayConfig->providerConfig('epoint', $company));
        $resp = $epoint->requestPayment([
            'public_key' => $epoint->publicKey(),
            'amount' => $amount,
            'currency' => $currency,
            'language' => $epoint->normalizeLanguage(app()->getLocale()),
            'order_id' => $orderId,
            'description' => $description,
            'success_redirect_url' => $successUrl,
            'error_redirect_url' => $errorUrl,
        ]);

        if (($resp['status'] ?? '') === 'success' && !empty($resp['redirect_url'])) {
            return redirect()->away($resp['redirect_url']);
        }

        $tx->status = EpointTransaction::STATUS_FAILED;
        $tx->message = $resp['message'] ?? 'Payment request failed';
        $tx->payload = $resp;
        $tx->save();

        return back()->withErrors(['payment' => ___('Payment gateway error. Please try again.')]);
    }
}
