<?php

namespace App\Http\Controllers;

use App\Events\NotificationCreated;
use App\Models\Notification;
use App\Models\Ticket;
use App\Models\TicketMessage;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    private array $categories = [
        'technical' => 'Texniki dəstək',
        'sales' => 'Satış',
        'proposal' => 'Təklif',
        'complaint' => 'Şikayət',
        'other' => 'Digər',
    ];

    private array $priorities = [
        'low' => 'Təcili deyil',
        'normal' => 'Vacib',
        'urgent' => 'Çox vacib',
    ];

    private function ensureCompany(Request $request): void
    {
        $user = $request->user();
        if (!$user || !$user->company_id || $user->isSuperAdmin()) {
            abort(403);
        }
    }

    public function index(Request $request)
    {
        $this->ensureCompany($request);
        $user = $request->user();

        $tickets = Ticket::query()
            ->where('company_id', $user->company_id)
            ->orderByDesc('updated_at')
            ->paginate(20);

        return view('tickets.index', [
            'tickets' => $tickets,
            'categories' => $this->categories,
            'priorities' => $this->priorities,
        ]);
    }

    public function create(Request $request)
    {
        $this->ensureCompany($request);

        return view('tickets.create', [
            'categories' => $this->categories,
            'priorities' => $this->priorities,
        ]);
    }

    public function store(Request $request)
    {
        $this->ensureCompany($request);
        $user = $request->user();

        $data = $request->validate([
            'subject' => ['required','string','max:255'],
            'category' => ['required','in:'.implode(',', array_keys($this->categories))],
            'priority' => ['required','in:'.implode(',', array_keys($this->priorities))],
            'body' => ['required','string','max:5000'],
        ]);

        $ticket = Ticket::create([
            'company_id' => $user->company_id,
            'user_id' => $user->id,
            'subject' => $data['subject'],
            'category' => $data['category'],
            'priority' => $data['priority'],
            'status' => 'open',
        ]);

        TicketMessage::create([
            'ticket_id' => $ticket->id,
            'user_id' => $user->id,
            'body' => $data['body'],
        ]);

        $this->notifySuperadmins($ticket, 'Yeni ticket: '.$ticket->subject, $data['body']);

        return redirect()->route('tickets.show', $ticket)->with('status', 'Ticket göndərildi.');
    }

    public function show(Request $request, Ticket $ticket)
    {
        $this->ensureCompany($request);
        $user = $request->user();
        if ((int)$ticket->company_id !== (int)$user->company_id) {
            abort(404);
        }

        $ticket->load(['messages.user','company','user']);

        return view('tickets.show', [
            'ticket' => $ticket,
            'categories' => $this->categories,
            'priorities' => $this->priorities,
        ]);
    }

    public function reply(Request $request, Ticket $ticket)
    {
        $this->ensureCompany($request);
        $user = $request->user();
        if ((int)$ticket->company_id !== (int)$user->company_id) {
            abort(404);
        }

        $data = $request->validate([
            'body' => ['required','string','max:5000'],
            'close' => ['nullable','boolean'],
        ]);

        TicketMessage::create([
            'ticket_id' => $ticket->id,
            'user_id' => $user->id,
            'body' => $data['body'],
        ]);

        $ticket->status = $request->boolean('close') ? 'closed' : 'open';
        $ticket->save();

        $this->notifySuperadmins($ticket, 'Ticket cavabı: '.$ticket->subject, $data['body']);

        return redirect()->route('tickets.show', $ticket)->with('status', 'Cavab göndərildi.');
    }

    private function notifySuperadmins(Ticket $ticket, string $title, ?string $body = null): void
    {
        $notification = Notification::create([
            'company_id' => $ticket->company_id,
            'sender_id' => $ticket->user_id,
            'target_scope' => 'role',
            'target_role' => 'superadmin',
            'title' => $title,
            'body' => $body,
            'data' => ['ticket_id' => $ticket->id],
        ]);

        try {
            NotificationCreated::dispatch($notification);
        } catch (\Throwable $e) {
            // ignore broadcast failure
        }
    }
}
