<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\User;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CompanyUserController extends Controller
{
    public function __construct(private SubscriptionService $subscriptions)
    {
    }

    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    private function assertSameCompany(User $user): void
    {
        if ((int)$user->company_id !== $this->companyId()) abort(404);
    }

    private function permissionGroups(): array
    {
        $groups = [
            'Customers' => [
                'customers.view'   => 'Customers view',
                'customers.create' => 'Customers create',
                'customers.edit'   => 'Customers edit',
                'customers.delete' => 'Customers delete',
            ],
            'Vehicles' => [
                'vehicles.view'   => 'Vehicles view',
                'vehicles.create' => 'Vehicles create',
                'vehicles.edit'   => 'Vehicles edit',
                'vehicles.delete' => 'Vehicles delete',
                'vehicles.gps'    => 'Vehicles gps',
            ],
            'Rentals' => [
                'rentals.view'   => 'Rentals view',
                'rentals.create' => 'Rentals create',
            ],
            'Taxi park' => [
                'taxi.drivers.view' => 'Taxi drivers view',
                'taxi.drivers.create' => 'Taxi drivers create',
                'taxi.drivers.edit' => 'Taxi drivers edit',
                'taxi.drivers.delete' => 'Taxi drivers delete',
                'taxi.assignments.view' => 'Taxi assignments view',
                'taxi.assignments.create' => 'Taxi assignments create',
                'taxi.assignments.edit' => 'Taxi assignments edit',
                'taxi.assignments.delete' => 'Taxi assignments delete',
                'taxi.issues.view' => 'Taxi vehicle issues view',
                'taxi.issues.create' => 'Taxi vehicle issues create',
                'taxi.issues.edit' => 'Taxi vehicle issues edit',
                'taxi.issues.delete' => 'Taxi vehicle issues delete',
                'taxi.addons.manage' => 'Taxi add-ons manage',
                'taxi.trips.view' => 'Taxi trips view',
                'taxi.trips.create' => 'Taxi trips create',
                'taxi.trips.edit' => 'Taxi trips edit',
                'taxi.trips.delete' => 'Taxi trips delete',
                'taxi.payroll.view' => 'Taxi payroll view',
                'taxi.payroll.manage' => 'Taxi payroll manage',
            ],
            'Contracts & Accounts' => [
                'contracts.view'    => 'Contracts view',
                'contracts.create'  => 'Contracts create',
                'contracts.edit'    => 'Contracts edit',
                'contracts.delete'  => 'Contracts delete',
                'contracts.approve' => 'Contracts approve',
                'bhph.view'         => 'Accounts view',
                'bhph.create'       => 'Accounts create',
                'bhph.edit'         => 'Accounts edit',
                'bhph.delete'       => 'Accounts delete',
            ],
            'Payments' => [
                'payments.view'   => 'Payments view',
                'payments.create' => 'Payments create',
                'payments.edit'   => 'Payments edit',
                'payments.delete' => 'Payments delete',
            ],
            'Owner payments' => [
                'owner_payments.view' => 'Owner payments view',
                'owner_payments.create' => 'Owner payments create',
            ],
            'Risk & Notifications' => [
                'risk.view'   => 'Risk view',
                'risk.create' => 'Risk create',
                'notify.view' => 'Notify view',
                'notify.edit' => 'Notify edit',
                'notify.logs' => 'Notify logs',
                'notify.send' => 'Notifications send (SMS/Email/WA)',
                'whatsapp.campaigns' => 'WhatsApp campaigns',
                'whatsapp.manual' => 'Manual WhatsApp send',
                'whatsapp.settings' => 'WhatsApp settings',
                'whatsapp.logs' => 'WhatsApp logs',
            ],
            'Settings' => [
                'settings.view' => 'Settings view',
                'settings.edit' => 'Settings edit',
                'users.manage'  => 'Users manage',
                'public.theme'  => 'Public theme manage',
                'public.blog'   => 'Public blog manage',
                'public.pages'  => 'Public pages manage',
                'public.test_drives' => 'Public test drives manage',
                'addons.manage' => 'Add-ons purchase/manage',
            ],
        ];

        $groups = $this->filterPermissionGroupsByPlan($groups);
        return $this->filterPermissionGroupsByModule($groups);
    }

    private function permissionFeatureMapExact(): array
    {
        return [
            'vehicles.gps' => 'gps',
            'users.manage' => 'users',
            'public.theme' => 'public_theme',
            'public.blog' => 'public_theme',
            'public.pages' => 'public_theme',
            'public.test_drives' => 'public_theme',
            'whatsapp.campaigns' => 'whatsapp_campaigns',
            'whatsapp.manual' => 'whatsapp_campaigns',
            'whatsapp.settings' => 'notifications',
            'whatsapp.logs' => 'notifications',
            'addons.manage' => 'settings',
            'owner_payments.view' => 'vehicles',
            'owner_payments.create' => 'vehicles',
            'rentals.view' => 'vehicles',
            'rentals.create' => 'vehicles',
            'taxi.addons.manage' => 'taxi',
            'taxi.payroll.view' => 'taxi',
            'taxi.payroll.manage' => 'taxi',
        ];
    }

    private function permissionFeatureMapPrefixes(): array
    {
        return [
            'customers.' => 'customers',
            'vehicles.' => 'vehicles',
            'rentals.' => 'vehicles',
            'taxi.' => 'taxi',
            'contracts.' => 'contracts',
            'bhph.' => 'bhph',
            'payments.' => 'payments',
            'risk.' => 'risk',
            'notify.' => 'notifications',
            'settings.' => 'settings',
        ];
    }

    private function requiredFeaturesForPermission(string $permission): array
    {
        $exact = $this->permissionFeatureMapExact();
        if (isset($exact[$permission])) {
            return (array) $exact[$permission];
        }

        foreach ($this->permissionFeatureMapPrefixes() as $prefix => $feature) {
            if (str_starts_with($permission, $prefix)) {
                return (array) $feature;
            }
        }

        return [];
    }

    private function permissionAllowedByPlan(string $permission, Company $company): bool
    {
        $features = $this->requiredFeaturesForPermission($permission);
        if (empty($features)) {
            return true;
        }

        foreach ($features as $feature) {
            if ($this->subscriptions->hasFeature($company, $feature)) {
                return true;
            }
        }

        return false;
    }

    private function filterPermissionGroupsByPlan(array $groups): array
    {
        $company = auth()->user()?->company;
        if (!$company) {
            return $groups;
        }

        $filtered = [];
        foreach ($groups as $group => $perms) {
            $allowed = [];
            foreach ($perms as $perm => $label) {
                if ($this->permissionAllowedByPlan($perm, $company)) {
                    $allowed[$perm] = $label;
                }
            }
            if (!empty($allowed)) {
                $filtered[$group] = $allowed;
            }
        }

        return $filtered;
    }

    private function filterPermissionsByPlan(array $permissions): array
    {
        $company = auth()->user()?->company;
        if (!$company) {
            return [];
        }

        $allowed = [];
        foreach ($permissions as $permission) {
            if ($this->permissionAllowedByPlan($permission, $company)) {
                $allowed[] = $permission;
            }
        }

        return $allowed;
    }

    private function filterPermissionGroupsByModule(array $groups): array
    {
        $company = auth()->user()?->company;
        if (!$company || !method_exists($company, 'moduleCode')) {
            return $groups;
        }

        if (!in_array($company->moduleCode(), ['rentacar','taxipark'], true)) {
            $filtered = [];
            foreach ($groups as $group => $perms) {
                $allowed = [];
                foreach ($perms as $perm => $label) {
                    if (
                        !str_starts_with($perm, 'owner_payments.')
                        && !str_starts_with($perm, 'rentals.')
                        && !str_starts_with($perm, 'taxi.')
                    ) {
                        $allowed[$perm] = $label;
                    }
                }
                if (!empty($allowed)) {
                    $filtered[$group] = $allowed;
                }
            }
            return $filtered;
        }

        $module = $company->moduleCode();
        $allowedPrefixes = [
            'customers.',
            'vehicles.',
            'notify.',
            'whatsapp.',
            'settings.',
            'public.',
        ];
        if ($module === 'rentacar') {
            $allowedPrefixes[] = 'rentals.';
            $allowedPrefixes[] = 'owner_payments.';
        }
        if ($module === 'taxipark') {
            $allowedPrefixes[] = 'taxi.';
        }
        $allowedExact = [
            'users.manage',
            'addons.manage',
        ];

        $filtered = [];
        foreach ($groups as $group => $perms) {
            $allowed = [];
            foreach ($perms as $perm => $label) {
                $ok = false;
                if (in_array($perm, $allowedExact, true)) {
                    $ok = true;
                } else {
                    foreach ($allowedPrefixes as $prefix) {
                        if (str_starts_with($perm, $prefix)) {
                            $ok = true;
                            break;
                        }
                    }
                }
                if ($ok) {
                    $allowed[$perm] = $label;
                }
            }
            if (!empty($allowed)) {
                $filtered[$group] = $allowed;
            }
        }

        return $filtered;
    }




    private function allowedPermissions(): array
    {
        $all = [];
        foreach ($this->permissionGroups() as $g) $all = array_merge($all, array_keys($g));
        return $all;
    }

    private function normalizePhone(?string $phone): ?string
    {
        if (function_exists('normalizeAzPhone')) {
            $p = normalizeAzPhone($phone);
            return $p ?: $phone;
        }
        return $phone;
    }

    public function index()
    {
        $users = User::query()
            ->where('company_id', $this->companyId())
            ->orderByDesc('id')
            ->paginate(20);

        return view('company.users.index', compact('users'));
    }

    public function create()
    {
        $permissionGroups = $this->permissionGroups();
        return view('company.users.create', compact('permissionGroups'));
    }

    public function store(Request $request)
    {
        $request->merge(['phone' => $this->normalizePhone($request->input('phone'))]);

        $data = $request->validate([
            'first_name' => ['required','string','max:255'],
            'last_name'  => ['required','string','max:255'],
            'phone'      => ['required','string','max:32','regex:/^\+994\d{9}$/', Rule::unique('users','phone')],
            'email'      => ['nullable','email','max:255', Rule::unique('users','email')],
            'password'   => ['required','string','min:8','confirmed'],
            'role'       => ['nullable','string','max:50'],
            'is_active'  => ['nullable','boolean'],
            'permissions'   => ['nullable','array'],
            'permissions.*' => ['string', Rule::in($this->allowedPermissions())],
            'base_salary' => ['nullable','numeric','min:0'],
            'salary_currency' => ['nullable','string','max:8'],
            'commission_type' => ['nullable','string','max:32'],
            'commission_rate' => ['nullable','numeric','min:0'],
            'payout_period' => ['nullable','string','max:32'],
            'salary_notes' => ['nullable','string','max:2000'],
        ]);

        $data['company_id']  = $this->companyId();
        $data['created_by']  = auth()->id();
        $data['is_owner']    = false;
        $data['is_active']   = (bool)($data['is_active'] ?? true);
        $data['permissions'] = array_values(array_unique($this->filterPermissionsByPlan($data['permissions'] ?? [])));

        $user = User::create($data);

        // Notify superadmins about new user
        try {
            \App\Models\Notification::create([
                'company_id' => $user->company_id,
                'sender_id' => auth()->id(),
                'target_scope' => 'role',
                'target_role' => 'superadmin',
                'title' => 'Yeni istifadəçi',
                'body' => $user->full_name.' qeydiyyatdan keçdi.',
            ])->tap(function ($n) {
                event(new \App\Events\NotificationCreated($n));
            });
        } catch (\Throwable $e) {
            // swallow
        }

        return redirect()->route('company.users.edit', $user)->with('success', 'İşçi yaradıldı.');
    }

    public function edit(User $user)
    {
        $this->assertSameCompany($user);

        if ($user->is_owner || $user->role === 'owner') {
            abort(403, 'Owner hesabı buradan edit olunmur.');
        }

        $permissionGroups = $this->permissionGroups();

        return view('company.users.edit', compact('user', 'permissionGroups'));
    }

    public function update(Request $request, User $user)
    {
        $this->assertSameCompany($user);

        if ($user->is_owner || $user->role === 'owner') {
            abort(403, 'Owner hesabı buradan edit olunmur.');
        }

        $request->merge(['phone' => $this->normalizePhone($request->input('phone'))]);

        $data = $request->validate([
            'first_name' => ['required','string','max:255'],
            'last_name'  => ['required','string','max:255'],
            'phone'      => ['required','string','max:32','regex:/^\+994\d{9}$/', Rule::unique('users','phone')->ignore($user->id)],
            'email'      => ['nullable','email','max:255', Rule::unique('users','email')->ignore($user->id)],
            'password'   => ['nullable','string','min:8','confirmed'],
            'role'       => ['nullable','string','max:50'],
            'is_active'  => ['nullable','boolean'],
            'permissions'   => ['nullable','array'],
            'permissions.*' => ['string', Rule::in($this->allowedPermissions())],
            'base_salary' => ['nullable','numeric','min:0'],
            'salary_currency' => ['nullable','string','max:8'],
            'commission_type' => ['nullable','string','max:32'],
            'commission_rate' => ['nullable','numeric','min:0'],
            'payout_period' => ['nullable','string','max:32'],
            'salary_notes' => ['nullable','string','max:2000'],
        ]);

        if (empty($data['password'] ?? null)) unset($data['password']);

        $data['is_active']   = (bool)($data['is_active'] ?? false);
        $data['permissions'] = array_values(array_unique($this->filterPermissionsByPlan($data['permissions'] ?? [])));

        $user->update($data);

        return back()->with('success', 'Dəyişikliklər yadda saxlanıldı.');
    }

    public function resetPassword(Request $request, User $user)
    {
        $this->assertSameCompany($user);
        $actor = $request->user();
        if (!($actor->is_owner || $actor->role === 'owner' || $actor->isSuperAdmin())) {
            abort(403);
        }

        $temp = bin2hex(random_bytes(4)); // 8 hex chars
        $user->password = $temp;
        $user->save();

        return back()->with('status', 'Müvəqqəti şifrə: '.$temp);
    }

    public function destroy(User $user)
    {
        $this->assertSameCompany($user);

        if ($user->id === auth()->id()) {
            return back()->with('error', 'Öz hesabını silə bilməzsən.');
        }

        if ($user->is_owner || $user->role === 'owner') {
            return back()->with('error', 'Owner silinmir.');
        }

        $user->delete();
        return redirect()->route('company.users.index')->with('success', 'İşçi silindi.');
    }
}



