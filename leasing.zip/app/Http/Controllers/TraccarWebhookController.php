<?php

namespace App\Http\Controllers;

use App\Events\NotificationCreated;
use App\Models\Company;
use App\Models\Notification;
use App\Models\Vehicle;
use App\Services\Gps\GpsManager;
use Illuminate\Http\Request;

class TraccarWebhookController extends Controller
{
    public function handle(Request $request)
    {
        // Traccar default webhook payload keys: event > type/speed/deviceId/position/device
        $event = $request->input('event', []);
        $type = $event['type'] ?? $request->input('type');

        if ($type !== 'geofenceEnter' && $type !== 'geofenceExit' && $type !== 'alarm') {
            // speed alarm gələndə type=alarm, alarm="overspeed" olur
        }

        $alarm = $event['alarm'] ?? $request->input('alarm');
        if ($type === 'alarm' && $alarm === 'overspeed') {
            $this->notifyOverspeed($event);
        }

        return response()->json(['ok' => true]);
    }

    private function notifyOverspeed(array $event): void
    {
        $deviceId = $event['deviceId'] ?? null;
        $position = $event['position'] ?? [];
        $speed = $position['speed'] ?? $event['speed'] ?? null;
        $lat = $position['latitude'] ?? null;
        $lng = $position['longitude'] ?? null;

        if (!$deviceId) {
            return;
        }

        $vehicle = Vehicle::where('traccar_device_id', $deviceId)->first();
        if (!$vehicle) {
            // bəzən deviceId numeric olur, uniqueId ilə də yoxlayaq
            $vehicle = Vehicle::where('traccar_device_id', (string) ($event['uniqueId'] ?? ''))->first();
        }
        if (!$vehicle || !$vehicle->company_id) {
            return;
        }

        $gpsManager = app(GpsManager::class);
        if ($gpsManager->providerForCompany($vehicle->company) !== 'traccar') {
            return;
        }

        $companyId = $vehicle->company_id;
        $title = ___('Speed limit exceeded');
        $body = ___(':vehicle sürət limitini aşdı. Sürət: :speed km/s. Yer: :lat,:lng', [
            'vehicle' => $vehicle->display_name ?? $vehicle->plate_number ?? $vehicle->id,
            'speed' => $speed ?? '—',
            'lat' => $lat ?? '—',
            'lng' => $lng ?? '—',
        ]);

        $notif = Notification::create([
            'company_id' => $companyId,
            'sender_id' => null,
            'target_scope' => 'company',
            'title' => $title,
            'body' => $body,
            'data' => [
                'type' => 'overspeed',
                'vehicle_id' => $vehicle->id,
                'speed' => $speed,
                'lat' => $lat,
                'lng' => $lng,
            ],
        ]);

        NotificationCreated::dispatch($notif);
    }
}
