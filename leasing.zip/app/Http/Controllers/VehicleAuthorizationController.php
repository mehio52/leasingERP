<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use App\Models\VehicleAuthorization;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class VehicleAuthorizationController extends Controller
{
    public function __construct()
    {
        $this->middleware('perm:vehicles.view')->only(['indexAll']);
        $this->middleware('perm:vehicles.edit')->only(['index','store','destroy']);
    }

    public function indexAll(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }

        $q = trim((string) $request->query('q', ''));
        $endsIn = $request->query('ends_in_days');
        $endsIn = $endsIn !== null && $endsIn !== '' ? (int) $endsIn : null;

        $authorizations = VehicleAuthorization::query()
            ->where('company_id', $user->company_id)
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($x) use ($q) {
                    $x->where('authorized_name', 'like', "%{$q}%")
                      ->orWhere('note', 'like', "%{$q}%");
                });
            })
            ->when($endsIn !== null && $endsIn >= 0, function ($query) use ($endsIn) {
                $start = now()->startOfDay();
                $end = now()->addDays($endsIn)->endOfDay();
                $query->whereBetween('end_date', [$start, $end]);
            })
            ->with('vehicle')
            ->latest('id')
            ->paginate(20)
            ->withQueryString();

        return view('vehicles.authorizations_all', compact('authorizations', 'q', 'endsIn'));
    }

    public function index(Request $request, Vehicle $vehicle)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }
        if ((int) $vehicle->company_id !== (int) $user->company_id && !$user->isSuperAdmin()) {
            abort(404);
        }

        $authorizations = VehicleAuthorization::query()
            ->where('vehicle_id', $vehicle->id)
            ->latest('id')
            ->paginate(20);

        return view('vehicles.authorizations', compact('vehicle', 'authorizations'));
    }

    public function store(Request $request, Vehicle $vehicle)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }
        if ((int) $vehicle->company_id !== (int) $user->company_id && !$user->isSuperAdmin()) {
            abort(404);
        }

        $data = $request->validate([
            'authorized_name' => ['required','string','max:255'],
            'start_date' => ['nullable','date'],
            'end_date' => ['nullable','date','after_or_equal:start_date'],
            'note' => ['nullable','string','max:2000'],
        ]);

        VehicleAuthorization::create([
            'company_id' => $vehicle->company_id,
            'vehicle_id' => $vehicle->id,
            'authorized_name' => $data['authorized_name'],
            'start_date' => $data['start_date'] ?? null,
            'end_date' => $data['end_date'] ?? null,
            'note' => $data['note'] ?? null,
            'created_by' => $user->id,
        ]);

        return back()->with('status', 'Etibarnamə əlavə edildi.');
    }

    public function destroy(Request $request, VehicleAuthorization $authorization)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }
        if ((int) $authorization->company_id !== (int) $user->company_id && !$user->isSuperAdmin()) {
            abort(404);
        }

        $authorization->delete();

        return back()->with('status', 'Etibarnamə silindi.');
    }
}
