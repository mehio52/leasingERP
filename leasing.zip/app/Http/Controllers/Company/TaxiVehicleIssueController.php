<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\TaxiDriver;
use App\Models\TaxiVehicleIssue;
use App\Models\Vehicle;
use Illuminate\Http\Request;

class TaxiVehicleIssueController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth','module:taxipark','feature:taxi']);
        $this->middleware('perm:taxi.issues.view')->only(['index']);
        $this->middleware('perm:taxi.issues.create')->only(['create','store']);
        $this->middleware('perm:taxi.issues.edit')->only(['edit','update']);
        $this->middleware('perm:taxi.issues.delete')->only(['destroy']);
    }

    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    private function assertSameCompany(TaxiVehicleIssue $issue): void
    {
        if ((int) $issue->company_id !== $this->companyId()) abort(404);
    }

    public function index()
    {
        $issues = TaxiVehicleIssue::query()
            ->where('company_id', $this->companyId())
            ->with(['driver','vehicle'])
            ->orderByDesc('id')
            ->paginate(20);

        return view('company.taxi_issues.index', compact('issues'));
    }

    public function create()
    {
        $drivers = TaxiDriver::where('company_id', $this->companyId())->orderBy('first_name')->orderBy('last_name')->get();
        $vehicles = Vehicle::where('company_id', $this->companyId())->orderBy('id','desc')->get();
        return view('company.taxi_issues.create', compact('drivers','vehicles'));
    }

    public function store(Request $request)
    {
        $data = $this->validateIssue($request);
        $data['company_id'] = $this->companyId();
        $data['reported_at'] = $data['reported_at'] ?? now();
        TaxiVehicleIssue::create($data);
        return redirect()->route('company.taxi_issues.index')->with('status', ___('Issue created.'));
    }

    public function edit(TaxiVehicleIssue $issue)
    {
        $this->assertSameCompany($issue);
        $drivers = TaxiDriver::where('company_id', $this->companyId())->orderBy('first_name')->orderBy('last_name')->get();
        $vehicles = Vehicle::where('company_id', $this->companyId())->orderBy('id','desc')->get();
        return view('company.taxi_issues.edit', compact('issue','drivers','vehicles'));
    }

    public function update(Request $request, TaxiVehicleIssue $issue)
    {
        $this->assertSameCompany($issue);
        $data = $this->validateIssue($request);
        $issue->update($data);
        return back()->with('status', ___('Issue updated.'));
    }

    public function destroy(TaxiVehicleIssue $issue)
    {
        $this->assertSameCompany($issue);
        $issue->delete();
        return back()->with('status', ___('Issue deleted.'));
    }

    private function validateIssue(Request $request): array
    {
        return $request->validate([
            'vehicle_id' => ['required','integer'],
            'driver_id' => ['nullable','integer'],
            'title' => ['required','string','max:190'],
            'details' => ['nullable','string','max:5000'],
            'severity' => ['nullable','string','in:low,normal,high'],
            'status' => ['nullable','string','in:open,in_progress,closed'],
            'reported_at' => ['nullable','date'],
        ]);
    }
}
