<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\CompanyDomainRequest;
use Illuminate\Http\Request;

class DomainRequestController extends Controller
{
    public function index(Request $request)
    {
        $company = $request->user()?->company;
        if (!$company) {
            abort(403);
        }

        $requests = CompanyDomainRequest::query()
            ->where('company_id', $company->id)
            ->latest('id')
            ->get();

        return view('company.domain_requests.index', compact('company', 'requests'));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        $company = $user?->company;
        if (!$company) {
            abort(403);
        }

        $raw = (string) $request->input('requested_domain', '');
        $domain = strtolower(trim($raw));
        $domain = preg_replace('#^https?://#', '', $domain);
        $domain = strtok($domain, '/');
        $domain = preg_replace('/:\\d+$/', '', $domain);

        $request->merge(['requested_domain' => $domain]);

        $request->validate([
            'requested_domain' => [
                'required',
                'string',
                'max:255',
                'regex:/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,}$/i',
            ],
        ], [
            'requested_domain.regex' => ___('Enter a valid domain (example: example.com).'),
        ]);

        $domain = (string) $request->input('requested_domain');

        $alreadyUsed = Company::query()
            ->whereNotNull('domain')
            ->where('domain', $domain)
            ->exists();

        if ($alreadyUsed) {
            return back()->withErrors(['requested_domain' => ___('This domain is already in use.')])->withInput();
        }

        $pending = CompanyDomainRequest::query()
            ->where('company_id', $company->id)
            ->where('status', CompanyDomainRequest::STATUS_PENDING)
            ->exists();

        if ($pending) {
            return back()->withErrors(['requested_domain' => ___('You already have a pending request.')])->withInput();
        }

        CompanyDomainRequest::create([
            'company_id' => $company->id,
            'requested_by' => $user?->id,
            'requested_domain' => $domain,
            'status' => CompanyDomainRequest::STATUS_PENDING,
        ]);

        return redirect()->route('company.domain_requests.index')
            ->with('status', ___('Domain request sent.'));
    }
}
