<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\TaxiDriver;
use App\Models\TaxiVehicleAssignment;
use App\Models\TaxiAddon;
use App\Models\Vehicle;
use Illuminate\Http\Request;

class TaxiVehicleAssignmentController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth','module:taxipark','feature:taxi']);
        $this->middleware('perm:taxi.assignments.view')->only(['index']);
        $this->middleware('perm:taxi.assignments.create')->only(['create','store']);
        $this->middleware('perm:taxi.assignments.edit')->only(['edit','update']);
        $this->middleware('perm:taxi.assignments.delete')->only(['destroy']);
    }

    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    private function assertSameCompany(TaxiVehicleAssignment $assignment): void
    {
        if ((int) $assignment->company_id !== $this->companyId()) abort(404);
    }

    public function index()
    {
        $assignments = TaxiVehicleAssignment::query()
            ->where('company_id', $this->companyId())
            ->with(['driver','vehicle'])
            ->orderByDesc('id')
            ->paginate(20);

        return view('company.taxi_assignments.index', compact('assignments'));
    }

    public function create()
    {
        $drivers = TaxiDriver::where('company_id', $this->companyId())->orderBy('first_name')->orderBy('last_name')->get();
        $vehicles = Vehicle::where('company_id', $this->companyId())->orderBy('id','desc')->get();
        $addons = TaxiAddon::where('company_id', $this->companyId())->where('is_active', true)->orderBy('sort_order')->get();
        return view('company.taxi_assignments.create', compact('drivers','vehicles','addons'));
    }

    public function store(Request $request)
    {
        $data = $this->validateAssignment($request);
        $data['company_id'] = $this->companyId();
        $data['issues'] = $this->parseKeyValuePairs($request->input('issues_k'), $request->input('issues_v'));
        $data['addons'] = $this->parseAddonMap($request->input('addons_id'), $request->input('addons_qty'));
        $data['attributes'] = $this->parseKeyValuePairs($request->input('attrs_k'), $request->input('attrs_v'));
        TaxiVehicleAssignment::create($data);
        return redirect()->route('company.taxi_assignments.index')->with('status', ___('Assignment created.'));
    }

    public function edit(TaxiVehicleAssignment $assignment)
    {
        $this->assertSameCompany($assignment);
        $drivers = TaxiDriver::where('company_id', $this->companyId())->orderBy('first_name')->orderBy('last_name')->get();
        $vehicles = Vehicle::where('company_id', $this->companyId())->orderBy('id','desc')->get();
        $addons = TaxiAddon::where('company_id', $this->companyId())->where('is_active', true)->orderBy('sort_order')->get();
        return view('company.taxi_assignments.edit', compact('assignment','drivers','vehicles','addons'));
    }

    public function update(Request $request, TaxiVehicleAssignment $assignment)
    {
        $this->assertSameCompany($assignment);
        $data = $this->validateAssignment($request);
        $data['issues'] = $this->parseKeyValuePairs($request->input('issues_k'), $request->input('issues_v'));
        $data['addons'] = $this->parseAddonMap($request->input('addons_id'), $request->input('addons_qty'));
        $data['attributes'] = $this->parseKeyValuePairs($request->input('attrs_k'), $request->input('attrs_v'));
        $assignment->update($data);
        return back()->with('status', ___('Assignment updated.'));
    }

    public function destroy(TaxiVehicleAssignment $assignment)
    {
        $this->assertSameCompany($assignment);
        $assignment->delete();
        return back()->with('status', ___('Assignment deleted.'));
    }

    private function validateAssignment(Request $request): array
    {
        return $request->validate([
            'vehicle_id' => ['required','integer'],
            'driver_id' => ['required','integer'],
            'assigned_at' => ['nullable','date'],
            'returned_at' => ['nullable','date'],
            'notes' => ['nullable','string','max:2000'],
        ]);
    }

    private function parseKeyValuePairs($keys, $values): array
    {
        $out = [];
        $keys = is_array($keys) ? $keys : [];
        $values = is_array($values) ? $values : [];
        foreach ($keys as $i => $k) {
            $k = trim((string) $k);
            if ($k === '') continue;
            $out[$k] = trim((string) ($values[$i] ?? ''));
        }
        return $out;
    }

    private function parseAddonMap($ids, $qtys): array
    {
        $out = [];
        $ids = is_array($ids) ? $ids : [];
        $qtys = is_array($qtys) ? $qtys : [];
        foreach ($ids as $i => $id) {
            $id = (int) $id;
            if ($id <= 0) continue;
            $qty = (int) ($qtys[$id] ?? $qtys[$i] ?? 1);
            $out[$id] = max(1, $qty);
        }
        return $out;
    }
}
