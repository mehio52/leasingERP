<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\Vehicle;
use App\Models\VehicleExpense;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class VehicleExpenseController extends Controller
{
    private function categories(): array
    {
        return [
            'fuel' => ___('Fuel'),
            'oil' => ___('Oil change'),
            'repair' => ___('Repair'),
            'service' => ___('Service / Maintenance'),
            'tire' => ___('Tire'),
            'insurance' => ___('Insurance'),
            'other' => ___('Other'),
        ];
    }

    public function index(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }

        $companyId = (int) $user->company_id;
        $categories = $this->categories();

        $vehicles = Vehicle::query()
            ->where('company_id', $companyId)
            ->orderBy('brand')
            ->orderBy('model')
            ->get();

        $filters = [
            'vehicle_id' => $request->query('vehicle_id'),
            'category' => $request->query('category'),
            'date_from' => $request->query('date_from'),
            'date_to' => $request->query('date_to'),
        ];

        $query = VehicleExpense::query()
            ->where('company_id', $companyId)
            ->with('vehicle')
            ->latest('expense_date')
            ->latest('id');

        if (!empty($filters['vehicle_id'])) {
            $query->where('vehicle_id', (int) $filters['vehicle_id']);
        }
        if (!empty($filters['category'])) {
            $query->where('category', $filters['category']);
        }
        if (!empty($filters['date_from'])) {
            $query->whereDate('expense_date', '>=', $filters['date_from']);
        }
        if (!empty($filters['date_to'])) {
            $query->whereDate('expense_date', '<=', $filters['date_to']);
        }

        $totalAmount = (float) (clone $query)->sum('amount');
        $expenses = $query->paginate(20)->withQueryString();

        return view('company.vehicle_expenses.index', compact(
            'vehicles',
            'expenses',
            'filters',
            'categories',
            'totalAmount'
        ));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }

        $categories = $this->categories();
        $companyId = (int) $user->company_id;

        $data = $request->validate([
            'vehicle_id' => [
                'required',
                'integer',
                Rule::exists('vehicles', 'id')->where('company_id', $companyId),
            ],
            'category' => ['required', Rule::in(array_keys($categories))],
            'title' => ['nullable', 'string', 'max:255'],
            'details' => ['nullable', 'string', 'max:4000'],
            'amount' => ['required', 'numeric', 'min:0'],
            'expense_date' => ['nullable', 'date'],
            'vendor' => ['nullable', 'string', 'max:255'],
        ]);

        $expenseDate = !empty($data['expense_date'])
            ? Carbon::parse($data['expense_date'])->toDateString()
            : now()->toDateString();

        VehicleExpense::create([
            'company_id' => $companyId,
            'vehicle_id' => (int) $data['vehicle_id'],
            'category' => $data['category'],
            'title' => $data['title'] ?? null,
            'details' => $data['details'] ?? null,
            'amount' => (float) $data['amount'],
            'expense_date' => $expenseDate,
            'vendor' => $data['vendor'] ?? null,
            'created_by' => $user->id,
        ]);

        return redirect()
            ->route('company.vehicle_expenses.index')
            ->with('status', ___('Expense saved.'));
    }
}
