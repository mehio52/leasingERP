<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\TaxiDriver;
use App\Models\TaxiTrip;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

class TaxiPayrollController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth','module:taxipark','feature:taxi']);
        $this->middleware('perm:taxi.payroll.view');
    }

    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    public function index(Request $request)
    {
        $month = $request->query('month', now()->format('Y-m'));
        $start = Carbon::createFromFormat('Y-m', $month)->startOfMonth();
        $end = $start->copy()->endOfMonth();

        $drivers = TaxiDriver::where('company_id', $this->companyId())
            ->orderBy('first_name')
            ->orderBy('last_name')
            ->get();

        $trips = TaxiTrip::query()
            ->where('company_id', $this->companyId())
            ->whereBetween('start_at', [$start, $end])
            ->get();

        $stats = $drivers->map(function ($d) use ($trips) {
            $driverTrips = $trips->where('driver_id', $d->id);
            $revenue = (float) $driverTrips->sum('total');
            $count = $driverTrips->count();
            $salary = $this->calcSalary($d, $revenue, $count);
            return [
                'driver' => $d,
                'trips' => $count,
                'revenue' => $revenue,
                'salary' => $salary,
            ];
        });

        return view('company.taxi_payroll.index', compact('stats','month','start','end'));
    }

    private function calcSalary(TaxiDriver $driver, float $revenue, int $tripCount): float
    {
        $type = $driver->salary_type;
        $value = (float) ($driver->salary_value ?? 0);
        if (!$type) return 0.0;

        return match ($type) {
            'fixed_monthly' => $value,
            'fixed_weekly' => $value * 4,
            'fixed_daily' => $value * 30,
            'per_trip_fixed' => $value * $tripCount,
            'percent_trip', 'percent_revenue' => ($value / 100) * $revenue,
            default => $value,
        };
    }
}
