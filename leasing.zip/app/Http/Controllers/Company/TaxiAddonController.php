<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\TaxiAddon;
use Illuminate\Http\Request;

class TaxiAddonController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth','module:taxipark','feature:taxi']);
        $this->middleware('perm:taxi.addons.manage');
    }

    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    public function index()
    {
        $addons = TaxiAddon::query()
            ->where('company_id', $this->companyId())
            ->orderBy('sort_order')
            ->orderByDesc('id')
            ->get();

        return view('company.taxi_addons.index', compact('addons'));
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $data['company_id'] = $this->companyId();
        TaxiAddon::create($data);
        return back()->with('status', ___('Addon created.'));
    }

    public function update(Request $request, TaxiAddon $addon)
    {
        $this->assertSameCompany($addon);
        $data = $this->validated($request);
        $addon->update($data);
        return back()->with('status', ___('Addon updated.'));
    }

    public function destroy(TaxiAddon $addon)
    {
        $this->assertSameCompany($addon);
        $addon->delete();
        return back()->with('status', ___('Addon deleted.'));
    }

    private function assertSameCompany(TaxiAddon $addon): void
    {
        if ((int) $addon->company_id !== $this->companyId()) abort(404);
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'name' => ['required','string','max:120'],
            'price' => ['required','numeric','min:0'],
            'billing_type' => ['required','string','in:per_trip,per_day,per_month'],
            'quantity' => ['nullable','integer','min:0'],
            'is_active' => ['nullable','boolean'],
            'sort_order' => ['nullable','integer','min:0'],
        ]) + [
            'is_active' => $request->boolean('is_active'),
            'quantity' => (int) $request->input('quantity', 0),
            'sort_order' => (int) $request->input('sort_order', 0),
        ];
    }
}
