<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\TaxiDriver;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class TaxiDriverController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth','module:taxipark','feature:taxi']);
        $this->middleware('perm:taxi.drivers.view')->only(['index','show']);
        $this->middleware('perm:taxi.drivers.create')->only(['create','store']);
        $this->middleware('perm:taxi.drivers.edit')->only(['edit','update']);
        $this->middleware('perm:taxi.drivers.delete')->only(['destroy']);
    }

    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    private function assertSameCompany(TaxiDriver $driver): void
    {
        if ((int) $driver->company_id !== $this->companyId()) {
            abort(404);
        }
    }

    public function index(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        $drivers = TaxiDriver::query()
            ->where('company_id', $this->companyId())
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($x) use ($q) {
                    $x->where('first_name', 'like', "%{$q}%")
                        ->orWhere('last_name', 'like', "%{$q}%")
                        ->orWhere('phone', 'like', "%{$q}%")
                        ->orWhere('email', 'like', "%{$q}%");
                });
            })
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('company.taxi_drivers.index', compact('drivers', 'q'));
    }

    public function create()
    {
        $salaryTypes = $this->salaryTypes();
        return view('company.taxi_drivers.create', compact('salaryTypes'));
    }

    public function store(Request $request)
    {
        $data = $this->validateDriver($request);
        $data['company_id'] = $this->companyId();
        $data['created_by'] = auth()->id();

        $this->handleUploads($request, $data);

        TaxiDriver::create($data);
        return redirect()->route('company.taxi_drivers.index')->with('status', ___('Driver created.'));
    }

    public function edit(TaxiDriver $driver)
    {
        $this->assertSameCompany($driver);
        $salaryTypes = $this->salaryTypes();
        return view('company.taxi_drivers.edit', compact('driver', 'salaryTypes'));
    }

    public function update(Request $request, TaxiDriver $driver)
    {
        $this->assertSameCompany($driver);
        $data = $this->validateDriver($request, $driver->id);
        $this->handleUploads($request, $data, $driver);
        $driver->update($data);

        return redirect()->route('company.taxi_drivers.edit', $driver)->with('status', ___('Driver updated.'));
    }

    public function destroy(TaxiDriver $driver)
    {
        $this->assertSameCompany($driver);
        foreach (['certificate_image','id_card_image','driver_license_image'] as $field) {
            if (!empty($driver->{$field})) {
                Storage::disk('public')->delete($driver->{$field});
            }
        }
        $driver->delete();
        return redirect()->route('company.taxi_drivers.index')->with('status', ___('Driver deleted.'));
    }

    private function validateDriver(Request $request, ?int $id = null): array
    {
        return $request->validate([
            'first_name' => ['required','string','max:100'],
            'last_name' => ['required','string','max:100'],
            'phone' => ['nullable','string','max:32'],
            'email' => ['nullable','email','max:190'],
            'address' => ['nullable','string','max:255'],
            'status' => ['nullable','string','in:active,inactive'],

            'salary_type' => ['nullable','string', Rule::in(array_keys($this->salaryTypes()))],
            'salary_value' => ['nullable','numeric','min:0'],
            'salary_currency' => ['nullable','string','max:8'],
            'salary_meta_k' => ['nullable','array'],
            'salary_meta_k.*' => ['nullable','string','max:64'],
            'salary_meta_v' => ['nullable','array'],
            'salary_meta_v.*' => ['nullable','string','max:255'],
            'notes' => ['nullable','string','max:5000'],

            'certificate_no' => ['nullable','string','max:64'],
            'id_card_no' => ['nullable','string','max:64'],
            'driver_license_no' => ['nullable','string','max:64'],

            'certificate_image' => ['nullable','image','mimes:jpg,jpeg,png,webp','max:5120'],
            'id_card_image' => ['nullable','image','mimes:jpg,jpeg,png,webp','max:5120'],
            'driver_license_image' => ['nullable','image','mimes:jpg,jpeg,png,webp','max:5120'],
        ]);
    }

    private function salaryTypes(): array
    {
        return [
            'fixed_monthly' => ___('Fixed monthly'),
            'fixed_weekly' => ___('Fixed weekly'),
            'fixed_daily' => ___('Fixed daily'),
            'per_trip_fixed' => ___('Per trip (fixed)'),
            'percent_trip' => ___('Per trip (%)'),
            'percent_revenue' => ___('Revenue share (%)'),
            'mixed' => ___('Mixed / custom'),
        ];
    }

    private function handleUploads(Request $request, array &$data, ?TaxiDriver $driver = null): void
    {
        $meta = $this->parseKeyValuePairs(
            $request->input('salary_meta_k'),
            $request->input('salary_meta_v')
        );
        $data['salary_meta'] = $meta ?: null;

        foreach (['certificate_image','id_card_image','driver_license_image'] as $field) {
            if ($request->hasFile($field)) {
                if ($driver && !empty($driver->{$field})) {
                    Storage::disk('public')->delete($driver->{$field});
                }
                $data[$field] = $request->file($field)->store('taxi_drivers', 'public');
            }
        }
    }

    private function parseKeyValuePairs($keys, $values): array
    {
        $out = [];
        $keys = is_array($keys) ? $keys : [];
        $values = is_array($values) ? $values : [];
        foreach ($keys as $i => $k) {
            $k = trim((string) $k);
            if ($k === '') continue;
            $out[$k] = trim((string) ($values[$i] ?? ''));
        }
        return $out;
    }
}
