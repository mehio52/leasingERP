<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\Addon;
use App\Models\EpointTransaction;
use App\Models\Subscription;
use App\Models\SubscriptionAddon;
use App\Models\CompanyOption;
use App\Services\CompanyGatewayConfig;
use App\Services\EpointService;
use App\Services\IyzicoService;
use App\Services\PaymentGatewayService;
use App\Services\StripeService;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;

class CompanyAddonController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'perm:settings.edit|addons.manage']);
    }

    public function index(Request $request)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $module = $company?->moduleCode();
        $addons = Addon::active()
            ->where(function ($q) use ($module) {
                $q->whereNull('module')->orWhere('module', $module);
            })
            ->orderBy('sort_order')
            ->get();
        $active = SubscriptionAddon::query()
            ->where('company_id', $company->id)
            ->where(function ($q) {
                $q->whereNull('ends_at')->orWhere('ends_at', '>', now());
            })
            ->get();

        return view('addons.index', [
            'addons' => $addons,
            'active' => $active,
            'gatewayEnabled' => app(PaymentGatewayService::class)->activeProvider($company) !== null,
        ]);
    }

    public function store(Request $request, SubscriptionService $subs, PaymentGatewayService $gateway, EpointService $epoint, StripeService $stripe, IyzicoService $iyzico)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $data = $request->validate([
            'addon_code' => ['required', 'string', 'exists:addons,code'],
            'billing_period' => ['required','in:monthly,yearly'],
        ]);

        $addon = Addon::where('code', $data['addon_code'])
            ->where(function ($q) use ($company) {
                $mod = $company?->moduleCode();
                $q->whereNull('module')->orWhere('module', $mod);
            })
            ->firstOrFail();
        $subscription = $subs->current($company);
        if (!$subscription) {
            return back()->withErrors(['addon' => ___('Active plan not found. Please choose a plan first.')]);
        }

        $provider = $gateway->activeProvider($company);
        if (!$provider) {
            return back()->withErrors(['payment' => ___('Payment gateway is not configured.')]);
        }

        $gatewayConfig = app(CompanyGatewayConfig::class);

        $activeAddon = SubscriptionAddon::query()
            ->where('company_id', $company->id)
            ->where('addon_id', $addon->id)
            ->where(function ($q) {
                $q->whereNull('ends_at')->orWhere('ends_at', '>', now());
            })
            ->exists();

        if ($activeAddon) {
            return back()->withErrors(['addon' => ___('This add-on is already active.')]);
        }

        $period = $data['billing_period'] === 'yearly'
            ? Subscription::PERIOD_YEARLY
            : Subscription::PERIOD_MONTHLY;

        $amount = $period === Subscription::PERIOD_YEARLY
            ? (float) ($addon->price_yearly ?? 0)
            : (float) ($addon->price_monthly ?? 0);

        if ($amount <= 0) {
            return back()->withErrors(['payment' => ___('Add-on price is not set.')]);
        }

        $orderId = EpointTransaction::generateOrderId('addon');
        $description = "Addon {$addon->name} ({$period})";

        $currency = $gateway->providerCurrency($provider, $company, $addon->currency ?? null);

        $tx = EpointTransaction::create([
            'company_id' => $company->id,
            'requested_by_user_id' => $request->user()?->id,
            'type' => EpointTransaction::TYPE_ADDON,
            'gateway' => $provider,
            'status' => EpointTransaction::STATUS_PENDING,
            'amount' => $amount,
            'currency' => $currency,
            'order_id' => $orderId,
            'description' => $description,
            'meta' => [
                'addon_id' => $addon->id,
                'billing_period' => $period,
            ],
        ]);

        $successUrl = route('epoint.success', ['order_id' => $orderId]);
        $errorUrl = route('epoint.error', ['order_id' => $orderId]);

        if ($provider === 'stripe') {
            $stripe = $stripe->withConfig($gatewayConfig->providerConfig('stripe', $company));
            $resp = $stripe->createCheckoutSession([
                'amount' => $amount,
                'currency' => strtolower($currency),
                'order_id' => $orderId,
                'description' => $description,
                'success_url' => $successUrl,
                'cancel_url' => $errorUrl,
            ]);

            if (($resp['status'] ?? '') === 'success' && !empty($resp['url'])) {
                $tx->gateway_transaction = $resp['id'] ?? null;
                $tx->payload = $resp['payload'] ?? null;
                $tx->save();
                return redirect()->away($resp['url']);
            }

            $tx->status = EpointTransaction::STATUS_FAILED;
            $tx->message = $resp['message'] ?? 'Payment request failed';
            $tx->payload = $resp;
            $tx->save();

            return back()->withErrors(['payment' => ___('Payment gateway error. Please try again.')]);
        }

        if ($provider === 'iyzico') {
            $options = CompanyOption::query()->where('company_id', $company->id)->first();

            $buyer = [
                'id' => 'company_' . $company->id,
                'name' => $company->name ?? 'Company',
                'surname' => $company->legal_name ?? $company->name ?? 'Company',
                'gsm' => $options?->contact_phone ?? $company->phone ?? '',
                'email' => $options?->contact_email ?? $company->email ?? '',
                'identity_number' => $company->voen ?? '',
                'address' => $options?->address ?? $company->address ?? '',
                'city' => $options?->city ?? '',
                'country' => $options?->country ?? '',
                'zip' => '',
                'ip' => $request->ip(),
            ];

            if (($buyer['email'] ?? '') === '' || ($buyer['gsm'] ?? '') === '' || ($buyer['address'] ?? '') === '') {
                return back()->withErrors(['payment' => ___('Company contact details are required for Iyzico payments.')]);
            }

            $iyzico = $iyzico->withConfig($gatewayConfig->providerConfig('iyzico', $company));
            $callbackUrl = route('iyzico.callback', ['order_id' => $orderId]);
            $resp = $iyzico->createCheckoutForm([
                'amount' => $amount,
                'currency' => $currency,
                'order_id' => $orderId,
                'callback_url' => $callbackUrl,
                'locale' => app()->getLocale(),
                'buyer' => $buyer,
                'item_name' => $description,
                'item_category' => 'Addon',
            ]);

            if (($resp['status'] ?? '') === 'success' && !empty($resp['content'])) {
                $meta = is_array($tx->meta) ? $tx->meta : [];
                if (!empty($resp['token'])) {
                    $meta['iyzico_token'] = $resp['token'];
                    $tx->gateway_transaction = $resp['token'];
                }
                $tx->meta = $meta;
                $tx->payload = $resp['raw'] ?? null;
                $tx->save();

                return view('payments.iyzico', [
                    'title' => ___('Complete payment'),
                    'checkoutFormContent' => $resp['content'],
                    'returnUrl' => route('iyzico.redirect', ['order_id' => $orderId]),
                ]);
            }

            $tx->status = EpointTransaction::STATUS_FAILED;
            $tx->message = $resp['message'] ?? 'Payment request failed';
            $tx->payload = $resp;
            $tx->save();

            return back()->withErrors(['payment' => ___('Payment gateway error. Please try again.')]);
        }

        $epoint = $epoint->withConfig($gatewayConfig->providerConfig('epoint', $company));
        $resp = $epoint->requestPayment([
            'public_key' => $epoint->publicKey(),
            'amount' => $amount,
            'currency' => $currency,
            'language' => $epoint->normalizeLanguage(app()->getLocale()),
            'order_id' => $orderId,
            'description' => $description,
            'success_redirect_url' => $successUrl,
            'error_redirect_url' => $errorUrl,
        ]);

        if (($resp['status'] ?? '') === 'success' && !empty($resp['redirect_url'])) {
            return redirect()->away($resp['redirect_url']);
        }

        $tx->status = EpointTransaction::STATUS_FAILED;
        $tx->message = $resp['message'] ?? 'Payment request failed';
        $tx->payload = $resp;
        $tx->save();

        return back()->withErrors(['payment' => ___('Payment gateway error. Please try again.')]);
    }

    public function destroy(Request $request, SubscriptionAddon $subscriptionAddon, SubscriptionService $subs)
    {
        $company = $request->user()?->company;
        if (!$company || (int)$subscriptionAddon->company_id !== (int)$company->id) {
            abort(403);
        }

        $subscriptionAddon->update(['ends_at' => now()]);
        $subs->syncCompanyFeatures($company);

        return back()->with('status', "{$subscriptionAddon->addon_name_snapshot} deaktiv edildi.");
    }
}
