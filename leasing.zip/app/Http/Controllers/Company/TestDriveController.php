<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\TestDrive;
use Carbon\Carbon;
use Illuminate\Http\Request;

class TestDriveController extends Controller
{
    public function index(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $testDrives = TestDrive::query()
            ->where('company_id', $company->id)
            ->with('vehicle')
            ->orderByDesc('created_at')
            ->paginate(20);

        $calendarStats = TestDrive::query()
            ->where('company_id', $company->id)
            ->selectRaw('date(coalesce(scheduled_for, created_at)) as day, count(*) as total, sum(case when status = "confirmed" then 1 else 0 end) as confirmed')
            ->groupBy('day')
            ->orderBy('day')
            ->get()
            ->map(function ($row) {
                return [
                    'day' => $row->day,
                    'total' => (int) $row->total,
                    'confirmed' => (int) $row->confirmed,
                ];
            });

        return view('company.test_drives.index', compact('company', 'testDrives', 'calendarStats'));
    }

    public function update(Request $request, TestDrive $testDrive)
    {
        $company = $request->user()?->company;
        abort_unless($company && $testDrive->company_id === $company->id, 403);

        $data = $request->validate([
            'status' => ['required', 'in:pending,confirmed,cancelled,done'],
            'scheduled_for' => ['nullable', 'date'],
            'note' => ['nullable', 'string', 'max:2000'],
        ]);

        $testDrive->status = $data['status'];
        $testDrive->note = $data['note'] ?? null;
        $testDrive->scheduled_for = !empty($data['scheduled_for'])
            ? Carbon::parse($data['scheduled_for'])
            : null;
        $testDrive->save();

        return redirect()->back()->with('status', 'Test drive updated.');
    }
}
