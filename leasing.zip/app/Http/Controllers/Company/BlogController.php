<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\BlogPost;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BlogController extends Controller
{
    public function index(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $posts = BlogPost::query()
            ->where('company_id', $company->id)
            ->latest('published_at')
            ->paginate(15);

        return view('company.blog.index', compact('company', 'posts'));
    }

    public function create(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        return view('company.blog.create', compact('company'));
    }

    public function store(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $data = $request->validate([
            'title' => ['required','string','max:255'],
            'slug' => ['nullable','string','max:255'],
            'excerpt' => ['nullable','string','max:1000'],
            'content' => ['nullable','string'],
            'status' => ['nullable','in:published,draft'],
        ]);

        $post = new BlogPost();
        $post->fill($data);
        $post->company_id = $company->id;
        if (blank($post->slug)) {
            $post->slug = \Illuminate\Support\Str::slug($post->title);
        }
        if ($post->status === 'published') {
            $post->published_at = now();
        }
        $post->save();

        return redirect()->route('company.blog.index')->with('status', 'Blog post saved.');
    }
}
