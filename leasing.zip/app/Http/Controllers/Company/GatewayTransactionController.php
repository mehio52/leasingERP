<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\BhphAccount;
use App\Models\EpointTransaction;
use Illuminate\Http\Request;

class GatewayTransactionController extends Controller
{
    public function index(Request $request)
    {
        $company = $request->user()?->company;
        if (!$company) {
            abort(403);
        }

        $status = (string) $request->query('status', '');
        $q = trim((string) $request->query('q', ''));

        $query = EpointTransaction::query()
            ->where('company_id', $company->id)
            ->where('type', EpointTransaction::TYPE_LOAN_PAYMENT);

        if ($status !== '') {
            $query->where('status', $status);
        }

        if ($q !== '') {
            $query->where(function ($w) use ($q) {
                $w->where('order_id', 'like', "%{$q}%")
                    ->orWhere('gateway_transaction', 'like', "%{$q}%")
                    ->orWhere('epoint_transaction', 'like', "%{$q}%")
                    ->orWhere('bank_transaction', 'like', "%{$q}%")
                    ->orWhere('message', 'like', "%{$q}%");
            });
        }

        $transactions = $query->latest('id')->paginate(30)->withQueryString();

        $accountIds = collect($transactions->items())
            ->map(function ($tx) {
                $meta = is_array($tx->meta) ? $tx->meta : [];
                return $meta['bhph_account_id'] ?? null;
            })
            ->filter()
            ->unique()
            ->values();

        $accounts = $accountIds->isEmpty()
            ? collect()
            : BhphAccount::query()
                ->with(['customer', 'contract'])
                ->whereIn('id', $accountIds)
                ->get()
                ->keyBy('id');

        return view('company.transactions.index', [
            'transactions' => $transactions,
            'accounts' => $accounts,
            'status' => $status,
            'q' => $q,
        ]);
    }
}
