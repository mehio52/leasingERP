<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\TaxiDriver;
use App\Models\TaxiTrip;
use App\Models\Vehicle;
use Illuminate\Http\Request;

class TaxiTripController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth','module:taxipark','feature:taxi']);
        $this->middleware('perm:taxi.trips.view')->only(['index']);
        $this->middleware('perm:taxi.trips.create')->only(['create','store']);
        $this->middleware('perm:taxi.trips.edit')->only(['edit','update']);
        $this->middleware('perm:taxi.trips.delete')->only(['destroy']);
    }

    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    private function assertSameCompany(TaxiTrip $trip): void
    {
        if ((int) $trip->company_id !== $this->companyId()) abort(404);
    }

    public function index(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        $trips = TaxiTrip::query()
            ->where('company_id', $this->companyId())
            ->with(['driver','vehicle'])
            ->when($q !== '', function ($query) use ($q) {
                $query->whereHas('driver', function ($d) use ($q) {
                    $d->where('first_name', 'like', "%{$q}%")
                        ->orWhere('last_name', 'like', "%{$q}%");
                });
            })
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('company.taxi_trips.index', compact('trips', 'q'));
    }

    public function create()
    {
        $drivers = TaxiDriver::where('company_id', $this->companyId())->orderBy('first_name')->orderBy('last_name')->get();
        $vehicles = Vehicle::where('company_id', $this->companyId())->orderBy('id','desc')->get();
        return view('company.taxi_trips.create', compact('drivers','vehicles'));
    }

    public function store(Request $request)
    {
        $data = $this->validateTrip($request);
        $data['company_id'] = $this->companyId();
        $data['total'] = $this->calcTotal($data);
        TaxiTrip::create($data);
        return redirect()->route('company.taxi_trips.index')->with('status', ___('Trip created.'));
    }

    public function edit(TaxiTrip $trip)
    {
        $this->assertSameCompany($trip);
        $drivers = TaxiDriver::where('company_id', $this->companyId())->orderBy('first_name')->orderBy('last_name')->get();
        $vehicles = Vehicle::where('company_id', $this->companyId())->orderBy('id','desc')->get();
        return view('company.taxi_trips.edit', compact('trip','drivers','vehicles'));
    }

    public function update(Request $request, TaxiTrip $trip)
    {
        $this->assertSameCompany($trip);
        $data = $this->validateTrip($request);
        $data['total'] = $this->calcTotal($data);
        $trip->update($data);
        return back()->with('status', ___('Trip updated.'));
    }

    public function destroy(TaxiTrip $trip)
    {
        $this->assertSameCompany($trip);
        $trip->delete();
        return back()->with('status', ___('Trip deleted.'));
    }

    private function validateTrip(Request $request): array
    {
        return $request->validate([
            'driver_id' => ['required','integer'],
            'vehicle_id' => ['required','integer'],
            'start_at' => ['nullable','date'],
            'end_at' => ['nullable','date'],
            'distance_km' => ['nullable','numeric','min:0'],
            'fare' => ['nullable','numeric','min:0'],
            'tip' => ['nullable','numeric','min:0'],
            'discount' => ['nullable','numeric','min:0'],
            'payment_method' => ['nullable','string','max:24'],
            'status' => ['nullable','string','max:24'],
            'notes' => ['nullable','string','max:2000'],
        ]);
    }

    private function calcTotal(array $data): float
    {
        $fare = (float) ($data['fare'] ?? 0);
        $tip = (float) ($data['tip'] ?? 0);
        $discount = (float) ($data['discount'] ?? 0);
        $total = $fare + $tip - $discount;
        return $total < 0 ? 0 : $total;
    }
}
