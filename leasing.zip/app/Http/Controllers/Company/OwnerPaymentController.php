<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Vehicle;
use App\Models\VehicleOwnerPayment;
use Carbon\Carbon;
use Illuminate\Http\Request;

class OwnerPaymentController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403);

        $companyId = (int) $user->company_id;
        $ownerVehicles = Vehicle::query()
            ->where('company_id', $companyId)
            ->where('owner_type', 'owner')
            ->orderBy('brand')
            ->orderBy('model')
            ->get();

        $ownerIds = $ownerVehicles->pluck('owner_customer_id')->filter()->unique()->values();
        $owners = Customer::query()
            ->where('company_id', $companyId)
            ->when($ownerIds->isNotEmpty(), fn ($q) => $q->whereIn('id', $ownerIds))
            ->orderBy('first_name')
            ->orderBy('last_name')
            ->get();

        $filters = [
            'vehicle_id' => $request->query('vehicle_id'),
            'owner_customer_id' => $request->query('owner_customer_id'),
            'date_from' => $request->query('date_from'),
            'date_to' => $request->query('date_to'),
        ];

        $query = VehicleOwnerPayment::query()
            ->where('company_id', $companyId)
            ->with(['vehicle', 'owner', 'creator'])
            ->latest('id');

        if (!empty($filters['vehicle_id'])) {
            $query->where('vehicle_id', (int) $filters['vehicle_id']);
        }
        if (!empty($filters['owner_customer_id'])) {
            $query->where('owner_customer_id', (int) $filters['owner_customer_id']);
        }
        if (!empty($filters['date_from'])) {
            $query->whereDate('paid_at', '>=', $filters['date_from']);
        }
        if (!empty($filters['date_to'])) {
            $query->whereDate('paid_at', '<=', $filters['date_to']);
        }

        $payments = $query->paginate(30)->withQueryString();
        $totalAmount = (clone $query)->sum('amount');

        return view('company.owner_payments.index', compact('ownerVehicles', 'owners', 'payments', 'filters', 'totalAmount'));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403);

        $companyId = (int) $user->company_id;

        $data = $request->validate([
            'vehicle_id' => ['required','integer'],
            'amount' => ['required','numeric','min:0.01'],
            'payment_type' => ['nullable','string','in:daily,weekly,monthly,per_rental'],
            'paid_at' => ['nullable','date'],
            'period_start' => ['nullable','date'],
            'period_end' => ['nullable','date','after_or_equal:period_start'],
            'note' => ['nullable','string','max:2000'],
        ]);

        $vehicle = Vehicle::query()
            ->where('company_id', $companyId)
            ->where('id', $data['vehicle_id'])
            ->where('owner_type', 'owner')
            ->first();
        if (!$vehicle) {
            return back()->withErrors(['vehicle_id' => ___('Owner vehicle not found.')])->withInput();
        }

        $ownerId = $vehicle->owner_customer_id;
        if (!$ownerId) {
            return back()->withErrors(['vehicle_id' => ___('Vehicle owner is not set.')])->withInput();
        }

        $paidAt = $data['paid_at'] ?? null;
        if ($paidAt) {
            $paidAt = Carbon::parse($paidAt)->toDateTimeString();
        }

        VehicleOwnerPayment::create([
            'company_id' => $companyId,
            'vehicle_id' => $vehicle->id,
            'owner_customer_id' => $ownerId,
            'payment_type' => $data['payment_type'] ?: ($vehicle->owner_payment_type ?? null),
            'amount' => $data['amount'],
            'period_start' => $data['period_start'] ?? null,
            'period_end' => $data['period_end'] ?? null,
            'paid_at' => $paidAt,
            'note' => $data['note'] ?? null,
            'created_by' => $user->id,
        ]);

        return back()->with('status', ___('Payment recorded.'));
    }
}
