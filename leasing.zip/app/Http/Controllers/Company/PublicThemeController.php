<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PublicThemeController extends Controller
{
    public function edit(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $moduleCode = $company->moduleCode();
        $themes = $this->availableThemes($moduleCode);
        $vehicles = $company->vehicles()->orderByDesc('id')->get();

        return view('company.theme', [
            'company' => $company,
            'themes' => $themes,
            'defaultTheme' => config('public_theme.default', 'classic'),
            'vehicles' => $vehicles,
            'showCalculator' => (bool)($company->public_settings['show_calculator'] ?? true),
            'themeLocales' => (array)($company->public_settings['theme_locales'] ?? ['en']),
            'themeDefaultLocale' => (string)($company->public_settings['theme_default_locale'] ?? 'en'),
        ]);
    }

    public function update(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $moduleCode = $company->moduleCode();
        $themes = $this->availableThemes($moduleCode);
        $codes = array_column($themes, 'code');

        $data = $request->validate([
            'public_enabled' => ['nullable'],
            'public_theme' => ['nullable','string','in:'.implode(',', $codes)],
            'theme_default_locale' => ['nullable','string','max:10'],
            'theme_locales' => ['nullable','array'],
            'theme_locales.*' => ['string','max:10'],
            'show_blog_link' => ['nullable'],
            'show_pages_footer' => ['nullable'],
            'show_public_vehicles' => ['nullable'],
            'show_test_drive' => ['nullable'],
            'bg_color' => ['nullable','string','max:20'],
            'text_color' => ['nullable','string','max:20'],
            'heading_color' => ['nullable','string','max:20'],
            'link_color' => ['nullable','string','max:20'],
            'card_bg_color' => ['nullable','string','max:20'],
            'font_size' => ['nullable','string','max:8'],
        ]);

        $company->public_enabled = $request->boolean('public_enabled');
        $company->public_theme = $data['public_theme']
            ?? $company->public_theme
            ?? config('public_theme.default', 'classic');
        $settings = $company->public_settings ?? [];
        $settings['public_vehicle_ids'] = array_map('intval', $request->input('public_vehicle_ids', []));
        $settings['show_calculator'] = $request->boolean('show_calculator', true);
        $locales = $request->input('theme_locales', []);
        $locales = array_values(array_unique(array_filter(array_map('trim', (array)$locales))));
        if (empty($locales)) {
            $locales = ['en'];
        }
        $settings['theme_locales'] = $locales;
        $defaultLocale = $request->input('theme_default_locale', $locales[0]);
        if (!in_array($defaultLocale, $locales, true)) {
            $defaultLocale = $locales[0];
        }
        $settings['theme_default_locale'] = $defaultLocale;
        $settings['show_blog_link'] = $request->boolean('show_blog_link', true);
        $settings['show_pages_footer'] = $request->boolean('show_pages_footer', true);
        $settings['show_public_vehicles'] = $request->boolean('show_public_vehicles', true);
        $settings['show_test_drive'] = $request->boolean('show_test_drive', true);
        $settings['theme_styles'] = [
            'background_color' => $request->input('bg_color', '#f8fafc'),
            'text_color' => $request->input('text_color', '#0f172a'),
            'heading_color' => $request->input('heading_color', '#0f172a'),
            'link_color' => $request->input('link_color', '#0f172a'),
            'card_bg_color' => $request->input('card_bg_color', '#ffffff'),
            'font_size' => $request->input('font_size', '16px'),
        ];
        $company->public_settings = $settings;
        $company->save();

        return redirect()->route('company.theme.edit')->with('status', 'Public theme settings updated.');
    }

    public function previewImage(Request $request, string $theme)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $file = resource_path("themes/{$theme}/assets/preview.png");
        abort_unless(is_file($file), 404);

        $mime = mime_content_type($file) ?: 'image/png';
        return response()->file($file, ['Content-Type' => $mime]);
    }

    private function availableThemes(?string $moduleFilter = null): array
    {
        $base = config('public_theme.base_path', resource_path('themes'));
        $dirs = glob($base.'/*', GLOB_ONLYDIR) ?: [];
        $themes = [];
        foreach ($dirs as $dir) {
            $code = basename($dir);
            $meta = $this->readMeta($dir.'/theme-info.txt');
            $themeModule = $this->normalizeThemeModule($meta['module'] ?? null);
            if ($moduleFilter && $themeModule !== $moduleFilter) {
                continue;
            }
            $themes[] = [
                'code' => $code,
                'name' => $meta['name'] ?? Str::title($code),
                'version' => $meta['version'] ?? '',
                'plans' => $meta['plans'] ?? '',
                'preview' => $this->themePreviewUrl($code),
                'module' => $themeModule,
            ];
        }
        return $themes;
    }

    private function readMeta(string $file): array
    {
        if (!is_file($file)) return [];
        $data = [];
        foreach (file($file) as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) continue;
            if (str_contains($line, ':')) {
                [$k, $v] = array_map('trim', explode(':', $line, 2));
                $data[$k] = $v;
            }
        }
        return $data;
    }

    private function themePreviewUrl(string $theme): ?string
    {
        if (!$this->themePreviewExists($theme)) {
            return null;
        }
        return route('company.theme.preview', ['theme' => $theme]);
    }

    private function themePreviewExists(string $theme): bool
    {
        return is_file(resource_path("themes/{$theme}/assets/preview.png"));
    }

    private function normalizeThemeModule(?string $value): string
    {
        $module = strtolower(trim((string) ($value ?? 'leasing')));
        return in_array($module, ['leasing', 'rentacar', 'taxipark'], true) ? $module : 'leasing';
    }
}
