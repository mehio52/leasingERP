<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\CompanyRentalAddon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class RentalAddonController extends Controller
{
    private function companyId(): int
    {
        return (int) auth()->user()->company_id;
    }

    public function index()
    {
        $addons = CompanyRentalAddon::query()
            ->where('company_id', $this->companyId())
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        return view('company.rental_addons.index', compact('addons'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required','string','max:255'],
            'price' => ['required','numeric','min:0'],
            'billing_type' => ['required','string','in:per_rental,per_day'],
            'quantity' => ['required','integer','min:0','max:100000'],
            'is_active' => ['nullable','boolean'],
            'sort_order' => ['nullable','integer','min:0','max:9999'],
        ]);

        $data['company_id'] = $this->companyId();
        $data['is_active'] = (bool) ($data['is_active'] ?? true);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        CompanyRentalAddon::create($data);

        return back()->with('status', ___('Addon created.'));
    }

    public function update(Request $request, CompanyRentalAddon $addon)
    {
        if ((int) $addon->company_id !== $this->companyId()) {
            abort(403);
        }

        $data = $request->validate([
            'name' => ['required','string','max:255'],
            'price' => ['required','numeric','min:0'],
            'billing_type' => ['required','string','in:per_rental,per_day'],
            'quantity' => ['required','integer','min:0','max:100000'],
            'is_active' => ['nullable','boolean'],
            'sort_order' => ['nullable','integer','min:0','max:9999'],
        ]);

        $data['is_active'] = (bool) ($data['is_active'] ?? false);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        $addon->update($data);

        return back()->with('status', ___('Addon updated.'));
    }

    public function destroy(CompanyRentalAddon $addon)
    {
        if ((int) $addon->company_id !== $this->companyId()) {
            abort(403);
        }

        $addon->delete();

        return back()->with('status', ___('Addon deleted.'));
    }
}
