<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\PublicPage;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PublicPageController extends Controller
{
    public function index(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $pages = PublicPage::query()
            ->where('company_id', $company->id)
            ->latest('published_at')
            ->paginate(15);

        return view('company.pages.index', compact('company', 'pages'));
    }

    public function create(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        return view('company.pages.create', compact('company'));
    }

    public function store(Request $request)
    {
        $company = $request->user()?->company;
        abort_unless($company, 403);

        $data = $request->validate([
            'title' => ['required','string','max:255'],
            'slug' => ['nullable','string','max:255'],
            'content' => ['nullable','string'],
            'status' => ['nullable','in:published,draft'],
        ]);

        $page = new PublicPage();
        $page->fill($data);
        $page->company_id = $company->id;
        if (blank($page->slug)) {
            $page->slug = Str::slug($page->title);
        }
        if ($page->status === 'published') {
            $page->published_at = now();
        }
        $page->save();

        return redirect()->route('company.pages.index')->with('status', 'Page saved.');
    }
}
