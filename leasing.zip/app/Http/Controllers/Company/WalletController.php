<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\CompanyPayout;
use App\Models\CompanyPayoutCard;
use App\Models\EpointTransaction;
use App\Models\Payment;
use App\Services\CompanyGatewayConfig;
use App\Services\EpointService;
use Illuminate\Http\Request;

class WalletController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'perm:payments.view'])->only(['index']);
        $this->middleware(['auth', 'perm:payments.create'])->only(['registerCard', 'requestPayout']);
    }

    public function index(Request $request)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $totalReceived = (float) Payment::query()
            ->where('company_id', $company->id)
            ->where('status', Payment::STATUS_CONFIRMED)
            ->where('method', Payment::METHOD_CARD)
            ->sum('amount');

        $paidOut = (float) CompanyPayout::query()
            ->where('company_id', $company->id)
            ->where('status', CompanyPayout::STATUS_SUCCESS)
            ->sum('amount');

        $pendingOut = (float) CompanyPayout::query()
            ->where('company_id', $company->id)
            ->whereIn('status', [CompanyPayout::STATUS_PENDING, CompanyPayout::STATUS_PROCESSING])
            ->sum('amount');

        $available = max(0.0, $totalReceived - $paidOut - $pendingOut);

        $payoutCard = CompanyPayoutCard::query()
            ->where('company_id', $company->id)
            ->where('is_active', true)
            ->first();

        $payouts = CompanyPayout::query()
            ->where('company_id', $company->id)
            ->latest('id')
            ->limit(20)
            ->get();

        $gatewayConfig = app(CompanyGatewayConfig::class);
        $epointConfigured = app(EpointService::class)->withConfig($gatewayConfig->providerConfig('epoint', $company));

        return view('company.wallet.index', [
            'company' => $company,
            'totalReceived' => $totalReceived,
            'paidOut' => $paidOut,
            'pendingOut' => $pendingOut,
            'available' => $available,
            'payoutCard' => $payoutCard,
            'payouts' => $payouts,
            'epointEnabled' => $epointConfigured->isConfigured(),
        ]);
    }

    public function registerCard(Request $request, EpointService $epoint)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $gatewayConfig = app(CompanyGatewayConfig::class);
        $epoint = $epoint->withConfig($gatewayConfig->providerConfig('epoint', $company));

        if (!$epoint->isConfigured()) {
            return back()->withErrors(['payment' => ___('Payment gateway is not configured.')]);
        }

        $orderId = EpointTransaction::generateOrderId('payoutcard');
        $description = 'Payout card registration';

        $tx = EpointTransaction::create([
            'company_id' => $company->id,
            'requested_by_user_id' => $request->user()?->id,
            'type' => EpointTransaction::TYPE_PAYOUT_CARD,
            'status' => EpointTransaction::STATUS_PENDING,
            'amount' => 0,
            'currency' => 'AZN',
            'order_id' => $orderId,
            'description' => $description,
        ]);

        $successUrl = route('epoint.success', ['order_id' => $orderId]);
        $errorUrl = route('epoint.error', ['order_id' => $orderId]);

        $resp = $epoint->cardRegistration([
            'public_key' => $epoint->publicKey(),
            'language' => $epoint->normalizeLanguage(app()->getLocale()),
            'refund' => 1,
            'description' => $description,
            'success_redirect_url' => $successUrl,
            'error_redirect_url' => $errorUrl,
        ]);

        if (($resp['status'] ?? '') === 'success' && !empty($resp['redirect_url'])) {
            $meta = is_array($tx->meta) ? $tx->meta : [];
            if (!empty($resp['card_id'])) {
                $meta['card_id'] = $resp['card_id'];
            }
            $tx->meta = $meta;
            $tx->payload = $resp;
            $tx->save();

            return redirect()->away($resp['redirect_url']);
        }

        $tx->status = EpointTransaction::STATUS_FAILED;
        $tx->message = $resp['message'] ?? 'Card registration failed';
        $tx->payload = $resp;
        $tx->save();

        return back()->withErrors(['payment' => ___('Card registration failed. Please try again.')]);
    }

    public function requestPayout(Request $request, EpointService $epoint)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $gatewayConfig = app(CompanyGatewayConfig::class);
        $epoint = $epoint->withConfig($gatewayConfig->providerConfig('epoint', $company));

        if (!$epoint->isConfigured()) {
            return back()->withErrors(['payment' => ___('Payment gateway is not configured.')]);
        }

        $data = $request->validate([
            'amount' => ['required','numeric','min:1'],
        ]);

        $amount = (float) $data['amount'];

        $totalReceived = (float) Payment::query()
            ->where('company_id', $company->id)
            ->where('status', Payment::STATUS_CONFIRMED)
            ->where('method', Payment::METHOD_CARD)
            ->sum('amount');

        $paidOut = (float) CompanyPayout::query()
            ->where('company_id', $company->id)
            ->whereIn('status', [CompanyPayout::STATUS_SUCCESS, CompanyPayout::STATUS_PENDING, CompanyPayout::STATUS_PROCESSING])
            ->sum('amount');

        $available = max(0.0, $totalReceived - $paidOut);
        if ($amount > $available + 0.0001) {
            return back()->withErrors(['amount' => ___('Insufficient balance for payout.')]);
        }

        $card = CompanyPayoutCard::query()
            ->where('company_id', $company->id)
            ->where('is_active', true)
            ->first();

        if (!$card) {
            return back()->withErrors(['payment' => ___('No payout card registered.')]);
        }

        $orderId = EpointTransaction::generateOrderId('payout');
        $description = 'Company payout';

        $tx = EpointTransaction::create([
            'company_id' => $company->id,
            'requested_by_user_id' => $request->user()?->id,
            'type' => EpointTransaction::TYPE_PAYOUT,
            'status' => EpointTransaction::STATUS_PENDING,
            'amount' => $amount,
            'currency' => 'AZN',
            'order_id' => $orderId,
            'description' => $description,
            'meta' => [
                'card_id' => $card->card_id,
            ],
        ]);

        $payout = CompanyPayout::create([
            'company_id' => $company->id,
            'requested_by_user_id' => $request->user()?->id,
            'epoint_transaction_id' => $tx->id,
            'amount' => $amount,
            'currency' => 'AZN',
            'status' => CompanyPayout::STATUS_PENDING,
            'order_id' => $orderId,
        ]);

        $resp = $epoint->payoutRequest([
            'public_key' => $epoint->publicKey(),
            'language' => $epoint->normalizeLanguage(app()->getLocale()),
            'card_id' => $card->card_id,
            'order_id' => $orderId,
            'amount' => $amount,
            'currency' => 'AZN',
            'description' => $description,
        ]);

        $tx->epoint_transaction = $resp['transaction'] ?? null;
        $tx->message = $resp['message'] ?? null;
        $tx->payload = $resp;
        $tx->processed_at = now();

        $payout->epoint_transaction = $resp['transaction'] ?? null;
        $payout->message = $resp['message'] ?? null;
        $payout->response = $resp;
        $payout->processed_at = now();

        if (($resp['status'] ?? '') === 'success') {
            $tx->status = EpointTransaction::STATUS_SUCCESS;
            $payout->status = CompanyPayout::STATUS_SUCCESS;
        } else {
            $tx->status = EpointTransaction::STATUS_FAILED;
            $payout->status = CompanyPayout::STATUS_FAILED;
        }

        $tx->save();
        $payout->save();

        if ($payout->status === CompanyPayout::STATUS_SUCCESS) {
            return back()->with('status', ___('Payout request sent.'));
        }

        return back()->withErrors(['payment' => ___('Payout failed. Please try again.')]);
    }
}
