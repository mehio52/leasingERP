<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Models\CompanyRentalAddon;
use App\Models\Notification;
use App\Models\Vehicle;
use App\Models\VehicleRental;
use App\Events\NotificationCreated;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class RentalController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }

        $status = (string) $request->query('status', 'active');

        $rentals = VehicleRental::query()
            ->where('company_id', $user->company_id)
            ->when($status !== '', fn($q) => $q->where('status', $status))
            ->with('vehicle')
            ->latest('id')
            ->paginate(20)
            ->withQueryString();

        return view('rentals.index', compact('rentals', 'status'));
    }

    public function create(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }

        $vehicles = Vehicle::query()
            ->where('company_id', $user->company_id)
            ->where('status', 'available')
            ->orderBy('brand')
            ->orderBy('model')
            ->get();

        $addons = CompanyRentalAddon::query()
            ->where('company_id', $user->company_id)
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();
        $addons->each(function ($addon) use ($user) {
            $activeCount = VehicleRental::query()
                ->where('company_id', $user->company_id)
                ->where('status', 'active')
                ->whereJsonContains('addons', ['id' => $addon->id])
                ->count();
            $remaining = max(0, (int) $addon->quantity - (int) $activeCount);
            $addon->remaining = $remaining;
        });
        return view('rentals.create', compact('vehicles', 'addons'));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) {
            abort(403, 'User is not linked to a company.');
        }

        $data = $request->validate([
            'vehicle_id' => [
                'required',
                'integer',
                Rule::exists('vehicles', 'id')->where('company_id', $user->company_id),
            ],
            'renter_name' => ['required','string','max:255'],
            'renter_phone' => ['nullable','string','max:32'],
            'renter_fin_code' => ['nullable','string','max:16'],
            'renter_id_card_number' => ['nullable','string','max:64'],
            'driver_license_number' => ['nullable','string','max:64'],
            'driver_license_category' => ['nullable','string','max:16'],
            'driver_license_image' => ['nullable','image','mimes:jpg,jpeg,png,webp','max:5120'],
            'id_card_image' => ['nullable','image','mimes:jpg,jpeg,png,webp','max:5120'],
            'renter_note' => ['nullable','string','max:2000'],
            'addons' => ['nullable','array'],
            'addons.*' => [
                'integer',
                Rule::exists('company_rental_addons', 'id')->where('company_id', $user->company_id),
            ],
            'start_at' => ['nullable','date'],
            'rent_days' => ['required','integer','min:1','max:365'],
            'discount_type' => ['nullable','string','in:percent,amount'],
            'discount_value' => ['nullable','numeric','min:0'],
        ]);

        $vehicle = Vehicle::query()
            ->where('company_id', $user->company_id)
            ->findOrFail((int) $data['vehicle_id']);

        if ($vehicle->status !== 'available') {
            return back()->withErrors(['vehicle_id' => 'Vehicle is not available.'])->withInput();
        }

        $startAt = !empty($data['start_at']) ? Carbon::parse($data['start_at']) : now();
        $rentDays = (int) $data['rent_days'];
        $dueAt = $startAt->copy()->addDays($rentDays);

        $hasConflict = VehicleRental::query()
            ->where('company_id', $user->company_id)
            ->where('vehicle_id', $vehicle->id)
            ->where('status', 'active')
            ->where(function ($q) use ($startAt, $dueAt) {
                $q->where(function ($q) use ($startAt, $dueAt) {
                    $q->whereNotNull('start_at')
                        ->whereNotNull('due_at')
                        ->where('start_at', '<=', $dueAt)
                        ->where('due_at', '>=', $startAt);
                })->orWhere(function ($q) {
                    $q->whereNull('start_at')->orWhereNull('due_at');
                });
            })
            ->exists();
        if ($hasConflict) {
            return back()->withErrors(['vehicle_id' => 'Vehicle already has an active rental in this period.'])->withInput();
        }

        $dailyRate = $vehicle->rent_daily_price !== null ? (float) $vehicle->rent_daily_price : 0.0;
        $weeklyRate = $vehicle->rent_weekly_price !== null ? (float) $vehicle->rent_weekly_price : $dailyRate * 7;
        $monthlyRate = $vehicle->rent_monthly_price !== null ? (float) $vehicle->rent_monthly_price : $dailyRate * 30;

        $months = intdiv($rentDays, 30);
        $remaining = $rentDays % 30;
        $weeks = intdiv($remaining, 7);
        $days = $remaining % 7;

        $priceMonthly = $months * $monthlyRate;
        $priceWeekly = $weeks * $weeklyRate;
        $priceDaily = $days * $dailyRate;
        $baseTotal = $priceMonthly + $priceWeekly + $priceDaily;

        $addonList = CompanyRentalAddon::query()
            ->where('company_id', $user->company_id)
            ->where('is_active', true)
            ->get()
            ->keyBy('id');
        $selectedCodes = array_values(array_unique(array_filter($data['addons'] ?? [])));
        $remainingMap = [];
        foreach ($selectedCodes as $addonId) {
            $addon = $addonList->get((int) $addonId);
            if (!$addon) {
                continue;
            }
            $activeCount = VehicleRental::query()
                ->where('company_id', $user->company_id)
                ->where('status', 'active')
                ->whereJsonContains('addons', ['id' => $addon->id])
                ->count();
            $remaining = max(0, (int) $addon->quantity - (int) $activeCount);
            $remainingMap[$addon->id] = $remaining;
            if ($remaining <= 0) {
                return back()->withErrors(['addons' => ___('Selected add-on is out of stock.')])->withInput();
            }
        }
        $addonsTotal = 0.0;
        $addonsPayload = [];
        foreach ($selectedCodes as $addonId) {
            $addon = $addonList->get((int) $addonId);
            if (!$addon) {
                continue;
            }
            $addonsTotal += (float) $addon->price;
            $billingType = $addon->billing_type ?? 'per_rental';
            $addonPrice = (float) $addon->price;
            $addonCharge = $billingType === 'per_day' ? ($addonPrice * $rentDays) : $addonPrice;
            $addonsTotal += $addonCharge;
            $addonsPayload[] = [
                'id' => $addon->id,
                'name' => $addon->name,
                'price' => $addonPrice,
                'billing_type' => $billingType,
                'charge' => $addonCharge,
            ];
        }

        $total = $baseTotal + $addonsTotal;
        $discountType = $data['discount_type'] ?? null;
        $discountValue = $data['discount_value'] ?? null;
        $discountValue = $discountValue !== null ? (float) $discountValue : null;
        $totalAfterDiscount = $total;
        if ($discountType === 'percent' && $discountValue !== null) {
            $totalAfterDiscount = max(0, $total - ($total * ($discountValue / 100)));
        } elseif ($discountType === 'amount' && $discountValue !== null) {
            $totalAfterDiscount = max(0, $total - $discountValue);
        }

        $driverLicenseImagePath = null;
        $idCardImagePath = null;
        if ($request->hasFile('driver_license_image')) {
            $driverLicenseImagePath = $request->file('driver_license_image')
                ? $request->file('driver_license_image')->store('rentals', 'public')
                : null;
        }
        if ($request->hasFile('id_card_image')) {
            $idCardImagePath = $request->file('id_card_image')
                ? $request->file('id_card_image')->store('rentals', 'public')
                : null;
        }

        $rental = VehicleRental::create([
            'company_id' => $user->company_id,
            'vehicle_id' => $vehicle->id,
            'renter_name' => $data['renter_name'],
            'renter_phone' => $data['renter_phone'] ?? null,
            'renter_fin_code' => $data['renter_fin_code'] ?? null,
            'renter_id_card_number' => $data['renter_id_card_number'] ?? null,
            'driver_license_number' => $data['driver_license_number'] ?? null,
            'driver_license_category' => $data['driver_license_category'] ?? null,
            'driver_license_image_path' => $driverLicenseImagePath,
            'id_card_image_path' => $idCardImagePath,
            'renter_note' => $data['renter_note'] ?? null,
            'addons' => !empty($addonsPayload) ? $addonsPayload : null,
            'addons_total' => $addonsTotal,
            'start_at' => $startAt,
            'due_at' => $dueAt,
            'rent_days' => $rentDays,
            'price_daily' => $priceDaily,
            'price_weekly' => $priceWeekly,
            'price_monthly' => $priceMonthly,
            'discount_type' => $discountType,
            'discount_value' => $discountValue,
            'total_after_discount' => $totalAfterDiscount,
            'total_price' => $total,
            'status' => 'active',
            'created_by' => $user->id,
        ]);

        $vehicle->status = 'rented';
        $vehicle->rent_due_at = $dueAt->toDateTimeString();
        $vehicle->rent_source = $data['renter_name'];
        $vehicle->is_returned = false;
        $vehicle->save();

        foreach ($selectedCodes as $addonId) {
            $addon = $addonList->get((int) $addonId);
            if (!$addon) {
                continue;
            }
            $before = $remainingMap[$addon->id] ?? null;
            if ($before === null) {
                continue;
            }
            $after = $before - 1;
            if ($before > 0 && $after <= 0) {
                $notif = Notification::create([
                    'company_id' => $user->company_id,
                    'sender_id' => $user->id,
                    'target_scope' => 'company',
                    'title' => ___('Addon out of stock'),
                    'body' => ___('Addon “:name” is now depleted.', ['name' => $addon->name]),
                    'data' => [
                        'type' => 'addon_depleted',
                        'addon_id' => $addon->id,
                    ],
                ]);
                NotificationCreated::dispatch($notif);
            }
        }

        return redirect()->route('rentals.index')
            ->with('status', 'Rental created.');
    }

    public function close(Request $request, VehicleRental $rental)
    {
        $user = $request->user();
        if (!$user?->company_id || (int) $rental->company_id !== (int) $user->company_id) {
            abort(403, 'Access denied.');
        }

        if ($rental->status !== 'active') {
            return back()->withErrors(['status' => 'Rental is not active.']);
        }

        $data = $request->validate([
            'closed_at' => ['nullable', 'date'],
            'grace_hours' => ['nullable', 'integer', 'min:0', 'max:168'],
            'extra_day_rate' => ['nullable', 'numeric', 'min:0'],
            'penalty_type' => ['nullable', 'string', 'in:amount_per_day,percent_per_day,fixed'],
            'penalty_value' => ['nullable', 'numeric', 'min:0'],
        ]);

        $closedAt = !empty($data['closed_at']) ? Carbon::parse($data['closed_at']) : now();
        if ($rental->start_at && $closedAt->lt($rental->start_at)) {
            return back()->withErrors(['closed_at' => 'Return date cannot be before start date.']);
        }

        $actualDays = 1;
        if ($rental->start_at) {
            $diffDays = $rental->start_at->copy()->startOfDay()->diffInDays($closedAt->copy()->startOfDay());
            $actualDays = max(1, $diffDays + 1);
        }

        $vehicle = $rental->vehicle;
        $dailyRate = $vehicle?->rent_daily_price !== null ? (float) $vehicle->rent_daily_price : 0.0;
        $weeklyRate = $vehicle?->rent_weekly_price !== null ? (float) $vehicle->rent_weekly_price : $dailyRate * 7;
        $monthlyRate = $vehicle?->rent_monthly_price !== null ? (float) $vehicle->rent_monthly_price : $dailyRate * 30;

        $months = intdiv($actualDays, 30);
        $remaining = $actualDays % 30;
        $weeks = intdiv($remaining, 7);
        $days = $remaining % 7;

        $priceMonthly = $months * $monthlyRate;
        $priceWeekly = $weeks * $weeklyRate;
        $priceDaily = $days * $dailyRate;
        $addonsTotal = 0.0;
        if (is_array($rental->addons)) {
            foreach ($rental->addons as $addon) {
                if (!is_array($addon)) {
                    continue;
                }
                $billingType = $addon['billing_type'] ?? 'per_rental';
                $charge = $addon['charge'] ?? null;
                if ($charge !== null) {
                    $addonsTotal += (float) $charge;
                    continue;
                }
                $price = isset($addon['price']) ? (float) $addon['price'] : 0.0;
                $addonsTotal += $billingType === 'per_day' ? ($price * $actualDays) : $price;
            }
        } else {
            $addonsTotal = (float) ($rental->addons_total ?? 0);
        }
        $total = $priceMonthly + $priceWeekly + $priceDaily + $addonsTotal;

        $discountType = $rental->discount_type;
        $discountValue = $rental->discount_value !== null ? (float) $rental->discount_value : null;
        $totalAfterDiscount = $total;
        if ($discountType === 'percent' && $discountValue !== null) {
            $totalAfterDiscount = max(0, $total - ($total * ($discountValue / 100)));
        } elseif ($discountType === 'amount' && $discountValue !== null) {
            $totalAfterDiscount = max(0, $total - $discountValue);
        }

        $graceHours = isset($data['grace_hours']) ? (int) $data['grace_hours'] : 0;
        $extraDayRate = isset($data['extra_day_rate']) ? (float) $data['extra_day_rate'] : $dailyRate;

        $lateDays = 0;
        if ($rental->due_at) {
            $lateMinutes = max(0, $rental->due_at->diffInMinutes($closedAt, false));
            $graceMinutes = max(0, $graceHours * 60);
            if ($lateMinutes > $graceMinutes) {
                $lateDays = (int) ceil(($lateMinutes - $graceMinutes) / 1440);
            }
        } else {
            $lateDays = max(0, $actualDays - (int) ($rental->rent_days ?? 0));
        }

        $extraDaysCharge = $lateDays * $extraDayRate;

        $penaltyType = $data['penalty_type'] ?? null;
        $penaltyValue = isset($data['penalty_value']) ? (float) $data['penalty_value'] : null;
        $penaltyAmount = 0.0;
        if ($penaltyType === 'amount_per_day' && $penaltyValue !== null) {
            $penaltyAmount = $lateDays * $penaltyValue;
        } elseif ($penaltyType === 'percent_per_day' && $penaltyValue !== null) {
            $penaltyAmount = $lateDays * ($extraDayRate * ($penaltyValue / 100));
        } elseif ($penaltyType === 'fixed' && $penaltyValue !== null) {
            $penaltyAmount = $penaltyValue;
        }

        $totalAfterPenalty = $totalAfterDiscount + $extraDaysCharge + $penaltyAmount;

        $rental->status = 'closed';
        $rental->closed_at = $closedAt;
        $rental->actual_rent_days = $actualDays;
        $rental->actual_price_daily = $priceDaily;
        $rental->actual_price_weekly = $priceWeekly;
        $rental->actual_price_monthly = $priceMonthly;
        $rental->actual_total_price = $total;
        $rental->actual_total_after_discount = $totalAfterDiscount;
        $rental->grace_hours = $graceHours;
        $rental->extra_days = $lateDays;
        $rental->extra_day_rate = $extraDayRate;
        $rental->extra_days_charge = $extraDaysCharge;
        $rental->penalty_type = $penaltyType;
        $rental->penalty_value = $penaltyValue;
        $rental->penalty_amount = $penaltyAmount;
        $rental->total_after_penalty = $totalAfterPenalty;
        $rental->save();

        if ($vehicle) {
            $vehicle->status = 'available';
            $vehicle->rent_due_at = null;
            $vehicle->rent_source = null;
            $vehicle->is_returned = true;
            $vehicle->save();
        }

        return redirect()->route('rentals.index')->with('status', 'Rental closed.');
    }

}
