<?php

namespace App\Http\Controllers;

use App\Models\BhphAccount;
use App\Models\CompanyOption;
use App\Models\Customer;
use App\Models\Payment;
use App\Models\AnalyticsForecast;
use App\Models\Amortization;
use App\Models\CompanyRentalAddon;
use App\Models\Vehicle;
use App\Models\VehicleExpense;
use App\Models\VehicleRental;
use App\Models\TaxReport;
use App\Services\SubscriptionService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        if ($user?->gps_provider_id) {
            return redirect()->route('gps_provider.dashboard');
        }
        $company = $user?->company;
        $companyId = $company?->id;
        $subscriptionService = app(SubscriptionService::class);
        $module = $company?->moduleCode() ?? 'leasing';

        // Şirkət statusu
        $trialActive = $company && method_exists($company, 'isTrialActive') ? (bool)$company->isTrialActive() : false;
        $subActive   = $company && method_exists($company, 'isSubscriptionActive') ? (bool)$company->isSubscriptionActive() : false;

        $isSuspended = (bool) ($company?->suspended_at);
        $isActive    = (bool) ($company?->is_active);
        $readOnly    = $company ? !$subscriptionService->isWritable($company) : true;

        // Filtrlər
        $start = $request->input('start_date');
        $end   = $request->input('end_date');
        $accountStatus = (string) $request->input('account_status', 'all');

        $dateFrom = $start ? Carbon::parse($start)->startOfDay() : now()->subDays(29)->startOfDay();
        $dateTo   = $end ? Carbon::parse($end)->endOfDay() : now()->endOfDay();

        $filters = [
            'start_date' => $dateFrom->toDateString(),
            'end_date' => $dateTo->toDateString(),
            'account_status' => $accountStatus,
        ];

        // company yoxdursa boş dataset
        if (!$companyId) {
            return view('dashboard', [
                'user' => $user,
                'company' => $company,
                'trialActive' => $trialActive,
                'subActive' => $subActive,
                'isSuspended' => $isSuspended,
                'isActive' => $isActive,
                'readOnly' => $readOnly,
                'filters' => $filters,

                'paymentTotals' => (object)[
                    'total_amount' => 0,
                    'principal_amount' => 0,
                    'interest_amount' => 0,
                    'penalty_amount' => 0,
                ],
                'daily' => collect(),
                'recentPayments' => collect(),

                'accountCounts' => ['total' => 0, 'active' => 0, 'overdue' => 0, 'legal' => 0],
                'topOverdue' => collect(),

                'vehicleCounts' => ['total'=>0,'available'=>0,'leasing'=>0,'sold'=>0],
                'vehicleValues' => ['purchase_total'=>0,'sale_total'=>0],
                'soldValues' => ['purchase_total'=>0,'sale_total'=>0,'profit'=>0],
                'creditDashboard' => [
                    'monthly' => [
                        'payments' => 0,
                        'overdue_accounts' => 0,
                        'overdue_amount' => 0,
                        'interest' => 0,
                        'customers' => 0,
                        'sold_vehicles' => 0,
                    ],
                    'overall' => [
                        'down_payment' => 0,
                        'paid_interest' => 0,
                        'remaining_principal' => 0,
                        'remaining_total' => 0,
                        'remaining_interest' => 0,
                        'inventory_value' => 0,
                        'paid_principal' => 0,
                        'paid_total' => 0,
                    ],
                ],
                'creditReports' => [
                    'aging' => [
                        'bucket_0_30' => 0,
                        'bucket_31_60' => 0,
                        'bucket_61_90' => 0,
                        'bucket_90_plus' => 0,
                    ],
                    'par' => [
                        'overdue_principal' => 0,
                        'outstanding_principal' => 0,
                        'ratio' => 0,
                    ],
                    'collection' => [
                        'target' => 0,
                        'actual' => 0,
                        'performance' => 0,
                        'gap' => 0,
                    ],
                    'interest' => [
                        'accrued' => 0,
                        'collected' => 0,
                        'gap' => 0,
                    ],
                ],
                'currencyCode' => 'AZN',
            ]);
        }

        if ($module === 'rentacar') {
            $vehicleBase = Vehicle::query()->where('company_id', $companyId);

            $vehicleCounts = [
                'total' => (clone $vehicleBase)->count(),
                'available' => (clone $vehicleBase)->where('status', 'available')->count(),
                'rented' => (clone $vehicleBase)->where('status', 'rented')->count(),
                'maintenance' => (clone $vehicleBase)->where('status', 'maintenance')->count(),
            ];

            $returnWindowDays = 7;
            $now = now();
            $dueSoon = (clone $vehicleBase)
                ->whereNotNull('rent_due_at')
                ->whereBetween('rent_due_at', [$now, $now->copy()->addDays($returnWindowDays)])
                ->orderBy('rent_due_at')
                ->limit(8)
                ->get(['id','brand','model','plate_number','status','rent_due_at']);

            $overdueReturns = (clone $vehicleBase)
                ->whereNotNull('rent_due_at')
                ->where('rent_due_at', '<', $now)
                ->orderBy('rent_due_at')
                ->limit(8)
                ->get(['id','brand','model','plate_number','status','rent_due_at']);

            $dueSoon->each(function ($v) {
                $v->rent_remaining = $this->formatRemaining($v->rent_due_at);
            });
            $overdueReturns->each(function ($v) {
                $v->rent_remaining = $this->formatRemaining($v->rent_due_at);
            });

            $rentedCars = (clone $vehicleBase)
                ->where('status', 'rented')
                ->orderByRaw('CASE WHEN rent_due_at IS NULL THEN 1 ELSE 0 END')
                ->orderBy('rent_due_at')
                ->limit(12)
                ->get(['id','brand','model','plate_number','status','rent_due_at','rent_source']);

            $rentedCars->each(function ($v) {
                $v->rent_remaining = $this->formatRemaining($v->rent_due_at);
            });

            $rentalCalendarEvents = VehicleRental::query()
                ->where('company_id', $companyId)
                ->whereIn('status', ['active', 'closed'])
                ->with('vehicle')
                ->orderByDesc('id')
                ->limit(200)
                ->get()
                ->map(function ($r) {
                    $vehicleName = $r->vehicle?->display_name ?? ('#' . $r->vehicle_id);
                    $startDate = $r->start_at?->toDateString();
                    $endDate = ($r->closed_at ?? $r->due_at)?->toDateString();
                    return [
                        'id' => $r->id,
                        'vehicle' => $vehicleName,
                        'status' => $r->status,
                        'start' => $startDate,
                        'end' => $endDate,
                    ];
                })
                ->filter(fn ($row) => !empty($row['start']))
                ->values()
                ->all();

            $monthStart = now()->startOfMonth();
            $monthEnd = now()->endOfMonth();

            $expenseRows = VehicleExpense::query()
                ->where('company_id', $companyId)
                ->whereBetween('expense_date', [$monthStart->toDateString(), $monthEnd->toDateString()])
                ->select('vehicle_id', DB::raw('COALESCE(SUM(amount),0) as total'))
                ->groupBy('vehicle_id')
                ->get();

            $expenseMap = $expenseRows
                ->keyBy('vehicle_id')
                ->map(fn ($row) => (float) ($row->total ?? 0))
                ->all();

            $totalExpenseMonth = (float) $expenseRows->sum('total');

            $rentalDateExpr = "COALESCE(vehicle_rentals.closed_at, vehicle_rentals.start_at, vehicle_rentals.created_at)";
            $rentalRevenueExpr = "COALESCE(vehicle_rentals.total_after_penalty, vehicle_rentals.actual_total_after_discount, vehicle_rentals.total_after_discount, vehicle_rentals.actual_total_price, vehicle_rentals.total_price, 0)";

            $revenueRows = VehicleRental::query()
                ->where('company_id', $companyId)
                ->whereIn('status', ['active', 'closed'])
                ->whereBetween(DB::raw($rentalDateExpr), [$monthStart, $monthEnd])
                ->select('vehicle_id', DB::raw("COALESCE(SUM($rentalRevenueExpr),0) as total"))
                ->groupBy('vehicle_id')
                ->get();

            $revenueMap = $revenueRows
                ->keyBy('vehicle_id')
                ->map(fn ($row) => (float) ($row->total ?? 0))
                ->all();

            $totalRevenueMonth = (float) $revenueRows->sum('total');
            $totalProfitMonth = $totalRevenueMonth - $totalExpenseMonth;

            $statVehicleIds = array_unique(array_merge(
                array_map('intval', array_keys($expenseMap)),
                array_map('intval', array_keys($revenueMap))
            ));

            $statVehicles = Vehicle::query()
                ->whereIn('id', $statVehicleIds)
                ->get()
                ->keyBy('id');

            $vehicleProfitStats = collect($statVehicleIds)
                ->map(function ($vehicleId) use ($statVehicles, $expenseMap, $revenueMap) {
                    $vehicle = $statVehicles->get($vehicleId);
                    $label = $vehicle?->display_name
                        ?? trim(($vehicle?->brand ?? '') . ' ' . ($vehicle?->model ?? ''));
                    if ($label === '') {
                        $label = '#' . $vehicleId;
                    } elseif (!empty($vehicle?->plate_number)) {
                        $label .= ' (' . $vehicle->plate_number . ')';
                    }

                    $revenue = (float) ($revenueMap[$vehicleId] ?? 0);
                    $expense = (float) ($expenseMap[$vehicleId] ?? 0);
                    $profit = $revenue - $expense;

                    return [
                        'label' => $label,
                        'revenue' => $revenue,
                        'expense' => $expense,
                        'profit' => $profit,
                    ];
                })
                ->sortByDesc('revenue')
                ->take(8)
                ->values();

            $topVehicleRows = VehicleRental::query()
                ->where('company_id', $companyId)
                ->whereIn('status', ['active', 'closed'])
                ->whereNotNull('vehicle_id')
                ->select('vehicle_id', DB::raw('COUNT(*) as total'))
                ->groupBy('vehicle_id')
                ->orderByDesc('total')
                ->limit(8)
                ->get();

            $vehicleMap = Vehicle::query()
                ->whereIn('id', $topVehicleRows->pluck('vehicle_id'))
                ->get()
                ->keyBy('id');

            $topRentedVehicles = $topVehicleRows->map(function ($row) use ($vehicleMap) {
                $vehicle = $vehicleMap->get($row->vehicle_id);
                $name = $vehicle?->display_name
                    ?? trim(($vehicle?->brand ?? '') . ' ' . ($vehicle?->model ?? ''));
                if ($name === '') {
                    $name = '#' . $row->vehicle_id;
                } elseif (!empty($vehicle?->plate_number)) {
                    $name .= ' (' . $vehicle->plate_number . ')';
                }

                return [
                    'label' => $name,
                    'value' => (int) $row->total,
                ];
            })->values();

            $addonCounts = [];
            $addonNames = [];
            VehicleRental::query()
                ->where('company_id', $companyId)
                ->whereIn('status', ['active', 'closed'])
                ->whereNotNull('addons')
                ->orderByDesc('id')
                ->limit(2000)
                ->pluck('addons')
                ->each(function ($addons) use (&$addonCounts, &$addonNames) {
                    if (!is_array($addons)) {
                        return;
                    }

                    foreach ($addons as $addon) {
                        if (!is_array($addon)) {
                            continue;
                        }
                        $id = $addon['id'] ?? null;
                        $name = $addon['name'] ?? null;
                        if ($id === null && !$name) {
                            continue;
                        }
                        $key = $id !== null ? 'id:' . $id : 'name:' . $name;
                        $addonCounts[$key] = ($addonCounts[$key] ?? 0) + 1;
                        if ($id !== null && $name) {
                            $addonNames[$id] = $name;
                        }
                    }
                });

            $addonIds = collect($addonNames)->keys()->map(fn ($id) => (int) $id)->all();
            $addonNameMap = CompanyRentalAddon::query()
                ->whereIn('id', $addonIds)
                ->pluck('name', 'id');

            $topRentedAddons = collect($addonCounts)
                ->map(function ($count, $key) use ($addonNames, $addonNameMap) {
                    $name = null;
                    if (str_starts_with($key, 'id:')) {
                        $id = (int) substr($key, 3);
                        $name = $addonNameMap->get($id) ?? ($addonNames[$id] ?? null);
                        if (!$name) {
                            $name = '#' . $id;
                        }
                    } else {
                        $name = substr($key, 5);
                    }

                    return [
                        'label' => $name,
                        'value' => (int) $count,
                    ];
                })
                ->sortByDesc('value')
                ->take(8)
                ->values();

            return view('dashboard-rentacar', compact(
                'user','company','trialActive','subActive','isSuspended','isActive','readOnly',
                'vehicleCounts','dueSoon','overdueReturns','returnWindowDays','module','rentedCars',
                'rentalCalendarEvents','topRentedVehicles','topRentedAddons',
                'vehicleProfitStats','totalExpenseMonth','totalRevenueMonth','totalProfitMonth'
            ));
        }

        // =========================
        // ÖDƏNİŞLƏR (doğru filter)
        // =========================
        $dateExprSql = "COALESCE(payments.paid_date, payments.created_at)";
        $dateExpr    = DB::raw($dateExprSql);

        // confirmed status (əgər constant yoxdursa "confirmed" götür)
        $confirmedStatus = defined(\App\Models\Payment::class . '::STATUS_CONFIRMED')
            ? Payment::STATUS_CONFIRMED
            : 'confirmed';

        $paymentsBase = Payment::query()
            ->join('bhph_accounts as a', function ($join) use ($companyId) {
                $join->on('a.id', '=', 'payments.bhph_account_id')
                    ->where('a.company_id', $companyId)
                    ->whereNull('a.deleted_at');
            })
            ->whereBetween($dateExpr, [$dateFrom, $dateTo]);

        $paymentsConfirmed = (clone $paymentsBase)->where('payments.status', $confirmedStatus);
        $paymentsQuery = (clone $paymentsConfirmed)->exists() ? $paymentsConfirmed : $paymentsBase;

        $paymentTotals = (clone $paymentsQuery)
            ->selectRaw('
                COALESCE(SUM(payments.amount),0) as total_amount,
                COALESCE(SUM(payments.principal_amount),0) as principal_amount,
                COALESCE(SUM(payments.interest_amount),0) as interest_amount,
                COALESCE(SUM(payments.penalty_amount),0) as penalty_amount
            ')
            ->first();

        // Günlük xammal (yalnız olan günlər)
        $rawDaily = (clone $paymentsQuery)
            ->selectRaw("
                DATE($dateExprSql) as d,
                COALESCE(SUM(payments.amount),0) as t,
                COALESCE(SUM(payments.penalty_amount),0) as p
            ")
            ->groupBy('d')
            ->orderBy('d')
            ->get()
            ->keyBy('d');

        // Chart üçün bütün günləri 0-larla doldur
        $daily = collect();
        for ($d = $dateFrom->copy()->startOfDay(); $d->lte($dateTo->copy()->startOfDay()); $d->addDay()) {
            $key = $d->toDateString();
            $row = $rawDaily->get($key);
            $daily->push([
                'date' => $key,
                'total' => (float) ($row->t ?? 0),
                'penalty' => (float) ($row->p ?? 0),
            ]);
        }

        // Son ödənişlər (eyni tarix expr + fallback)
        $recentBase = (clone $paymentsBase)->select('payments.*');
        $recentConfirmed = (clone $paymentsBase)
            ->select('payments.*')
            ->where('payments.status', $confirmedStatus);

        $recentPayments = ((clone $recentConfirmed)->exists() ? $recentConfirmed : $recentBase)
            ->orderByDesc($dateExpr)
            ->orderByDesc('payments.id')
            ->limit(6)
            ->get();

        // =========================
        // Kredit modul göstəriciləri (aylıq + ümumi)
        // =========================
        $monthStart = now()->startOfMonth();
        $monthEnd = now()->endOfMonth();

        $monthlyBase = Payment::query()
            ->join('bhph_accounts as a', function ($join) use ($companyId) {
                $join->on('a.id', '=', 'payments.bhph_account_id')
                    ->where('a.company_id', $companyId)
                    ->whereNull('a.deleted_at');
            })
            ->whereBetween($dateExpr, [$monthStart, $monthEnd]);

        $monthlyConfirmed = (clone $monthlyBase)->where('payments.status', $confirmedStatus);
        $monthlyQuery = (clone $monthlyConfirmed)->exists() ? $monthlyConfirmed : $monthlyBase;

        $monthlyTotals = (clone $monthlyQuery)
            ->selectRaw('COALESCE(SUM(payments.amount),0) as total_amount')
            ->selectRaw('COALESCE(SUM(payments.interest_amount),0) as interest_amount')
            ->first();

        $overdueAmount = Amortization::forCompany($companyId)
            ->whereDate('due_date', '<', now()->toDateString())
            ->whereIn('status', [
                Amortization::STATUS_OVERDUE,
                Amortization::STATUS_PARTIAL,
                Amortization::STATUS_PENDING,
            ])
            ->selectRaw('COALESCE(SUM(GREATEST(due_amount - paid_amount,0)),0) as total')
            ->value('total');

        $accountSummary = BhphAccount::forCompany($companyId)
            ->selectRaw('COALESCE(SUM(down_payment),0) as down_payment_total')
            ->selectRaw('COALESCE(SUM(paid_interest_amount),0) as paid_interest_total')
            ->selectRaw('COALESCE(SUM(paid_principal_amount),0) as paid_principal_total')
            ->selectRaw('COALESCE(SUM(paid_total_amount),0) as paid_total_amount')
            ->selectRaw('COALESCE(SUM(total_principal_amount - paid_principal_amount),0) as remaining_principal')
            ->selectRaw('COALESCE(SUM(total_interest_amount - paid_interest_amount),0) as remaining_interest')
            ->selectRaw('COALESCE(SUM((total_principal_amount + total_interest_amount) - (paid_principal_amount + paid_interest_amount)),0) as remaining_total')
            ->first();

        $inventoryValue = Vehicle::query()
            ->where('company_id', $companyId)
            ->where('status', '!=', 'sold')
            ->sum('purchase_price');

        $options = CompanyOption::forCompany($companyId)->first();
        $currencyCode = strtoupper((string) ($options?->currency ?? 'AZN'));
        $collectionTarget = (float) data_get($options?->settings, 'collection_target_monthly', 0);

        $today = now()->toDateString();
        $agingBase = Amortization::forCompany($companyId)
            ->whereDate('due_date', '<', $today)
            ->whereIn('status', [
                Amortization::STATUS_OVERDUE,
                Amortization::STATUS_PARTIAL,
                Amortization::STATUS_PENDING,
            ]);

        $sumRemainingExpr = 'COALESCE(SUM(GREATEST(due_amount - paid_amount,0)),0)';

        $bucket0_30 = (clone $agingBase)
            ->whereRaw('DATEDIFF(?, due_date) BETWEEN 1 AND 30', [$today])
            ->selectRaw("$sumRemainingExpr as total")
            ->value('total');
        $bucket31_60 = (clone $agingBase)
            ->whereRaw('DATEDIFF(?, due_date) BETWEEN 31 AND 60', [$today])
            ->selectRaw("$sumRemainingExpr as total")
            ->value('total');
        $bucket61_90 = (clone $agingBase)
            ->whereRaw('DATEDIFF(?, due_date) BETWEEN 61 AND 90', [$today])
            ->selectRaw("$sumRemainingExpr as total")
            ->value('total');
        $bucket90Plus = (clone $agingBase)
            ->whereRaw('DATEDIFF(?, due_date) >= 91', [$today])
            ->selectRaw("$sumRemainingExpr as total")
            ->value('total');

        $overdueAccountIds = (clone $agingBase)
            ->whereRaw('GREATEST(due_amount - paid_amount,0) > 0')
            ->pluck('bhph_account_id')
            ->unique()
            ->values();

        $outstandingPrincipal = BhphAccount::forCompany($companyId)
            ->selectRaw('COALESCE(SUM(total_principal_amount - paid_principal_amount),0) as total')
            ->value('total');

        $overduePrincipal = $overdueAccountIds->isEmpty()
            ? 0
            : BhphAccount::forCompany($companyId)
                ->whereIn('id', $overdueAccountIds)
                ->selectRaw('COALESCE(SUM(total_principal_amount - paid_principal_amount),0) as total')
                ->value('total');

        $parRatio = $outstandingPrincipal > 0
            ? round(((float) $overduePrincipal / (float) $outstandingPrincipal) * 100, 2)
            : 0;

        $collectionActual = (float) ($paymentTotals->total_amount ?? 0);
        $collectionPerformance = $collectionTarget > 0
            ? round(($collectionActual / $collectionTarget) * 100, 2)
            : 0;
        $collectionGap = $collectionTarget > 0
            ? ($collectionTarget - $collectionActual)
            : 0;

        $accruedInterest = Amortization::forCompany($companyId)
            ->whereBetween('due_date', [$dateFrom, $dateTo])
            ->sum('interest_amount');
        $collectedInterest = (clone $paymentsQuery)
            ->sum('payments.interest_amount');
        $interestGap = (float) $accruedInterest - (float) $collectedInterest;

        // =========================
        // HESABLAR
        // =========================
        $accountsQuery = BhphAccount::query()->where('company_id', $companyId);
        if ($accountStatus !== 'all') {
            $accountsQuery->where('status', $accountStatus);
        }

        $accountCounts = [
            'total'   => (clone $accountsQuery)->count(),
            'active'  => (clone $accountsQuery)->where('status', BhphAccount::STATUS_ACTIVE)->count(),
            'overdue' => (clone $accountsQuery)->where('status', BhphAccount::STATUS_OVERDUE)->count(),
            'legal'   => (clone $accountsQuery)->where('status', BhphAccount::STATUS_LEGAL)->count(),
        ];

        $topOverdue = BhphAccount::query()
            ->where('company_id', $companyId)
            ->where('status', BhphAccount::STATUS_OVERDUE)
            ->with('customer')
            ->latest('updated_at')
            ->limit(5)
            ->get();

        // =========================
        // AVTOMOBİL GÖSTƏRİCİLƏRİ
        // =========================
        $vehicleBase = Vehicle::query()->where('company_id', $companyId);

        $vehicleCounts = [
            'total'     => (clone $vehicleBase)->count(),
            'available' => (clone $vehicleBase)->where('status', 'available')->count(),
            'leasing'   => (clone $vehicleBase)->where('status', 'leasing')->count(),
            'sold'      => (clone $vehicleBase)->where('status', 'sold')->count(),
        ];

        $vehicleValues = [
            'purchase_total' => (float) (clone $vehicleBase)->sum('purchase_price'),
            'sale_total'     => (float) (clone $vehicleBase)->sum('sale_price'),
        ];

        $soldFiltered = (clone $vehicleBase)->where('status', 'sold');
        $soldValues = [
            'purchase_total' => (float) (clone $soldFiltered)->sum('purchase_price'),
            'sale_total'     => (float) (clone $soldFiltered)->sum('sale_price'),
        ];
        $soldValues['profit'] = $soldValues['sale_total'] - $soldValues['purchase_total'];

        // =========================
        // Taxes summary (dashboard)
        // =========================
        $taxTotalYear = TaxReport::forCompany($companyId)
            ->whereYear('period_end', now()->year)
            ->sum('tax_amount');
        $lastTax = TaxReport::forCompany($companyId)
            ->latest('period_end')
            ->latest('id')
            ->first();

        // =========================
        // Forecasts (analytics / advanced_reports feature)
        // =========================
        $addonFeatures = $company ? $subscriptionService->activeAddonFeatures($company) : [];
        $hasAnalytics = $company && (
            $subscriptionService->hasFeature($company, 'advanced_reports')
            || $subscriptionService->hasFeature($company, 'analytics')
            || $subscriptionService->hasFeature($company, 'kpi')
            || !empty($addonFeatures['advanced_reports'])
            || !empty($addonFeatures['analytics'])
            || !empty($addonFeatures['kpi'])
        );
        $forecastTurnover = collect();
        if ($company && $hasAnalytics) {
            $forecastTurnover = AnalyticsForecast::forCompany($companyId)
                ->where('metric', 'turnover')
                ->where('period', 'monthly')
                ->where('forecast_date', '>=', now()->startOfMonth()->toDateString())
                ->orderBy('forecast_date')
                ->limit(6)
                ->get();
        }

        // =========================
        // Payment calendar from amortization schedule
        // =========================
        $amortTimelineRaw = Amortization::query()
            ->with(['bhphAccount.customer'])
            ->where('company_id', $companyId)
            ->orderBy('due_date')
            ->get();

        $amortTimeline = $amortTimelineRaw->map(function ($row) {
            $customerName = $row->bhphAccount?->customer?->full_name
                ?? trim(($row->bhphAccount?->customer?->first_name ?? '') . ' ' . ($row->bhphAccount?->customer?->last_name ?? ''));
            return [
                'date' => optional($row->due_date)->format('Y-m-d'),
                'amount' => (float) $row->due_amount,
                'principal' => (float) ($row->principal_amount ?? 0),
                'interest' => (float) ($row->interest_amount ?? 0),
                'penalty' => 0.0,
                'paid' => (float) ($row->paid_amount ?? 0),
                'status' => $row->status,
                'account_id' => $row->bhph_account_id,
                'customer' => $customerName ?: null,
            ];
        })->filter(fn ($row) => !empty($row['date']))->values();

        $timelineStart = $amortTimeline->min('date');
        $timelineEnd   = $amortTimeline->max('date');

        $creditDashboard = [
            'monthly' => [
                'payments' => (float) ($monthlyTotals->total_amount ?? 0),
                'overdue_accounts' => (int) ($accountCounts['overdue'] ?? 0),
                'overdue_amount' => (float) ($overdueAmount ?? 0),
                'interest' => (float) ($monthlyTotals->interest_amount ?? 0),
                'customers' => (int) Customer::query()->where('company_id', $companyId)->count(),
                'sold_vehicles' => (int) Vehicle::query()->where('company_id', $companyId)->where('status', 'sold')->count(),
            ],
            'overall' => [
                'down_payment' => (float) ($accountSummary->down_payment_total ?? 0),
                'paid_interest' => (float) ($accountSummary->paid_interest_total ?? 0),
                'remaining_principal' => (float) ($accountSummary->remaining_principal ?? 0),
                'remaining_total' => (float) ($accountSummary->remaining_total ?? 0),
                'remaining_interest' => (float) ($accountSummary->remaining_interest ?? 0),
                'inventory_value' => (float) ($inventoryValue ?? 0),
                'paid_principal' => (float) ($accountSummary->paid_principal_total ?? 0),
                'paid_total' => (float) ($accountSummary->paid_total_amount ?? 0),
            ],
        ];

        $creditReports = [
            'aging' => [
                'bucket_0_30' => (float) ($bucket0_30 ?? 0),
                'bucket_31_60' => (float) ($bucket31_60 ?? 0),
                'bucket_61_90' => (float) ($bucket61_90 ?? 0),
                'bucket_90_plus' => (float) ($bucket90Plus ?? 0),
            ],
            'par' => [
                'overdue_principal' => (float) ($overduePrincipal ?? 0),
                'outstanding_principal' => (float) ($outstandingPrincipal ?? 0),
                'ratio' => (float) $parRatio,
            ],
            'collection' => [
                'target' => (float) $collectionTarget,
                'actual' => (float) $collectionActual,
                'performance' => (float) $collectionPerformance,
                'gap' => (float) $collectionGap,
            ],
            'interest' => [
                'accrued' => (float) $accruedInterest,
                'collected' => (float) $collectedInterest,
                'gap' => (float) $interestGap,
            ],
        ];

        return view('dashboard', compact(
            'user','company','trialActive','subActive','isSuspended','isActive','readOnly',
            'filters','paymentTotals','daily','recentPayments','accountCounts','topOverdue',
            'vehicleCounts','vehicleValues','soldValues','amortTimeline','timelineStart','timelineEnd',
            'taxTotalYear','lastTax','forecastTurnover','hasAnalytics',
            'creditDashboard','creditReports','currencyCode'
        ));
    }

    public function exportPdf(Request $request)
    {
        $user = $request->user();
        if ($user?->gps_provider_id) {
            abort(403);
        }

        $canAny = $user && (
            $user->hasPermission('payments.view')
            || $user->hasPermission('bhph.view')
            || $user->hasPermission('vehicles.view')
            || $user->hasPermission('customers.view')
            || $user->hasPermission('settings.edit')
        );
        if (!$canAny) {
            abort(403, 'No permission to export dashboard.');
        }

        $company = $user?->company;
        $module = $company?->moduleCode() ?? 'leasing';
        if ($module !== 'leasing') {
            abort(403, 'PDF export is available only for leasing dashboard.');
        }

        $view = $this->index($request);
        if ($view instanceof RedirectResponse) {
            return $view;
        }
        if (!$view instanceof View) {
            abort(500, 'Dashboard export failed.');
        }

        $data = $view->getData();
        return response()->view('dashboard_pdf', $data);
    }

    private function formatRemaining(?Carbon $due): ?string
    {
        if (!$due) {
            return null;
        }

        $seconds = now()->diffInSeconds($due, false);
        $abs = abs($seconds);

        $days = intdiv($abs, 86400);
        $hours = intdiv($abs % 86400, 3600);
        $mins = intdiv($abs % 3600, 60);

        $parts = [];
        if ($days > 0) {
            $parts[] = $days . 'd';
        }
        if ($hours > 0) {
            $parts[] = $hours . 'h';
        }
        if ($days === 0 && $hours === 0) {
            $parts[] = $mins . 'm';
        }

        $label = implode(' ', $parts) ?: '0m';
        if ($seconds < 0) {
            return ___('Overdue by') . ' ' . $label;
        }

        return $label;
    }
}
