<?php

namespace App\Http\Controllers;

use App\Models\RiskAssessment;
use App\Models\RiskFactorDefinition;
use App\Services\RiskEngine;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class RiskAssessmentController extends Controller
{
    public function __construct()
    {
        $this->middleware('perm:risk.view')->only(['show']);
        $this->middleware('perm:risk.create')->only(['create','store']);
    }

    public function create(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        if (!$companyId) {
            abort(403, 'Company not set for user.');
        }

        $factors = RiskFactorDefinition::query()
            ->where('company_id', $companyId)
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->get();

        return view('risk_assessments.create', compact('factors'));
    }

    public function store(Request $request, RiskEngine $engine)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        if (!$companyId) {
            abort(403, 'Company not set for user.');
        }

        $definitions = RiskFactorDefinition::query()
            ->where('company_id', $companyId)
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->get();

        $rules = [
            'monthly_income' => ['required','numeric','min:0.01'],
            'existing_monthly_debt' => ['required','numeric','min:0'],
            'requested_monthly_payment' => ['nullable','numeric','min:0'],
            'job_value' => ['required','numeric','min:0'],
            'job_unit' => ['required','in:months,years'],
            'adjustments' => ['nullable','array'],
            'adjustments.*.key' => ['nullable','string','max:64'],
            'adjustments.*.points' => ['nullable','numeric'],
            'adjustments.*.note' => ['nullable','string','max:255'],
            'extra_factors' => ['nullable','array'],
            'extra_factors.*.key' => ['nullable','string','max:64'],
            'extra_factors.*.value' => ['nullable'],
        ];

        foreach ($definitions as $def) {
            $key = $def->key;
            $rule = match ($def->type) {
                'boolean' => ['nullable','boolean'],
                'select' => ['nullable','string','max:120'],
                'text' => ['nullable','string','max:255'],
                default => ['nullable','numeric'],
            };
            $rules["factors.$key"] = $rule;
        }

        $data = $request->validate($rules);

        $cleanFactors = [];
        $rawFactors = $request->input('factors', []);

        foreach ($definitions as $def) {
            $key = $def->key;
            if (!array_key_exists($key, $rawFactors)) {
                continue;
            }
            $val = $rawFactors[$key];
            if ($def->type === 'boolean') {
                $cleanFactors[$key] = filter_var($val, FILTER_VALIDATE_BOOL);
            } elseif ($def->type === 'number') {
                $cleanFactors[$key] = (float)$val;
            } else {
                $cleanFactors[$key] = $val;
            }
        }

        $extraFactors = [];
        foreach ($request->input('extra_factors', []) as $row) {
            $ekey = trim((string)($row['key'] ?? ''));
            if ($ekey === '') {
                continue;
            }
            $extraFactors[$ekey] = $row['value'] ?? null;
        }

        $adjustments = [];
        foreach ($request->input('adjustments', []) as $row) {
            $points = $row['points'] ?? null;
            $akey = trim((string)($row['key'] ?? ''));
            if ($points === null || $akey === '') {
                continue;
            }
            $adjustments[] = [
                'key' => $akey,
                'points' => (float)$points,
                'note' => Arr::get($row, 'note'),
            ];
        }

        $jobMonths = (float)$data['job_value'];
        if (($data['job_unit'] ?? 'months') === 'years') {
            $jobMonths = $jobMonths * 12;
        }

        $base = [
            'monthly_income' => (float)$data['monthly_income'],
            'existing_monthly_debt' => (float)$data['existing_monthly_debt'],
            'requested_monthly_payment' => (float)($data['requested_monthly_payment'] ?? 0),
            'job_months' => (int)round($jobMonths),
        ];

        $result = $engine->evaluate($companyId, $base, $cleanFactors, $adjustments, $definitions);

        $assessment = RiskAssessment::create([
            'company_id' => $companyId,
            'created_by' => $user->id,
            'monthly_income' => $base['monthly_income'],
            'existing_monthly_debt' => $base['existing_monthly_debt'],
            'requested_monthly_payment' => $base['requested_monthly_payment'],
            'job_months' => $base['job_months'],
            'factors' => array_merge($cleanFactors, $extraFactors),
            'adjustments' => $adjustments,
            'score' => $result['score'],
            'risk_band' => $result['risk_band'],
            'decision_status' => $result['decision_status'],
            'decision_comment' => $result['decision_comment'],
            'decision_notes' => $result['decision_notes'],
            'guarantor_required' => $result['guarantor_required'],
            'max_allowed_payment' => $result['max_allowed_payment'],
            'requested_monthly_payment' => $result['suggested_payment'],
            'explain' => $result['explain'],
        ]);

        return redirect()->route('risk_assessments.show', $assessment);
    }

    public function show(Request $request, RiskAssessment $riskAssessment)
    {
        $user = $request->user();
        if ($riskAssessment->company_id !== $user?->company_id) {
            abort(403);
        }

        return view('risk_assessments.show', [
            'assessment' => $riskAssessment,
        ]);
    }
}
