<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Jobs\SendWhatsAppCampaign;
use App\Models\NotificationOption;
use App\Models\WhatsAppCampaign;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;

class WhatsAppCampaignController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'feature:whatsapp_campaigns', 'perm:notify.send|whatsapp.campaigns']);
    }

    public function index(Request $request)
    {
        $companyId = $request->user()?->company_id;
        if (!$companyId) {
            abort(403);
        }

        $campaigns = WhatsAppCampaign::where('company_id', $companyId)
            ->orderByDesc('created_at')
            ->paginate(15)
            ->withQueryString();

        return view('whatsapp_campaigns.index', compact('campaigns'));
    }

    public function create(Request $request, SubscriptionService $subs)
    {
        $company = $request->user()?->company;
        if (!$company) abort(403);

        $option = NotificationOption::where('company_id', $company->id)->first();
        $featureOk = $subs->hasFeature($company, 'whatsapp_campaigns');

        return view('whatsapp_campaigns.create', compact('option', 'featureOk'));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        if (!$companyId) abort(403);

        $data = $request->validate([
            'title' => ['required', 'string', 'max:160'],
            'message' => ['required', 'string', 'max:1000'],
        ]);

        $option = NotificationOption::where('company_id', $companyId)
            ->where('is_active', true)
            ->first();

        if (!$option || !$option->wp_api_secret) {
            return back()
                ->withInput()
                ->withErrors(['message' => 'WhatsApp API ayarları tamamlanmayıb. Əvvəlcə aktivləşdirin.']);
        }

        $campaign = WhatsAppCampaign::create([
            'company_id' => $companyId,
            'created_by' => $user->id ?? null,
            'title' => $data['title'],
            'message' => $data['message'],
            'status' => 'queued',
        ]);

        SendWhatsAppCampaign::dispatch($campaign->id);

        return redirect()
            ->route('company.whatsapp_campaigns.index')
            ->with('status', 'Kampaniya növbəyə əlavə olundu və göndərilir.');
    }
}
