<?php

namespace App\Http\Controllers;

use App\Models\PaymentOption;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class PaymentOptionController extends Controller
{
    public function edit(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'İstifadəçi şirkətə bağlı deyil.');
        }

        $options = PaymentOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            PaymentOption::defaults()
        );

        return view('payment_options.edit', compact('user', 'options'));
    }

    public function update(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'İstifadəçi şirkətə bağlı deyil.');
        }

        $options = PaymentOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            PaymentOption::defaults()
        );

        $overpayAllowed = $request->boolean('allow_overpayment');

        $v = Validator::make($request->all(), [
            'apply_to' => ['required', Rule::in([
                PaymentOption::APPLY_OLDEST_DUE_FIRST,
                PaymentOption::APPLY_CURRENT_DUE_ONLY,
                PaymentOption::APPLY_NEWEST_FIRST,
            ])],

            'allocation_order' => ['required', Rule::in([
                PaymentOption::ALLOC_INTEREST_THEN_PRINCIPAL,
                PaymentOption::ALLOC_PRINCIPAL_THEN_INTEREST,
            ])],

            'payment_gateway_provider' => ['required', Rule::in([
                'auto',
                'epoint',
                'iyzico',
                'stripe',
            ])],

            'overpayment_behavior' => array_filter([
                $overpayAllowed ? 'required' : 'nullable',
                Rule::in([
                    PaymentOption::OVERPAY_KEEP_AS_CREDIT,
                    PaymentOption::OVERPAY_REDUCE_PRINCIPAL,
                    PaymentOption::OVERPAY_APPLY_NEXT_INSTALLMENTS,
                ]),
            ]),

            'min_partial_payment_amount' => ['nullable','numeric','min:0','max:100000000'],
            'min_overpayment_amount' => ['nullable','numeric','min:0','max:100000000'],

            'notes' => ['nullable','string','max:2000'],

            // settings key/value rows
            'settings_k' => ['nullable','array'],
            'settings_k.*' => ['nullable','string','max:190'],
            'settings_v' => ['nullable','array'],
            'settings_v.*' => ['nullable','string','max:2000'],
        ]);

        $data = $v->validate();

        // checkbox-lar (yoxdursa 0)
        $data['allow_payment_gateway'] = $request->boolean('allow_payment_gateway');
        $data['allow_overpayment'] = $request->boolean('allow_overpayment');
        $data['allow_partial_payment'] = $request->boolean('allow_partial_payment');
        $data['allow_principal_only_payment'] = $request->boolean('allow_principal_only_payment');
        $data['allow_advance_payment'] = $request->boolean('allow_advance_payment');

        // normalize: boş string -> null
        foreach (['min_partial_payment_amount','min_overpayment_amount'] as $f) {
            if (array_key_exists($f, $data) && ($data[$f] === '' || $data[$f] === null)) {
                $data[$f] = null;
            }
        }

        // Əgər qismən ödəniş söndürülübsə, minimumu ləğv elə
        if (!$data['allow_partial_payment']) {
            $data['min_partial_payment_amount'] = null;
        }

        // Əgər artıq ödəniş söndürülübsə, bağlı funksiyaları da söndür
        if (!$data['allow_overpayment']) {
            $data['min_overpayment_amount'] = null;
            // DB sütunu NOT NULL olduğuna görə fallback dəyəri saxla
            $data['overpayment_behavior'] = $options->overpayment_behavior ?? PaymentOption::OVERPAY_KEEP_AS_CREDIT;
            $data['allow_principal_only_payment'] = false;
            $data['allow_advance_payment'] = false;
        }

        // settings => assoc (açar/dəyər)
        $settings = [];
        $keys = $request->input('settings_k', []);
        $vals = $request->input('settings_v', []);

        if (is_array($keys) && is_array($vals)) {
            foreach ($keys as $i => $k) {
                $k = trim((string)$k);
                if ($k === '') continue;
                $settings[$k] = (string)($vals[$i] ?? '');
            }
        }

        $data['company_id'] = $companyId;

        $options->fill($data);
        $options->settings = $settings ?: null;
        $options->save();

        return redirect()
            ->route('company.payment_options.edit')
            ->with('status', 'Ödəniş ayarları yadda saxlanıldı.');
    }
}
