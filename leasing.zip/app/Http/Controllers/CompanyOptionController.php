<?php

namespace App\Http\Controllers;

use App\Models\CompanyOption;
use App\Models\GpsProvider;
use App\Models\CompanyGpsConnection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CompanyOptionController extends Controller
{
    public function edit(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'User şirkətə bağlı deyil.');
        }

        $options = CompanyOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            [
                'timezone' => 'Asia/Baku',
                'locale'   => 'az',
                'currency' => 'AZN',
            ]
        );

        $this->prepareOptionsForDisplay($options, $user?->company);
        $gpsProviders = GpsProvider::query()->active()->orderBy('name')->get();
        $gpsConnection = CompanyGpsConnection::query()
            ->with('provider')
            ->where('company_id', $companyId)
            ->first();

        return view('company_options.edit', compact('user', 'options', 'gpsProviders', 'gpsConnection'));
    }

    public function update(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'User şirkətə bağlı deyil.');
        }

        $options = CompanyOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            [
                'timezone' => 'Asia/Baku',
                'locale'   => 'az',
                'currency' => 'AZN',
            ]
        );

        // Əsas field-lər + yeni structured inputs
        $validated = $request->validate([
            // branding
            'display_name' => ['nullable','string','max:120'],
            'logo' => ['nullable','image','max:2048'],
            'cover_image' => ['nullable','image','max:4096'],

            // contact
            'contact_email' => ['nullable','email','max:190'],
            'contact_phone' => ['nullable','string','max:32'],
            'whatsapp_phone' => ['nullable','string','max:32'],
            'address' => ['nullable','string','max:255'],
            'city' => ['nullable','string','max:100'],
            'country' => ['nullable','string','max:100'],

            // map
            'latitude' => ['nullable','numeric','between:-90,90'],
            'longitude' => ['nullable','numeric','between:-180,180'],
            'map_url' => ['nullable','url','max:500'],

            // localization
            'timezone' => ['nullable','string','max:64'],
            'locale' => ['nullable','in:az,en,ru,tr'],
            'currency' => ['nullable','string','max:16'],

            // seo
            'seo_title' => ['nullable','string','max:120'],
            'seo_description' => ['nullable','string','max:255'],
            'seo_keywords' => ['nullable','string','max:255'],
            'seo_canonical_url' => ['nullable','url','max:500'],
            'seo_indexable' => ['nullable','boolean'],

            // calculator
            'calc_interest_min' => ['nullable','numeric','min:0','max:100'],
            'calc_interest_max' => ['nullable','numeric','min:0','max:100'],
            'calc_term_min_months' => ['nullable','integer','min:1','max:600'],
            'calc_term_max_months' => ['nullable','integer','min:1','max:600'],
            'calc_amount_min' => ['nullable','numeric','min:0'],
            'calc_amount_max' => ['nullable','numeric','min:0'],

            // working hours
            'working_hours' => ['nullable','array'],
            'working_hours.*.closed' => ['nullable','boolean'],
            'working_hours.*.from' => ['nullable','date_format:H:i'],
            'working_hours.*.to' => ['nullable','date_format:H:i'],

            // social links
            'social_links' => ['nullable','array'],
            'social_links.*.type' => ['nullable','in:facebook,instagram,tiktok,youtube,linkedin,telegram,whatsapp,x,website'],
            'social_links.*.url' => ['nullable','url','max:500'],

            // settings key/value rows
            'settings_k' => ['nullable','array'],
            'settings_k.*' => ['nullable','string','max:190'],
            'settings_v' => ['nullable','array'],
            'settings_v.*' => ['nullable','string','max:2000'],
            'collection_target_monthly' => ['nullable','numeric','min:0'],
            'payment_gateways' => ['nullable','array'],
            'payment_gateways.epoint.public_key' => ['nullable','string','max:255'],
            'payment_gateways.epoint.private_key' => ['nullable','string','max:255'],
            'payment_gateways.epoint.base_url' => ['nullable','url','max:500'],
            'payment_gateways.stripe.public_key' => ['nullable','string','max:255'],
            'payment_gateways.stripe.secret' => ['nullable','string','max:255'],
            'payment_gateways.stripe.webhook_secret' => ['nullable','string','max:255'],
            'payment_gateways.iyzico.api_key' => ['nullable','string','max:255'],
            'payment_gateways.iyzico.secret_key' => ['nullable','string','max:255'],
            'payment_gateways.iyzico.base_url' => ['nullable','url','max:500'],

            // GPS provider selection (provider handles credentials)
            'gps_provider_id' => ['nullable','integer','exists:gps_providers,id'],
        ]);

        // checkbox fix (göndərilməyə bilər)
        $validated['seo_indexable'] = (bool) $request->input('seo_indexable', false);
        $collectionTargetInput = $request->input('collection_target_monthly');
        unset($validated['collection_target_monthly']);

        // -------------------------
        // Normalize: Working hours
        // -------------------------
        $allowedDays = ['mon','tue','wed','thu','fri','sat','sun'];
        $working = [];
        $inputWh = $request->input('working_hours', []);

        if (is_array($inputWh)) {
            foreach ($inputWh as $day => $row) {
                if (!in_array($day, $allowedDays, true)) continue;
                if (!is_array($row)) continue;

                $closed = (bool)($row['closed'] ?? false);

                if ($closed) {
                    $working[$day] = ['closed' => true];
                    continue;
                }

                $from = $row['from'] ?? null;
                $to   = $row['to'] ?? null;

                // açıqdırsa from/to olmalıdır
                if ($from && $to) {
                    $working[$day] = ['closed' => false, 'from' => $from, 'to' => $to];
                }
            }
        }

        // -------------------------
        // Normalize: Social links
        // -------------------------
        $social = [];
        $inputSocial = $request->input('social_links', []);
        if (is_array($inputSocial)) {
            foreach ($inputSocial as $row) {
                if (!is_array($row)) continue;

                $type = trim((string)($row['type'] ?? ''));
                $url  = trim((string)($row['url'] ?? ''));

                if ($type === '' || $url === '') continue;
                $social[] = ['type' => $type, 'url' => $url];
            }
        }

        // -------------------------
        // Normalize: Settings (assoc)
        // -------------------------
        $settings = [];
        $keys = $request->input('settings_k', []);
        $vals = $request->input('settings_v', []);

        if (is_array($keys) && is_array($vals)) {
            foreach ($keys as $i => $k) {
                $k = trim((string)$k);
                if ($k === '') continue;
                $settings[$k] = (string)($vals[$i] ?? '');
            }
        }

        if ($collectionTargetInput !== null) {
            $collectionTargetInput = trim((string)$collectionTargetInput);
            if ($collectionTargetInput === '') {
                unset($settings['collection_target_monthly']);
            } else {
                $settings['collection_target_monthly'] = $collectionTargetInput;
            }
        }

        $gatewayInputs = $request->input('payment_gateways', []);
        $allowedGatewayFields = [
            'epoint' => ['public_key', 'private_key', 'base_url'],
            'stripe' => ['public_key', 'secret', 'webhook_secret'],
            'iyzico' => ['api_key', 'secret_key', 'base_url'],
        ];

        $gateways = [];
        foreach ($allowedGatewayFields as $provider => $fields) {
            $providerRow = $gatewayInputs[$provider] ?? [];
            if (!is_array($providerRow)) {
                continue;
            }

            $clean = [];
            foreach ($fields as $field) {
                $value = trim((string)($providerRow[$field] ?? ''));
                if ($value === '') {
                    continue;
                }
                $clean[$field] = $value;
            }

            if ($clean !== []) {
                $gateways[$provider] = $clean;
            }
        }

        $validated['payment_gateways'] = $gateways ?: null;

        // Uploads
        if ($request->hasFile('logo')) {
            if ($options->logo_path) {
                Storage::disk('public')->delete($options->logo_path);
            }
            $validated['logo_path'] = $request->file('logo')->store("companies/{$companyId}", 'public');
        } else {
            unset($validated['logo_path']);
        }

        if ($request->hasFile('cover_image')) {
            if ($options->cover_image_path) {
                Storage::disk('public')->delete($options->cover_image_path);
            }
            $validated['cover_image_path'] = $request->file('cover_image')->store("companies/{$companyId}", 'public');
        } else {
            unset($validated['cover_image_path']);
        }

        // Safety
        $validated['company_id'] = $companyId;

        // Save normal fields
        $options->fill($validated);

        // Save structured arrays
        $options->working_hours = $working ?: null;
        $options->social_links  = $social ?: null;
        $options->settings      = $settings ?: null;

        $options->save();

        $selectedProviderId = $request->input('gps_provider_id');
        $gpsConnection = CompanyGpsConnection::query()
            ->where('company_id', $companyId)
            ->first();

        if ($selectedProviderId) {
            $provider = GpsProvider::query()->where('id', $selectedProviderId)->where('is_active', true)->first();
            if (!$provider) {
                return redirect()->back()->withErrors(['gps_provider_id' => ___('Selected GPS provider is inactive.')]);
            }

            $needsRequest = !$gpsConnection
                || (int) $gpsConnection->gps_provider_id !== (int) $selectedProviderId
                || $gpsConnection->status !== 'approved';

            if ($needsRequest) {
                $gpsConnection = $gpsConnection ?: new CompanyGpsConnection();
                $gpsConnection->company_id = $companyId;
                $gpsConnection->gps_provider_id = (int) $selectedProviderId;
                $gpsConnection->status = 'pending';
                $gpsConnection->requested_by = $user?->id;
                $gpsConnection->requested_at = now();
                $gpsConnection->approved_by = null;
                $gpsConnection->approved_at = null;
                $gpsConnection->rejected_at = null;
                $gpsConnection->save();
            }
        } else {
            if ($gpsConnection) {
                $gpsConnection->delete();
            }
        }

        return redirect()
            ->route('company.options.edit')
            ->with('status', 'Yadda saxlanıldı.');
    }

    private function prepareOptionsForDisplay(CompanyOption $options, $company): void
    {
        $shouldPrefill = $options->wasRecentlyCreated;

        if (!$shouldPrefill && $options->created_at && $options->updated_at) {
            $shouldPrefill = $options->created_at->eq($options->updated_at);
        }

        if ($company && $shouldPrefill) {
            $fallbacks = [
                'display_name' => $company->name ?? null,
                'contact_email' => $company->email ?? null,
                'contact_phone' => $company->phone ?? null,
                'address' => $company->address ?? null,
                'timezone' => $company->timezone ?? null,
                'locale' => $company->locale ?? null,
                'currency' => $company->currency ?? null,
                'logo_path' => $company->logo_path ?? null,
            ];

            foreach ($fallbacks as $key => $value) {
                if (($options->{$key} === null || $options->{$key} === '') && $value !== null && $value !== '') {
                    $options->{$key} = $value;
                }
            }
        }

        $options->working_hours = $this->normalizeWorkingHours($options->working_hours);
        $options->social_links = $this->normalizeSocialLinks($options->social_links);
    }

    private function normalizeWorkingHours($working): array
    {
        if (!is_array($working)) {
            return [];
        }

        $normalized = [];
        foreach ($working as $day => $row) {
            if (!is_array($row)) {
                continue;
            }

            $closed = (bool)($row['closed'] ?? false);
            $from = $row['from'] ?? $row['open'] ?? null;
            $to = $row['to'] ?? $row['close'] ?? null;

            if ($closed) {
                $normalized[$day] = ['closed' => true];
                continue;
            }

            if ($from !== null || $to !== null) {
                $normalized[$day] = [
                    'closed' => false,
                    'from' => $from,
                    'to' => $to,
                ];
            }
        }

        return $normalized;
    }

    private function normalizeSocialLinks($social): array
    {
        if (!is_array($social)) {
            return [];
        }

        $normalized = [];
        foreach ($social as $key => $value) {
            if (is_array($value)) {
                $type = $value['type'] ?? (is_string($key) ? $key : '');
                $url = $value['url'] ?? '';
                $normalized[] = [
                    'type' => (string)$type,
                    'url' => (string)$url,
                ];
                continue;
            }

            if (is_string($value) && $value !== '') {
                $normalized[] = [
                    'type' => is_string($key) ? $key : '',
                    'url' => $value,
                ];
            }
        }

        return $normalized;
    }
}
