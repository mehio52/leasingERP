<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('perm:customers.view')->only(['index']);
        $this->middleware('perm:customers.create')->only(['create','store']);
        $this->middleware('perm:customers.edit')->only(['edit','update']);
        $this->middleware('perm:customers.delete')->only(['destroy']);
    }

    private function normalizeAzPhone(?string $raw): ?string
    {
        $raw = trim((string)$raw);
        if ($raw === '') return null;

        // varsa səndə helper, onu istifadə et
        if (function_exists('normalizeAzPhone')) {
            return normalizeAzPhone($raw);
        }

        // fallback: 0501234567 -> +994501234567, 994501234567 -> +994501234567
        $digits = preg_replace('/\D+/', '', $raw);
        if (!$digits) return null;

        if (str_starts_with($digits, '0') && strlen($digits) === 10) {
            $digits = '994' . substr($digits, 1);
        }
        if (str_starts_with($digits, '994') && strlen($digits) === 12) {
            return '+' . $digits;
        }

        if (preg_match('/^\+994\d{9}$/', $raw)) return $raw;

        return null;
    }

    public function index(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $q = trim((string)$request->query('q', ''));

        $customers = Customer::query()
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($x) use ($q) {
                    $x->where('first_name', 'like', "%{$q}%")
                      ->orWhere('last_name', 'like', "%{$q}%")
                      ->orWhere('father_name', 'like', "%{$q}%")
                      ->orWhere('phone', 'like', "%{$q}%")
                      ->orWhere('voen', 'like', "%{$q}%")
                      ->orWhere('fin_code', 'like', "%{$q}%")
                      ->orWhere('id_card_number', 'like', "%{$q}%")
                      ->orWhere('driver_license_number', 'like', "%{$q}%");
                });
            })
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('customers.index', compact('user', 'customers', 'q'));
    }

    public function create(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        return view('customers.create', compact('user'));
    }

    public function store(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $phone = $this->normalizeAzPhone($request->input('phone'));
        if (!$phone) {
            return back()->withErrors(['phone' => 'Telefon formatı yanlışdır. Məs: +994501234567'])->withInput();
        }

        // yalnız DB sütunları!
        $data = $request->only([
            'first_name',
            'last_name',
            'father_name',
            'voen',
            'id_card_number',
            'fin_code',
            'driver_license_number',
            'driver_license_category',
            'birth_date',
        ]);
        $data['phone'] = $phone;
        $data['whatsapp_opt_in'] = $request->boolean('whatsapp_opt_in');
        $data['whatsapp_opt_in_at'] = $data['whatsapp_opt_in'] ? now() : null;

        $v = Validator::make($data, [
            'first_name' => ['required','string','max:255'],
            'last_name'  => ['required','string','max:255'],
            'father_name'=> ['nullable','string','max:255'],

            'phone'      => ['required','string','regex:/^\+994\d{9}$/'],

            'voen'       => ['nullable','string','max:32'],
            'id_card_number' => ['nullable','string','max:64'],
            'fin_code'   => ['nullable','string','max:16'],
            'driver_license_number' => ['nullable','string','max:64'],
            'driver_license_category' => ['nullable','string','max:16'],

            'birth_date' => ['nullable','date'],

            // Əgər nömrə eyni şirkətdə təkrar olmasın istəyirsənsə:
            // (TenantScope onsuz da company filter edir, amma store zamanı düzgün olsun)
            // 'phone' => [
            //   'required','string','regex:/^\+994\d{9}$/',
            //   Rule::unique('customers','phone')->where(fn($q) => $q->where('company_id', $user->company_id)),
            // ],
        ]);

        $validated = $v->validate();

        // boş stringləri null et (opsional, amma səliqəlidir)
        foreach ($validated as $k => $val) {
            if (is_string($val) && trim($val) === '') $validated[$k] = null;
        }

        $customer = new Customer();
        $customer->fill($validated);
        // BelongsToCompany creating hook company_id-ni qoyacaq (auth var)
        $customer->save();

        return redirect()->route('customers.index')->with('status', 'Müştəri yaradıldı.');
    }

    public function edit(Request $request, Customer $customer)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        return view('customers.edit', compact('user', 'customer'));
    }

    public function update(Request $request, Customer $customer)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $phone = $this->normalizeAzPhone($request->input('phone'));
        if (!$phone) {
            return back()->withErrors(['phone' => 'Telefon formatı yanlışdır. Məs: +994501234567'])->withInput();
        }

        $data = $request->only([
            'first_name',
            'last_name',
            'father_name',
            'voen',
            'id_card_number',
            'fin_code',
            'driver_license_number',
            'driver_license_category',
            'birth_date',
        ]);
        $data['phone'] = $phone;
        $data['whatsapp_opt_in'] = $request->boolean('whatsapp_opt_in');
        $data['whatsapp_opt_in_at'] = $data['whatsapp_opt_in'] ? now() : null;

        $v = Validator::make($data, [
            'first_name' => ['required','string','max:255'],
            'last_name'  => ['required','string','max:255'],
            'father_name'=> ['nullable','string','max:255'],

            'phone'      => ['required','string','regex:/^\+994\d{9}$/'],

            'voen'       => ['nullable','string','max:32'],
            'id_card_number' => ['nullable','string','max:64'],
            'fin_code'   => ['nullable','string','max:16'],
            'driver_license_number' => ['nullable','string','max:64'],
            'driver_license_category' => ['nullable','string','max:16'],

            'birth_date' => ['nullable','date'],

            // Eyni şirkətdə phone təkrarı olmasın istəyirsənsə:
            // 'phone' => [
            //   'required','string','regex:/^\+994\d{9}$/',
            //   Rule::unique('customers','phone')
            //     ->where(fn($q) => $q->where('company_id', $user->company_id))
            //     ->ignore($customer->id),
            // ],
        ]);

        $validated = $v->validate();

        foreach ($validated as $k => $val) {
            if (is_string($val) && trim($val) === '') $validated[$k] = null;
        }

        $customer->fill($validated);
        $customer->save();

        return redirect()->route('customers.index')->with('status', 'Müştəri yeniləndi.');
    }

    public function destroy(Request $request, Customer $customer)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $customer->delete();

        return redirect()->route('customers.index')->with('status', 'Müştəri silindi.');
    }
}
