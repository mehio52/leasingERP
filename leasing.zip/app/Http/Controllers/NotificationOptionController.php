<?php

namespace App\Http\Controllers;

use App\Models\NotificationOption;
use Illuminate\Http\Request;

class NotificationOptionController extends Controller
{
    public function __construct()
    {
        $this->middleware('perm:notify.edit|whatsapp.settings')->only(['edit','update']);
    }

    public function edit(Request $request)
    {
        $companyId = $request->user()?->company_id;
        if (!$companyId) {
            abort(403, 'Şirkət tapılmadı.');
        }
        $module = $request->user()?->company?->moduleCode() ?? 'leasing';
        $isTaxi = $module === 'taxipark';


        $option = NotificationOption::firstOrCreate(
            ['company_id' => $companyId],
            [
                'is_active' => false,
                'settings' => [],
            ]
        );

        return view('company_options.notifications.edit', compact('option', 'isTaxi'));
    }

    public function update(Request $request)
    {
        $companyId = $request->user()?->company_id;
        if (!$companyId) {
            abort(403, 'Şirkət tapılmadı.');
        }
        $module = $request->user()?->company?->moduleCode() ?? 'leasing';
        $isTaxi = $module === 'taxipark';


        $data = $request->validate([
            'is_active' => ['nullable','boolean'],
            'wp_api_url' => ['nullable','string','max:255'],
            'wp_api_key' => ['nullable','string','max:255'],
            'wp_api_secret' => ['nullable','string','max:255'],
            'sender_label' => ['nullable','string','max:120'],
            'template_due_soon' => ['nullable','string'],
            'template_overdue' => ['nullable','string'],
            'template_penalty_applied' => ['nullable','string'],
            'schedule_interval_minutes' => ['nullable','integer','min:5'],
            'schedule_time_ranges' => ['nullable','string'],
            'geofence_admin_panel' => ['nullable','boolean'],
            'geofence_admin_whatsapp' => ['nullable','boolean'],
            'geofence_customer_enter_whatsapp' => ['nullable','boolean'],
            'geofence_customer_reminder_whatsapp' => ['nullable','boolean'],
            'geofence_customer_reminder_interval_minutes' => ['nullable','integer','min:5'],
            'geofence_template_admin_exit' => ['nullable','string','max:2000'],
            'geofence_template_customer_enter' => ['nullable','string','max:2000'],
            'geofence_template_customer_reminder' => ['nullable','string','max:2000'],
            'authorization_admin_panel' => ['nullable','boolean'],
            'authorization_admin_whatsapp' => ['nullable','boolean'],
            'authorization_days_before' => ['nullable','integer','min:1','max:365'],
            'authorization_template_admin_expire' => ['nullable','string','max:2000'],
            'taxi_payroll_admin_panel' => ['nullable','boolean'],
            'taxi_payroll_admin_whatsapp' => ['nullable','boolean'],
            'taxi_payroll_days_before' => ['nullable','integer','min:0','max:60'],
            'taxi_payroll_template_admin' => ['nullable','string','max:2000'],
            'taxi_assignment_admin_panel' => ['nullable','boolean'],
            'taxi_assignment_admin_whatsapp' => ['nullable','boolean'],
            'taxi_assignment_template_admin' => ['nullable','string','max:2000'],
            'taxi_service_admin_panel' => ['nullable','boolean'],
            'taxi_service_admin_whatsapp' => ['nullable','boolean'],
            'taxi_service_days_before' => ['nullable','integer','min:0','max:365'],
            'taxi_service_template_admin' => ['nullable','string','max:2000'],
        ]);

        $option = NotificationOption::firstOrCreate(
            ['company_id' => $companyId],
            ['is_active' => false, 'settings' => []]
        );

        $option->fill($data);
        $option->is_active = $request->boolean('is_active');

        $settings = $option->settings ?? [];
        $existing = $settings['schedule'] ?? [];
        $schedule = [
            'interval_minutes' => $existing['interval_minutes'] ?? 60,
            'allowed_time_ranges' => $existing['allowed_time_ranges'] ?? [],
            'last_sent_at' => $existing['last_sent_at'] ?? null,
        ];

        if ($request->has('schedule_interval_minutes')) {
            $intervalValue = (int) ($request->input('schedule_interval_minutes') ?: 60);
            $schedule['interval_minutes'] = max(5, $intervalValue);
        }

        if ($request->has('schedule_time_ranges')) {
            $schedule['allowed_time_ranges'] = $this->parseTimeRanges($request->input('schedule_time_ranges'));
        }

        $settings['schedule'] = $schedule;

        $geofence = $settings['geofence'] ?? [];
        $geofence['admin_panel'] = $request->boolean('geofence_admin_panel');
        $geofence['admin_whatsapp'] = $request->boolean('geofence_admin_whatsapp');
        $geofence['customer_enter_whatsapp'] = $request->boolean('geofence_customer_enter_whatsapp');
        $geofence['customer_reminder_whatsapp'] = $request->boolean('geofence_customer_reminder_whatsapp');
        $geofence['customer_reminder_interval_minutes'] = max(5, (int) ($request->input('geofence_customer_reminder_interval_minutes') ?: ($geofence['customer_reminder_interval_minutes'] ?? 60)));
        $geofence['template_admin_exit'] = $request->input('geofence_template_admin_exit') ?? ($geofence['template_admin_exit'] ?? null);
        $geofence['template_customer_enter'] = $request->input('geofence_template_customer_enter') ?? ($geofence['template_customer_enter'] ?? null);
        $geofence['template_customer_reminder'] = $request->input('geofence_template_customer_reminder') ?? ($geofence['template_customer_reminder'] ?? null);
        $settings['geofence'] = $geofence;

        $authorization = $settings['authorization'] ?? [];
        $authorization['admin_panel'] = $request->boolean('authorization_admin_panel');
        $authorization['admin_whatsapp'] = $request->boolean('authorization_admin_whatsapp');
        $authorization['days_before'] = max(1, (int) ($request->input('authorization_days_before') ?: ($authorization['days_before'] ?? 7)));
        $authorization['template_admin_expire'] = $request->input('authorization_template_admin_expire') ?? ($authorization['template_admin_expire'] ?? null);
        $settings['authorization'] = $authorization;

        $taxi = $settings['taxi'] ?? [];
        $taxi['payroll_admin_panel'] = $request->boolean('taxi_payroll_admin_panel');
        $taxi['payroll_admin_whatsapp'] = $request->boolean('taxi_payroll_admin_whatsapp');
        $taxi['payroll_days_before'] = max(0, (int) ($request->input('taxi_payroll_days_before') ?? ($taxi['payroll_days_before'] ?? 0)));
        $taxi['payroll_template_admin'] = $request->input('taxi_payroll_template_admin') ?? ($taxi['payroll_template_admin'] ?? null);
        $taxi['assignment_admin_panel'] = $request->boolean('taxi_assignment_admin_panel');
        $taxi['assignment_admin_whatsapp'] = $request->boolean('taxi_assignment_admin_whatsapp');
        $taxi['assignment_template_admin'] = $request->input('taxi_assignment_template_admin') ?? ($taxi['assignment_template_admin'] ?? null);
        $taxi['service_admin_panel'] = $request->boolean('taxi_service_admin_panel');
        $taxi['service_admin_whatsapp'] = $request->boolean('taxi_service_admin_whatsapp');
        $taxi['service_days_before'] = max(0, (int) ($request->input('taxi_service_days_before') ?? ($taxi['service_days_before'] ?? 0)));
        $taxi['service_template_admin'] = $request->input('taxi_service_template_admin') ?? ($taxi['service_template_admin'] ?? null);
        $settings['taxi'] = $taxi;

        if ($isTaxi) {
            $option->template_due_soon = null;
            $option->template_overdue = null;
            $option->template_penalty_applied = null;
            $settings['schedule'] = $settings['schedule'] ?? [];
            $settings['schedule']['allowed_time_ranges'] = [];
            $settings['schedule']['interval_minutes'] = 60;
        }

        $option->settings = $settings;
        $option->save();

        return redirect()->route('company.notifications.edit')->with('status', 'Bildiriş ayarları yeniləndi.');
    }

    private function parseTimeRanges(?string $value): array
    {
        if (!$value) {
            return [];
        }

        $parts = preg_split('/[,\r\n]+/', $value);
        return array_values(array_filter(array_map('trim', $parts)));
    }
}
