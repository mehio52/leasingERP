<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\EpointTransaction;
use App\Services\CompanyGatewayConfig;
use App\Services\GatewayTransactionService;
use App\Services\StripeService;
use Illuminate\Http\Request;

class StripeController extends Controller
{
    public function webhook(Request $request, StripeService $stripe, GatewayTransactionService $transactions)
    {
        $payload = $request->getContent();
        $signature = (string) $request->header('Stripe-Signature', '');

        $event = json_decode($payload, true);
        if (!is_array($event)) {
            return response('invalid', 400);
        }

        $session = $event['data']['object'] ?? [];
        if (!is_array($session)) {
            return response('invalid', 400);
        }

        $orderId = (string) ($session['client_reference_id'] ?? ($session['metadata']['order_id'] ?? ''));
        if ($orderId === '') {
            return response('missing', 400);
        }

        $tx = EpointTransaction::query()->where('order_id', $orderId)->first();
        if (!$tx) {
            return response('not_found', 404);
        }

        $company = Company::find($tx->company_id);
        if ($company) {
            $gatewayConfig = app(CompanyGatewayConfig::class);
            $stripe = $stripe->withConfig($gatewayConfig->providerConfig('stripe', $company));
        }

        if (!$stripe->verifySignature($payload, $signature)) {
            return response('invalid', 400);
        }

        $type = (string) ($event['type'] ?? '');
        if (!in_array($type, [
            'checkout.session.completed',
            'checkout.session.async_payment_failed',
            'checkout.session.expired',
        ], true)) {
            return response('ok', 200);
        }

        $tx->gateway = 'stripe';
        $tx->gateway_transaction = $session['payment_intent'] ?? $session['id'] ?? $tx->gateway_transaction;
        $tx->payload = $event;
        $tx->processed_at = now();

        $isPaid = ($session['payment_status'] ?? '') === 'paid';
        if ($type === 'checkout.session.completed' && $isPaid) {
            if ($tx->status !== EpointTransaction::STATUS_SUCCESS) {
                $tx->status = EpointTransaction::STATUS_SUCCESS;
                $tx->save();

                try {
                    $transactions->applySuccess($tx, $session);
                } catch (\Throwable $e) {
                    $meta = is_array($tx->meta) ? $tx->meta : [];
                    $meta['processing_error'] = $e->getMessage();
                    $tx->meta = $meta;
                    $tx->save();
                }
            } else {
                $tx->save();
            }

            return response('ok', 200);
        }

        if ($tx->status !== EpointTransaction::STATUS_SUCCESS) {
            $tx->status = EpointTransaction::STATUS_FAILED;
        }
        $tx->save();

        return response('ok', 200);
    }
}
