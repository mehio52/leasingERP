<?php

namespace App\Http\Controllers;

use App\Models\RiskFactorDefinition;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class RiskFactorDefinitionController extends Controller
{
    public function index(Request $request)
    {
        $companyId = $request->user()?->company_id;
        if (!$companyId) {
            abort(403, 'Company not set for user.');
        }

        $items = RiskFactorDefinition::query()
            ->where('company_id', $companyId)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        return view('company_options.risk_factors.index', compact('items'));
    }

    public function create(Request $request)
    {
        $companyId = $request->user()?->company_id;
        if (!$companyId) {
            abort(403, 'Company not set for user.');
        }

        return view('company_options.risk_factors.create', [
            'item' => new RiskFactorDefinition([
                'is_active' => true,
                'sort_order' => 0,
            ]),
            'mode' => 'create',
        ]);
    }

    public function store(Request $request)
    {
        $companyId = $request->user()?->company_id;
        if (!$companyId) {
            abort(403, 'Company not set for user.');
        }

        $data = $this->validateData($request, $companyId);
        $data['company_id'] = $companyId;

        RiskFactorDefinition::create($data);

        return redirect()->route('company_options.risk_factors.index')
            ->with('status', 'Faktor yaradıldı.');
    }

    public function edit(Request $request, RiskFactorDefinition $riskFactor)
    {
        $companyId = $request->user()?->company_id;
        if ($riskFactor->company_id !== $companyId) {
            abort(403);
        }

        return view('company_options.risk_factors.create', [
            'item' => $riskFactor,
            'mode' => 'edit',
        ]);
    }

    public function update(Request $request, RiskFactorDefinition $riskFactor)
    {
        $companyId = $request->user()?->company_id;
        if ($riskFactor->company_id !== $companyId) {
            abort(403);
        }

        $data = $this->validateData($request, $companyId, $riskFactor->id);
        $riskFactor->update($data);

        return redirect()->route('company_options.risk_factors.index')
            ->with('status', 'Faktor yeniləndi.');
    }

    public function toggle(Request $request, RiskFactorDefinition $riskFactor)
    {
        $companyId = $request->user()?->company_id;
        if ($riskFactor->company_id !== $companyId) {
            abort(403);
        }

        $riskFactor->is_active = !$riskFactor->is_active;
        $riskFactor->save();

        return redirect()->route('company_options.risk_factors.index')
            ->with('status', 'Aktivlik dəyişdirildi.');
    }

    public function destroy(Request $request, RiskFactorDefinition $riskFactor)
    {
        $companyId = $request->user()?->company_id;
        if ($riskFactor->company_id !== $companyId) {
            abort(403);
        }

        $riskFactor->delete();

        return redirect()->route('company_options.risk_factors.index')
            ->with('status', 'Faktor silindi.');
    }

    protected function validateData(Request $request, int $companyId, ?int $ignoreId = null): array
    {
        $uniqueRule = Rule::unique('risk_factor_definitions', 'key')
            ->where('company_id', $companyId);
        if ($ignoreId) {
            $uniqueRule->ignore($ignoreId);
        }

        $validated = $request->validate([
            'key' => ['required','string','max:64', $uniqueRule],
            'label' => ['required','string','max:120'],
            'type' => ['required','in:number,boolean,select,text'],
            'method' => ['required','in:bands,linear,boolean,select_map'],
            'sort_order' => ['nullable','integer'],
            'is_active' => ['nullable','boolean'],
            'bands' => ['nullable','array'],
            'bands.*.op' => ['nullable','in:lte,lt,gte,gt,eq'],
            'bands.*.value' => ['nullable','numeric'],
            'bands.*.points' => ['nullable','numeric'],
            'linear_unit' => ['nullable','numeric'],
            'linear_points_per_unit' => ['nullable','numeric'],
            'linear_max_points' => ['nullable','numeric'],
            'boolean_true_points' => ['nullable','numeric'],
            'boolean_false_points' => ['nullable','numeric'],
            'select_options' => ['nullable','array'],
            'select_options.*.value' => ['nullable','string','max:120'],
            'select_options.*.label' => ['nullable','string','max:120'],
            'select_map' => ['nullable','array'],
            'select_map.*.value' => ['nullable','string','max:120'],
            'select_map.*.label' => ['nullable','string','max:120'],
            'select_map.*.points' => ['nullable','numeric'],
        ]);

        $validated['sort_order'] = $validated['sort_order'] ?? 0;
        $validated['is_active'] = $request->boolean('is_active');

        $options = [];
        foreach ($request->input('select_options', []) as $row) {
            $v = trim((string)($row['value'] ?? ''));
            if ($v === '') continue;
            $options[] = [
                'value' => $v,
                'label' => trim((string)($row['label'] ?? $v)),
            ];
        }

        $config = ['method' => $validated['method']];
        if ($validated['method'] === 'bands') {
            $penalties = [];
            foreach ($request->input('bands', []) as $row) {
                $op = $row['op'] ?? null;
                $val = $row['value'] ?? null;
                $pts = $row['points'] ?? null;
                if (!$op || $val === null || $pts === null) continue;
                $penRow = [$op => (float)$val, 'points' => (float)$pts];
                $penalties[] = $penRow;
            }
            $config['penalties'] = $penalties;
        } elseif ($validated['method'] === 'linear') {
            $config['unit'] = (float)($request->input('linear_unit', 0));
            $config['points_per_unit'] = (float)($request->input('linear_points_per_unit', 0));
            $max = $request->input('linear_max_points');
            if ($max !== null && $max !== '') {
                $config['max_points'] = (float)$max;
            }
        } elseif ($validated['method'] === 'boolean') {
            $config['true_points'] = (float)($request->input('boolean_true_points', 0));
            $falsePts = $request->input('boolean_false_points');
            if ($falsePts !== null && $falsePts !== '') {
                $config['false_points'] = (float)$falsePts;
            }
        } elseif ($validated['method'] === 'select_map') {
            $map = [];
            foreach ($request->input('select_map', []) as $row) {
                $v = trim((string)($row['value'] ?? ''));
                if ($v === '') continue;
                $map[$v] = (float)($row['points'] ?? 0);
            }
            $config['map'] = $map;
        }

        $validated['options'] = $options ?: null;
        $validated['config'] = $config ?: null;

        return $validated;
    }
}
