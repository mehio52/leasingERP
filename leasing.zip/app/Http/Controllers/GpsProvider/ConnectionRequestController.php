<?php

namespace App\Http\Controllers\GpsProvider;

use App\Http\Controllers\Controller;
use App\Models\CompanyGpsConnection;
use Illuminate\Http\Request;

class ConnectionRequestController extends Controller
{
    public function index(Request $request)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        $status = trim((string) $request->query('status', 'pending'));
        $allowed = ['pending', 'approved', 'rejected', 'all'];
        if (!in_array($status, $allowed, true)) {
            $status = 'pending';
        }

        $query = CompanyGpsConnection::query()
            ->with(['company', 'requester', 'approver'])
            ->where('gps_provider_id', $provider->id)
            ->orderByDesc('requested_at');

        if ($status !== 'all') {
            $query->where('status', $status);
        }

        $connections = $query->paginate(20)->withQueryString();

        return view('gps_provider.requests.index', compact('provider', 'connections', 'status'));
    }

    public function approve(Request $request, CompanyGpsConnection $connection)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider || (int) $connection->gps_provider_id !== (int) $provider->id) {
            abort(403);
        }

        $connection->status = 'approved';
        $connection->approved_by = $request->user()?->id;
        $connection->approved_at = now();
        $connection->rejected_at = null;
        $connection->save();

        return redirect()
            ->route('gps_provider.requests.index', ['status' => 'pending'])
            ->with('status', 'Şirkət təsdiqləndi.');
    }

    public function reject(Request $request, CompanyGpsConnection $connection)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider || (int) $connection->gps_provider_id !== (int) $provider->id) {
            abort(403);
        }

        $connection->status = 'rejected';
        $connection->approved_by = $request->user()?->id;
        $connection->approved_at = null;
        $connection->rejected_at = now();
        $connection->save();

        return redirect()
            ->route('gps_provider.requests.index', ['status' => 'pending'])
            ->with('status', 'Sorğu rədd edildi.');
    }
}
