<?php

namespace App\Http\Controllers\GpsProvider;

use App\Http\Controllers\Controller;
use App\Models\GpsVehicleRequest;
use App\Services\Gps\GpsManager;
use Illuminate\Http\Request;

class VehicleRequestController extends Controller
{
    public function index(Request $request, GpsManager $gpsManager)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) abort(403);

        $status = trim((string) $request->query('status', 'pending'));
        $allowed = ['pending', 'approved', 'rejected', 'all'];
        if (!in_array($status, $allowed, true)) {
            $status = 'pending';
        }

        $query = GpsVehicleRequest::query()
            ->with(['company', 'vehicle'])
            ->where('gps_provider_id', $provider->id)
            ->orderByDesc('requested_at');

        if ($status !== 'all') {
            $query->where('status', $status);
        }

        $requests = $query->paginate(20)->withQueryString();

        $hwTypes = [];
        $wialon = $gpsManager->wialonForProvider($provider);
        if ($wialon->isConfigured()) {
            $hwTypes = $wialon->getHardwareTypes();
        }

        return view('gps_provider.vehicle_requests.index', compact('provider', 'requests', 'status', 'hwTypes'));
    }

    public function approve(Request $request, GpsManager $gpsManager, GpsVehicleRequest $vehicleRequest)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider || (int) $vehicleRequest->gps_provider_id !== (int) $provider->id) {
            abort(403);
        }

        $data = $request->validate([
            'hw_type_id' => ['required','integer','min:1'],
        ]);

        $vehicle = $vehicleRequest->vehicle;
        if (!$vehicle) {
            return back()->withErrors(['vehicle' => 'Vehicle not found.']);
        }

        $settings = is_array($provider->settings) ? $provider->settings : [];
        $limits = is_array($settings['limits'] ?? null) ? $settings['limits'] : [];
        $maxUnits = isset($limits['max_units']) ? (int) $limits['max_units'] : null;
        if ($maxUnits && $maxUnits > 0) {
            $companyIds = $provider->connections()
                ->where('status', 'approved')
                ->pluck('company_id')
                ->unique()
                ->values();

            $count = \App\Models\Vehicle::query()
                ->whereIn('company_id', $companyIds)
                ->whereNotNull('wialon_device_id')
                ->count();

            if ($count >= $maxUnits) {
                return back()->withErrors(['hw_type_id' => 'Max unit limit reached.']);
            }
        }

        $wialon = $gpsManager->wialonForProvider($provider);
        if (!$wialon->isConfigured()) {
            return back()->withErrors(['hw_type_id' => 'Wialon config is missing.']);
        }

        $uniqueId = trim((string) $vehicleRequest->unique_id);
        if ($uniqueId === '') {
            return back()->withErrors(['unique_id' => 'Unique ID is required.']);
        }

        $name = $vehicleRequest->unit_name ?: ($vehicle->plate_number . ' ' . $vehicle->display_name);
        $name = trim($name) ?: ('Vehicle #' . $vehicle->id);

        $created = $wialon->createUnit($name, $uniqueId, (int) $data['hw_type_id']);
        $unitId = $created['item']['id'] ?? $created['id'] ?? null;
        if (!$unitId) {
            return back()->withErrors(['hw_type_id' => 'Unit create failed.']);
        }

        $vehicle->wialon_device_id = (string) $unitId;
        $vehicle->save();

        $vehicleRequest->status = 'approved';
        $vehicleRequest->hw_type_id = (int) $data['hw_type_id'];
        $vehicleRequest->approved_by = $request->user()?->id;
        $vehicleRequest->approved_at = now();
        $vehicleRequest->rejected_at = null;
        $vehicleRequest->save();

        return redirect()
            ->route('gps_provider.vehicle_requests.index', ['status' => 'pending'])
            ->with('status', 'Unit created and approved.');
    }

    public function reject(Request $request, GpsManager $gpsManager, GpsVehicleRequest $vehicleRequest)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider || (int) $vehicleRequest->gps_provider_id !== (int) $provider->id) {
            abort(403);
        }

        $vehicleRequest->status = 'rejected';
        $vehicleRequest->approved_by = $request->user()?->id;
        $vehicleRequest->approved_at = null;
        $vehicleRequest->rejected_at = now();
        $vehicleRequest->save();

        return redirect()
            ->route('gps_provider.vehicle_requests.index', ['status' => 'pending'])
            ->with('status', 'Request rejected.');
    }
}
