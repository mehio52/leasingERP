<?php

namespace App\Http\Controllers\GpsProvider;

use App\Http\Controllers\Controller;
use App\Models\CompanyGpsConnection;
use App\Models\GpsVehicleRequest;
use Carbon\Carbon;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class PortalController extends Controller
{
    public function dashboard(Request $request)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        [$fromStart, $toEnd, $fromDate, $toDate] = $this->resolveDateRange($request);

        $metrics = $this->buildDashboardMetrics($provider->id, $fromStart, $toEnd);

        $recentConnections = CompanyGpsConnection::query()
            ->with(['company', 'requester'])
            ->where('gps_provider_id', $provider->id)
            ->orderByDesc('requested_at')
            ->limit(8)
            ->get();

        $recentVehicleRequests = GpsVehicleRequest::query()
            ->with(['company', 'vehicle'])
            ->where('gps_provider_id', $provider->id)
            ->orderByDesc('requested_at')
            ->limit(8)
            ->get();

        return view('gps_provider.dashboard', [
            'provider' => $provider,
            'fromDate' => $fromDate,
            'toDate' => $toDate,
            'metrics' => $metrics,
            'recentConnections' => $recentConnections,
            'recentVehicleRequests' => $recentVehicleRequests,
        ]);
    }

    public function exportCsv(Request $request): StreamedResponse
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        [$fromStart, $toEnd, $fromDate, $toDate] = $this->resolveDateRange($request);
        $metrics = $this->buildDashboardMetrics($provider->id, $fromStart, $toEnd);

        $filename = 'provider_dashboard_' . $fromDate . '_' . $toDate . '.csv';
        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function () use ($provider, $fromDate, $toDate, $metrics) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Provider', $provider->name]);
            fputcsv($out, ['Date range', $fromDate . ' to ' . $toDate]);
            fputcsv($out, []);

            fputcsv($out, ['Connections summary']);
            fputcsv($out, ['pending', $metrics['connections']['pending']]);
            fputcsv($out, ['approved', $metrics['connections']['approved']]);
            fputcsv($out, ['rejected', $metrics['connections']['rejected']]);
            fputcsv($out, ['avg approval hours', $metrics['connections']['avg_approval_hours']]);
            fputcsv($out, []);

            fputcsv($out, ['Vehicle requests summary']);
            fputcsv($out, ['pending', $metrics['vehicle_requests']['pending']]);
            fputcsv($out, ['approved', $metrics['vehicle_requests']['approved']]);
            fputcsv($out, ['rejected', $metrics['vehicle_requests']['rejected']]);
            fputcsv($out, ['avg approval hours', $metrics['vehicle_requests']['avg_approval_hours']]);
            fputcsv($out, []);

            fputcsv($out, ['Daily connections']);
            fputcsv($out, ['date', 'total', 'approved', 'rejected']);
            foreach ($metrics['daily_connections'] as $row) {
                fputcsv($out, [$row['date'], $row['total'], $row['approved'], $row['rejected']]);
            }
            fputcsv($out, []);

            fputcsv($out, ['Daily vehicle requests']);
            fputcsv($out, ['date', 'total', 'approved', 'rejected']);
            foreach ($metrics['daily_vehicle_requests'] as $row) {
                fputcsv($out, [$row['date'], $row['total'], $row['approved'], $row['rejected']]);
            }
            fputcsv($out, []);

            fputcsv($out, ['Top companies (connections)']);
            fputcsv($out, ['company', 'requests']);
            foreach ($metrics['top_connections'] as $row) {
                fputcsv($out, [$row['name'], $row['total']]);
            }
            fputcsv($out, []);

            fputcsv($out, ['Top companies (vehicle requests)']);
            fputcsv($out, ['company', 'requests']);
            foreach ($metrics['top_vehicle_requests'] as $row) {
                fputcsv($out, [$row['name'], $row['total']]);
            }
            fputcsv($out, []);

            fputcsv($out, ['Pending SLA']);
            fputcsv($out, ['connections > 24h', $metrics['sla']['connections_over_24h']]);
            fputcsv($out, ['connections > 72h', $metrics['sla']['connections_over_72h']]);
            fputcsv($out, ['vehicle requests > 24h', $metrics['sla']['vehicles_over_24h']]);
            fputcsv($out, ['vehicle requests > 72h', $metrics['sla']['vehicles_over_72h']]);

            fclose($out);
        };

        return response()->stream($callback, 200, $headers);
    }

    public function exportPdf(Request $request): Response
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        [$fromStart, $toEnd, $fromDate, $toDate] = $this->resolveDateRange($request);
        $metrics = $this->buildDashboardMetrics($provider->id, $fromStart, $toEnd);

        return response()->view('gps_provider.dashboard_pdf', [
            'provider' => $provider,
            'fromDate' => $fromDate,
            'toDate' => $toDate,
            'metrics' => $metrics,
        ]);
    }

    private function resolveDateRange(Request $request): array
    {
        $from = trim((string) $request->query('from', ''));
        $to = trim((string) $request->query('to', ''));

        $toDate = $to !== '' ? Carbon::parse($to) : Carbon::today();
        $fromDate = $from !== '' ? Carbon::parse($from) : $toDate->copy()->subDays(29);

        $fromStart = $fromDate->copy()->startOfDay();
        $toEnd = $toDate->copy()->endOfDay();

        return [$fromStart, $toEnd, $fromStart->toDateString(), $toEnd->toDateString()];
    }

    private function buildDashboardMetrics(int $providerId, Carbon $fromStart, Carbon $toEnd): array
    {
        $connectionBase = CompanyGpsConnection::query()
            ->where('gps_provider_id', $providerId)
            ->whereBetween('requested_at', [$fromStart, $toEnd]);

        $vehicleBase = GpsVehicleRequest::query()
            ->where('gps_provider_id', $providerId)
            ->whereBetween('requested_at', [$fromStart, $toEnd]);

        $connectionCounts = (clone $connectionBase)
            ->selectRaw("SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending")
            ->selectRaw("SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved")
            ->selectRaw("SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected")
            ->first();

        $vehicleCounts = (clone $vehicleBase)
            ->selectRaw("SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending")
            ->selectRaw("SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved")
            ->selectRaw("SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected")
            ->first();

        $connectionAvgMinutes = (clone $connectionBase)
            ->where('status', 'approved')
            ->whereNotNull('approved_at')
            ->avg(DB::raw('TIMESTAMPDIFF(MINUTE, requested_at, approved_at)'));

        $vehicleAvgMinutes = (clone $vehicleBase)
            ->where('status', 'approved')
            ->whereNotNull('approved_at')
            ->avg(DB::raw('TIMESTAMPDIFF(MINUTE, requested_at, approved_at)'));

        $dailyConnections = (clone $connectionBase)
            ->selectRaw("DATE(requested_at) AS day")
            ->selectRaw('COUNT(*) AS total')
            ->selectRaw("SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved")
            ->selectRaw("SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected")
            ->groupBy('day')
            ->orderBy('day')
            ->get()
            ->keyBy('day');

        $dailyVehicle = (clone $vehicleBase)
            ->selectRaw("DATE(requested_at) AS day")
            ->selectRaw('COUNT(*) AS total')
            ->selectRaw("SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved")
            ->selectRaw("SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected")
            ->groupBy('day')
            ->orderBy('day')
            ->get()
            ->keyBy('day');

        $days = [];
        $cursor = $fromStart->copy();
        while ($cursor->lte($toEnd)) {
            $days[] = $cursor->toDateString();
            $cursor->addDay();
        }

        $dailyConnectionRows = [];
        $dailyVehicleRows = [];
        foreach ($days as $day) {
            $c = $dailyConnections->get($day);
            $v = $dailyVehicle->get($day);
            $dailyConnectionRows[] = [
                'date' => $day,
                'total' => (int) ($c->total ?? 0),
                'approved' => (int) ($c->approved ?? 0),
                'rejected' => (int) ($c->rejected ?? 0),
            ];
            $dailyVehicleRows[] = [
                'date' => $day,
                'total' => (int) ($v->total ?? 0),
                'approved' => (int) ($v->approved ?? 0),
                'rejected' => (int) ($v->rejected ?? 0),
            ];
        }

        $topConnections = CompanyGpsConnection::query()
            ->selectRaw('company_id, COUNT(*) AS total')
            ->where('gps_provider_id', $providerId)
            ->whereBetween('requested_at', [$fromStart, $toEnd])
            ->groupBy('company_id')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        $topConnections->load('company:id,name');

        $topVehicle = GpsVehicleRequest::query()
            ->selectRaw('company_id, COUNT(*) AS total')
            ->where('gps_provider_id', $providerId)
            ->whereBetween('requested_at', [$fromStart, $toEnd])
            ->groupBy('company_id')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        $topVehicle->load('company:id,name');

        $now = now();
        $slaConnections = CompanyGpsConnection::query()
            ->where('gps_provider_id', $providerId)
            ->where('status', 'pending');

        $slaVehicles = GpsVehicleRequest::query()
            ->where('gps_provider_id', $providerId)
            ->where('status', 'pending');

        return [
            'connections' => [
                'pending' => (int) ($connectionCounts->pending ?? 0),
                'approved' => (int) ($connectionCounts->approved ?? 0),
                'rejected' => (int) ($connectionCounts->rejected ?? 0),
                'avg_approval_hours' => $connectionAvgMinutes ? round($connectionAvgMinutes / 60, 1) : 0,
            ],
            'vehicle_requests' => [
                'pending' => (int) ($vehicleCounts->pending ?? 0),
                'approved' => (int) ($vehicleCounts->approved ?? 0),
                'rejected' => (int) ($vehicleCounts->rejected ?? 0),
                'avg_approval_hours' => $vehicleAvgMinutes ? round($vehicleAvgMinutes / 60, 1) : 0,
            ],
            'daily_connections' => $dailyConnectionRows,
            'daily_vehicle_requests' => $dailyVehicleRows,
            'top_connections' => $topConnections->map(fn($row) => [
                'name' => $row->company?->name ?? ('#' . $row->company_id),
                'total' => (int) $row->total,
            ])->all(),
            'top_vehicle_requests' => $topVehicle->map(fn($row) => [
                'name' => $row->company?->name ?? ('#' . $row->company_id),
                'total' => (int) $row->total,
            ])->all(),
            'sla' => [
                'connections_over_24h' => (clone $slaConnections)->where('requested_at', '<=', $now->copy()->subHours(24))->count(),
                'connections_over_72h' => (clone $slaConnections)->where('requested_at', '<=', $now->copy()->subHours(72))->count(),
                'vehicles_over_24h' => (clone $slaVehicles)->where('requested_at', '<=', $now->copy()->subHours(24))->count(),
                'vehicles_over_72h' => (clone $slaVehicles)->where('requested_at', '<=', $now->copy()->subHours(72))->count(),
            ],
        ];
    }
}
