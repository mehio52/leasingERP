<?php

namespace App\Http\Controllers\GpsProvider;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    private function providerId(): int
    {
        return (int) Auth::user()?->gps_provider_id;
    }

    private function assertSameProvider(User $user): void
    {
        if ((int) $user->gps_provider_id !== $this->providerId()) {
            abort(404);
        }
    }

    private function permissionGroups(): array
    {
        return [
            'Requests' => [
                'gps_provider.requests.view' => 'View requests',
                'gps_provider.requests.approve' => 'Approve/reject requests',
            ],
            'Vehicle Requests' => [
                'gps_provider.vehicle_requests.view' => 'Vehicle requests view',
                'gps_provider.vehicle_requests.manage' => 'Vehicle requests manage',
            ],
            'Companies' => [
                'gps_provider.companies.view' => 'Connected companies view',
                'gps_provider.companies.manage' => 'Connected companies manage',
            ],
            'Vehicles' => [
                'gps_provider.vehicles.view' => 'Provider vehicles view',
            ],
            'Settings' => [
                'gps_provider.settings.edit' => 'Provider settings edit',
            ],
            'Users' => [
                'gps_provider.users.manage' => 'Provider users manage',
            ],
        ];
    }

    private function allowedPermissions(): array
    {
        $all = [];
        foreach ($this->permissionGroups() as $group) {
            $all = array_merge($all, array_keys($group));
        }
        return $all;
    }

    public function index()
    {
        $users = User::query()
            ->where('gps_provider_id', $this->providerId())
            ->orderByDesc('id')
            ->paginate(20);

        return view('gps_provider.users.index', compact('users'));
    }

    public function create()
    {
        $permissionGroups = $this->permissionGroups();
        return view('gps_provider.users.create', compact('permissionGroups'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'first_name' => ['required','string','max:255'],
            'last_name'  => ['required','string','max:255'],
            'phone'      => ['required','string','max:32','regex:/^\+994\d{9}$/', Rule::unique('users','phone')],
            'email'      => ['nullable','email','max:255', Rule::unique('users','email')],
            'password'   => ['required','string','min:8','confirmed'],
            'role'       => ['required','in:gps_provider_admin,gps_provider_staff'],
            'is_active'  => ['nullable','boolean'],
            'permissions'   => ['nullable','array'],
            'permissions.*' => ['string', Rule::in($this->allowedPermissions())],
        ]);

        $data['company_id'] = null;
        $data['gps_provider_id'] = $this->providerId();
        $data['created_by'] = Auth::id();
        $data['is_owner'] = false;
        $data['is_active'] = (bool) ($data['is_active'] ?? true);
        $data['permissions'] = array_values(array_unique($data['permissions'] ?? []));

        User::create($data);

        return redirect()->route('gps_provider.users.index')->with('status', 'Istifadeci yaradildi.');
    }

    public function edit(User $user)
    {
        $this->assertSameProvider($user);
        $permissionGroups = $this->permissionGroups();

        return view('gps_provider.users.edit', compact('user', 'permissionGroups'));
    }

    public function update(Request $request, User $user)
    {
        $this->assertSameProvider($user);

        $data = $request->validate([
            'first_name' => ['required','string','max:255'],
            'last_name'  => ['required','string','max:255'],
            'phone'      => ['required','string','max:32','regex:/^\+994\d{9}$/', Rule::unique('users','phone')->ignore($user->id)],
            'email'      => ['nullable','email','max:255', Rule::unique('users','email')->ignore($user->id)],
            'password'   => ['nullable','string','min:8','confirmed'],
            'role'       => ['required','in:gps_provider_admin,gps_provider_staff'],
            'is_active'  => ['nullable','boolean'],
            'permissions'   => ['nullable','array'],
            'permissions.*' => ['string', Rule::in($this->allowedPermissions())],
        ]);

        $data['permissions'] = array_values(array_unique($data['permissions'] ?? []));
        $data['is_active'] = (bool) ($data['is_active'] ?? true);

        $user->fill($data);
        $user->save();

        return redirect()->route('gps_provider.users.edit', $user)->with('status', 'Yadda saxlanildi.');
    }

    public function destroy(User $user)
    {
        $this->assertSameProvider($user);
        if ($user->id === Auth::id()) {
            return back()->withErrors(['user' => 'Oz hesabinizi sile bilmirsiniz.']);
        }

        $user->delete();

        return redirect()->route('gps_provider.users.index')->with('status', 'Silindi.');
    }
}
