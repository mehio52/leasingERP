<?php

namespace App\Http\Controllers\GpsProvider;

use App\Http\Controllers\Controller;
use App\Services\Gps\GpsManager;
use Illuminate\Http\Request;

class ProviderVehicleController extends Controller
{
    public function index(Request $request, GpsManager $gpsManager)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        $settings = is_array($provider->settings) ? $provider->settings : [];
        $activePlatform = $settings['active_platform'] ?? 'traccar';
        $units = [];
        $positions = [];
        $error = null;

        if ($activePlatform !== 'wialon') {
            $error = ___('Active platform is not Wialon.');
        } else {
            $wialon = $gpsManager->wialonForProvider($provider);
            if (!$wialon->isConfigured()) {
                $error = ___('Wialon config is missing.');
            } else {
                $units = $wialon->searchUnits(1);
                foreach ($units as $unit) {
                    $unitId = (int) ($unit['id'] ?? 0);
                    if ($unitId <= 0) continue;
                    $pos = $wialon->getLastPosition((string) $unitId);
                    if ($pos) {
                        $positions[$unitId] = $pos;
                    }
                }
            }
        }

        return view('gps_provider.vehicles.index', compact('provider', 'units', 'positions', 'error'));
    }
}
