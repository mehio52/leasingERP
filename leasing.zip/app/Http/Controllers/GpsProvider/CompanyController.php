<?php

namespace App\Http\Controllers\GpsProvider;

use App\Http\Controllers\Controller;
use App\Models\CompanyGpsConnection;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    public function index(Request $request)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        $connections = CompanyGpsConnection::query()
            ->with(['company'])
            ->where('gps_provider_id', $provider->id)
            ->where('status', 'approved')
            ->orderByDesc('id')
            ->paginate(20);

        return view('gps_provider.companies.index', compact('provider', 'connections'));
    }

    public function edit(Request $request, CompanyGpsConnection $connection)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider || (int) $connection->gps_provider_id !== (int) $provider->id) {
            abort(403);
        }

        $providerSettings = is_array($provider->settings) ? $provider->settings : [];
        $mode = $providerSettings['gps_data_mode'] ?? 'by_user';
        $settings = is_array($connection->settings) ? $connection->settings : [];

        return view('gps_provider.companies.edit', compact('provider', 'connection', 'mode', 'settings'));
    }

    public function update(Request $request, CompanyGpsConnection $connection)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider || (int) $connection->gps_provider_id !== (int) $provider->id) {
            abort(403);
        }

        $providerSettings = is_array($provider->settings) ? $provider->settings : [];
        $mode = $providerSettings['gps_data_mode'] ?? 'by_user';

        $rules = [
            'wialon_user' => ['nullable','string','max:120'],
            'wialon_account_id' => ['nullable','string','max:120'],
            'wialon_unit_group_ids' => ['nullable','string','max:500'],
        ];

        $data = $request->validate($rules);

        $settings = [];
        if ($mode === 'by_unit_group') {
            $raw = trim((string) ($data['wialon_unit_group_ids'] ?? ''));
            $list = $raw === '' ? [] : preg_split('/\s*,\s*/', $raw, -1, PREG_SPLIT_NO_EMPTY);
            $settings['wialon_unit_group_ids'] = array_values(array_unique(array_map('intval', $list)));
        } elseif ($mode === 'by_account') {
            $settings['wialon_account_id'] = trim((string) ($data['wialon_account_id'] ?? ''));
        } else {
            $settings['wialon_user'] = trim((string) ($data['wialon_user'] ?? ''));
        }

        $connection->settings = $settings;
        $connection->save();

        return redirect()
            ->route('gps_provider.companies.edit', $connection)
            ->with('status', 'Yadda saxlanildi.');
    }
}
