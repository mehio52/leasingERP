<?php

namespace App\Http\Controllers\GpsProvider;

use App\Http\Controllers\Controller;
use App\Services\WialonService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SettingsController extends Controller
{
    public function edit(Request $request)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        $settings = is_array($provider->settings) ? $provider->settings : [];
        $platforms = $settings['platforms'] ?? ['traccar'];
        $activePlatform = $settings['active_platform'] ?? 'traccar';
        $gpsDataMode = $settings['gps_data_mode'] ?? 'by_user';
        $commandOptions = [];

        $wialonConfig = is_array($settings['wialon'] ?? null) ? $settings['wialon'] : [];
        $wialon = app(WialonService::class)->withConfig([
            'base_url' => $wialonConfig['base_url'] ?? null,
            'token' => $wialonConfig['token'] ?? null,
            'username' => $wialonConfig['username'] ?? null,
            'password' => $wialonConfig['password'] ?? null,
        ], 'provider-' . $provider->id);

        if ($wialon->isConfigured()) {
            $units = $wialon->searchUnits(1);
            $types = [];
            foreach ($units as $unit) {
                $unitId = (int) ($unit['id'] ?? 0);
                if ($unitId <= 0) continue;
                $list = $wialon->listCommandTypes((string) $unitId);
                foreach ($list as $item) {
                    if (is_string($item)) {
                        $types[$item] = $item;
                        continue;
                    }
                    if (!is_array($item)) continue;
                    $type = $item['type'] ?? $item['name'] ?? null;
                    if (!$type) continue;
                    $label = $item['label'] ?? $type;
                    $types[$type] = $label;
                }
            }

            if (!empty($types)) {
                ksort($types);
                foreach ($types as $type => $label) {
                    $commandOptions[] = ['value' => $type, 'label' => $label];
                }
            }
        }

        return view('gps_provider.settings.edit', compact('provider', 'settings', 'platforms', 'activePlatform', 'gpsDataMode', 'commandOptions'));
    }

    public function update(Request $request)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        $data = $request->validate([
            'name' => ['required','string','max:120'],
            'logo' => ['nullable','image','max:2048'],
            'remove_logo' => ['nullable','boolean'],
            'platforms' => ['required','array','min:1'],
            'platforms.*' => ['in:traccar,wialon'],
            'active_platform' => ['required','in:traccar,wialon'],
            'gps_data_mode' => ['nullable','in:by_user,by_unit_group,by_account'],
            'features' => ['nullable','array'],
            'features.*' => ['in:live_map,history,reports,alerts,geofences,drivers,commands,export'],
            'alerts_templates' => ['nullable','array'],
            'alerts_templates.*' => ['in:speed,geofence,ignition'],
            'commands_blocklist' => ['nullable','array'],
            'commands_blocklist.*' => ['string','max:64'],
            'max_units' => ['nullable','integer','min:0'],
            'max_alert_rules' => ['nullable','integer','min:0'],
            'api_poll_interval' => ['nullable','integer','min:3','max:300'],
            'rate_limit_per_min' => ['nullable','integer','min:0'],
            'policy_require_provider_approval' => ['nullable','boolean'],
            'policy_require_2fa' => ['nullable','boolean'],
            'traccar_base_url' => ['nullable','string','max:255'],
            'traccar_token' => ['nullable','string','max:255'],
            'traccar_username' => ['nullable','string','max:255'],
            'traccar_password' => ['nullable','string','max:255'],
            'wialon_base_url' => ['nullable','string','max:255'],
            'wialon_token' => ['nullable','string','max:255'],
            'wialon_username' => ['nullable','string','max:255'],
            'wialon_password' => ['nullable','string','max:255'],
        ]);

        $platforms = array_values(array_unique($data['platforms'] ?? ['traccar']));
        $activePlatform = $data['active_platform'];
        if (!in_array($activePlatform, $platforms, true)) {
            $activePlatform = $platforms[0] ?? 'traccar';
        }

        $currentSettings = is_array($provider->settings) ? $provider->settings : [];
        $logoPath = $currentSettings['logo_path'] ?? null;

        if ($request->boolean('remove_logo')) {
            if ($logoPath) {
                Storage::disk('public')->delete($logoPath);
            }
            $logoPath = null;
        }

        if ($request->hasFile('logo')) {
            if ($logoPath) {
                Storage::disk('public')->delete($logoPath);
            }
            $logoPath = $request->file('logo')->store("gps_providers/{$provider->id}", 'public');
        }

        $settings = [
            'logo_path' => $logoPath,
            'platforms' => $platforms,
            'active_platform' => $activePlatform,
            'gps_data_mode' => $data['gps_data_mode'] ?? 'by_user',
            'features' => array_values(array_unique($data['features'] ?? [])),
            'alerts_templates' => array_values(array_unique($data['alerts_templates'] ?? [])),
            'commands_blocklist' => array_values(array_unique(array_filter(array_map('trim', $data['commands_blocklist'] ?? [])))),
            'limits' => [
                'max_units' => isset($data['max_units']) ? (int) $data['max_units'] : null,
                'max_alert_rules' => isset($data['max_alert_rules']) ? (int) $data['max_alert_rules'] : null,
                'api_poll_interval' => isset($data['api_poll_interval']) ? (int) $data['api_poll_interval'] : null,
                'rate_limit_per_min' => isset($data['rate_limit_per_min']) ? (int) $data['rate_limit_per_min'] : null,
            ],
            'policy' => [
                'require_provider_approval' => $request->boolean('policy_require_provider_approval'),
                'require_2fa' => $request->boolean('policy_require_2fa'),
            ],
            'traccar' => [
                'base_url' => trim((string) ($data['traccar_base_url'] ?? '')),
                'token' => trim((string) ($data['traccar_token'] ?? '')),
                'username' => trim((string) ($data['traccar_username'] ?? '')),
                'password' => trim((string) ($data['traccar_password'] ?? '')),
            ],
            'wialon' => [
                'base_url' => trim((string) ($data['wialon_base_url'] ?? '')),
                'token' => trim((string) ($data['wialon_token'] ?? '')),
                'username' => trim((string) ($data['wialon_username'] ?? '')),
                'password' => trim((string) ($data['wialon_password'] ?? '')),
            ],
        ];

        $provider->name = $data['name'];
        $provider->settings = $settings;
        $provider->save();

        return redirect()
            ->route('gps_provider.settings.edit')
            ->with('status', 'Yadda saxlanildi.');
    }

    public function testWialon(Request $request)
    {
        $provider = $request->user()?->gpsProvider;
        if (!$provider) {
            abort(403);
        }

        $data = $request->validate([
            'wialon_base_url' => ['nullable','string','max:255'],
            'wialon_token' => ['nullable','string','max:255'],
            'wialon_username' => ['nullable','string','max:255'],
            'wialon_password' => ['nullable','string','max:255'],
        ]);

        $config = [
            'base_url' => trim((string) ($data['wialon_base_url'] ?? '')),
            'token' => trim((string) ($data['wialon_token'] ?? '')),
            'username' => trim((string) ($data['wialon_username'] ?? '')),
            'password' => trim((string) ($data['wialon_password'] ?? '')),
        ];

        $service = app(\App\Services\WialonService::class)->withConfig($config, 'provider-' . $provider->id);
        if (!$service->isConfigured()) {
            return back()->withErrors(['wialon_token' => 'Wialon token və ya login/password tələb olunur.']);
        }

        $ok = $service->testConnection();
        if (!$ok) {
            return back()->withErrors(['wialon_token' => 'Wialon bağlantısı alınmadı. Host və giriş məlumatlarını yoxlayın.']);
        }

        return back()->with('status', 'Wialon bağlantısı uğurludur.');
    }
}
