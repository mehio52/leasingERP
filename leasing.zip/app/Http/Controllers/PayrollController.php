<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\PayrollService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PayrollController extends Controller
{
    public function __construct(private PayrollService $payroll)
    {
        $this->middleware(['auth','perm:users.manage']);
    }

    public function index(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;
        $from = Carbon::parse($request->input('from', now()->startOfMonth()->toDateString()));
        $to   = Carbon::parse($request->input('to', now()->endOfMonth()->toDateString()));

        $employees = User::query()
            ->where('company_id', $companyId)
            ->where('is_owner', false)
            ->orderBy('id')
            ->get();

        $payouts = [];
        foreach ($employees as $emp) {
            $payouts[$emp->id] = $this->payroll->calculate($emp, $from, $to);
        }

        return view('company.payroll.index', compact('employees', 'payouts', 'from', 'to'));
    }
}
