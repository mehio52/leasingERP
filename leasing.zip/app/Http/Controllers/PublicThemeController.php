<?php

namespace App\Http\Controllers;

use App\Models\BhphAccount;
use App\Models\CompanyOption;
use App\Models\Contract;
use App\Models\EpointTransaction;
use App\Models\PaymentOption;
use App\Services\CompanyGatewayConfig;
use App\Services\EpointService;
use App\Services\IyzicoService;
use App\Services\PaymentGatewayService;
use App\Services\PaymentService;
use App\Services\PenaltyService;
use App\Services\StripeService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PublicThemeController extends Controller
{
    public function handle(Request $request, string $companySlug = '', string $path = '')
    {
        $company = $request->attributes->get('public_company');
        if ($company) {
            if ($companySlug === '' || $companySlug !== $company->slug) {
                $path = $companySlug !== ''
                    ? trim(($path ? $companySlug . '/' . $path : $companySlug), '/')
                    : $path;
                $companySlug = $company->slug;
            }
        }
        $domainRequest = $request->attributes->get('public_domain_request');
        $publicBase = $domainRequest ? url('/') : url($company?->slug ?? '');
        $publicUrl = function (string $path = '') use ($publicBase) {
            $base = rtrim($publicBase, '/');
            if ($path === '') {
                return $base;
            }
            if (str_starts_with($path, '#')) {
                return $base . $path;
            }
            return $base . '/' . ltrim($path, '/');
        };
        $theme = $company?->public_theme ?: config('public_theme.default', 'classic');
        $themePath = resource_path("themes/{$theme}");
        $settings = $company?->public_settings ?? [];
        $themeLocales = (array)($settings['theme_locales'] ?? ['en']);
        if (empty($themeLocales)) {
            $themeLocales = ['en'];
        }
        $themeDefaultLocale = (string)($settings['theme_default_locale'] ?? ($themeLocales[0] ?? 'en'));
        if (!in_array($themeDefaultLocale, $themeLocales, true)) {
            $themeDefaultLocale = $themeLocales[0];
        }
        $currentLocale = $request->query('lang');
        if (!$currentLocale || !in_array($currentLocale, $themeLocales, true)) {
            $currentLocale = $themeDefaultLocale;
        }
        app()->setLocale($currentLocale);

        $paymentOption = PaymentOption::query()->firstOrCreate(
            ['company_id' => $company->id],
            PaymentOption::defaults()
        );
        $gateway = app(PaymentGatewayService::class);
        $activeProvider = $gateway->activeProvider($company, $paymentOption);
        $paymentGatewayEnabled = $paymentOption->gatewayAllowed() && $activeProvider !== null;
        $companyOptions = CompanyOption::query()->where('company_id', $company->id)->first();

        if (!is_dir($themePath)) {
            abort(404, 'Theme not found');
        }

        // Action handler: /{slug}/_action/{name}
        if (Str::startsWith($path, '_action')) {
            $action = trim(Str::after($path, '_action'), '/');
            return $this->handleAction($action, $request, $company);
        }

        // Asset passthrough: /{slug}/_asset/{file}
        if (Str::startsWith($path, '_asset')) {
            $assetRel = trim(Str::after($path, '_asset'), '/');
            $file = $themePath . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . $assetRel;
            if (!is_file($file)) {
                abort(404);
            }
            $mime = mime_content_type($file) ?: 'application/octet-stream';
            return response()->file($file, ['Content-Type' => $mime]);
        }

        if ($path === 'pay') {
            if (!$paymentGatewayEnabled) {
                abort(404);
            }

            $gatewayConfig = app(CompanyGatewayConfig::class);

            $themeMeta = $this->readThemeMeta($themePath);
            $orderId = (string) $request->query('order_id', '');
            $orderStatus = (string) $request->query('status', '');
            $orderTx = $orderId !== ''
                ? EpointTransaction::query()->where('order_id', $orderId)->first()
                : null;

            $account = null;
            $paymentSummary = null;

            if ($request->isMethod('post')) {
                $intent = (string) $request->input('intent', 'lookup');

                $rules = [
                    'contract_no' => ['required', 'string', 'max:64'],
                    'fin_code' => ['required', 'string', 'max:64'],
                ];

                if ($intent === 'checkout') {
                    $rules['amount'] = ['required', 'numeric', 'min:0.01'];
                    if ($activeProvider === 'iyzico') {
                        $rules['buyer_email'] = ['required', 'email', 'max:255'];
                        $rules['buyer_phone'] = ['required', 'string', 'max:64'];
                        $rules['buyer_address'] = ['required', 'string', 'max:255'];
                        $rules['buyer_city'] = ['required', 'string', 'max:100'];
                        $rules['buyer_country'] = ['required', 'string', 'max:100'];
                        $rules['buyer_zip'] = ['nullable', 'string', 'max:20'];
                        $rules['buyer_identity'] = ['nullable', 'string', 'max:32'];
                    }
                }

                $data = $request->validate($rules);
                $contractNo = trim((string) $data['contract_no']);
                $finCode = strtoupper(trim((string) $data['fin_code']));

                $account = $this->findPaymentAccount($company->id, $contractNo, $finCode);
                if (!$account) {
                    return back()
                        ->withErrors(['contract_no' => ___('Contract or FIN not found.')])
                        ->withInput();
                }

                $paymentSummary = $this->buildPaymentSummary($account);

                if ($intent === 'checkout') {
                    $amount = (float) $data['amount'];
                    $payments = app(PaymentService::class);
                    if (!$paymentOption->allow_overpayment) {
                        $maxAmount = (float) ($paymentSummary['totalDue'] ?? 0);
                        if ($amount > $maxAmount + 0.0001) {
                            return back()
                                ->withErrors([
                                    'amount' => ___('Overpayment is not allowed. Max: :amount AZN', [
                                        'amount' => number_format($maxAmount, 2, '.', ''),
                                    ]),
                                ])
                                ->withInput();
                        }
                    }

                    $preview = $payments->previewPayment($account, now()->toDateString(), $amount);
                    if (($preview['needs_choice'] ?? false) === true) {
                        $overpayAction = $this->resolveOverpayAction(
                            $preview['payment_option'] ?? $paymentOption,
                            $preview['allowed_actions'] ?? []
                        );

                        if (!$overpayAction) {
                            return back()
                                ->withErrors(['amount' => ___('Overpayment action required for this payment.')])
                                ->withInput();
                        }

                        $preview = $payments->previewPayment($account, now()->toDateString(), $amount, $overpayAction);
                        if (($preview['needs_choice'] ?? false) === true) {
                            return back()
                                ->withErrors(['amount' => ___('Overpayment action required for this payment.')])
                                ->withInput();
                        }
                    }

                    $orderId = EpointTransaction::generateOrderId('loan');
                    $description = 'Loan payment: ' . ($account->contract?->contract_no ?? $account->id);
                    $currency = $gateway->providerCurrency($activeProvider ?? 'epoint', $company, 'AZN');

                    $tx = EpointTransaction::create([
                        'company_id' => $company->id,
                        'type' => EpointTransaction::TYPE_LOAN_PAYMENT,
                        'gateway' => $activeProvider ?? 'epoint',
                        'status' => EpointTransaction::STATUS_PENDING,
                        'amount' => $amount,
                        'currency' => $currency,
                        'order_id' => $orderId,
                        'description' => $description,
                        'meta' => [
                            'bhph_account_id' => $account->id,
                            'contract_no' => $account->contract?->contract_no,
                        ],
                    ]);

                    $queryBase = ['order_id' => $orderId, 'lang' => $currentLocale];
                    $successUrl = route('epoint.success', $queryBase);
                    $errorUrl = route('epoint.error', $queryBase);

                    if ($activeProvider === 'stripe') {
                        $stripe = app(StripeService::class)->withConfig($gatewayConfig->providerConfig('stripe', $company));
                        $resp = $stripe->createCheckoutSession([
                            'amount' => $amount,
                            'currency' => strtolower($currency),
                            'order_id' => $orderId,
                            'description' => $description,
                            'success_url' => $successUrl,
                            'cancel_url' => $errorUrl,
                        ]);

                        if (($resp['status'] ?? '') === 'success' && !empty($resp['url'])) {
                            $tx->gateway_transaction = $resp['id'] ?? null;
                            $tx->payload = $resp['payload'] ?? null;
                            $tx->save();
                            return redirect()->away($resp['url']);
                        }
                    } elseif ($activeProvider === 'iyzico') {
                        $iyzico = app(IyzicoService::class)->withConfig($gatewayConfig->providerConfig('iyzico', $company));
                        $buyer = [
                            'id' => 'customer_' . ($account->customer?->id ?? $account->id),
                            'name' => $account->customer?->first_name ?? 'Customer',
                            'surname' => $account->customer?->last_name ?? 'Payment',
                            'gsm' => $data['buyer_phone'] ?? '',
                            'email' => $data['buyer_email'] ?? '',
                            'identity_number' => $data['buyer_identity'] ?? ($account->customer?->id_card_number ?? $account->customer?->fin_code ?? ''),
                            'address' => $data['buyer_address'] ?? '',
                            'city' => $data['buyer_city'] ?? '',
                            'country' => $data['buyer_country'] ?? '',
                            'zip' => $data['buyer_zip'] ?? '',
                            'ip' => $request->ip(),
                        ];

                        $callbackUrl = route('iyzico.callback', ['order_id' => $orderId, 'lang' => $currentLocale]);
                        $resp = $iyzico->createCheckoutForm([
                            'amount' => $amount,
                            'currency' => $currency,
                            'order_id' => $orderId,
                            'callback_url' => $callbackUrl,
                            'locale' => $currentLocale,
                            'buyer' => $buyer,
                            'item_name' => $description,
                            'item_category' => 'Loan',
                        ]);

                        if (($resp['status'] ?? '') === 'success' && !empty($resp['content'])) {
                            $meta = is_array($tx->meta) ? $tx->meta : [];
                            if (!empty($resp['token'])) {
                                $meta['iyzico_token'] = $resp['token'];
                                $tx->gateway_transaction = $resp['token'];
                            }
                            $tx->meta = $meta;
                            $tx->payload = $resp['raw'] ?? null;
                            $tx->save();

                            return view('payments.iyzico', [
                                'title' => ___('Complete payment'),
                                'checkoutFormContent' => $resp['content'],
                                'returnUrl' => route('iyzico.redirect', ['order_id' => $orderId, 'lang' => $currentLocale]),
                            ]);
                        }
                    } else {
                        $epoint = app(EpointService::class)->withConfig($gatewayConfig->providerConfig('epoint', $company));
                        $resp = $epoint->requestPayment([
                            'public_key' => $epoint->publicKey(),
                            'amount' => $amount,
                            'currency' => $currency,
                            'language' => $epoint->normalizeLanguage($currentLocale),
                            'order_id' => $orderId,
                            'description' => $description,
                            'success_redirect_url' => $successUrl,
                            'error_redirect_url' => $errorUrl,
                        ]);

                        if (($resp['status'] ?? '') === 'success' && !empty($resp['redirect_url'])) {
                            return redirect()->away($resp['redirect_url']);
                        }
                    }

                    $tx->status = EpointTransaction::STATUS_FAILED;
                    $tx->message = $resp['message'] ?? 'Payment request failed';
                    $tx->payload = $resp;
                    $tx->save();

                    $message = (string)($resp['message'] ?? '');
                    if ($message === '' && isset($resp['body']) && is_string($resp['body'])) {
                        $body = trim($resp['body']);
                        if ($body !== '') {
                            $decoded = json_decode($body, true);
                            if (is_array($decoded) && !empty($decoded['message'])) {
                                $message = (string) $decoded['message'];
                            } else {
                                $message = $body;
                            }
                        }
                    }
                    if ($message === '' && is_array($resp) && !empty($resp['message'])) {
                        $message = (string) $resp['message'];
                    }
                    if ($message === '') {
                        $message = ___('Payment gateway error. Please try again.');
                    }

                    $errorUrlLocal = url($company->slug . '/pay') . '?' . http_build_query($queryBase + ['status' => 'error']);

                    return redirect()->to($errorUrlLocal)
                        ->withErrors(['amount' => $message])
                        ->with('gateway_error', $message)
                        ->withInput();
                }
            }

            $paymentCurrency = $gateway->providerCurrency($activeProvider ?? 'epoint', $company, 'AZN');

            return view("theme-{$theme}::pay", [
                'company' => $company,
                'theme' => $theme,
                'themeMeta' => $themeMeta,
                'themeAsset' => fn(string $asset) => $this->themeAsset($theme, $asset),
                'publicBase' => $publicBase,
                'publicUrl' => $publicUrl,
                'themeLocales' => $themeLocales,
                'themeDefaultLocale' => $themeDefaultLocale,
                'currentLocale' => $currentLocale,
                'themeStyles' => $company->public_settings['theme_styles'] ?? [],
                'paymentOption' => $paymentOption,
                'paymentProvider' => $activeProvider,
                'paymentCurrency' => $paymentCurrency,
                'companyOptions' => $companyOptions,
                'account' => $account,
                'paymentSummary' => $paymentSummary,
                'orderStatus' => $orderStatus,
                'orderTx' => $orderTx,
            ]);
        }

        // vehicle detail: /{slug}/vehicles/{id}
        if (Str::startsWith($path, 'vehicles/')) {
            $vehicleId = (int) Str::after($path, 'vehicles/');
            $selectedIds = (array)($company->public_settings['public_vehicle_ids'] ?? []);
            if (!in_array($vehicleId, $selectedIds, true)) {
                abort(404);
            }
            $vehicle = \App\Models\Vehicle::query()
                ->where('company_id', $company->id)
                ->findOrFail($vehicleId);
            $themeMeta = $this->readThemeMeta($themePath);
            return view("theme-{$theme}::vehicle", [
                'company' => $company,
                'theme' => $theme,
                'themeMeta' => $themeMeta,
                'themeAsset' => fn(string $asset) => $this->themeAsset($theme, $asset),
                'publicBase' => $publicBase,
                'publicUrl' => $publicUrl,
                'vehicle' => $vehicle,
                'paymentGatewayEnabled' => $paymentGatewayEnabled,
                'themeLocales' => $themeLocales,
                'themeDefaultLocale' => $themeDefaultLocale,
                'currentLocale' => $currentLocale,
            ]);
        }

        // blog routes: /{slug}/blog or /blog/{slug}
        if ($path === 'blog' || Str::startsWith($path, 'blog/')) {
            $themeMeta = $this->readThemeMeta($themePath);
            if ($path === 'blog') {
                $posts = \App\Models\BlogPost::query()
                    ->where('company_id', $company->id)
                    ->where('status', 'published')
                    ->latest('published_at')
                    ->get();
                return view("theme-{$theme}::blog.index", [
                    'company' => $company,
                    'theme' => $theme,
                    'themeMeta' => $themeMeta,
                    'posts' => $posts,
                    'themeAsset' => fn(string $asset) => $this->themeAsset($theme, $asset),
                    'publicBase' => $publicBase,
                    'publicUrl' => $publicUrl,
                    'paymentGatewayEnabled' => $paymentGatewayEnabled,
                    'themeLocales' => $themeLocales,
                    'themeDefaultLocale' => $themeDefaultLocale,
                    'currentLocale' => $currentLocale,
                ]);
            }

            $slug = Str::after($path, 'blog/');
            $post = \App\Models\BlogPost::query()
                ->where('company_id', $company->id)
                ->where('slug', $slug)
                ->where('status', 'published')
                ->firstOrFail();
            return view("theme-{$theme}::blog.show", [
                'company' => $company,
                'theme' => $theme,
                'themeMeta' => $themeMeta,
                'post' => $post,
                'themeAsset' => fn(string $asset) => $this->themeAsset($theme, $asset),
                'publicBase' => $publicBase,
                'publicUrl' => $publicUrl,
                'paymentGatewayEnabled' => $paymentGatewayEnabled,
                'themeLocales' => $themeLocales,
                'themeDefaultLocale' => $themeDefaultLocale,
                'currentLocale' => $currentLocale,
            ]);
        }

        // blog posts direct: /{slug}/{post-slug}
        $cleanPath = trim($path, '/');
        if ($cleanPath !== '') {
            $page = \App\Models\PublicPage::query()
                ->where('company_id', $company->id)
                ->where('slug', $cleanPath)
                ->where('status', 'published')
                ->first();
            if ($page) {
                $themeMeta = $this->readThemeMeta($themePath);
                return view("theme-{$theme}::page", [
                    'company' => $company,
                    'theme' => $theme,
                    'themeMeta' => $themeMeta,
                    'page' => $page,
                    'themeAsset' => fn(string $asset) => $this->themeAsset($theme, $asset),
                    'publicBase' => $publicBase,
                    'publicUrl' => $publicUrl,
                    'paymentGatewayEnabled' => $paymentGatewayEnabled,
                    'themeLocales' => $themeLocales,
                    'themeDefaultLocale' => $themeDefaultLocale,
                    'currentLocale' => $currentLocale,
                ]);
            }

            $post = \App\Models\BlogPost::query()
                ->where('company_id', $company->id)
                ->where('slug', $cleanPath)
                ->where('status', 'published')
                ->first();
            if ($post) {
                $themeMeta = $this->readThemeMeta($themePath);
            return view("theme-{$theme}::blog.show", [
                'company' => $company,
                'theme' => $theme,
                'themeMeta' => $themeMeta,
                'post' => $post,
                'themeAsset' => fn(string $asset) => $this->themeAsset($theme, $asset),
                'publicBase' => $publicBase,
                'publicUrl' => $publicUrl,
                'paymentGatewayEnabled' => $paymentGatewayEnabled,
                'themeLocales' => $themeLocales,
                'themeDefaultLocale' => $themeDefaultLocale,
                'currentLocale' => $currentLocale,
            ]);
            }
        }

        $viewName = $this->resolveView($theme, $path);
        if (!view()->exists($viewName)) {
            abort(404);
        }

        $themeMeta = $this->readThemeMeta($themePath);
        $selectedIds = (array)($company->public_settings['public_vehicle_ids'] ?? []);
        $publicVehicles = \App\Models\Vehicle::query()
            ->where('company_id', $company->id)
            ->whereIn('id', $selectedIds)
            ->get();
        $publicPages = \App\Models\PublicPage::query()
            ->where('company_id', $company->id)
            ->where('status', 'published')
            ->orderBy('title')
            ->get();
        $showCalculator = (bool)($company->public_settings['show_calculator'] ?? true);
        $showBlogLink = (bool)($company->public_settings['show_blog_link'] ?? true);
        $showPagesFooter = (bool)($company->public_settings['show_pages_footer'] ?? true);
        $showPublicVehicles = (bool)($company->public_settings['show_public_vehicles'] ?? true);
        $showTestDrive = (bool)($company->public_settings['show_test_drive'] ?? true);
        $leasing = \App\Models\LeasingOption::query()->where('company_id', $company->id)->first();
        $settings = $leasing?->settings ?? [];
        $rateMin = $settings['interest_min'] ?? null;
        $rateMax = $settings['interest_max'] ?? null;
        $themeStyles = $company->public_settings['theme_styles'] ?? [];

        return view($viewName, [
            'company' => $company,
            'theme' => $theme,
            'themeMeta' => $themeMeta,
            'themeAsset' => fn(string $asset) => $this->themeAsset($theme, $asset),
            'publicBase' => $publicBase,
            'publicUrl' => $publicUrl,
            'publicVehicles' => $publicVehicles,
            'publicPages' => $publicPages,
            'showCalculator' => $showCalculator,
            'showBlogLink' => $showBlogLink,
            'showPagesFooter' => $showPagesFooter,
            'showPublicVehicles' => $showPublicVehicles,
            'showTestDrive' => $showTestDrive,
            'rateMin' => $rateMin,
            'rateMax' => $rateMax,
            'themeLocales' => $themeLocales,
            'themeDefaultLocale' => $themeDefaultLocale,
            'currentLocale' => $currentLocale,
            'themeStyles' => $themeStyles,
            'paymentGatewayEnabled' => $paymentGatewayEnabled,
        ]);
    }

    private function resolveView(string $theme, string $path): string
    {
        $clean = trim($path, '/');
        $clean = $clean === '' ? 'home' : $clean;
        $clean = str_replace(['..', '//'], '', $clean);
        $clean = str_replace('/', '.', $clean); // subpages: about/team -> about.team

        // Use namespace registered in AppServiceProvider (theme-{code})
        return "theme-{$theme}::{$clean}";
    }

    private function themeAsset(string $theme, string $asset): string
    {
        // Served via controller: /{slug}/_asset/{path}
        $slug = request()->route('companySlug');
        if (!$slug) {
            // Use static public assets for custom domains to avoid web server blocking /_asset
            return url('/theme-assets/' . $theme . '/' . ltrim($asset, '/'));
        }
        return url($slug . '/_asset/' . ltrim($asset, '/'));
    }

    private function readThemeMeta(string $themePath): array
    {
        $file = $themePath . DIRECTORY_SEPARATOR . 'theme-info.txt';
        if (!is_file($file)) return [];

        $data = [];
        foreach (file($file) as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) continue;
            if (str_contains($line, ':')) {
                [$k, $v] = array_map('trim', explode(':', $line, 2));
                $data[$k] = $v;
            }
        }
        return $data;
    }

    private function findPaymentAccount(int $companyId, string $contractNo, string $finCode): ?BhphAccount
    {
        $contract = Contract::query()
            ->where('company_id', $companyId)
            ->where('contract_no', $contractNo)
            ->whereHas('customer', function ($q) use ($finCode) {
                $q->where('fin_code', $finCode);
            })
            ->first();

        if (!$contract) {
            return null;
        }

        $account = BhphAccount::query()
            ->where('company_id', $companyId)
            ->where('contract_id', $contract->id)
            ->first();

        return $account ? $account->load(['customer', 'contract']) : null;
    }

    private function buildPaymentSummary(BhphAccount $account): array
    {
        $today = Carbon::now()->startOfDay();

        $currentDue = $account->amortizations()
            ->whereColumn('paid_amount', '<', 'due_amount')
            ->whereDate('due_date', '<=', $today->toDateString())
            ->selectRaw('COALESCE(SUM(due_amount - paid_amount),0) as due')
            ->value('due') ?? 0;

        $penaltyService = app(PenaltyService::class);
        $penaltySummary = $penaltyService->summarizeAccount($account, $today);
        $penaltyOutstanding = (float) ($penaltySummary['outstanding'] ?? 0);

        $overdueDays = 0;
        foreach (($penaltySummary['rows'] ?? []) as $row) {
            $overdueDays = max($overdueDays, (int) ($row['days_late'] ?? 0));
        }

        $nextDue = $account->amortizations()
            ->whereColumn('paid_amount', '<', 'due_amount')
            ->orderBy('due_date')
            ->first();

        return [
            'currentDue' => (float) $currentDue,
            'penaltySummary' => $penaltySummary,
            'penaltyOutstanding' => $penaltyOutstanding,
            'overdueDays' => $overdueDays,
            'totalDue' => (float) $currentDue + $penaltyOutstanding,
            'nextDueDate' => $nextDue?->due_date ? Carbon::parse($nextDue->due_date)->toDateString() : null,
            'remainingPrincipal' => $account->remainingPrincipalCalc(),
            'remainingAmount' => (float) ($account->remaining_amount ?? 0),
        ];
    }

    private function resolveOverpayAction(PaymentOption $option, array $allowedActions = []): ?string
    {
        $allowed = $allowedActions;

        if (empty($allowed)) {
            if ($option->allow_overpayment && $option->allow_advance_payment) {
                $allowed[] = 'apply_next_installments';
            }
            if ($option->allow_overpayment && $option->allow_principal_only_payment) {
                $allowed[] = 'reduce_principal';
            }
            if ($option->allow_overpayment) {
                $allowed[] = 'keep_as_credit';
            }
        }

        $preferred = $option->overpayment_behavior;
        if ($preferred && in_array($preferred, $allowed, true)) {
            return $preferred;
        }

        return $allowed[0] ?? null;
    }

    private function handleAction(string $action, Request $request, $company)
    {
        // Sample shared action: credit calculator
        if ($action === 'credit-calc' && $request->isMethod('post')) {
            $data = $request->validate([
                'amount' => ['required','numeric','min:0'],
                'months' => ['required','integer','min:1'],
                'rate'   => ['required','numeric','min:0'],
            ]);

            $leasing = \App\Models\LeasingOption::query()->where('company_id', $company->id)->first();
            $settings = $leasing?->settings ?? [];
            $minRate = isset($settings['interest_min']) ? (float)$settings['interest_min'] : null;
            $maxRate = isset($settings['interest_max']) ? (float)$settings['interest_max'] : null;

            if ($minRate !== null && $data['rate'] < $minRate) $data['rate'] = $minRate;
            if ($maxRate !== null && $data['rate'] > $maxRate) $data['rate'] = $maxRate;

            $amount = (float)$data['amount'];
            $months = (int)$data['months'];
            $rate   = (float)$data['rate'] / 100 / 12;
            $pay = $rate > 0
                ? ($amount * $rate) / (1 - pow(1 + $rate, -$months))
                : $amount / $months;

            return response()->json([
                'monthly_payment' => round($pay, 2),
                'total' => round($pay * $months, 2),
            ]);
        }

        if ($action === 'test-drive' && $request->isMethod('post')) {
            $data = $request->validate([
                'name' => ['required','string','max:255'],
                'phone' => ['nullable','string','max:64'],
                'email' => ['nullable','email','max:255'],
                'vehicle_id' => ['nullable','integer'],
            ]);

            $vehicleId = $data['vehicle_id'] ?? null;
            if ($vehicleId) {
                $exists = \App\Models\Vehicle::query()
                    ->where('company_id', $company->id)
                    ->where('id', $vehicleId)
                    ->exists();
                if (!$exists) {
                    $vehicleId = null;
                }
            }

            \App\Models\TestDrive::create([
                'company_id' => $company->id,
                'vehicle_id' => $vehicleId,
                'name' => $data['name'],
                'phone' => $data['phone'] ?? null,
                'email' => $data['email'] ?? null,
                'status' => 'pending',
                'note' => 'Created from public theme',
            ]);

            return response()->json(['message' => 'Request received'], 201);
        }

        abort(404);
    }
}
