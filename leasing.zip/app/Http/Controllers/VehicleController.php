<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Services\Gps\GpsManager;
use App\Models\GpsVehicleRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;

class VehicleController extends Controller
{
    public function __construct()
    {
        $this->middleware('perm:vehicles.view')->only(['index']);
        $this->middleware('perm:vehicles.create')->only(['create','store']);
        $this->middleware('perm:vehicles.edit')->only(['edit','update']);
        $this->middleware('perm:vehicles.delete')->only(['destroy']);
        $this->middleware('perm:vehicles.gps')->only(['gps','sendCommand','saveGeofence']);
    }

    private function normalizeImagePath($item): ?string
    {
        // DB-də bəzən ["path"=>...], ["url"=>...] kimi saxlanıbsa düzəlt
        if (is_array($item)) {
            $item = $item['path'] ?? $item['url'] ?? null;
        }

        if (!is_string($item)) return null;

        $item = trim($item);
        if ($item === '') return null;

        // Əgər tam URL saxlanıbsa, public storage url hissəsini çıxartmağa çalışaq
        // Məs: /storage/vehicles/a.jpg -> vehicles/a.jpg
        $item = preg_replace('#^https?://[^/]+/#', '', $item); // domain çıxar
        $item = ltrim($item, '/');
        if (str_starts_with($item, 'storage/')) {
            $item = substr($item, strlen('storage/'));
        }

        return $item ?: null;
    }

    private function normalizeImageList($arr): array
    {
        $arr = is_array($arr) ? $arr : [];
        $out = [];

        foreach ($arr as $it) {
            $p = $this->normalizeImagePath($it);
            if ($p) $out[] = $p;
        }

        // uniq + reindex
        return array_values(array_unique($out));
    }

    public function index(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $q = trim((string) $request->query('q', ''));
        $status = trim((string) $request->query('status', ''));
        $module = $this->companyModule($user);
        $statuses = $this->statusOptions($module);

        $vehicles = Vehicle::query()
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($x) use ($q) {
                    $x->where('plate_number', 'like', "%{$q}%")
                        ->orWhere('vin_code', 'like', "%{$q}%")
                        ->orWhere('brand', 'like', "%{$q}%")
                        ->orWhere('model', 'like', "%{$q}%")
                        ->orWhere('sub_model', 'like', "%{$q}%")
                        ->orWhere('year', 'like', "%{$q}%");
                });
            })
            ->when($status !== '', fn ($query) => $query->where('status', $status))
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('vehicles.index', compact('user', 'vehicles', 'q', 'status', 'statuses', 'module'));
    }

    public function create(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $module = $this->companyModule($user);
        $statuses = $this->statusOptions($module);
        $customers = \App\Models\Customer::query()
            ->where('company_id', $user->company_id)
            ->orderBy('first_name')
            ->orderBy('last_name')
            ->get(['id','first_name','last_name','phone']);

        $gpsProvider = app(GpsManager::class)->providerForCompany($user?->company);

        return view('vehicles.create', compact('user', 'statuses', 'module', 'customers', 'gpsProvider'));
    }

    public function gpsSetup()
    {
        $user = request()->user();
        $company = $user?->company;
        $gpsManager = app(GpsManager::class);
        $provider = $gpsManager->providerForCompany($company);
        $settings = $gpsManager->settingsForCompany($company);
        $devices = $this->loadTraccarDevicePorts();
        $host = $this->traccarHost($settings['traccar_base_url'] ?? config('services.traccar.base_url'));
        $wialonHost = $settings['wialon_base_url'] ?? config('services.wialon.base_url', env('WIALON_BASE_URL', 'https://hst-api.wialon.com'));

        return view('vehicles.gps-guide', [
            'devicePorts' => $devices,
            'traccarHost' => $host,
            'wialonHost' => $wialonHost,
            'gpsProvider' => $provider,
        ]);
    }

    private function traccarHost(?string $baseUrl): string
    {
        if (!$baseUrl) {
            return '';
        }

        $host = parse_url($baseUrl, PHP_URL_HOST);
        if ($host) {
            return $host;
        }

        return trim($baseUrl, '/');
    }

    public function store(Request $request)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');
        $module = $this->companyModule($user);
        $statuses = $this->statusOptions($module);

        $v = Validator::make($request->all(), [
            'purchase_price' => ['nullable','numeric','min:0'],
            'sale_price'     => ['nullable','numeric','min:0'],
            'rent_daily_price' => ['nullable','numeric','min:0'],
            'rent_weekly_price' => ['nullable','numeric','min:0'],
            'rent_monthly_price' => ['nullable','numeric','min:0'],
            'rent_source' => ['nullable','string','max:255'],
            'rent_due_at' => ['nullable','date'],
            'owner_type' => ['nullable','string','in:company,owner'],
            'owner_customer_id' => ['nullable','integer', Rule::exists('customers','id')->where('company_id', $user->company_id)],
            'owner_payment_type' => ['nullable','string','in:daily,weekly,monthly,per_rental'],
            'owner_payment_amount' => ['nullable','numeric','min:0'],
            'owner_type' => ['nullable','string','in:company,owner'],
            'owner_customer_id' => ['nullable','integer', Rule::exists('customers','id')->where('company_id', $user->company_id)],
            'owner_payment_type' => ['nullable','string','in:daily,weekly,monthly,per_rental'],
            'owner_payment_amount' => ['nullable','numeric','min:0'],

            'plate_number' => ['nullable','string','max:32'],
            'vin_code'     => ['nullable','string','max:64'],

            'brand'     => ['required','string','max:80'],
            'model'     => ['required','string','max:80'],
            'sub_model' => ['nullable','string','max:80'],
            'year'      => ['nullable','integer','min:1950','max:2100'],
            'color'     => ['nullable','string','max:64'],

            'traccar_device_id' => ['nullable','string','max:128'],
            'wialon_unique_id' => ['nullable','string','max:128'],
            'specs_k'    => ['nullable','array'],
            'specs_k.*'  => ['nullable','string','max:255'],
            'specs_v'    => ['nullable','array'],
            'specs_v.*'  => ['nullable','string','max:255'],
            'comforts_k'   => ['nullable','array'],
            'comforts_k.*' => ['nullable','string','max:255'],
            'comforts_v'   => ['nullable','array'],
            'comforts_v.*' => ['nullable','string','max:255'],
            'specs_kv'   => ['nullable','string','max:4000'],
            'comfort_kv' => ['nullable','string','max:4000'],
            'public_title' => ['nullable','string','max:255'],
            'public_description' => ['nullable','string','max:5000'],

            'status' => ['required', Rule::in(array_keys($statuses))],

            'has_insurance' => ['nullable'],
            'has_technical' => ['nullable'],
            'is_returned'   => ['nullable'],

            'images_new'   => ['nullable','array'],
            'images_new.*' => ['image','mimes:jpg,jpeg,png,webp','max:5120'],
        ]);

        $data = $v->validate();
        if ($module === 'rentacar') {
            if (!isset($data['sale_price']) || $data['sale_price'] === null || $data['sale_price'] === '') {
                $data['sale_price'] = 0;
            }
            if (($data['owner_type'] ?? null) === 'owner') {
                if (empty($data['owner_customer_id']) || empty($data['owner_payment_type']) || $data['owner_payment_amount'] === null) {
                    return back()->withErrors(['owner_type' => ___('Owner details are required.')])->withInput();
                }
            } else {
                $data['owner_customer_id'] = null;
                $data['owner_payment_type'] = null;
                $data['owner_payment_amount'] = null;
            }
        }
        if (!empty($data['rent_due_at'])) {
            $data['rent_due_at'] = Carbon::parse($data['rent_due_at'])->toDateTimeString();
        }

        $data['has_insurance'] = $request->boolean('has_insurance');
        $data['has_technical'] = $request->boolean('has_technical');
        $data['is_returned']   = $request->boolean('is_returned');
        $gpsProvider = app(GpsManager::class)->providerForCompany($user->company);
        if ($gpsProvider !== 'wialon') {
            $data['wialon_unique_id'] = null;
        }
        $specs = $this->parseKeyValuePairs(
            $request->input('specs_k'),
            $request->input('specs_v')
        );
        if (empty($specs)) {
            $specs = $this->parseKeyValueLines($request->input('specs_kv'));
        }
        $data['specs'] = $specs;

        $comforts = $this->parseKeyValuePairs(
            $request->input('comforts_k'),
            $request->input('comforts_v')
        );
        if (empty($comforts)) {
            $comforts = $this->parseKeyValueLines($request->input('comfort_kv'));
        }
        $data['comforts'] = $comforts;

        $paths = [];

        if ($request->hasFile('images_new')) {
            foreach ($request->file('images_new') as $file) {
                if (!$file) continue;
                $paths[] = Storage::disk('public')->putFile('vehicles', $file);
            }
        }

        $data['images'] = $paths; // DB-də yalnız string path-lər saxlanır

        $vehicle = new Vehicle();
        $vehicle->fill($data);
        $vehicle->save(); // BelongsToCompany company_id-ni özü qoyacaq

        $this->maybeCreateGpsVehicleRequest($vehicle, $user);

        return redirect()->route('vehicles.gps_setup')->with('status', 'Avtomobil yaradıldı. GPS quraşdırma təlimatına keçdiniz.');
    }

    public function edit(Request $request, Vehicle $vehicle)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $module = $this->companyModule($user);
        $statuses = $this->statusOptions($module);

        // köhnədən qalan array strukturu varsa burada da düzəltmək üçün view-ə normal göndərək
        $vehicle->images = $this->normalizeImageList($vehicle->images);

        $customers = \App\Models\Customer::query()
            ->where('company_id', $user->company_id)
            ->orderBy('first_name')
            ->orderBy('last_name')
            ->get(['id','first_name','last_name','phone']);

        $gpsProvider = app(GpsManager::class)->providerForCompany($user?->company);
        $vehicleRequest = GpsVehicleRequest::query()
            ->where('vehicle_id', $vehicle->id)
            ->orderByDesc('id')
            ->first();

        return view('vehicles.edit', compact('user', 'vehicle', 'statuses', 'module', 'customers', 'gpsProvider', 'vehicleRequest'));
    }

    public function update(Request $request, Vehicle $vehicle)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');
        $module = $this->companyModule($user);
        $statuses = $this->statusOptions($module);

        $v = Validator::make($request->all(), [
            'purchase_price' => ['nullable','numeric','min:0'],
            'sale_price'     => ['nullable','numeric','min:0'],
            'rent_daily_price' => ['nullable','numeric','min:0'],
            'rent_weekly_price' => ['nullable','numeric','min:0'],
            'rent_monthly_price' => ['nullable','numeric','min:0'],
            'rent_source' => ['nullable','string','max:255'],
            'rent_due_at' => ['nullable','date'],

            'plate_number' => ['nullable','string','max:32'],
            'vin_code'     => ['nullable','string','max:64'],

            'brand'     => ['required','string','max:80'],
            'model'     => ['required','string','max:80'],
            'sub_model' => ['nullable','string','max:80'],
            'year'      => ['nullable','integer','min:1950','max:2100'],
            'color'     => ['nullable','string','max:64'],

            'traccar_device_id' => ['nullable','string','max:128'],
            'wialon_unique_id' => ['nullable','string','max:128'],
            'specs_k'    => ['nullable','array'],
            'specs_k.*'  => ['nullable','string','max:255'],
            'specs_v'    => ['nullable','array'],
            'specs_v.*'  => ['nullable','string','max:255'],
            'comforts_k'   => ['nullable','array'],
            'comforts_k.*' => ['nullable','string','max:255'],
            'comforts_v'   => ['nullable','array'],
            'comforts_v.*' => ['nullable','string','max:255'],
            'specs_kv'   => ['nullable','string','max:4000'],
            'comfort_kv' => ['nullable','string','max:4000'],
            'public_title' => ['nullable','string','max:255'],
            'public_description' => ['nullable','string','max:5000'],

            'status' => ['required', Rule::in(array_keys($statuses))],

            'has_insurance' => ['nullable'],
            'has_technical' => ['nullable'],
            'is_returned'   => ['nullable'],

            'delete_images' => ['nullable','array'],
            'delete_images.*' => ['nullable'],

            'images_new'   => ['nullable','array'],
            'images_new.*' => ['image','mimes:jpg,jpeg,png,webp','max:5120'],
        ]);

        $data = $v->validate();
        if ($module === 'rentacar') {
            if (!isset($data['sale_price']) || $data['sale_price'] === null || $data['sale_price'] === '') {
                $data['sale_price'] = 0;
            }
            if (($data['owner_type'] ?? null) === 'owner') {
                if (empty($data['owner_customer_id']) || empty($data['owner_payment_type']) || $data['owner_payment_amount'] === null) {
                    return back()->withErrors(['owner_type' => ___('Owner details are required.')])->withInput();
                }
            } else {
                $data['owner_customer_id'] = null;
                $data['owner_payment_type'] = null;
                $data['owner_payment_amount'] = null;
            }
        }
        if (!empty($data['rent_due_at'])) {
            $data['rent_due_at'] = Carbon::parse($data['rent_due_at'])->toDateTimeString();
        }

        $data['has_insurance'] = $request->boolean('has_insurance');
        $data['has_technical'] = $request->boolean('has_technical');
        $data['is_returned']   = $request->boolean('is_returned');
        $gpsProvider = app(GpsManager::class)->providerForCompany($user->company);
        if ($gpsProvider !== 'wialon') {
            $data['wialon_unique_id'] = null;
        }
        $specs = $this->parseKeyValuePairs(
            $request->input('specs_k'),
            $request->input('specs_v')
        );
        if (empty($specs)) {
            $specs = $this->parseKeyValueLines($request->input('specs_kv'));
        }
        $data['specs'] = $specs;

        $comforts = $this->parseKeyValuePairs(
            $request->input('comforts_k'),
            $request->input('comforts_v')
        );
        if (empty($comforts)) {
            $comforts = $this->parseKeyValueLines($request->input('comfort_kv'));
        }
        $data['comforts'] = $comforts;

        // Mövcud şəkilləri normal formaya sal
        $existing = $this->normalizeImageList($vehicle->images);

        // Silinməli olanlar (yalnız string path qəbul edirik)
        $toDelete = $this->normalizeImageList($request->input('delete_images', []));

        // yalnız mövcud olanları sil
        $toDelete = array_values(array_intersect($existing, $toDelete));

        if (!empty($toDelete)) {
            foreach ($toDelete as $path) {
                Storage::disk('public')->delete($path);
            }
            $existing = array_values(array_diff($existing, $toDelete));
        }

        // Yeni yüklənənləri əlavə et
        if ($request->hasFile('images_new')) {
            foreach ($request->file('images_new') as $file) {
                if (!$file) continue;
                $existing[] = Storage::disk('public')->putFile('vehicles', $file);
            }
        }

        $data['images'] = array_values(array_unique($existing));

        $vehicle->fill($data);
        $vehicle->save();

        $this->maybeCreateGpsVehicleRequest($vehicle, $user);

        return redirect()->route('vehicles.edit', $vehicle)->with('status', 'Avtomobil yeniləndi.');
    }

    public function destroy(Request $request, Vehicle $vehicle)
    {
        $user = $request->user();
        if (!$user?->company_id) abort(403, 'İstifadəçi şirkətə bağlı deyil.');

        $imgs = $this->normalizeImageList($vehicle->images);
        foreach ($imgs as $path) {
            Storage::disk('public')->delete($path);
        }

        $vehicle->delete();

        return redirect()->route('vehicles.index')->with('status', 'Avtomobil silindi.');
    }

    private function parseKeyValueLines(?string $raw): array
    {
        $out = [];
        $raw = (string)$raw;
        foreach (preg_split("/\\r?\\n/", $raw) as $line) {
            $line = trim($line);
            if ($line === '' || !str_contains($line, ':')) continue;
            [$k, $v] = array_map('trim', explode(':', $line, 2));
            if ($k === '') continue;
            $out[$k] = $v;
        }
        return $out;
    }

    private function filterCommandTypes(array $commandTypes, array $allowed): array
    {
        if (empty($allowed)) return $commandTypes;

        $allowedSet = array_flip($allowed);

        return array_values(array_filter($commandTypes, function ($item) use ($allowedSet) {
            if (is_string($item)) {
                return isset($allowedSet[strtolower($item)]);
            }
            if (is_array($item)) {
                $type = $item['type'] ?? $item['name'] ?? null;
                if (!$type) return false;
                return isset($allowedSet[strtolower((string) $type)]);
            }
            return false;
        }));
    }

    private function maybeCreateGpsVehicleRequest(Vehicle $vehicle, $user): void
    {
        if (!$user?->company_id) return;

        $gpsManager = app(GpsManager::class);
        $provider = $gpsManager->providerForCompany($user->company);
        if ($provider !== 'wialon') {
            return;
        }

        if (!$vehicle->wialon_unique_id || $vehicle->wialon_device_id) {
            return;
        }

        $connection = $gpsManager->approvedConnectionForCompany($user->company);
        if (!$connection) {
            return;
        }

        $pending = GpsVehicleRequest::query()
            ->where('vehicle_id', $vehicle->id)
            ->where('status', 'pending')
            ->first();

        if ($pending) {
            $pending->unique_id = $vehicle->wialon_unique_id;
            $pending->unit_name = $this->wialonUnitName($vehicle);
            $pending->save();
            return;
        }

        GpsVehicleRequest::create([
            'vehicle_id' => $vehicle->id,
            'company_id' => $vehicle->company_id,
            'gps_provider_id' => $connection->gps_provider_id,
            'status' => 'pending',
            'unique_id' => $vehicle->wialon_unique_id,
            'unit_name' => $this->wialonUnitName($vehicle),
            'requested_by' => $user->id,
            'requested_at' => now(),
        ]);
    }

    private function wialonUnitName(Vehicle $vehicle): string
    {
        $parts = array_filter([
            $vehicle->plate_number ? trim((string) $vehicle->plate_number) : null,
            trim($vehicle->brand . ' ' . $vehicle->model),
        ]);
        $name = trim(implode(' ', $parts));
        return $name !== '' ? $name : ('Vehicle #' . $vehicle->id);
    }

    private function companyModule(?object $user): string
    {
        $company = $user?->company;
        if (!$company) {
            return 'leasing';
        }
        if (method_exists($company, 'moduleCode')) {
            return $company->moduleCode();
        }
        $module = strtolower(trim((string) ($company->module ?? 'leasing')));
        return in_array($module, ['leasing','rentacar','taxipark'], true) ? $module : 'leasing';
    }

    private function statusOptions(string $module): array
    {
        if (in_array($module, ['rentacar','taxipark'], true)) {
            return [
                'available' => 'Boş / Mövcud',
                'rented' => 'Kirayədə',
                'maintenance' => 'Servisdə',
            ];
        }

        return [
            'available' => 'Satışda / Mövcud',
            'leasing'   => 'Leasingdə',
            'sold'      => 'Satılıb',
        ];
    }

    private function formatRemaining(?Carbon $due): ?string
    {
        if (!$due) {
            return null;
        }

        $seconds = now()->diffInSeconds($due, false);
        $abs = abs($seconds);

        $days = intdiv($abs, 86400);
        $hours = intdiv($abs % 86400, 3600);
        $mins = intdiv($abs % 3600, 60);

        $parts = [];
        if ($days > 0) {
            $parts[] = $days . 'd';
        }
        if ($hours > 0) {
            $parts[] = $hours . 'h';
        }
        if ($days === 0 && $hours === 0) {
            $parts[] = $mins . 'm';
        }

        $label = implode(' ', $parts) ?: '0m';
        if ($seconds < 0) {
            return ___('Overdue by') . ' ' . $label;
        }

        return $label;
    }

    private function parseKeyValuePairs(?array $keys, ?array $values): array
    {
        $out = [];
        $keys = is_array($keys) ? $keys : [];
        $values = is_array($values) ? $values : [];
        $count = max(count($keys), count($values));

        for ($i = 0; $i < $count; $i++) {
            $k = trim((string)($keys[$i] ?? ''));
            $v = trim((string)($values[$i] ?? ''));
            if ($k === '' && $v === '') {
                continue;
            }
            if ($k === '') {
                continue;
            }
            $out[$k] = $v;
        }

        return $out;
    }

    private function loadTraccarDevicePorts(): array
    {
        $path = resource_path('data/traccar_devices.txt');
        if (!is_file($path)) {
            return [];
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $devices = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $parts = preg_split('/\\t+/', $line);
            if (count($parts) < 3) {
                $parts = preg_split('/\\s+/', $line);
            }
            if (count($parts) < 3) {
                continue;
            }

            $port = trim(array_pop($parts));
            $protocol = trim(array_pop($parts));
            $device = trim(implode(' ', $parts));

            if ($device === '') {
                continue;
            }

            $devices[] = [
                'device' => $device,
                'protocol' => $protocol,
                'port' => $port,
            ];
        }

        return $devices;
    }

    public function gps(Request $request, Vehicle $vehicle, GpsManager $gpsManager)
    {
        $user = $request->user();
        if (!$user) abort(403);

        $module = $this->companyModule($user);
        // superadmin istisna olmaqla eyni company-y? m?xsus olmal?d?r
        if (!($user->isSuperAdmin()) && (int) $vehicle->company_id !== (int) $user->company_id) {
            abort(404);
        }

        $company = $user->company;
        $provider = $gpsManager->providerForCompany($company);
        if (!$user->isSuperAdmin() && !$gpsManager->featureEnabled($company, 'live_map')) {
            return redirect()->route('vehicles.index')->withErrors(['gps' => 'Live map deaktiv edilib.']);
        }
        $position = null;
        $error = null;
        $commandTypes = [];
        $wsUrl = null;
        $wsToken = null;
        $commandsEnabled = $user->isSuperAdmin() ? true : $gpsManager->featureEnabled($company, 'commands');

        if ($provider === 'wialon') {
            $wialon = $gpsManager->wialonForCompany($company);
            if (!$vehicle->wialon_device_id) {
                $error = ___('Wialon unit ID is empty for this vehicle.');
            } elseif (!$wialon->isConfigured()) {
                abort(403, ___('Wialon config is missing. Ask provider to set credentials.'));
            } else {
                $position = $wialon->getLastPosition($vehicle->wialon_device_id);
                if (!$position) {
                    $error = ___('No location data received from Wialon yet.');
                }
                $commandTypes = $user->isSuperAdmin() ? [] : $wialon->listCommandTypes($vehicle->wialon_device_id);
                if (!$user->isSuperAdmin()) {
                    $commandTypes = $this->filterCommandTypes($commandTypes, $gpsManager->allowedCommandsForCompany($company));
                }
            }
        } else {
            $traccar = $gpsManager->traccarForCompany($company);
            $wsUrl = $traccar->wsUrl();
            $wsToken = $traccar->token();
            if (!$vehicle->traccar_device_id) {
                $error = ___('Traccar device ID is empty for this vehicle.');
            } elseif (!$traccar->isConfigured()) {
                abort(403, ___('Traccar config is missing. Ask provider to set credentials.'));
            } else {
                $position = $traccar->getLastPosition($vehicle->traccar_device_id);
                if (!$position) {
                    $error = ___('No location data received from Traccar yet.');
                }
                // superadmin komanda g?nd?r? bilm?z
                $commandTypes = $user->isSuperAdmin() ? [] : $traccar->listCommandTypes($vehicle->traccar_device_id);
                if (!$user->isSuperAdmin()) {
                    $commandTypes = $this->filterCommandTypes($commandTypes, $gpsManager->allowedCommandsForCompany($company));
                }
            }
        }

        $rentRemaining = in_array($module, ['rentacar','taxipark'], true)
            ? $this->formatRemaining($vehicle->rent_due_at)
            : null;

        $geofence = [
            'enabled' => (bool) $vehicle->geofence_enabled,
            'lat' => $vehicle->geofence_lat !== null ? (float) $vehicle->geofence_lat : null,
            'lng' => $vehicle->geofence_lng !== null ? (float) $vehicle->geofence_lng : null,
            'radius_m' => $vehicle->geofence_radius_m !== null ? (int) $vehicle->geofence_radius_m : null,
        ];

        if (!$provider) {
            $error = ___('GPS provider is not connected yet.');
            return view('vehicles.gps', compact('vehicle', 'position', 'error', 'commandTypes', 'wsUrl', 'wsToken', 'module', 'rentRemaining', 'geofence', 'provider', 'commandsEnabled'));
        }

        return view('vehicles.gps', compact('vehicle', 'position', 'error', 'commandTypes', 'wsUrl', 'wsToken', 'module', 'rentRemaining', 'geofence', 'provider', 'commandsEnabled'));
    }

    public function gpsPosition(Request $request, Vehicle $vehicle, GpsManager $gpsManager)
    {
        $user = $request->user();
        if (!$user) abort(403);
        if (!($user->isSuperAdmin()) && (int) $vehicle->company_id !== (int) $user->company_id) {
            abort(404);
        }

        $company = $user->company;
        $provider = $gpsManager->providerForCompany($company);
        if (!$provider) {
            return response()->json(['error' => 'GPS provider is not connected.'], 422);
        }
        if (!$user->isSuperAdmin() && !$gpsManager->featureEnabled($company, 'live_map')) {
            return response()->json(['error' => 'Live map disabled.'], 403);
        }
        if (!$user->isSuperAdmin() && !$gpsManager->featureEnabled($company, 'live_map')) {
            return response()->json(['error' => 'Live map disabled.'], 403);
        }

        if ($provider === 'wialon') {
            $wialon = $gpsManager->wialonForCompany($company);
            if (!$wialon->isConfigured() || !$vehicle->wialon_device_id) {
                return response()->json(['error' => 'Provider credentials missing.'], 403);
            }
            $pos = $wialon->getLastPosition($vehicle->wialon_device_id);
        } else {
            $traccar = $gpsManager->traccarForCompany($company);
            if (!$traccar->isConfigured() || !$vehicle->traccar_device_id) {
                return response()->json(['error' => 'Provider credentials missing.'], 403);
            }
            $pos = $traccar->getLastPosition($vehicle->traccar_device_id);
        }

        if (!$pos) {
            return response()->json(['error' => 'No location data available.'], 404);
        }

        return response()->json($pos);
    }

    public function saveGeofence(Request $request, Vehicle $vehicle)
    {
        $user = $request->user();
        if (!$user) abort(403);
        if ($user->isSuperAdmin()) abort(403);
        if ((int) $vehicle->company_id !== (int) $user->company_id) {
            abort(404);
        }

        $data = $request->validate([
            'geofence_lat' => ['nullable','numeric','between:-90,90'],
            'geofence_lng' => ['nullable','numeric','between:-180,180'],
            'geofence_radius_m' => ['nullable','integer','min:20','max:200000'],
            'clear_geofence' => ['nullable','boolean'],
        ]);

        if ($request->boolean('clear_geofence')) {
            $vehicle->geofence_enabled = false;
            $vehicle->geofence_lat = null;
            $vehicle->geofence_lng = null;
            $vehicle->geofence_radius_m = null;
            $vehicle->geofence_state = null;
            $vehicle->geofence_last_exit_at = null;
            $vehicle->geofence_last_enter_at = null;
            $vehicle->geofence_last_reminder_at = null;
            $vehicle->save();

            return back()->with('status', ___('Geofence cleared.'));
        }

        if ($data['geofence_lat'] === null || $data['geofence_lng'] === null || $data['geofence_radius_m'] === null) {
            return back()->withErrors(['geofence' => ___('Please draw an area on the map to save geofence.')]);
        }

        $vehicle->geofence_enabled = true;
        $vehicle->geofence_lat = (float) $data['geofence_lat'];
        $vehicle->geofence_lng = (float) $data['geofence_lng'];
        $vehicle->geofence_radius_m = (int) $data['geofence_radius_m'];
        $vehicle->geofence_state = null;
        $vehicle->geofence_last_exit_at = null;
        $vehicle->geofence_last_enter_at = null;
        $vehicle->geofence_last_reminder_at = null;
        $vehicle->save();

        return back()->with('status', ___('Geofence saved.'));
    }

    public function gpsAll(Request $request, GpsManager $gpsManager)
    {
        $user = $request->user();
        if (!$user) abort(403);

        $module = $this->companyModule($user);
        $company = $user->company;
        $provider = $gpsManager->providerForCompany($company);
        if (!$user->isSuperAdmin() && !$gpsManager->featureEnabled($company, 'live_map')) {
            return redirect()->route('vehicles.index')->withErrors(['gps' => 'Live map deaktiv edilib.']);
        }
        if (!$provider) {
            return redirect()->route('vehicles.index')->withErrors(['gps' => 'GPS provider is not connected.']);
        }

        if ($provider === 'wialon') {
            $wialon = $gpsManager->wialonForCompany($company);
            if (!$wialon->isConfigured()) {
                abort(403, ___('Wialon config is missing. Ask provider to set credentials.'));
            }
            if (!$user->isSuperAdmin()) {
                $units = $gpsManager->wialonUnitsForCompany($company);
                if (empty($units)) {
                    return redirect()->route('vehicles.index')->withErrors(['gps' => 'Wialon mapping yoxdur və ya masin tapilmadi.']);
                }

                $vehicles = collect($units)->map(function ($unit) {
                    $unitId = (int) ($unit['id'] ?? 0);
                    $name = $unit['nm'] ?? $unit['name'] ?? ('Unit #' . $unitId);
                    $plate = $unit['uid'] ?? null;
                    return (object) [
                        'id' => null,
                        'company_id' => null,
                        'brand' => null,
                        'model' => null,
                        'year' => null,
                        'plate_number' => $plate,
                        'wialon_device_id' => $unitId,
                        'traccar_device_id' => null,
                        'display_name' => $name,
                        'rent_due_at' => null,
                    ];
                });

                $positions = [];
                $commandTypes = [];
                foreach ($vehicles as $v) {
                    $deviceId = (string) $v->wialon_device_id;
                    if ($deviceId === '' || $deviceId === '0') continue;
                    $pos = $wialon->getLastPosition($deviceId);
                    if ($pos) {
                        $positions[] = array_merge($pos, [
                            'vehicle_id' => null,
                            'name' => $v->display_name,
                            'plate' => $v->plate_number,
                            'brand' => null,
                            'model' => null,
                            'year' => null,
                            'company_id' => null,
                            'rent_due_at' => null,
                            'rent_remaining' => null,
                        ]);
                    }
                    $list = $wialon->listCommandTypes($deviceId);
                    $commandTypes[$deviceId] = $this->filterCommandTypes($list, $gpsManager->allowedCommandsForCompany($company));
                }

                $wsUrl = null;
                $wsToken = null;
                $showReturnDue = false;
                $pollIntervalSec = (int) ($gpsManager->settingsForCompany($company)['api_poll_interval'] ?? 5);
                if ($pollIntervalSec < 3) $pollIntervalSec = 3;
                if ($pollIntervalSec > 300) $pollIntervalSec = 300;
                $commandsEnabled = $user->isSuperAdmin() ? true : $gpsManager->featureEnabled($company, 'commands');
                $historyEnabled = $user->isSuperAdmin() ? true : $gpsManager->featureEnabled($company, 'history');

                return view('vehicles.map', compact('vehicles', 'positions', 'wsUrl', 'wsToken', 'commandTypes', 'module', 'showReturnDue', 'provider', 'pollIntervalSec', 'commandsEnabled', 'historyEnabled'));
            }
        } else {
            $traccar = $gpsManager->traccarForCompany($company);
            if (!$traccar->isConfigured()) {
                abort(403, ___('Traccar config is missing. Ask provider to set credentials.'));
            }
        }

        // superadmin bütün şirkətlərin maşınlarını görə bilər, amma komanda göndərmir
        $vehicleQuery = Vehicle::query()->whereNotNull($provider === 'wialon' ? 'wialon_device_id' : 'traccar_device_id');
        if (!$user->isSuperAdmin()) {
            if (!$user->company_id) abort(403);
            $vehicleQuery->where('company_id', $user->company_id);
        }

        $vehicles = $vehicleQuery
            ->orderBy('id', 'desc')
            ->get([
                'id','company_id','brand','model','year','plate_number','traccar_device_id','wialon_device_id',
                'rent_due_at',
            ]);

        $positions = [];
        $commandTypes = [];
        $showReturnDue = in_array($module, ['rentacar','taxipark'], true)
            || ($user->isSuperAdmin() && $vehicles->contains(fn($v) => (bool) $v->rent_due_at));

        foreach ($vehicles as $v) {
            $deviceId = (string) ($provider === 'wialon' ? $v->wialon_device_id : $v->traccar_device_id);

            if ($provider === 'wialon') {
                $wialon = $gpsManager->wialonForCompany($company);
                $pos = $wialon->getLastPosition($deviceId);
            } else {
                $traccar = $gpsManager->traccarForCompany($company);
                $pos = $traccar->getLastPosition($deviceId);
            }
            $rentRemaining = $showReturnDue ? $this->formatRemaining($v->rent_due_at) : null;
            if ($showReturnDue) {
                $v->rent_remaining = $rentRemaining;
            }

            if ($pos) {
                // + DEYİL -> array_merge: sağ tərəf overwrite edir
                $positions[] = array_merge($pos, [
                    'vehicle_id' => $v->id,
                    'name'       => $v->display_name,
                    'plate'      => $v->plate_number,
                    // istəsən markanı da ver:
                    'brand'      => $v->brand,
                    'model'      => $v->model,
                    'year'       => $v->year,
                    'company_id' => $v->company_id,
                    'rent_due_at' => $v->rent_due_at?->toDateTimeString(),
                    'rent_remaining' => $rentRemaining,
                ]);
            }

            // superadmin komanda göndərmir
            if ($provider === 'wialon') {
                if ($user->isSuperAdmin()) {
                    $commandTypes[$deviceId] = [];
                } else {
                    $list = $wialon->listCommandTypes($deviceId);
                    $commandTypes[$deviceId] = $this->filterCommandTypes($list, $gpsManager->allowedCommandsForCompany($company));
                }
            } else {
                $traccar = $gpsManager->traccarForCompany($company);
                if ($user->isSuperAdmin()) {
                    $commandTypes[$deviceId] = [];
                } else {
                    $list = $traccar->listCommandTypes($deviceId);
                    $commandTypes[$deviceId] = $this->filterCommandTypes($list, $gpsManager->allowedCommandsForCompany($company));
                }
            }
        }

        $wsUrl = null;
        $wsToken = null;
        $pollIntervalSec = (int) ($gpsManager->settingsForCompany($company)['api_poll_interval'] ?? 5);
        if ($pollIntervalSec < 3) $pollIntervalSec = 3;
        if ($pollIntervalSec > 300) $pollIntervalSec = 300;
        if ($provider !== 'wialon') {
            $traccar = $gpsManager->traccarForCompany($company);
            $wsUrl = $traccar->wsUrl();
            $wsToken = $traccar->token();
        }

        $commandsEnabled = $user->isSuperAdmin() ? true : $gpsManager->featureEnabled($company, 'commands');
        $historyEnabled = $user->isSuperAdmin() ? true : $gpsManager->featureEnabled($company, 'history');

        return view('vehicles.map', compact('vehicles', 'positions', 'wsUrl', 'wsToken', 'commandTypes', 'module', 'showReturnDue', 'provider', 'pollIntervalSec', 'commandsEnabled', 'historyEnabled'));
    }

    public function gpsPositions(Request $request, GpsManager $gpsManager)
    {
        $user = $request->user();
        if (!$user) abort(403);

        $company = $user->company;
        $provider = $gpsManager->providerForCompany($company);
        if (!$provider) {
            return response()->json(['error' => 'GPS provider is not connected.'], 422);
        }

        if ($provider === 'wialon' && !$user->isSuperAdmin()) {
            $wialon = $gpsManager->wialonForCompany($company);
            if (!$wialon->isConfigured()) {
                return response()->json(['error' => 'GPS is not configured.'], 422);
            }

            $units = $gpsManager->wialonUnitsForCompany($company);
            if (empty($units)) {
                return response()->json(['error' => 'No units available for this company.'], 404);
            }

            $positions = [];
            foreach ($units as $unit) {
                $deviceId = (string) ($unit['id'] ?? '');
                if ($deviceId === '' || $deviceId === '0') continue;
                $pos = $wialon->getLastPosition($deviceId);
                if ($pos) {
                    $positions[] = array_merge($pos, [
                        'vehicle_id' => null,
                        'name' => $unit['nm'] ?? $unit['name'] ?? ('Unit #' . $deviceId),
                        'plate' => $unit['uid'] ?? null,
                        'brand' => null,
                        'model' => null,
                        'year' => null,
                        'company_id' => null,
                        'rent_due_at' => null,
                        'rent_remaining' => null,
                    ]);
                }
            }

            return response()->json([
                'provider' => $provider,
                'positions' => $positions,
            ]);
        }

        $vehicleQuery = Vehicle::query()->whereNotNull($provider === 'wialon' ? 'wialon_device_id' : 'traccar_device_id');
        if (!$user->isSuperAdmin()) {
            if (!$user->company_id) abort(403);
            $vehicleQuery->where('company_id', $user->company_id);
        }

        $vehicles = $vehicleQuery
            ->orderBy('id', 'desc')
            ->get([
                'id','company_id','brand','model','year','plate_number','traccar_device_id','wialon_device_id','rent_due_at',
            ]);

        $positions = [];
        $showReturnDue = in_array($this->companyModule($user), ['rentacar','taxipark'], true)
            || ($user->isSuperAdmin() && $vehicles->contains(fn($v) => (bool) $v->rent_due_at));

        foreach ($vehicles as $v) {
            $deviceId = (string) ($provider === 'wialon' ? $v->wialon_device_id : $v->traccar_device_id);

            if ($provider === 'wialon') {
                $wialon = $gpsManager->wialonForCompany($company);
                $pos = $wialon->getLastPosition($deviceId);
            } else {
                $traccar = $gpsManager->traccarForCompany($company);
                $pos = $traccar->getLastPosition($deviceId);
            }

            if ($pos) {
                $positions[] = array_merge($pos, [
                    'vehicle_id' => $v->id,
                    'name'       => $v->display_name,
                    'plate'      => $v->plate_number,
                    'brand'      => $v->brand,
                    'model'      => $v->model,
                    'year'       => $v->year,
                    'company_id' => $v->company_id,
                    'rent_due_at' => $v->rent_due_at?->toDateTimeString(),
                    'rent_remaining' => $showReturnDue ? $this->formatRemaining($v->rent_due_at) : null,
                ]);
            }
        }

        return response()->json([
            'provider' => $provider,
            'positions' => $positions,
        ]);
    }

    public function gpsHistory(Request $request, GpsManager $gpsManager, string $unitId)
    {
        $user = $request->user();
        if (!$user?->company_id || $user->isSuperAdmin()) abort(403);

        $company = $user->company;
        $provider = $gpsManager->providerForCompany($company);
        if ($provider !== 'wialon') {
            return redirect()->route('vehicles.index')->withErrors(['gps' => 'History yalnız Wialon üçün aktivdir.']);
        }
        if (!$gpsManager->featureEnabled($company, 'history')) {
            return redirect()->route('company.gps')->withErrors(['gps' => 'History deaktiv edilib.']);
        }

        $allowedIds = $gpsManager->wialonUnitIdsForCompany($company);
        $unitIdInt = (int) $unitId;
        if (!in_array($unitIdInt, $allowedIds, true)) {
            return redirect()->route('company.gps')->withErrors(['gps' => 'Bu cihaz id-si şirkətə aid deyil.']);
        }

        $from = $request->query('from');
        $to = $request->query('to');
        $fromTs = $from ? strtotime($from . ' 00:00:00') : null;
        $toTs = $to ? strtotime($to . ' 23:59:59') : null;

        if (!$fromTs || !$toTs) {
            $toTs = time();
            $fromTs = $toTs - (24 * 60 * 60);
        }

        $wialon = $gpsManager->wialonForCompany($company);
        if (!$wialon->isConfigured()) {
            return redirect()->route('company.gps')->withErrors(['gps' => 'Wialon konfiqurasiya olunmayıb.']);
        }

        $messages = $wialon->loadMessagesInterval($unitIdInt, $fromTs, $toTs, 0);
        $points = [];
        foreach ($messages as $msg) {
            $pos = $msg['pos'] ?? $msg['position'] ?? null;
            if (!is_array($pos)) continue;

            $t = $msg['t'] ?? $pos['t'] ?? null;
            $points[] = [
                'time' => $t ? date('Y-m-d H:i:s', (int) $t) : null,
                'lat' => $pos['y'] ?? null,
                'lng' => $pos['x'] ?? null,
                'speed' => $pos['s'] ?? null,
            ];
        }

        return view('vehicles.gps_history', [
            'unitId' => $unitIdInt,
            'from' => date('Y-m-d', $fromTs),
            'to' => date('Y-m-d', $toTs),
            'points' => $points,
        ]);
    }

    public function gpsCommand(Request $request, GpsManager $gpsManager)
    {
        $user = $request->user();
        if (!$user?->company_id || $user->isSuperAdmin()) abort(403);

        $company = $user->company;
        $provider = $gpsManager->providerForCompany($company);
        if (!$provider) {
            return back()->withErrors(['command_type' => 'GPS provider is not connected.']);
        }

        $data = $request->validate([
            'device_id' => ['required','string','max:128'],
            'command_type' => ['required','string','max:64'],
            'attributes' => ['nullable','string'],
            'command_type_custom' => ['nullable','string','max:64'],
            'command_link_type' => ['nullable','string','max:16'],
            'command_param' => ['nullable','string','max:1000'],
            'command_timeout' => ['nullable','integer','min:1','max:600'],
            'command_flags' => ['nullable','integer','min:0','max:65535'],
            'command_name' => ['nullable','string','max:64'],
        ]);

        if ($provider === 'wialon') {
            $policy = $gpsManager->policyForCompany($company);
            if (!empty($policy['require_provider_approval'])) {
                return back()->withErrors(['command_type' => 'Komandalar üçün provayder təsdiqi tələb olunur.']);
            }
            if (!empty($policy['require_2fa'])) {
                return back()->withErrors(['command_type' => 'Komanda üçün 2FA tələb olunur.']);
            }

            $wialon = $gpsManager->wialonForCompany($company);
            if (!$wialon->isConfigured()) {
                return back()->withErrors(['command_type' => 'Wialon konfiqurasiya olunmayıb.']);
            }
            $allowedIds = $gpsManager->wialonUnitIdsForCompany($company);
            if (!in_array((int) $data['device_id'], $allowedIds, true)) {
                return back()->withErrors(['device_id' => 'Bu cihaz id-si şirkətə aid deyil.']);
            }

            $commandType = $data['command_type'] === 'custom'
                ? trim((string) $data['command_type_custom'])
                : $data['command_type'];
            if ($commandType === '') {
                return back()->withErrors(['command_type' => 'Komanda tipi boş ola bilməz.']);
            }

            $blockedCommands = $gpsManager->blockedCommandsForCompany($company);
            if (!empty($blockedCommands) && in_array(strtolower($commandType), $blockedCommands, true)) {
                return back()->withErrors(['command_type' => 'Komanda blocklist-dədir.']);
            }

            $linkType = trim((string) ($data['command_link_type'] ?? ''));
            $param = (string) ($data['command_param'] ?? '');
            $timeout = (int) ($data['command_timeout'] ?? 60);
            $flags = (int) ($data['command_flags'] ?? 0);
            $commandName = trim((string) ($data['command_name'] ?? ''));

            if (!empty($data['attributes'])) {
                $decoded = json_decode($data['attributes'], true);
                if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                    return back()->withErrors(['attributes' => 'Attributes JSON formatında olmalıdır.']);
                }
                if (is_array($decoded)) {
                    $linkType = $decoded['linkType'] ?? $decoded['link_type'] ?? $linkType;
                    $param = $decoded['param'] ?? $param;
                    $timeout = (int) ($decoded['timeout'] ?? $timeout);
                    $flags = (int) ($decoded['flags'] ?? $flags);
                    $commandName = $decoded['commandName'] ?? $decoded['command_name'] ?? $commandName;
                }
            }

            if (is_array($param)) {
                $param = json_encode($param, JSON_UNESCAPED_UNICODE);
                $flags = $flags | 0x10;
            }

            $ok = $wialon->sendCommand($data['device_id'], $commandType, (string) $linkType, (string) $param, $timeout, $flags, $commandName ?: null);
            if (!$ok) {
                return back()->withErrors(['command_type' => 'Komanda göndərilmədi.']);
            }

            return back()->with('status', 'Komanda göndərildi.');
        }

        $traccar = $gpsManager->traccarForCompany($company);
        if (!$traccar->isConfigured()) {
            return back()->withErrors(['command_type' => 'Traccar konfiqurasiya olunmayıb.']);
        }

        $vehicle = Vehicle::where('company_id', $user->company_id)
            ->where('traccar_device_id', $data['device_id'])
            ->first();
        if (!$vehicle) {
            return back()->withErrors(['device_id' => 'Bu cihaz id-si şirkətə aid deyil.']);
        }

        $attributes = [];
        if (!empty($data['attributes'])) {
            $decoded = json_decode($data['attributes'], true);
            if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                return back()->withErrors(['attributes' => 'Attributes JSON formatında olmalıdır.']);
            }
            if (is_array($decoded)) {
                $attributes = $decoded;
            }
        }

        $blockedCommands = $gpsManager->blockedCommandsForCompany($company);
        if (!empty($blockedCommands) && in_array(strtolower($data['command_type']), $blockedCommands, true)) {
            return back()->withErrors(['command_type' => 'Komanda blocklist-dədir.']);
        }

        $ok = $traccar->sendCommand($data['device_id'], $data['command_type'], $attributes);
        if (!$ok) {
            return back()->withErrors(['command_type' => 'Komanda göndərilmədi.']);
        }

        return back()->with('status', 'Komanda göndərildi.');
    }

    public function sendCommand(Request $request, Vehicle $vehicle, GpsManager $gpsManager)
    {
        $user = $request->user();
        if (!$user) abort(403);

        if ($user->isSuperAdmin()) abort(403);
        if ((int) $vehicle->company_id !== (int) $user->company_id) {
            abort(404);
        }

        $company = $user->company;
        $provider = $gpsManager->providerForCompany($company);
        if (!$provider) {
            return redirect()->back()->withErrors(['command_type' => 'GPS provider is not connected.']);
        }
        if ($provider === 'wialon') {
            $policy = $gpsManager->policyForCompany($company);
            if (!empty($policy['require_provider_approval'])) {
                return redirect()->back()->withErrors(['command_type' => 'Komandalar üçün provayder təsdiqi tələb olunur.']);
            }
            if (!empty($policy['require_2fa'])) {
                return redirect()->back()->withErrors(['command_type' => 'Komanda üçün 2FA tələb olunur.']);
            }

            $wialon = $gpsManager->wialonForCompany($company);
            if (!$vehicle->wialon_device_id || !$wialon->isConfigured()) {
                return redirect()->back()->withErrors(['command_type' => 'Wialon konfiqurasiya olunmayıb və ya unit ID boşdur.']);
            }
        }

        $traccar = $gpsManager->traccarForCompany($company);
        $data = $request->validate([
            'command_type' => ['required','string','max:64'],
            'attributes' => ['nullable','string'],
            'command_type_custom' => ['nullable','string','max:64'],
            'command_link_type' => ['nullable','string','max:16'],
            'command_param' => ['nullable','string','max:1000'],
            'command_timeout' => ['nullable','integer','min:1','max:600'],
            'command_flags' => ['nullable','integer','min:0','max:65535'],
            'command_name' => ['nullable','string','max:64'],
        ]);

        if ($provider === 'wialon') {
            $commandType = $data['command_type'] === 'custom'
                ? trim((string) $data['command_type_custom'])
                : $data['command_type'];
            if ($commandType === '') {
                return redirect()->back()->withErrors(['command_type' => 'Komanda tipi boş ola bilməz.']);
            }

            $blockedCommands = $gpsManager->blockedCommandsForCompany($company);
            if (!empty($blockedCommands) && in_array(strtolower($commandType), $blockedCommands, true)) {
                return redirect()->back()->withErrors(['command_type' => 'Komanda blocklist-dədir.']);
            }

            $linkType = trim((string) ($data['command_link_type'] ?? ''));
            $param = (string) ($data['command_param'] ?? '');
            $timeout = (int) ($data['command_timeout'] ?? 60);
            $flags = (int) ($data['command_flags'] ?? 0);
            $commandName = trim((string) ($data['command_name'] ?? ''));

            if (!empty($data['attributes'])) {
                $decoded = json_decode($data['attributes'], true);
                if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                    return redirect()->back()->withErrors(['attributes' => 'Attributes JSON formatında olmalıdır.']);
                }
                if (is_array($decoded)) {
                    $linkType = $decoded['linkType'] ?? $decoded['link_type'] ?? $linkType;
                    $param = $decoded['param'] ?? $param;
                    $timeout = (int) ($decoded['timeout'] ?? $timeout);
                    $flags = (int) ($decoded['flags'] ?? $flags);
                    $commandName = $decoded['commandName'] ?? $decoded['command_name'] ?? $commandName;
                }
            }

            if (is_array($param)) {
                $param = json_encode($param, JSON_UNESCAPED_UNICODE);
                $flags = $flags | 0x10;
            }

            $ok = $wialon->sendCommand($vehicle->wialon_device_id, $commandType, (string) $linkType, (string) $param, $timeout, $flags, $commandName ?: null);
            if (!$ok) {
                return redirect()->back()->withErrors(['command_type' => 'Komanda göndərmək alınmadı.']);
            }

            return redirect()->back()->with('status', 'Komanda göndərildi.');
        }

        if (!$vehicle->traccar_device_id || !$traccar->isConfigured()) {
            return redirect()->back()->withErrors(['command_type' => 'Traccar konfiqurasiya olunmayıb və ya device ID boşdur.']);
        }

        $attributes = [];
        if (!empty($data['attributes'])) {
            $decoded = json_decode($data['attributes'], true);
            if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                return redirect()->back()->withErrors(['attributes' => 'Attributes JSON formatında olmalıdır.']);
            }
            if (is_array($decoded)) {
                $attributes = $decoded;
            }
        }

        $blockedCommands = $gpsManager->blockedCommandsForCompany($company);
        if (!empty($blockedCommands) && in_array(strtolower($data['command_type']), $blockedCommands, true)) {
            return redirect()->back()->withErrors(['command_type' => 'Komanda blocklist-dədir.']);
        }

        $ok = $traccar->sendCommand($vehicle->traccar_device_id, $data['command_type'], $attributes);

        if (!$ok) {
            return redirect()->back()->withErrors(['command_type' => 'Komanda göndərmək alınmadı.']);
        }

        return redirect()->back()->with('status', 'Komanda göndərildi.');
    }
}
