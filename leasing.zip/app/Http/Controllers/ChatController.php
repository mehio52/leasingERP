<?php

namespace App\Http\Controllers;

use App\Events\ChatMessageCreated;
use App\Models\ChatMessage;
use App\Models\ChatRoom;
use App\Models\User;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $rooms = $user->chatRooms()->with('users')->orderByDesc('id')->get();
        // default company room
        $defaultRoom = ChatRoom::firstOrCreate(
            ['company_id' => $user->company_id, 'is_group' => true, 'name' => 'Company chat'],
            ['created_by' => $user->id]
        );
        if (!$rooms->contains('id', $defaultRoom->id)) {
            $user->chatRooms()->syncWithoutDetaching([$defaultRoom->id]);
            $rooms->prepend($defaultRoom);
        }

        $activeRoom = $rooms->first();
        $messages = $activeRoom
            ? ChatMessage::where('chat_room_id', $activeRoom->id)->with('user')->latest()->limit(50)->get()->reverse()->values()
            : collect();

        return view('chat.index', compact('rooms', 'activeRoom', 'messages'));
    }

    public function messages(Request $request, ChatRoom $room)
    {
        $user = $request->user();
        abort_unless($user, 403);
        if (!$room->users()->where('user_id', $user->id)->exists()) abort(403);

        $messages = ChatMessage::where('chat_room_id', $room->id)
            ->with('user')
            ->latest()
            ->limit(100)
            ->get()
            ->reverse()
            ->values()
            ->map(function ($m) {
                return [
                    'id' => $m->id,
                    'chat_room_id' => $m->chat_room_id,
                    'user_id' => $m->user_id,
                    'user_name' => $m->user?->full_name,
                    'message' => $m->message,
                    'created_at' => optional($m->created_at)->toIso8601String(),
                ];
            });
        return response()->json($messages);
    }

    public function storeMessage(Request $request, ChatRoom $room)
    {
        $user = $request->user();
        abort_unless($user, 403);
        if (!$room->users()->where('user_id', $user->id)->exists()) abort(403);

        $data = $request->validate([
            'message' => ['required','string','max:2000'],
        ]);

        $msg = new ChatMessage();
        $msg->chat_room_id = $room->id;
        $msg->user_id = $user->id;
        $msg->message = $data['message'];
        $msg->save();

        $msg->load('user');
        ChatMessageCreated::dispatch($msg);

        return response()->json([
            'status' => 'ok',
            'id' => $msg->id,
            'user_name' => $msg->user?->full_name,
            'created_at' => optional($msg->created_at)->toIso8601String(),
        ]);
    }

    public function defaultRoom(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);
        $room = ChatRoom::firstOrCreate(
            ['company_id' => $user->company_id, 'is_group' => false, 'name' => 'Company chat'],
            ['created_by' => $user->id]
        );
        $user->chatRooms()->syncWithoutDetaching([$room->id]);
        return response()->json(['room_id' => $room->id]);
    }

    public function contacts(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);
        $users = $user->company?->users()
            ->where('id', '!=', $user->id)
            ->orderBy('first_name')
            ->get(['id','first_name','last_name'])
            ->map(fn($u) => [
                'id' => $u->id,
                'name' => trim($u->first_name.' '.$u->last_name),
            ]);
        return response()->json($users);
    }

    public function directRoom(Request $request, User $target)
    {
        $user = $request->user();
        abort_unless($user, 403);
        if ((int)$target->company_id !== (int)$user->company_id) {
            abort(403);
        }

        // Find existing direct room
        $room = ChatRoom::where('company_id', $user->company_id)
            ->where('is_group', false)
            ->where('name', '<>', 'Company chat')
            ->whereHas('users', fn($q) => $q->where('user_id', $user->id))
            ->whereHas('users', fn($q) => $q->where('user_id', $target->id))
            ->first();

        if (!$room) {
            $room = ChatRoom::create([
                'company_id' => $user->company_id,
                'name' => $target->full_name ?? ('User #'.$target->id),
                'is_group' => false,
                'created_by' => $user->id,
            ]);
            $room->users()->sync([$user->id, $target->id]);
        } else {
            $room->users()->syncWithoutDetaching([$user->id, $target->id]);
        }

        return response()->json(['room_id' => $room->id, 'name' => $room->name]);
    }
}
