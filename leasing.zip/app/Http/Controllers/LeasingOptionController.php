<?php

namespace App\Http\Controllers;

use App\Models\LeasingOption;
use Illuminate\Http\Request;

class LeasingOptionController extends Controller
{
    public function edit(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'User şirkətə bağlı deyil.');
        }

        $options = LeasingOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            [
                'amortization_method' => LeasingOption::AMORT_ANNUITY,
                'payment_frequency'   => LeasingOption::FREQ_MONTHLY,
                'allocation_order'    => LeasingOption::ALLOC_INTEREST_FIRST,
                'grace_days'          => 0,
                'late_fee_type'       => LeasingOption::LATE_FEE_NONE,
                'late_fee_value'      => 0,
                'rounding_step'       => 0.01,
                'allow_partial_payments' => true,
                'settings'            => [],
            ]
        );

        return view('leasing_options.edit', compact('user', 'options'));
    }

    public function update(Request $request)
    {
        $user = $request->user();
        $companyId = $user?->company_id;

        if (!$companyId) {
            abort(403, 'User şirkətə bağlı deyil.');
        }

        $options = LeasingOption::query()->firstOrCreate(
            ['company_id' => $companyId],
            [
                'amortization_method' => LeasingOption::AMORT_ANNUITY,
                'payment_frequency'   => LeasingOption::FREQ_MONTHLY,
                'allocation_order'    => LeasingOption::ALLOC_INTEREST_FIRST,
                'grace_days'          => 0,
                'late_fee_type'       => LeasingOption::LATE_FEE_NONE,
                'late_fee_value'      => 0,
                'rounding_step'       => 0.01,
                'allow_partial_payments' => true,
                'settings'            => [],
            ]
        );

        $validated = $request->validate([
            'amortization_method' => ['required', 'in:'.implode(',', [
                LeasingOption::AMORT_REDUCING_BALANCE,
                LeasingOption::AMORT_ANNUITY,
                LeasingOption::AMORT_FLAT,
            ])],
            'payment_frequency' => ['required', 'in:'.implode(',', [
                LeasingOption::FREQ_MONTHLY,
                LeasingOption::FREQ_WEEKLY,
                LeasingOption::FREQ_BIWEEKLY,
            ])],
            'allocation_order' => ['required', 'in:'.implode(',', [
                LeasingOption::ALLOC_INTEREST_FIRST,
                LeasingOption::ALLOC_PRINCIPAL_FIRST,
            ])],

            'grace_days' => ['nullable','integer','min:0','max:365'],

            'late_fee_type' => ['required', 'in:'.implode(',', [
                LeasingOption::LATE_FEE_NONE,
                LeasingOption::LATE_FEE_FIXED,
                LeasingOption::LATE_FEE_PERCENT,
            ])],
            'late_fee_value' => ['nullable','numeric','min:0','max:1000000'],

            'rounding_step' => ['nullable','numeric','min:0','max:100'],

            'allow_partial_payments' => ['nullable','boolean'],
            'notes' => ['nullable','string','max:2000'],

            // settings key/value rows
            'settings_k' => ['nullable','array'],
            'settings_k.*' => ['nullable','string','max:190'],
            'settings_v' => ['nullable','array'],
            'settings_v.*' => ['nullable','string','max:2000'],
        ]);

        // checkbox fix
        $validated['allow_partial_payments'] = (bool) $request->input('allow_partial_payments', false);

        // late_fee_value logic
        if (($validated['late_fee_type'] ?? LeasingOption::LATE_FEE_NONE) === LeasingOption::LATE_FEE_NONE) {
            $validated['late_fee_value'] = 0;
        } else {
            if (!isset($validated['late_fee_value'])) {
                $validated['late_fee_value'] = 0;
            }
        }

        // normalize settings => assoc
        $settings = [];
        $keys = $request->input('settings_k', []);
        $vals = $request->input('settings_v', []);

        if (is_array($keys) && is_array($vals)) {
            foreach ($keys as $i => $k) {
                $k = trim((string)$k);
                if ($k === '') continue;
                $settings[$k] = (string)($vals[$i] ?? '');
            }
        }

        $validated['company_id'] = $companyId;

        $options->fill($validated);
        $options->settings = $settings ?: null;
        $options->save();

        return redirect()
            ->route('company.leasing_options.edit')
            ->with('status', 'Leasing options yadda saxlanıldı.');
    }
}