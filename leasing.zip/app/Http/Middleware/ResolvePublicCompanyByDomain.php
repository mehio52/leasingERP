<?php

namespace App\Http\Middleware;

use App\Models\CompanyDomainRequest;
use Closure;
use Illuminate\Http\Request;

class ResolvePublicCompanyByDomain
{
    public function handle(Request $request, Closure $next)
    {
        $host = strtolower((string) $request->getHost());
        $host = preg_replace('/^www\./', '', $host);

        $domainRequest = CompanyDomainRequest::query()
            ->with('company')
            ->where('requested_domain', $host)
            ->where('status', CompanyDomainRequest::STATUS_APPROVED)
            ->where('is_active', true)
            ->latest('id')
            ->first();

        $company = $domainRequest?->company;
        if (!$company || !$company->public_enabled) {
            abort(404);
        }

        if (!$company->is_active || $company->suspended_at) {
            abort(404);
        }

        if (!$company->isTrialActive() && !$company->isSubscriptionActive()) {
            abort(404);
        }

        $request->attributes->set('public_company', $company);
        $request->attributes->set('public_domain_request', $domainRequest);

        return $next($request);
    }
}
