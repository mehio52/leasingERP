<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    protected $except = [
        'register-company*',
        'login*',
        'logout*',
        'epoint/result',
        'epoint/success',
        'epoint/error',
        'iyzico/callback',
        'stripe/webhook',
    ];

}
