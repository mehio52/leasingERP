<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureHasPermission
{
    public function handle(Request $request, Closure $next, ...$perms)
    {
        $u = $request->user();
        if (!$u) abort(403);

        // owner hər şeyə icazəlidir
        if ($u->is_owner || $u->role === 'owner') {
            return $next($request);
        }

        // perm param-ları comma ilə gəlir: perm:a,b,c
        // əlavə olaraq "OR" üçün pipe də dəstəkləyək: perm:a|b
        $flat = [];
        foreach ($perms as $p) {
            foreach (preg_split('/\|/', (string)$p) as $one) {
                $one = trim($one);
                if ($one !== '') $flat[] = $one;
            }
        }

        // Heç bir perm verilməyibsə default block
        if (count($flat) === 0) {
            abort(403, 'Permission tələb olunur.');
        }

        // OR məntiqi: verilənlərdən ən azı biri varsa burax
        foreach ($flat as $perm) {
            if ($u->hasPermission($perm)) {
                return $next($request);
            }
        }

        abort(403, 'Bu əməliyyat üçün icazən yoxdur.');
    }
}