<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureGpsProviderUser
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        if (!$user) {
            abort(403);
        }

        if (!$user->gps_provider_id) {
            abort(403, 'GPS provider access only.');
        }

        if (!in_array($user->role, ['gps_provider_admin', 'gps_provider_staff'], true)) {
            abort(403, 'GPS provider role is required.');
        }

        return $next($request);
    }
}
