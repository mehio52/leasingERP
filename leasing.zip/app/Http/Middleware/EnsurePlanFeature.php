<?php

namespace App\Http\Middleware;

use App\Services\SubscriptionService;
use Closure;
use Illuminate\Http\Request;

class EnsurePlanFeature
{
    public function __construct(private SubscriptionService $subscriptions)
    {
    }

    public function handle(Request $request, Closure $next, ...$features)
    {
        $user = $request->user();
        if (!$user) abort(403);

        if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) {
            return $next($request);
        }

        $company = $user->company;
        if (!$company) abort(403);

        $flat = [];
        foreach ($features as $group) {
            foreach (preg_split('/\|/', (string) $group) as $one) {
                $one = trim($one);
                if ($one !== '') $flat[] = $one;
            }
        }

        if (empty($flat)) {
            return $next($request);
        }

        // Əlavələr (addons) planı olmasa da xassəni aça bilər
        $addonFeatures = $this->subscriptions->activeAddonFeatures($company);
        foreach ($flat as $feature) {
            if (!empty($addonFeatures[$feature])) {
                return $next($request);
            }
        }

        if ($this->subscriptions->featuresAreUnlimited($company)) {
            return $next($request);
        }

        foreach ($flat as $feature) {
            if ($this->subscriptions->hasFeature($company, $feature)) {
                return $next($request);
            }
        }

        abort(403, ___('Your plan does not allow this action.'));
    }
}
