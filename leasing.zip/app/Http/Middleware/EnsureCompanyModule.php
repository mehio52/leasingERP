<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureCompanyModule
{
    public function handle(Request $request, Closure $next, ...$modules)
    {
        $user = $request->user();
        if (!$user) {
            abort(403);
        }

        if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) {
            return $next($request);
        }

        $company = $user->company;
        if (!$company) {
            abort(403);
        }

        $flat = [];
        foreach ($modules as $group) {
            foreach (preg_split('/\|/', (string) $group) as $one) {
                $one = trim($one);
                if ($one !== '') {
                    $flat[] = strtolower($one);
                }
            }
        }

        if (empty($flat)) {
            return $next($request);
        }

        $current = method_exists($company, 'moduleCode')
            ? $company->moduleCode()
            : strtolower(trim((string) ($company->module ?? 'leasing')));

        if (in_array($current, $flat, true)) {
            return $next($request);
        }

        abort(403, ___('Your company module does not allow this action.'));
    }
}
