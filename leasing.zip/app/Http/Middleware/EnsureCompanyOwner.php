<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureCompanyOwner
{
    public function handle(Request $request, Closure $next)
    {
        $u = $request->user();
        if (!$u) abort(403);

        if (!($u->is_owner || $u->role === 'owner')) {
            abort(403, 'Bu bölməyə yalnız owner daxil ola bilər.');
        }

        return $next($request);
    }
}