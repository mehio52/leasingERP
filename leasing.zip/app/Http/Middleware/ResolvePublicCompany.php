<?php

namespace App\Http\Middleware;

use App\Models\Company;
use Closure;
use Illuminate\Http\Request;

class ResolvePublicCompany
{
    public function handle(Request $request, Closure $next)
    {
        $slug = $request->route('companySlug');
        if (!$slug) {
            abort(404);
        }

        $company = Company::where('slug', $slug)->first();
        if (!$company || !$company->public_enabled) {
            abort(404);
        }

        $request->attributes->set('public_company', $company);

        return $next($request);
    }
}
