<?php

namespace App\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Support\Facades\Auth;

class TenantScope implements Scope
{
    public function apply(Builder $builder, Model $model): void
    {
        // CRITICAL: Auth::check() YOX! (recursion yaradır)
        if (!Auth::hasUser()) {
            return;
        }

        $user = Auth::user();
        $companyId = $user?->company_id;

        // superadmin ƒ?ƒƒ?n tenant filteri tetbiq etm‰Tik
        if ((method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) || ($user?->role ?? null) === 'superadmin') {
            return;
        }

        if (!$companyId) {
            return;
        }

        $builder->where($model->getTable() . '.company_id', $companyId);
    }
}
