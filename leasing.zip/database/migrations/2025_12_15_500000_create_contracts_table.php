<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('contracts', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            $table->foreignId('customer_id')
                ->constrained('customers')
                ->cascadeOnDelete();

            $table->foreignId('vehicle_id')
                ->constrained('vehicles')
                ->cascadeOnDelete();

            // BHPH Account ID (görünsün deyə)
            // Qeyd: bhph_accounts-da contract_id FK var deyə burada FK vermirik (circular olur)
            $table->unsignedBigInteger('bhph_account_id')->nullable();
            $table->unique(['company_id', 'bhph_account_id'], 'contracts_company_bhph_unique');
            $table->index(['company_id', 'bhph_account_id']);

            // Müqavilə nömrəsi (şirkət daxilində unikal)
            $table->string('contract_no', 64);
            $table->unique(['company_id', 'contract_no'], 'contracts_company_no_unique');

            // Satıcı (user)
            $table->foreignId('seller_user_id')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            // Tarixlər
            $table->date('signed_date')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();

            // Status
            $table->string('status', 16)->default('active');
            // active | closed | cancelled

            $table->timestamps();

            $table->index(['company_id', 'status']);
            $table->index(['company_id', 'customer_id']);
            $table->index(['company_id', 'vehicle_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contracts');
    }
};