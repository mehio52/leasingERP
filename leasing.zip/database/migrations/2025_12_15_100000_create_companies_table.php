<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->id();

            // ========== CORE TENANT INFO ==========
            $table->string('name');                         // Şirkət adı
            $table->string('legal_name')->nullable();       // Hüquqi ad
            $table->string('slug')->unique();               // tenant kodu: "abc-leasing"
            $table->string('domain')->nullable()->unique(); // subdomain/domain (opsional)

            // ========== CONTACT ==========
            $table->string('email')->nullable();
            $table->string('phone', 32)->unique();
            $table->string('address')->nullable();

            // ========== LEGAL / TAX ==========
            $table->string('voen', 32)->nullable();          // şirkət VÖEN
            $table->string('bank_account')->nullable();      // IBAN / hesab
            $table->string('bank_name')->nullable();

            // ========== SaaS STATUS ==========
            $table->boolean('is_active')->default(true);
            $table->timestamp('suspended_at')->nullable();   // bloklanma vaxtı
            $table->string('suspend_reason')->nullable();

            // ========== TRIAL / PLAN SNAPSHOT ==========
            // (Sonra subscriptions cədvəli qursaq belə, bunu saxlayıb sürətli check edə bilərsən)
            $table->string('plan_code')->nullable();         // "trial", "basic", "pro" və s.
            $table->timestamp('trial_ends_at')->nullable();
            $table->timestamp('subscription_ends_at')->nullable(); // manual/temporary

            // ========== LOCALIZATION ==========
            $table->string('timezone')->default('Asia/Baku');
            $table->string('locale', 8)->default('az');
            $table->string('currency', 8)->default('AZN');

            // ========== BRANDING ==========
            $table->string('logo_path')->nullable();
            $table->string('primary_color', 16)->nullable();

            // ========== SETTINGS / LIMITS ==========
            $table->json('settings')->nullable(); // ümumi config (SMS gateway keys, etc.)
            $table->json('limits')->nullable();   // paket limitləri: customers, contracts, users...

            $table->timestamps();

            $table->index(['is_active', 'trial_ends_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('companies');
    }
};