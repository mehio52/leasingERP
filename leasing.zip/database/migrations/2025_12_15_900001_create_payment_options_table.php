<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('payment_options', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            // Şirkət ödənişlərin ödəniş sistemi (payment gateway) vasitəsi ilə edilməsinə razıdır?
            $table->boolean('allow_payment_gateway')->default(false);

            // Əsas davranışlar
            $table->boolean('allow_overpayment')->default(true);            // aylıq ödənişdən çox ödəmək
            $table->boolean('allow_partial_payment')->default(true);        // hissə-hissə ödəmək
            $table->boolean('allow_principal_only_payment')->default(true); // yalnız əsas borca ödəmək

            // Ödəniş tətbiq qaydaları
            $table->string('apply_to', 24)->default('oldest_due_first');
            // oldest_due_first | current_due_only | newest_first

            $table->string('allocation_order', 24)->default('interest_then_principal');
            // interest_then_principal | principal_then_interest

            // Artıq ödəniş (overpayment) nə olsun
            $table->string('overpayment_behavior', 24)->default('keep_as_credit');
            // keep_as_credit | reduce_principal | apply_next_installments

            // Gələcək taksitləri qabaqcadan ödəmək
            $table->boolean('allow_advance_payment')->default(true);

            // Minimum qaydalar (opsional)
            $table->decimal('min_partial_payment_amount', 12, 2)->nullable(); // minimum hissə ödəniş
            $table->decimal('min_overpayment_amount', 12, 2)->nullable();     // minimum artıq ödəniş

            // Qeydlər və genişlənən settings
            $table->text('notes')->nullable();
            $table->json('settings')->nullable();

            $table->timestamps();

            // Hər şirkət üçün 1 sətir
            $table->unique('company_id', 'payment_options_company_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_options');
    }
};