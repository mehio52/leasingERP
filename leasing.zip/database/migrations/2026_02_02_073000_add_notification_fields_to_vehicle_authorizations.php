<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicle_authorizations', function (Blueprint $table) {
            $table->timestamp('last_notified_at')->nullable()->after('created_by');
            $table->unsignedInteger('last_notified_days')->nullable()->after('last_notified_at');
            $table->index(['end_date', 'last_notified_days']);
        });
    }

    public function down(): void
    {
        Schema::table('vehicle_authorizations', function (Blueprint $table) {
            $table->dropIndex(['end_date', 'last_notified_days']);
            $table->dropColumn(['last_notified_at', 'last_notified_days']);
        });
    }
};
