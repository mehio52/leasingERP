<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->string('address')->nullable()->after('phone');
            $table->date('id_card_issue_date')->nullable()->after('id_card_number');
            $table->string('id_card_authority')->nullable()->after('id_card_issue_date');
            $table->text('bank_details')->nullable()->after('voen');
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->string('seller_fin', 32)->nullable()->after('seller_id_number');
            $table->date('seller_id_issue_date')->nullable()->after('seller_fin');
            $table->string('seller_id_authority')->nullable()->after('seller_id_issue_date');
        });

        Schema::table('bhph_accounts', function (Blueprint $table) {
            $table->json('document_metadata')->nullable()->after('remaining_amount');
            $table->string('third_party_seller_fullname')->nullable()->after('seller_user_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->dropColumn(['address', 'id_card_issue_date', 'id_card_authority', 'bank_details']);
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn(['seller_fin', 'seller_id_issue_date', 'seller_id_authority']);
        });

        Schema::table('bhph_accounts', function (Blueprint $table) {
            $table->dropColumn(['document_metadata', 'third_party_seller_fullname']);
        });
    }
};
