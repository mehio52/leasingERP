<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('notification_options', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->unique();
            $table->boolean('is_active')->default(false);
            $table->string('wp_api_url')->nullable();
            $table->string('wp_api_key')->nullable();
            $table->string('wp_api_secret')->nullable();
            $table->string('sender_label')->nullable();
            $table->text('template_due_soon')->nullable();
            $table->text('template_overdue')->nullable();
            $table->text('template_penalty_applied')->nullable();
            $table->json('settings')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notification_options');
    }
};
