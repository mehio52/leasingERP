<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();

            $table->string('first_name');           // Ad
            $table->string('last_name');            // Soyad
            $table->string('father_name')->nullable(); // Ata adı (bəzən boş olur)

            $table->string('phone', 32)->uniuque();            // Nömrə
            $table->string('voen', 32)->nullable(); // VÖEN (null ola bilər)

            // Şəxsiyyət vəsiqəsi (format şirkətə görə dəyişir, ona görə string saxla)
            $table->string('id_card_number', 64)->nullable();   // AA1234567 kimi
            $table->string('fin_code', 16)->nullable();         // FIN

            // Sürücülük vəsiqəsi
            $table->string('driver_license_number', 64)->nullable();
            $table->string('driver_license_category', 16)->nullable(); // məsələn: B, C, D...

            $table->date('birth_date')->nullable();

            $table->timestamps();

            // Eyni şirkətdə eyni FIN təkrar olmasın (istəsən aktiv edərik)
            $table->unique(['company_id', 'fin_code']);
            // Eyni şirkətdə eyni nömrə təkrar olmasın (istəsən aktiv edərik)
            $table->index(['company_id', 'phone']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('customers');
    }
};