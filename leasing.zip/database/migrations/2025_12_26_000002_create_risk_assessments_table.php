<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('risk_assessments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->index();
            $table->foreignId('created_by')->index();
            $table->decimal('monthly_income', 12, 2)->default(0);
            $table->decimal('existing_monthly_debt', 12, 2)->default(0);
            $table->decimal('requested_monthly_payment', 12, 2)->default(0);
            $table->smallInteger('job_months')->default(0);
            $table->json('factors')->nullable();
            $table->json('adjustments')->nullable();
            $table->smallInteger('score')->default(0);
            $table->string('risk_band', 8)->default('D');
            $table->decimal('max_allowed_payment', 12, 2)->default(0);
            $table->json('explain')->nullable();
            $table->timestamps();

            $table->index(['company_id', 'risk_band']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('risk_assessments');
    }
};
