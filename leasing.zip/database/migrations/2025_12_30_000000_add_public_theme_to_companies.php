<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->string('public_theme')->nullable()->after('logo_path');
            $table->boolean('public_enabled')->default(false)->after('public_theme');
            $table->json('public_settings')->nullable()->after('public_enabled');
        });
    }

    public function down(): void
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropColumn(['public_theme','public_enabled','public_settings']);
        });
    }
};
