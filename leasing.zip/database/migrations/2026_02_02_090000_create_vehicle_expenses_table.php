<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vehicle_expenses', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('vehicle_id')->index();
            $table->string('category', 32)->default('other')->index();
            $table->string('title', 255)->nullable();
            $table->text('details')->nullable();
            $table->decimal('amount', 14, 2)->default(0);
            $table->date('expense_date')->index();
            $table->string('vendor', 255)->nullable();
            $table->unsignedBigInteger('created_by')->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vehicle_expenses');
    }
};
