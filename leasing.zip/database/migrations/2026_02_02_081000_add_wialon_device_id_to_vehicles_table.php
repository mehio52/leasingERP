﻿<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            if (!Schema::hasColumn('vehicles', 'wialon_device_id')) {
                $table->string('wialon_device_id', 128)->nullable()->after('traccar_device_id');
                $table->index('wialon_device_id');
            }
        });
    }

    public function down(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            if (Schema::hasColumn('vehicles', 'wialon_device_id')) {
                $table->dropIndex(['wialon_device_id']);
                $table->dropColumn('wialon_device_id');
            }
        });
    }
};
