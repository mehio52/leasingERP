<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('plans', function (Blueprint $table) {
            if (!Schema::hasColumn('plans', 'module')) {
                $table->string('module', 16)->default('leasing')->after('code');
                $table->index(['module', 'is_active'], 'plans_module_active_index');
            }
        });

        Schema::table('addons', function (Blueprint $table) {
            if (!Schema::hasColumn('addons', 'module')) {
                $table->string('module', 16)->default('leasing')->after('code');
                $table->index(['module', 'is_active'], 'addons_module_active_index');
            }
        });
    }

    public function down(): void
    {
        Schema::table('plans', function (Blueprint $table) {
            if (Schema::hasColumn('plans', 'module')) {
                $table->dropIndex('plans_module_active_index');
                $table->dropColumn('module');
            }
        });

        Schema::table('addons', function (Blueprint $table) {
            if (Schema::hasColumn('addons', 'module')) {
                $table->dropIndex('addons_module_active_index');
                $table->dropColumn('module');
            }
        });
    }
};
