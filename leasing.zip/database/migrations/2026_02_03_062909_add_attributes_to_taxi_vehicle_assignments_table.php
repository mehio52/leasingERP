<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('taxi_vehicle_assignments', function (Blueprint $table) {
            if (!Schema::hasColumn('taxi_vehicle_assignments', 'attributes')) {
                $table->json('attributes')->nullable()->after('addons');
            }
        });
    }

    public function down(): void
    {
        Schema::table('taxi_vehicle_assignments', function (Blueprint $table) {
            if (Schema::hasColumn('taxi_vehicle_assignments', 'attributes')) {
                $table->dropColumn('attributes');
            }
        });
    }
};
