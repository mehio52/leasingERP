<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('company_rental_addons', function (Blueprint $table) {
            $table->unsignedInteger('quantity')->default(0)->after('billing_type');
        });
    }

    public function down(): void
    {
        Schema::table('company_rental_addons', function (Blueprint $table) {
            $table->dropColumn('quantity');
        });
    }
};
