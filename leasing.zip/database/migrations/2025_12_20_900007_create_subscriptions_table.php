<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();

            // Plan silinsə tarixçə qalsın deyə nullOnDelete
            $table->foreignId('plan_id')->nullable()->constrained('plans')->nullOnDelete();

            $table->string('status', 16)->default('trial');
            // trial | active | past_due | cancelled | expired

            $table->string('billing_period', 16)->default('monthly');
            // monthly | yearly

            $table->timestamp('starts_at')->nullable();
            $table->timestamp('trial_ends_at')->nullable();
            $table->timestamp('ends_at')->nullable();       // bitmə tarixi (active abonəlikdə gələcəkdə dolacaq)
            $table->timestamp('cancelled_at')->nullable();

            // === Snapshot (plan sabah dəyişsə, bu abunəliyin şərtləri pozulmasın) ===
            $table->string('plan_code_snapshot', 32)->nullable();
            $table->string('plan_name_snapshot', 128)->nullable();
            $table->decimal('price_snapshot', 12, 2)->default(0);
            $table->string('currency_snapshot', 8)->default('AZN');

            $table->json('limits_snapshot')->nullable();
            $table->json('features_snapshot')->nullable();

            $table->json('meta')->nullable(); // gateway info, invoice ref, kupon və s. üçün

            $table->timestamps();

            $table->index(['company_id', 'status']);
            $table->index(['company_id', 'ends_at']);
            $table->index(['company_id', 'trial_ends_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscriptions');
    }
};