<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('risk_assessments', function (Blueprint $table) {
            $table->json('decision_notes')->nullable()->after('decision_comment');
            $table->boolean('guarantor_required')->default(false)->after('decision_notes');
        });
    }

    public function down(): void
    {
        Schema::table('risk_assessments', function (Blueprint $table) {
            $table->dropColumn(['decision_notes', 'guarantor_required']);
        });
    }
};
