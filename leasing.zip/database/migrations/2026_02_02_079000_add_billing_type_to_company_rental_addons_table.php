<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('company_rental_addons', function (Blueprint $table) {
            $table->string('billing_type', 16)->default('per_rental')->after('price'); // per_rental|per_day
        });
    }

    public function down(): void
    {
        Schema::table('company_rental_addons', function (Blueprint $table) {
            $table->dropColumn('billing_type');
        });
    }
};
