<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->boolean('geofence_enabled')->default(false)->after('traccar_device_id');
            $table->decimal('geofence_lat', 10, 7)->nullable()->after('geofence_enabled');
            $table->decimal('geofence_lng', 10, 7)->nullable()->after('geofence_lat');
            $table->unsignedInteger('geofence_radius_m')->nullable()->after('geofence_lng');
            $table->string('geofence_state', 16)->nullable()->after('geofence_radius_m');
            $table->timestamp('geofence_last_exit_at')->nullable()->after('geofence_state');
            $table->timestamp('geofence_last_enter_at')->nullable()->after('geofence_last_exit_at');
            $table->timestamp('geofence_last_reminder_at')->nullable()->after('geofence_last_enter_at');
            $table->index(['geofence_enabled']);
        });
    }

    public function down(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->dropIndex(['geofence_enabled']);
            $table->dropColumn([
                'geofence_enabled',
                'geofence_lat',
                'geofence_lng',
                'geofence_radius_m',
                'geofence_state',
                'geofence_last_exit_at',
                'geofence_last_enter_at',
                'geofence_last_reminder_at',
            ]);
        });
    }
};
