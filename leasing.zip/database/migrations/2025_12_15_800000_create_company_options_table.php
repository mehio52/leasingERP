<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('company_options', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            // ========== Branding / Vitrin ==========
            $table->string('display_name', 128)->nullable();   // vitrin adı (saytda görünəcək)
            $table->string('logo_path')->nullable();          // logo fayl yolu
            $table->string('cover_image_path')->nullable();   // cover/banner (opsional)

            // ========== Əlaqə məlumatları ==========
            $table->string('contact_email')->nullable();
            $table->string('contact_phone', 32)->nullable();
            $table->string('whatsapp_phone', 32)->nullable();
            $table->string('address')->nullable();
            $table->string('city', 64)->nullable();
            $table->string('country', 64)->default('Azerbaijan');

            // xəritə / koordinat (opsional)
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->string('map_url')->nullable();

            // ========== İş günləri / iş saatları ==========
            // format: {"mon":{"open":"09:00","close":"18:00","closed":false}, ...}
            $table->json('working_hours')->nullable();

            // ========== Sosial şəbəkələr ==========
            // format: {"instagram":"...", "facebook":"...", "tiktok":"...", "youtube":"...", "linkedin":"..."}
            $table->json('social_links')->nullable();

            // ========== SEO (ön üz səhifələr üçün) ==========
            $table->string('seo_title')->nullable();
            $table->string('seo_description', 500)->nullable();
            $table->string('seo_keywords', 500)->nullable();
            $table->string('seo_og_image')->nullable();
            $table->string('seo_canonical_url')->nullable();
            $table->boolean('seo_indexable')->default(true);

            // ========== Kredit kalkulyator (range-lər) ==========
            // faiz aralığı (məs: 10 - 25)
            $table->decimal('calc_interest_min', 5, 2)->default(10.00);
            $table->decimal('calc_interest_max', 5, 2)->default(25.00);

            // müddət aralığı (ay)
            $table->unsignedSmallInteger('calc_term_min_months')->default(6);
            $table->unsignedSmallInteger('calc_term_max_months')->default(60);

            // məbləğ aralığı
            $table->decimal('calc_amount_min', 12, 2)->nullable();
            $table->decimal('calc_amount_max', 12, 2)->nullable();

            // ========== Lokalizasiya (ön üz üçün lazımdırsa) ==========
            $table->string('timezone')->default('Asia/Baku');
            $table->string('locale', 8)->default('az');
            $table->string('currency', 8)->default('AZN');

            // genişlənən əlavə ayarlar
            $table->json('settings')->nullable();

            $table->timestamps();

            // Hər şirkət üçün 1 sətir
            $table->unique('company_id', 'company_options_company_unique');

            $table->index(['seo_indexable']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('company_options');
    }
};