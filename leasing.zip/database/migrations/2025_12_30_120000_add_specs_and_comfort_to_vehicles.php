<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->json('specs')->nullable();
            $table->json('comforts')->nullable();
            $table->string('public_title')->nullable();
            $table->text('public_description')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->dropColumn(['specs','comforts','public_title','public_description']);
        });
    }
};
