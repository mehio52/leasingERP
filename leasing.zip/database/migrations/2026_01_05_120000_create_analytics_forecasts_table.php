<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('analytics_forecasts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->string('metric');            // e.g. turnover, tax
            $table->string('period');            // e.g. monthly
            $table->date('forecast_date');       // which month/date this value refers to
            $table->decimal('value', 16, 2)->default(0);
            $table->json('meta')->nullable();    // confidence, model info, currency, etc.
            $table->timestamps();

            $table->unique(['company_id', 'metric', 'period', 'forecast_date'], 'af_company_metric_period_date');
            $table->foreign('company_id')->references('id')->on('companies')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('analytics_forecasts');
    }
};
