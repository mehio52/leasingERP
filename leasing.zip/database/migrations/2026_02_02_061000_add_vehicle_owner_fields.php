<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->string('owner_type', 16)->nullable()->after('rent_due_at');
            $table->unsignedBigInteger('owner_customer_id')->nullable()->after('owner_type');
            $table->string('owner_payment_type', 16)->nullable()->after('owner_customer_id');
            $table->decimal('owner_payment_amount', 12, 2)->nullable()->after('owner_payment_type');
            $table->index(['owner_type']);
            $table->index(['owner_customer_id']);
        });
    }

    public function down(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->dropIndex(['owner_type']);
            $table->dropIndex(['owner_customer_id']);
            $table->dropColumn([
                'owner_type',
                'owner_customer_id',
                'owner_payment_type',
                'owner_payment_amount',
            ]);
        });
    }
};
