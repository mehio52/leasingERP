<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();

            // ========== COMPANY ==========
            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            // ========== CORE INFO ==========
            $table->string('first_name');
            $table->string('last_name');
            $table->string('phone', 32)->unique();
            $table->string('email')->nullable()->unique();

            // ========== AUTH ==========
            $table->string('password');

            // ========== ROLE / ACCESS ==========
            $table->boolean('is_owner')->default(false); 
            // true = şirkət rəhbəri (1 nəfər)

            $table->string('role', 32)->default('staff');
            /*
                owner       -> şirkət rəhbəri
                manager     -> əməliyyat
                accountant  -> maliyyə
                staff       -> adi user
            */

            $table->json('permissions')->nullable();
            // ["customers.create","contracts.view"]

            // ========== STATUS ==========
            $table->boolean('is_active')->default(true);
            $table->timestamp('last_login_at')->nullable();

            // ========== AUDIT ==========
            $table->foreignId('created_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $table->rememberToken();
            $table->timestamps();

            // ========== INDEXES ==========
            $table->index(['company_id', 'role']);
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};