<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('bhph_accounts', function (Blueprint $table) {
            $table->id();

            // əlaqələr
            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            $table->foreignId('customer_id')
                ->constrained('customers')
                ->cascadeOnDelete();

            $table->foreignId('vehicle_id')
                ->constrained('vehicles')
                ->cascadeOnDelete();

            // müqavilə id-si (contracts -> FK)
            $table->foreignId('contract_id')
                ->nullable()
                ->constrained('contracts')
                ->nullOnDelete();

            // kredit parametrləri
            $table->decimal('loan_amount', 12, 2);                 // kredit məbləği (əsas məbləğ)
            $table->decimal('annual_interest_rate', 5, 2);         // illik faiz (%): məsələn 24.50
            $table->unsignedSmallInteger('term_months');           // kredit müddəti (ay)

            $table->decimal('down_payment', 12, 2)->default(0);     // ilkin ödəniş
            $table->decimal('insurance_fee', 12, 2)->default(0);    // sığorta haqqı
            $table->decimal('commission_fee', 12, 2)->default(0);   // komissiya
            $table->decimal('gps_fee', 12, 2)->default(0);          // GPS haqqı

            $table->date('payment_start_date');                    // ödənişin başlama tarixi

            // hesablamaların saxlanması (sonradan ödəniş cədvəli ilə də yenilənə bilər)
            $table->decimal('paid_total_amount', 12, 2)->default(0);        // ödənilən yekun məbləğ
            $table->decimal('remaining_amount', 12, 2)->default(0);         // qalan məbləğ

            $table->decimal('paid_interest_amount', 12, 2)->default(0);     // ödənilən faiz
            $table->decimal('total_interest_amount', 12, 2)->default(0);    // ümumi faiz

            $table->decimal('paid_principal_amount', 12, 2)->default(0);    // ödənilən əsas borc
            $table->decimal('total_principal_amount', 12, 2)->default(0);   // ümumi əsas borc (adətən loan_amount)

            $table->decimal('credit_balance', 12, 2)->default(0);   // müştərinin kredit balansı (artıq ödənişlər üçün)

            // satıcı (user)
            $table->foreignId('seller_user_id')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            // status
            $table->string('status', 16)->default('active');
            // active | overdue | legal | inactive

            $table->timestamps();

            $table->index(['company_id', 'status']);
            $table->index(['company_id', 'customer_id']);
            $table->index(['company_id', 'vehicle_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bhph_accounts');
    }
};