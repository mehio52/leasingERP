<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('bhph_accounts', function (Blueprint $table) {
            if (!Schema::hasColumn('bhph_accounts', 'credit_balance')) {
                $table->decimal('credit_balance', 12, 2)
                    ->default(0)
                    ->after('remaining_amount');
            }
        });
    }

    public function down(): void
    {
        Schema::table('bhph_accounts', function (Blueprint $table) {
            if (Schema::hasColumn('bhph_accounts', 'credit_balance')) {
                $table->dropColumn('credit_balance');
            }
        });
    }
};