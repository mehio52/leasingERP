<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('leasing_options', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            // Amortizasiya metodu: annuity / flat / reducing_balance və s.
            $table->string('amortization_method', 32)->default('reducing_balance');

            // Ödəniş periodu: monthly / weekly / biweekly (indi monthly default)
            $table->string('payment_frequency', 16)->default('monthly');

            // Ödəniş bölünmə sırası (sənin dediyin kimi: faiz daha çox/əvvəl ödənilsin)
            // interest_first => faiz sonra əsas borc
            // principal_first => əsas borc sonra faiz
            $table->string('allocation_order', 32)->default('interest_first');

            // Gecikmə üçün güzəşt günləri (məs: 3 gün geciksə overdue sayma)
            $table->unsignedSmallInteger('grace_days')->default(0);

            // Gecikmə cəriməsi (opsional)
            // none | fixed | percent
            $table->string('late_fee_type', 16)->default('none');
            $table->decimal('late_fee_value', 12, 2)->default(0); // fixed=AZN, percent=%

            // Yuvarlaqlaşdırma (pul hesabı üçün)
            // 0.01 / 0.05 / 0.10 kimi
            $table->decimal('rounding_step', 6, 2)->default(0.01);

            // Qismən ödənişə icazə
            $table->boolean('allow_partial_payments')->default(true);

            // “Şirkət rəhbərinin öz qeydləri / düşüncələri”
            $table->text('notes')->nullable();

            // Genişlənən settings (gələcəkdə əlavə qaydalar üçün)
            $table->json('settings')->nullable();

            $table->timestamps();

            // Hər şirkət üçün 1 sətir konfiq (istəsən çox sətir də edə bilərsən)
            $table->unique('company_id', 'leasing_options_company_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('leasing_options');
    }
};