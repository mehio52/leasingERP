<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('amortization', function (Blueprint $table) {
            $table->id();

            // əlaqələr
            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            $table->foreignId('bhph_account_id')
                ->constrained('bhph_accounts')
                ->cascadeOnDelete();

            // sıra
            $table->unsignedSmallInteger('installment_no');

            // ödənilməli hissə
            $table->date('due_date');                             // tarix
            $table->decimal('due_amount', 12, 2);                 // ödənilməli məbləğ

            // ödənilən hissə
            $table->decimal('paid_amount', 12, 2)->default(0);    // ödənilən məbləğ
            $table->decimal('paid_interest', 12, 2)->default(0);  // ödənilən faiz
            $table->decimal('paid_principal', 12, 2)->default(0); // ödənilən əsas borc
            $table->date('paid_date')->nullable();                // ödənilən tarix

            // ödənişdən sonra qalan ümumi borc
            $table->decimal('remaining_balance', 12, 2);          // qalan borc

            // status
            $table->string('status', 16)->default('pending');
            // pending | partial | paid | overdue

            $table->timestamps();

            // indekslər
            $table->unique(
                ['bhph_account_id', 'installment_no'],
                'amortization_account_installment_unique'
            );

            $table->index(['company_id', 'due_date']);
            $table->index(['company_id', 'status']);
            $table->index(['company_id', 'paid_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('amortization');
    }
};