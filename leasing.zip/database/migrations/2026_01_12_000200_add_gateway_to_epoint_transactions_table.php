<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('epoint_transactions', function (Blueprint $table) {
            $table->string('gateway', 16)->default('epoint')->after('type');
            $table->string('gateway_transaction', 128)->nullable()->after('order_id');
        });

        DB::table('epoint_transactions')
            ->whereNull('gateway')
            ->update(['gateway' => 'epoint']);
    }

    public function down(): void
    {
        Schema::table('epoint_transactions', function (Blueprint $table) {
            $table->dropColumn(['gateway', 'gateway_transaction']);
        });
    }
};
