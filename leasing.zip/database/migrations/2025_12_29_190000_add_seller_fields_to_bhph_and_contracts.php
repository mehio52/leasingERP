<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('bhph_accounts', function (Blueprint $table) {
            $table->string('contract_type', 16)->default('two'); // two | three
            $table->string('seller_name')->nullable();
            $table->string('seller_phone')->nullable();
            $table->string('seller_id_number')->nullable();
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->string('contract_type', 16)->default('two');
            $table->string('seller_name')->nullable();
            $table->string('seller_phone')->nullable();
            $table->string('seller_id_number')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('bhph_accounts', function (Blueprint $table) {
            $table->dropColumn(['contract_type','seller_name','seller_phone','seller_id_number']);
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn(['contract_type','seller_name','seller_phone','seller_id_number']);
        });
    }
};
