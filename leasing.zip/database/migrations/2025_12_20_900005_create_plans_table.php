<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('plans', function (Blueprint $table) {
            $table->id();

            $table->string('code', 32)->unique();     // trial, basic, pro...
            $table->string('name', 128);              // Basic, Pro...
            $table->string('description', 500)->nullable();

            $table->decimal('price_monthly', 12, 2)->default(0);
            $table->decimal('price_yearly', 12, 2)->default(0);
            $table->string('currency', 8)->default('AZN');

            $table->unsignedSmallInteger('trial_days')->default(0);

            // limits/features: global plan qaydaları
            $table->json('limits')->nullable();   // {"users":3,"active_contracts":10,...}
            $table->json('features')->nullable(); // {"document_automation":true,...}

            $table->boolean('is_active')->default(true);
            $table->unsignedSmallInteger('sort_order')->default(0);

            $table->timestamps();

            $table->index(['is_active', 'sort_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plans');
    }
};