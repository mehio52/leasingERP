﻿<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->decimal('base_salary', 12, 2)->default(0)->after('is_active');
            $table->string('salary_currency', 8)->default('AZN')->after('base_salary');
            $table->string('commission_type', 32)->nullable()->after('salary_currency');
            $table->decimal('commission_rate', 8, 2)->nullable()->after('commission_type');
            $table->string('payout_period', 32)->nullable()->after('commission_rate');
            $table->text('salary_notes')->nullable()->after('payout_period');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'base_salary',
                'salary_currency',
                'commission_type',
                'commission_rate',
                'payout_period',
                'salary_notes',
            ]);
        });
    }
};
