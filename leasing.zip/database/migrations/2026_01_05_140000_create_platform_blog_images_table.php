<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('platform_blog_images', function (Blueprint $table) {
            $table->id();
            $table->foreignId('platform_blog_post_id')
                ->constrained('platform_blog_posts')
                ->cascadeOnDelete();
            $table->string('path');
            $table->string('keyword', 60)->nullable();
            $table->string('alt_text', 255)->nullable();
            $table->timestamps();

            $table->unique(['platform_blog_post_id', 'keyword']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('platform_blog_images');
    }
};
