<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('risk_factor_definitions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->index();
            $table->string('key', 64);
            $table->string('label', 120);
            $table->string('type', 32)->default('number'); // number|boolean|select|text
            $table->json('options')->nullable();
            $table->json('config')->nullable();
            $table->boolean('is_active')->default(true);
            $table->smallInteger('sort_order')->default(0);
            $table->timestamps();

            $table->unique(['company_id', 'key']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('risk_factor_definitions');
    }
};
