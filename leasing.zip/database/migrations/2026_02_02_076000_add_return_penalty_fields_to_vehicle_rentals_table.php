<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->unsignedInteger('grace_hours')->nullable()->after('closed_at');
            $table->unsignedInteger('extra_days')->nullable()->after('grace_hours');
            $table->decimal('extra_day_rate', 10, 2)->nullable()->after('extra_days');
            $table->decimal('extra_days_charge', 10, 2)->nullable()->after('extra_day_rate');
            $table->string('penalty_type', 24)->nullable()->after('extra_days_charge'); // amount_per_day|percent_per_day|fixed
            $table->decimal('penalty_value', 10, 2)->nullable()->after('penalty_type');
            $table->decimal('penalty_amount', 10, 2)->nullable()->after('penalty_value');
            $table->decimal('total_after_penalty', 10, 2)->nullable()->after('penalty_amount');
        });
    }

    public function down(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->dropColumn([
                'grace_hours',
                'extra_days',
                'extra_day_rate',
                'extra_days_charge',
                'penalty_type',
                'penalty_value',
                'penalty_amount',
                'total_after_penalty',
            ]);
        });
    }
};
