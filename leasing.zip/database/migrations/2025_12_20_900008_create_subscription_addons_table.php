<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('subscription_addons', function (Blueprint $table) {
            $table->id();

            // tenant scope üçün company_id əlavə etmək çox rahatdır
            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();

            $table->foreignId('subscription_id')->constrained('subscriptions')->cascadeOnDelete();
            $table->foreignId('addon_id')->nullable()->constrained('addons')->nullOnDelete();

            $table->unsignedSmallInteger('quantity')->default(1);

            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();

            // snapshot
            $table->string('addon_code_snapshot', 48)->nullable();
            $table->string('addon_name_snapshot', 128)->nullable();
            $table->decimal('price_snapshot', 12, 2)->default(0);
            $table->string('currency_snapshot', 8)->default('AZN');
            $table->json('features_snapshot')->nullable();

            $table->json('meta')->nullable();

            $table->timestamps();

            $table->unique(['subscription_id', 'addon_id'], 'sub_addons_subscription_addon_unique');
            $table->index(['company_id', 'ends_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscription_addons');
    }
};