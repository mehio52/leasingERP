<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->string('discount_type', 16)->nullable()->after('price_monthly'); // percent|amount
            $table->decimal('discount_value', 10, 2)->nullable()->after('discount_type');
            $table->decimal('total_after_discount', 10, 2)->nullable()->after('discount_value');
        });
    }

    public function down(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->dropColumn(['discount_type', 'discount_value', 'total_after_discount']);
        });
    }
};
