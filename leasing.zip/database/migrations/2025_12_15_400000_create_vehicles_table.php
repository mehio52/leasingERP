<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();

            // Hansi şirkətə aiddir
            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            // Qiymətlər
            $table->decimal('purchase_price', 12, 2)->nullable(); // alış qiyməti (null ola bilər)
            $table->decimal('sale_price', 12, 2);                // satış qiyməti

            // Identifikatorlar
            $table->string('plate_number', 32)->nullable();       // nömrə (null ola bilər)
            $table->string('vin_code', 32)->unique();             // VIN (unikal)

            // Marka / Model
            $table->string('brand', 64);                          // marka
            $table->string('model', 64);                          // model
            $table->string('sub_model', 64)->nullable();          // alt model (opsional)
            $table->unsignedSmallInteger('year');                 // il
            $table->string('color', 64)->nullable();              // rəng

            // Şəkillər (fayl yolları / URL-lər siyahısı)
            $table->json('images')->nullable();                   // ["uploads/vehicles/1/a.jpg", "..."]

            // Status: elde, lizingde, satilib
            $table->string('status', 16)->default('available');
            // available | leasing | sold

            // Bayraqlar
            $table->boolean('has_insurance')->default(false);     // sığorta olub/olmayıb
            $table->boolean('has_technical')->default(false);     // texniki baxış olub/olmayıb
            $table->boolean('is_returned')->default(false);       // qaytarılıb ya yox

            $table->timestamps();

            $table->index(['company_id', 'status']);
            $table->index(['company_id', 'year']);
            $table->unique(['company_id', 'plate_number'], 'vehicles_company_plate_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};
