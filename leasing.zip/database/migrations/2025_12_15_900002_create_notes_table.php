<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('notes', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            // Note-u kim yazıb
            $table->foreignId('created_by_user_id')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            // Universal əlaqə (vehicles/customers/users/bhph_accounts/payments və s.)
            $table->string('noteable_type', 191);
            $table->unsignedBigInteger('noteable_id');

            // Məzmun
            $table->string('title', 255)->nullable();
            $table->text('content');

            // Status/etiket (opsional)
            $table->string('status', 16)->default('active'); // active | archived
            $table->json('meta')->nullable();

            $table->timestamps();

            $table->index(['company_id', 'noteable_type', 'noteable_id'], 'notes_company_noteable_idx');
            $table->index(['noteable_type', 'noteable_id'], 'notes_noteable_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notes');
    }
};