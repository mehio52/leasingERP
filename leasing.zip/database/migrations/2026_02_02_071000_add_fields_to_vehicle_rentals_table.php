<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->string('renter_fin_code', 16)->nullable()->after('renter_phone');
            $table->string('renter_id_card_number', 64)->nullable()->after('renter_fin_code');
            $table->string('driver_license_number', 64)->nullable()->after('renter_id_card_number');
            $table->string('driver_license_category', 16)->nullable()->after('driver_license_number');
            $table->string('driver_license_image_path', 255)->nullable()->after('driver_license_category');
            $table->string('id_card_image_path', 255)->nullable()->after('driver_license_image_path');
            $table->unsignedInteger('rent_days')->nullable()->after('due_at');
            $table->decimal('price_daily', 10, 2)->nullable()->after('rent_days');
            $table->decimal('price_weekly', 10, 2)->nullable()->after('price_daily');
            $table->decimal('price_monthly', 10, 2)->nullable()->after('price_weekly');
            $table->decimal('total_price', 10, 2)->nullable()->after('price_monthly');
        });
    }

    public function down(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->dropColumn([
                'renter_fin_code',
                'renter_id_card_number',
                'driver_license_number',
                'driver_license_category',
                'driver_license_image_path',
                'id_card_image_path',
                'rent_days',
                'price_daily',
                'price_weekly',
                'price_monthly',
                'total_price',
            ]);
        });
    }
};
