<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            $table->foreignId('bhph_account_id')
                ->constrained('bhph_accounts')
                ->cascadeOnDelete();

            $table->foreignId('received_by_user_id')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $table->date('paid_date');                          // ödəniş tarixi
            $table->decimal('amount', 12, 2);                    // ümumi ödəniş məbləği
            $table->string('currency', 8)->default('AZN');       // valyuta

            $table->decimal('interest_amount', 12, 2)->default(0);   // faiz hissəsi
            $table->decimal('principal_amount', 12, 2)->default(0);  // əsas borc hissəsi
            $table->decimal('penalty_amount', 12, 2)->default(0);    // gecikmə cəriməsi

            $table->string('method', 16)->default('cash');
            // cash | card | bank | transfer | other

            $table->string('status', 16)->default('confirmed');
            // pending | confirmed | rejected | cancelled

            $table->string('reference', 128)->nullable();        // çek/transaction id (uzun ola bilər)
            $table->text('note')->nullable();

            $table->timestamps();

            $table->index(['company_id', 'paid_date']);
            $table->index(['company_id', 'bhph_account_id']);
            $table->index(['company_id', 'status']);
            $table->index(['company_id', 'method']);
            $table->index(['company_id', 'reference']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};