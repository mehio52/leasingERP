<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('taxi_drivers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained()->cascadeOnDelete();
            $table->string('first_name', 100);
            $table->string('last_name', 100);
            $table->string('phone', 32)->nullable();
            $table->string('email', 190)->nullable();
            $table->string('address', 255)->nullable();
            $table->string('status', 32)->default('active');

            $table->string('salary_type', 32)->nullable();
            $table->decimal('salary_value', 12, 2)->nullable();
            $table->string('salary_currency', 8)->default('AZN');
            $table->json('salary_meta')->nullable();
            $table->text('notes')->nullable();

            $table->string('certificate_no', 64)->nullable();
            $table->string('certificate_image', 255)->nullable();
            $table->string('id_card_no', 64)->nullable();
            $table->string('id_card_image', 255)->nullable();
            $table->string('driver_license_no', 64)->nullable();
            $table->string('driver_license_image', 255)->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['company_id', 'status']);
            $table->index(['company_id', 'last_name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('taxi_drivers');
    }
};
