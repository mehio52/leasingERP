<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::create('penalty_options', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            // Gecikmə sayılma qaydası
            $table->unsignedSmallInteger('grace_days')->default(0); // güzəşt günləri
            $table->unsignedSmallInteger('overdue_after_days')->default(1); // neçə gündən sonra overdue

            // Cərimə tipi
            $table->string('penalty_type', 16)->default('none');
            // none | fixed | percent

            // fixed => AZN məbləğ, percent => % (məs: 1.50)
            $table->decimal('penalty_value', 12, 2)->default(0);

            // Cərimənin tətbiq tezliyi
            $table->string('penalty_frequency', 16)->default('once');
            // once | daily | monthly

            // Cərimə nəyə tətbiq olunsun
            $table->string('apply_on', 24)->default('remaining_due');
            // remaining_due | principal_only | total_installment

            // Maksimum limitlər
            $table->decimal('penalty_cap_amount', 12, 2)->nullable();   // ümumi maksimum AZN
            $table->decimal('penalty_cap_percent', 5, 2)->nullable();   // ümumi maksimum %

            // Cərimə hesablanması yuvarlaqlaşdırma
            $table->decimal('rounding_step', 6, 2)->default(0.01);
            $table->string('rounding_mode', 12)->default('nearest');
            // nearest | up | down

            // Qeydlər / genişlənən settings
            $table->text('notes')->nullable();
            $table->json('settings')->nullable();

            $table->timestamps();

            // Hər şirkət üçün 1 sətir
            $table->unique('company_id', 'penalty_options_company_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('penalty_options');
    }
};