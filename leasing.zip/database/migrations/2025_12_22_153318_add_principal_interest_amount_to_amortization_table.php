<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('amortization', function (Blueprint $table) {
            if (!Schema::hasColumn('amortization', 'principal_amount')) {
                $table->decimal('principal_amount', 12, 2)->default(0)->after('due_amount');
            }

            if (!Schema::hasColumn('amortization', 'interest_amount')) {
                $table->decimal('interest_amount', 12, 2)->default(0)->after('principal_amount');
            }
        });

        // Köhnə sütunlar varsa (səndə var: paid_principal / paid_interest),
        // yeni sütunlara backfill edək ki, dərhal işləsin.
        $pSrc = null;
        foreach (['paid_principal','due_principal','principal'] as $c) {
            if (Schema::hasColumn('amortization', $c)) { $pSrc = $c; break; }
        }

        $iSrc = null;
        foreach (['paid_interest','due_interest','interest'] as $c) {
            if (Schema::hasColumn('amortization', $c)) { $iSrc = $c; break; }
        }

        if ($pSrc) {
            DB::table('amortization')->update([
                'principal_amount' => DB::raw("COALESCE($pSrc,0)")
            ]);
        }

        if ($iSrc) {
            DB::table('amortization')->update([
                'interest_amount' => DB::raw("COALESCE($iSrc,0)")
            ]);
        }
    }

    public function down(): void
    {
        Schema::table('amortization', function (Blueprint $table) {
            if (Schema::hasColumn('amortization', 'interest_amount')) {
                $table->dropColumn('interest_amount');
            }
            if (Schema::hasColumn('amortization', 'principal_amount')) {
                $table->dropColumn('principal_amount');
            }
        });
    }
};