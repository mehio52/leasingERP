<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->decimal('rent_daily_price', 12, 2)->nullable()->after('sale_price');
            $table->decimal('rent_weekly_price', 12, 2)->nullable()->after('rent_daily_price');
            $table->decimal('rent_monthly_price', 12, 2)->nullable()->after('rent_weekly_price');
            $table->string('rent_source', 255)->nullable()->after('rent_monthly_price');
            $table->dateTime('rent_due_at')->nullable()->after('rent_source');
        });
    }

    public function down(): void
    {
        Schema::table('vehicles', function (Blueprint $table) {
            $table->dropColumn([
                'rent_daily_price',
                'rent_weekly_price',
                'rent_monthly_price',
                'rent_source',
                'rent_due_at',
            ]);
        });
    }
};
