<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('notification_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->index();
            $table->foreignId('bhph_account_id')->nullable()->index();
            $table->foreignId('customer_id')->nullable()->index();
            $table->string('phone', 32)->nullable()->index();
            $table->string('status', 16)->default('pending'); // sent|failed|skipped
            $table->string('reason', 191)->nullable();
            $table->text('message')->nullable();
            $table->json('response')->nullable();
            $table->string('provider_status', 64)->nullable();
            $table->timestamp('sent_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notification_logs');
    }
};
