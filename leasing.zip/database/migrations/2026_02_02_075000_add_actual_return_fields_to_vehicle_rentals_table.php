<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->unsignedInteger('actual_rent_days')->nullable()->after('rent_days');
            $table->decimal('actual_price_daily', 10, 2)->nullable()->after('actual_rent_days');
            $table->decimal('actual_price_weekly', 10, 2)->nullable()->after('actual_price_daily');
            $table->decimal('actual_price_monthly', 10, 2)->nullable()->after('actual_price_weekly');
            $table->decimal('actual_total_price', 10, 2)->nullable()->after('actual_price_monthly');
            $table->decimal('actual_total_after_discount', 10, 2)->nullable()->after('actual_total_price');
        });
    }

    public function down(): void
    {
        Schema::table('vehicle_rentals', function (Blueprint $table) {
            $table->dropColumn([
                'actual_rent_days',
                'actual_price_daily',
                'actual_price_weekly',
                'actual_price_monthly',
                'actual_total_price',
                'actual_total_after_discount',
            ]);
        });
    }
};
