<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('company_domain_requests', function (Blueprint $table) {
            $table->boolean('is_active')->default(false)->after('admin_note');
            $table->timestamp('activated_at')->nullable()->after('rejected_at');
            $table->timestamp('deactivated_at')->nullable()->after('activated_at');
            $table->index(['requested_domain', 'is_active']);
        });
    }

    public function down(): void
    {
        Schema::table('company_domain_requests', function (Blueprint $table) {
            $table->dropIndex(['requested_domain', 'is_active']);
            $table->dropColumn(['is_active', 'activated_at', 'deactivated_at']);
        });
    }
};
