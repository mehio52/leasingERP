<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tax_reports', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->date('period_start')->nullable();
            $table->date('period_end')->nullable();
            $table->decimal('gross_revenue', 14, 2)->default(0);
            $table->decimal('deductible_expenses', 14, 2)->default(0);
            $table->decimal('taxable_income', 14, 2)->default(0);
            $table->decimal('tax_rate', 6, 3)->default(0); // % olaraq
            $table->decimal('tax_amount', 14, 2)->default(0);
            $table->string('note')->nullable();
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tax_reports');
    }
};
