<?php

namespace Database\Seeders;

use App\Models\Company;
use App\Models\RiskFactorDefinition;
use Illuminate\Database\Seeder;

class RiskFactorSeeder extends Seeder
{
    public function run(): void
    {
        $companies = Company::all();
        if ($companies->isEmpty()) {
            return;
        }

        $defaults = [
            [
                'key' => 'late_count_12m',
                'label' => 'Son 12 ay gecikmə sayı',
                'type' => 'number',
                'sort_order' => 10,
                'config' => [
                    'method' => 'bands',
                    'penalties' => [
                        ['lte' => 0, 'points' => 0],
                        ['lte' => 2, 'points' => 6],
                        ['lte' => 4, 'points' => 12],
                        ['gt' => 4, 'points' => 20],
                    ],
                ],
            ],
            [
                'key' => 'max_days_late_12m',
                'label' => 'Son 12 ay maksimal gecikmə günləri',
                'type' => 'number',
                'sort_order' => 11,
                'config' => [
                    'method' => 'bands',
                    'penalties' => [
                        ['lte' => 5, 'points' => 0],
                        ['lte' => 15, 'points' => 8],
                        ['lte' => 30, 'points' => 16],
                        ['gt' => 30, 'points' => 25],
                    ],
                ],
            ],
            [
                'key' => 'dependents',
                'label' => 'Baxılan şəxslər',
                'type' => 'number',
                'sort_order' => 12,
                'config' => [
                    'method' => 'bands',
                    'penalties' => [
                        ['lte' => 1, 'points' => 0],
                        ['lte' => 3, 'points' => 6],
                        ['gt' => 3, 'points' => 12],
                    ],
                ],
            ],
            [
                'key' => 'medical_monthly',
                'label' => 'Aylıq tibbi xərclər',
                'type' => 'number',
                'sort_order' => 13,
                'config' => [
                    'method' => 'linear',
                    'unit' => 100,
                    'points_per_unit' => 1.5,
                    'max_points' => 20,
                ],
            ],
            [
                'key' => 'other_monthly_expenses',
                'label' => 'Digər aylıq xərclər',
                'type' => 'number',
                'sort_order' => 14,
                'config' => [
                    'method' => 'linear',
                    'unit' => 100,
                    'points_per_unit' => 1,
                    'max_points' => 15,
                ],
            ],
        ];

        foreach ($companies as $company) {
            foreach ($defaults as $row) {
                RiskFactorDefinition::updateOrCreate(
                    ['company_id' => $company->id, 'key' => $row['key']],
                    [
                        'label' => $row['label'],
                        'type' => $row['type'],
                        'options' => $row['options'] ?? null,
                        'config' => $row['config'] ?? null,
                        'is_active' => true,
                        'sort_order' => $row['sort_order'] ?? 0,
                    ]
                );
            }
        }
    }
}
