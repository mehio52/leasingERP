<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Plan;
use App\Models\Addon;

class PlanAddonSeeder extends Seeder
{
    public function run(): void
    {
        // Plans
        Plan::updateOrCreate(['code' => 'trial'], [
            'name' => 'Trial',
            'description' => '30 gün sınaq paketi',
            'price_monthly' => 0,
            'price_yearly' => 0,
            'currency' => 'AZN',
            'trial_days' => 30,
            'limits' => [
                'users' => 3,
                'active_contracts' => 10,
                'branches' => 1,
            ],
            'features' => [
                'settings' => true,
                'users' => true,
                'public_theme' => true,
                'contracts' => true,
                'bhph' => true,
                'customers' => true,
                'vehicles' => true,
                'risk' => true,
                'gps' => false,
                'whatsapp_campaigns' => false,
                'payments' => false,
                'document_automation' => false,
                'notifications' => false,
                'advanced_reports' => false,
                'export_watermark' => true,
            ],
            'is_active' => true,
            'sort_order' => 1,
        ]);

        Plan::updateOrCreate(['code' => 'basic'], [
            'name' => 'Basic',
            'description' => 'Kiçik şirkətlər üçün',
            'price_monthly' => 49,
            'price_yearly' => 499,
            'currency' => 'AZN',
            'trial_days' => 0,
            'limits' => [
                'users' => 10,
                'active_contracts' => 100,
                'branches' => 3,
            ],
            'features' => [
                'settings' => true,
                'users' => true,
                'public_theme' => true,
                'contracts' => true,
                'bhph' => true,
                'customers' => true,
                'vehicles' => true,
                'risk' => true,
                'gps' => true,
                'whatsapp_campaigns' => false,
                'payments' => true,
                'document_automation' => true,
                'notifications' => false,
                'advanced_reports' => false,
                'export_watermark' => false,
            ],
            'is_active' => true,
            'sort_order' => 2,
        ]);

        Plan::updateOrCreate(['code' => 'pro'], [
            'name' => 'Pro',
            'description' => 'Böyük həcm və bildirişlər',
            'price_monthly' => 99,
            'price_yearly' => 999,
            'currency' => 'AZN',
            'trial_days' => 0,
            'limits' => [
                'users' => 30,
                'active_contracts' => 500,
                'branches' => 10,
            ],
            'features' => [
                'settings' => true,
                'users' => true,
                'public_theme' => true,
                'contracts' => true,
                'bhph' => true,
                'customers' => true,
                'vehicles' => true,
                'risk' => true,
                'gps' => true,
                'whatsapp_campaigns' => true,
                'payments' => true,
                'document_automation' => true,
                'notifications' => true,
                'advanced_reports' => true,
                'export_watermark' => false,
            ],
            'is_active' => true,
            'sort_order' => 3,
        ]);

        // Addons
        Addon::updateOrCreate(['code' => 'document_automation'], [
            'name' => 'Document Automation',
            'description' => 'DOCX/PDF şablon doldurma',
            'price_monthly' => 15,
            'price_yearly' => 150,
            'currency' => 'AZN',
            'features' => ['document_automation' => true],
            'is_active' => true,
            'sort_order' => 1,
        ]);

        Addon::updateOrCreate(['code' => 'gps'], [
            'name' => 'GPS Tracking',
            'description' => 'GPS izləmə və xəritə',
            'price_monthly' => 10,
            'price_yearly' => 100,
            'currency' => 'AZN',
            'features' => ['gps' => true],
            'is_active' => true,
            'sort_order' => 2,
        ]);

        Addon::updateOrCreate(['code' => 'notifications'], [
            'name' => 'SMS/WhatsApp Notifications',
            'description' => 'Xatırlatma və gecikmə bildirişləri',
            'price_monthly' => 20,
            'price_yearly' => 200,
            'currency' => 'AZN',
            'features' => ['notifications' => true],
            'is_active' => true,
            'sort_order' => 3,
        ]);

        Addon::updateOrCreate(['code' => 'advanced_reports'], [
            'name' => 'Advanced Reports',
            'description' => 'KPI/analitika hesabatları',
            'price_monthly' => 25,
            'price_yearly' => 250,
            'currency' => 'AZN',
            'features' => ['advanced_reports' => true],
            'is_active' => true,
            'sort_order' => 4,
        ]);
    }
}
