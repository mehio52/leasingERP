<?php

use Illuminate\Foundation\Application;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use App\Http\Middleware\EnsureCompanyOwner;
use App\Http\Middleware\EnsureSuperAdmin;
use App\Http\Middleware\EnsureHasPermission;
use App\Http\Middleware\EnsureGpsProviderUser;
use App\Http\Middleware\EnsurePlanFeature;
use App\Http\Middleware\EnsureCompanyModule;
use App\Http\Middleware\SetLocale;
use App\Http\Middleware\ResolvePublicCompany;
use App\Http\Middleware\ResolvePublicCompanyByDomain;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        channels: __DIR__.'/../routes/channels.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'company.owner' => EnsureCompanyOwner::class,
            'superadmin' => EnsureSuperAdmin::class,
            'perm' => EnsureHasPermission::class,
            'gps.provider' => EnsureGpsProviderUser::class,
            'feature' => EnsurePlanFeature::class,
            'module' => EnsureCompanyModule::class,
            'locale' => SetLocale::class,
            'resolve.public.company' => ResolvePublicCompany::class,
            'resolve.public.domain' => ResolvePublicCompanyByDomain::class,
        ]);
        $middleware->appendToGroup('web', SetLocale::class);
    })
    ->withSchedule(function (Schedule $schedule): void {
        $schedule->command('notifications:send')
            ->everyThirtyMinutes()
            ->withoutOverlapping()
            ->onOneServer();

        $schedule->job(new \App\Jobs\PollVehicleSpeed())
            ->everyFiveMinutes()
            ->withoutOverlapping()
            ->onOneServer();

        $schedule->job(new \App\Jobs\PollVehicleGeofence())
            ->everyFiveMinutes()
            ->withoutOverlapping()
            ->onOneServer();

        $schedule->job(new \App\Jobs\PollVehicleAuthorizationExpiry())
            ->hourly()
            ->withoutOverlapping()
            ->onOneServer();
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
