<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'traccar' => [
        'base_url' => env('TRACCAR_BASE_URL'),
        'token' => env('TRACCAR_TOKEN'),
        'username' => env('TRACCAR_USERNAME'),
        'password' => env('TRACCAR_PASSWORD'),
    ],

    'wialon' => [
        'base_url' => env('WIALON_BASE_URL', 'https://hst-api.wialon.com'),
        'token' => env('WIALON_TOKEN'),
        'enabled' => env('WIALON_ENABLED', true),
    ],

    'google_maps' => [
        'key' => env('GOOGLE_MAPS_API_KEY'),
    ],

    'aapanel' => [
        'enabled' => env('AAPANEL_ENABLED', false),
        'url' => env('AAPANEL_URL'),
        'key' => env('AAPANEL_KEY'),
        // Existing site name in aaPanel where we add parked domains
        'site' => env('AAPANEL_SITE'),
        'site_id' => env('AAPANEL_SITE_ID'),
        'ssl_verify' => env('AAPANEL_SSL_VERIFY', true),
        'timeout' => env('AAPANEL_TIMEOUT', 12),
    ],

    'epoint' => [
        'public_key' => env('EPOINT_PUBLIC_KEY'),
        'private_key' => env('EPOINT_PRIVATE_KEY'),
        'base_url' => env('EPOINT_BASE_URL', 'https://epoint.az/api/1'),
    ],

    'stripe' => [
        'public_key' => env('STRIPE_PUBLIC_KEY'),
        'secret' => env('STRIPE_SECRET_KEY'),
        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
    ],

    'iyzico' => [
        'api_key' => env('IYZICO_API_KEY'),
        'secret_key' => env('IYZICO_SECRET_KEY'),
        'base_url' => env('IYZICO_BASE_URL', 'https://api.iyzipay.com'),
    ],

    'payment_gateway' => [
        'provider' => env('PAYMENT_GATEWAY_PROVIDER'),
        'pending_ttl_minutes' => env('PAYMENT_GATEWAY_PENDING_TTL_MINUTES', 120),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

];
