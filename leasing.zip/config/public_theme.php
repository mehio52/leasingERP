<?php

return [
    'default' => 'classic',
    'base_path' => resource_path('themes'),
];
