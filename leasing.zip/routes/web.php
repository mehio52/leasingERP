<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\CompanyRegisterController;
use App\Http\Controllers\Auth\CompanyAuthController;
use App\Http\Controllers\DashboardController;

use App\Http\Controllers\CompanyOptionController;
use App\Http\Controllers\LeasingOptionController;
use App\Http\Controllers\PenaltyOptionController;
use App\Http\Controllers\PaymentOptionController;
use App\Http\Controllers\PenaltyController;
use App\Http\Controllers\CompanyPlanController;

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\VehicleController;

use App\Http\Controllers\BhphAccountController;

use App\Http\Controllers\AccountDocumentController;
use App\Http\Controllers\CompanyUserController;
use App\Http\Controllers\RiskAssessmentController;
use App\Http\Controllers\RiskFactorDefinitionController;
use App\Http\Controllers\NotificationOptionController;
use App\Http\Controllers\NotificationLogController;
use App\Http\Controllers\WhatsAppCampaignController;
use App\Http\Controllers\Company\CompanyAddonController;
use App\Http\Controllers\Company\WalletController as CompanyWalletController;
use App\Http\Controllers\Company\GatewayTransactionController as CompanyGatewayTransactionController;
use App\Http\Controllers\TaxReportController;
use App\Http\Controllers\DocumentTemplateController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\SuperAdmin\DashboardController as SuperAdminDashboardController;
use App\Http\Controllers\SuperAdmin\CompanyController as SuperAdminCompanyController;
use App\Http\Controllers\SuperAdmin\PlanController as SuperAdminPlanController;
use App\Http\Controllers\SuperAdmin\AddonController as SuperAdminAddonController;
use App\Http\Controllers\SuperAdmin\SettingController as SuperAdminSettingController;
use App\Http\Controllers\SuperAdmin\SuperAdminCompanyAddonController as SuperAdminCompanyAddonController;
use App\Http\Controllers\SuperAdmin\TicketController as SuperAdminTicketController;
use App\Http\Controllers\SuperAdmin\PlatformBlogController as SuperAdminPlatformBlogController;
use App\Http\Controllers\SuperAdmin\EpointTransactionController as SuperAdminEpointTransactionController;
use App\Http\Controllers\SuperAdmin\DomainRequestController as SuperAdminDomainRequestController;
use App\Http\Controllers\SuperAdmin\GpsProviderController as SuperAdminGpsProviderController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\PublicBlogController;
use App\Http\Controllers\EpointController;
use App\Http\Controllers\StripeController;
use App\Http\Controllers\IyzicoController;
use App\Models\PlatformBlogPost;
use App\Http\Controllers\Company\DomainRequestController as CompanyDomainRequestController;
use App\Http\Controllers\Company\OwnerPaymentController as CompanyOwnerPaymentController;
use App\Http\Controllers\Company\RentalController as CompanyRentalController;
use App\Http\Controllers\Company\RentalAddonController as CompanyRentalAddonController;
use App\Http\Controllers\Company\VehicleExpenseController as CompanyVehicleExpenseController;
use App\Http\Controllers\Company\TaxiDriverController as CompanyTaxiDriverController;
use App\Http\Controllers\Company\TaxiAddonController as CompanyTaxiAddonController;
use App\Http\Controllers\Company\TaxiVehicleAssignmentController as CompanyTaxiVehicleAssignmentController;
use App\Http\Controllers\Company\TaxiVehicleIssueController as CompanyTaxiVehicleIssueController;
use App\Http\Controllers\Company\TaxiTripController as CompanyTaxiTripController;
use App\Http\Controllers\Company\TaxiPayrollController as CompanyTaxiPayrollController;
use App\Http\Controllers\VehicleAuthorizationController;
use App\Http\Controllers\GpsProvider\PortalController as GpsProviderPortalController;
use App\Http\Controllers\GpsProvider\ConnectionRequestController as GpsProviderConnectionRequestController;
use App\Http\Controllers\GpsProvider\SettingsController as GpsProviderSettingsController;
use App\Http\Controllers\GpsProvider\UserController as GpsProviderUserController;
use App\Http\Controllers\GpsProvider\CompanyController as GpsProviderCompanyController;
use App\Http\Controllers\GpsProvider\ProviderVehicleController as GpsProviderProviderVehicleController;
use App\Http\Controllers\GpsProvider\VehicleRequestController as GpsProviderVehicleRequestController;



// home page routes (main domain only)
$appDomain = parse_url(config('app.url'), PHP_URL_HOST);
$appDomainWww = $appDomain ? ('www.' . $appDomain) : null;
$mainDomains = array_filter([$appDomain, $appDomainWww]);

if (!empty($mainDomains)) {
    foreach ($mainDomains as $domain) {
        Route::domain($domain)->group(function () {
            Route::get('/', function () {
                $platformBlogPosts = PlatformBlogPost::query()
                    ->published()
                    ->latest('published_at')
                    ->latest('id')
                    ->get();
                $latestPlatformBlogPosts = $platformBlogPosts->take(6);

                return view('index', compact('platformBlogPosts', 'latestPlatformBlogPosts'));
            })->name('home');

            Route::get('/blog', [PublicBlogController::class, 'index'])->name('public.blog.index');
            Route::get('/blog/{slug}', [PublicBlogController::class, 'show'])->name('public.blog.show');
        });
    }
} else {
    Route::get('/', function () {
        $platformBlogPosts = PlatformBlogPost::query()
            ->published()
            ->latest('published_at')
            ->latest('id')
            ->get();
        $latestPlatformBlogPosts = $platformBlogPosts->take(6);

        return view('index', compact('platformBlogPosts', 'latestPlatformBlogPosts'));
    })->name('home');
    Route::get('/blog', [PublicBlogController::class, 'index'])->name('public.blog.index');
    Route::get('/blog/{slug}', [PublicBlogController::class, 'show'])->name('public.blog.show');
}
Route::match(['get', 'post'], '/epoint/success', [EpointController::class, 'success'])->name('epoint.success');
Route::match(['get', 'post'], '/epoint/error', [EpointController::class, 'error'])->name('epoint.error');
Route::post('/epoint/result', [EpointController::class, 'result'])->name('epoint.result');
Route::match(['get', 'post'], '/iyzico/callback', [IyzicoController::class, 'callback'])->name('iyzico.callback');
Route::get('/iyzico/return', [IyzicoController::class, 'redirect'])->name('iyzico.redirect');
Route::post('/stripe/webhook', [StripeController::class, 'webhook'])->name('stripe.webhook');
Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware('auth')
    ->name('dashboard');
Route::get('/dashboard/export-pdf', [DashboardController::class, 'exportPdf'])
    ->middleware('auth')
    ->name('dashboard.export_pdf');

// Locale switch
Route::get('/locale/{lang}', function (string $lang) {
    $allowed = ['en','az','tr','ru'];
    if (!in_array($lang, $allowed)) {
        abort(404);
    }
    session(['locale' => $lang]);
    return redirect()->back();
})->name('locale.switch');


// REGISTER (company + owner user)
Route::get('/register-company', [CompanyRegisterController::class, 'show'])
    ->middleware('guest')
    ->name('company.register.form');

Route::post('/register-company', [CompanyRegisterController::class, 'store'])
    ->middleware('guest')
    ->name('company.register');

// LOGIN/LOGOUT
Route::get('/login', [CompanyAuthController::class, 'showLogin'])
    ->middleware('guest')
    ->name('login');

Route::post('/login', [CompanyAuthController::class, 'login'])
    ->middleware('guest')
    ->name('auth.login');

Route::post('/forgot-password', [\App\Http\Controllers\Auth\ForgotPasswordController::class, 'requestReset'])
    ->middleware('guest')
    ->name('auth.forgot');

Route::post('/logout', [CompanyAuthController::class, 'logout'])
    ->middleware('auth')
    ->name('auth.logout');

// Impersonation
Route::middleware('auth')->group(function () {
    Route::post('/impersonate/{user}', [\App\Http\Controllers\ImpersonationController::class, 'start'])
        ->name('impersonate.start');
});
Route::any('/impersonate/stop/{any?}', [\App\Http\Controllers\ImpersonationController::class, 'stop'])
    ->where('any', '.*')
    ->name('impersonate.stop');

// SUPERADMIN
Route::middleware(['auth', 'superadmin'])
    ->prefix('superadmin')
    ->name('superadmin.')
    ->group(function () {
        Route::get('/', [SuperAdminDashboardController::class, 'index'])->name('dashboard');

        Route::get('/companies', [SuperAdminCompanyController::class, 'index'])->name('companies.index');
        Route::get('/companies/{company}', [SuperAdminCompanyController::class, 'show'])->name('companies.show');
        Route::put('/companies/{company}', [SuperAdminCompanyController::class, 'update'])->name('companies.update');
        Route::post('/companies/{company}/subscriptions', [SuperAdminCompanyController::class, 'createSubscription'])->name('companies.subscriptions.store');

        Route::resource('plans', SuperAdminPlanController::class)->except(['show']);
        Route::resource('addons', SuperAdminAddonController::class)->except(['show']);
        Route::resource('blogs', SuperAdminPlatformBlogController::class)
            ->parameters(['blogs' => 'post'])
            ->except(['show']);
        Route::post('blogs/{post}/images', [SuperAdminPlatformBlogController::class, 'storeImages'])->name('blogs.images.store');
        Route::put('blogs/{post}/images', [SuperAdminPlatformBlogController::class, 'updateImages'])->name('blogs.images.update');
        Route::delete('blogs/{post}/images/{image}', [SuperAdminPlatformBlogController::class, 'destroyImage'])->name('blogs.images.destroy');
        Route::post('/companies/{company}/addons', [SuperAdminCompanyAddonController::class, 'store'])->name('companies.addons.store');
        Route::delete('/companies/{company}/addons/{subscriptionAddon}', [SuperAdminCompanyAddonController::class, 'destroy'])->name('companies.addons.destroy');
        Route::get('/gps', [\App\Http\Controllers\VehicleController::class, 'gpsAll'])->name('gps');
        Route::get('/notifications-send', [\App\Http\Controllers\NotificationController::class, 'form'])->name('notifications.form');
        Route::post('/notifications-send', [\App\Http\Controllers\NotificationController::class, 'store'])->name('notifications.store');
        Route::get('/tickets', [SuperAdminTicketController::class, 'index'])->name('tickets.index');
        Route::get('/tickets/{ticket}', [SuperAdminTicketController::class, 'show'])->name('tickets.show');
        Route::post('/tickets/{ticket}/reply', [SuperAdminTicketController::class, 'reply'])->name('tickets.reply');
        Route::get('/epoint-transactions', [SuperAdminEpointTransactionController::class, 'index'])->name('epoint.index');
        Route::get('/settings', [SuperAdminSettingController::class, 'edit'])->name('settings.edit');
        Route::post('/settings', [SuperAdminSettingController::class, 'update'])->name('settings.update');

        Route::resource('gps-providers', SuperAdminGpsProviderController::class)->except(['show','destroy'])->names('gps_providers');
        Route::post('gps-providers/{gps_provider}/users', [SuperAdminGpsProviderController::class, 'storeUser'])->name('gps_providers.users.store');

        Route::get('/domain-requests', [SuperAdminDomainRequestController::class, 'index'])->name('domain_requests.index');
        Route::put('/domain-requests/{domainRequest}/approve', [SuperAdminDomainRequestController::class, 'approve'])->name('domain_requests.approve');
        Route::put('/domain-requests/{domainRequest}/reject', [SuperAdminDomainRequestController::class, 'reject'])->name('domain_requests.reject');
        Route::put('/domain-requests/{domainRequest}/activate', [SuperAdminDomainRequestController::class, 'activate'])->name('domain_requests.activate');
        Route::put('/domain-requests/{domainRequest}/deactivate', [SuperAdminDomainRequestController::class, 'deactivate'])->name('domain_requests.deactivate');
    });

// GPS Provider portal
Route::middleware(['auth', 'gps.provider'])
    ->prefix('gps-provider')
    ->name('gps_provider.')
    ->group(function () {
        Route::get('/', [GpsProviderPortalController::class, 'dashboard'])->name('dashboard');
        Route::get('/dashboard/export-csv', [GpsProviderPortalController::class, 'exportCsv'])->name('dashboard.export_csv');
        Route::get('/dashboard/export-pdf', [GpsProviderPortalController::class, 'exportPdf'])->name('dashboard.export_pdf');
        Route::get('/requests', [GpsProviderConnectionRequestController::class, 'index'])
            ->middleware('perm:gps_provider.requests.view')
            ->name('requests.index');
        Route::put('/requests/{connection}/approve', [GpsProviderConnectionRequestController::class, 'approve'])
            ->middleware('perm:gps_provider.requests.approve')
            ->name('requests.approve');
        Route::put('/requests/{connection}/reject', [GpsProviderConnectionRequestController::class, 'reject'])
            ->middleware('perm:gps_provider.requests.approve')
            ->name('requests.reject');

        Route::get('/vehicle-requests', [GpsProviderVehicleRequestController::class, 'index'])
            ->middleware('perm:gps_provider.vehicle_requests.view')
            ->name('vehicle_requests.index');
        Route::put('/vehicle-requests/{vehicleRequest}/approve', [GpsProviderVehicleRequestController::class, 'approve'])
            ->middleware('perm:gps_provider.vehicle_requests.manage')
            ->name('vehicle_requests.approve');
        Route::put('/vehicle-requests/{vehicleRequest}/reject', [GpsProviderVehicleRequestController::class, 'reject'])
            ->middleware('perm:gps_provider.vehicle_requests.manage')
            ->name('vehicle_requests.reject');

        Route::get('/companies', [GpsProviderCompanyController::class, 'index'])
            ->middleware('perm:gps_provider.companies.view')
            ->name('companies.index');
        Route::get('/companies/{connection}/edit', [GpsProviderCompanyController::class, 'edit'])
            ->middleware('perm:gps_provider.companies.manage')
            ->name('companies.edit');
        Route::put('/companies/{connection}', [GpsProviderCompanyController::class, 'update'])
            ->middleware('perm:gps_provider.companies.manage')
            ->name('companies.update');

        Route::get('/vehicles', [GpsProviderProviderVehicleController::class, 'index'])
            ->middleware('perm:gps_provider.vehicles.view')
            ->name('vehicles.index');

        Route::get('/settings', [GpsProviderSettingsController::class, 'edit'])
            ->middleware('perm:gps_provider.settings.edit')
            ->name('settings.edit');
        Route::put('/settings', [GpsProviderSettingsController::class, 'update'])
            ->middleware('perm:gps_provider.settings.edit')
            ->name('settings.update');
        Route::put('/settings/test-wialon', [GpsProviderSettingsController::class, 'testWialon'])
            ->middleware('perm:gps_provider.settings.edit')
            ->name('settings.test_wialon');

        Route::resource('users', GpsProviderUserController::class)
            ->except(['show'])
            ->middleware('perm:gps_provider.users.manage');
    });

// Company options
Route::middleware('auth')->group(function () {
    Route::get('/company/options', [CompanyOptionController::class, 'edit'])
        ->middleware(['feature:settings','perm:settings.edit'])
        ->name('company.options.edit');

    Route::post('/company/options', [CompanyOptionController::class, 'update'])
        ->middleware(['feature:settings','perm:settings.edit'])
        ->name('company.options.update');

    Route::get('/company/plans', [CompanyPlanController::class, 'index'])
        ->middleware('perm:settings.edit')
        ->name('company.plans.index');
    Route::post('/company/plans/checkout', [CompanyPlanController::class, 'checkout'])
        ->middleware('perm:settings.edit')
        ->name('company.plans.checkout');

    // Notification options
    Route::get('/company/notifications', [NotificationOptionController::class, 'edit'])->middleware('feature:notifications')->name('company.notifications.edit');
    Route::post('/company/notifications', [NotificationOptionController::class, 'update'])->middleware('feature:notifications')->name('company.notifications.update');
    Route::get('/company/notifications/logs', [NotificationLogController::class, 'index'])->middleware('feature:notifications')->name('company.notifications.logs');
    Route::get('/company/addons', [CompanyAddonController::class, 'index'])->name('company.addons.index');
    Route::post('/company/addons', [CompanyAddonController::class, 'store'])->name('company.addons.store');
    Route::delete('/company/addons/{subscriptionAddon}', [CompanyAddonController::class, 'destroy'])->name('company.addons.destroy');
    Route::get('/company/taxes', [TaxReportController::class, 'index'])->middleware('perm:settings.edit')->name('company.taxes.index');
    Route::post('/company/taxes', [TaxReportController::class, 'store'])->middleware('perm:settings.edit')->name('company.taxes.store');

    Route::get('/company/domain-requests', [CompanyDomainRequestController::class, 'index'])
        ->middleware(['feature:custom_domain','company.owner'])
        ->name('company.domain_requests.index');
    Route::post('/company/domain-requests', [CompanyDomainRequestController::class, 'store'])
        ->middleware(['feature:custom_domain','company.owner'])
        ->name('company.domain_requests.store');

    Route::get('/company/owner-payments', [CompanyOwnerPaymentController::class, 'index'])
        ->middleware(['module:rentacar','perm:owner_payments.view'])
        ->name('company.owner_payments.index');
    Route::post('/company/owner-payments', [CompanyOwnerPaymentController::class, 'store'])
        ->middleware(['module:rentacar','perm:owner_payments.create'])
        ->name('company.owner_payments.store');
    Route::get('/company/rentals', [CompanyRentalController::class, 'index'])
        ->middleware(['module:rentacar','feature:vehicles','perm:rentals.view'])
        ->name('rentals.index');
    Route::get('/company/rentals/create', [CompanyRentalController::class, 'create'])
        ->middleware(['module:rentacar','feature:vehicles','perm:rentals.create'])
        ->name('rentals.create');
    Route::post('/company/rentals', [CompanyRentalController::class, 'store'])
        ->middleware(['module:rentacar','feature:vehicles','perm:rentals.create'])
        ->name('rentals.store');
    Route::post('/company/rentals/{rental}/close', [CompanyRentalController::class, 'close'])
        ->middleware(['module:rentacar','feature:vehicles','perm:rentals.create'])
        ->name('rentals.close');
    Route::get('/company/rental-addons', [CompanyRentalAddonController::class, 'index'])
        ->middleware(['module:rentacar','perm:settings.edit'])
        ->name('company.rental_addons.index');
    Route::post('/company/rental-addons', [CompanyRentalAddonController::class, 'store'])
        ->middleware(['module:rentacar','perm:settings.edit'])
        ->name('company.rental_addons.store');
    Route::put('/company/rental-addons/{addon}', [CompanyRentalAddonController::class, 'update'])
        ->middleware(['module:rentacar','perm:settings.edit'])
        ->name('company.rental_addons.update');
    Route::delete('/company/rental-addons/{addon}', [CompanyRentalAddonController::class, 'destroy'])
        ->middleware(['module:rentacar','perm:settings.edit'])
        ->name('company.rental_addons.destroy');
    Route::get('/company/taxi-addons', [CompanyTaxiAddonController::class, 'index'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.addons.manage'])
        ->name('company.taxi_addons.index');
    Route::post('/company/taxi-addons', [CompanyTaxiAddonController::class, 'store'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.addons.manage'])
        ->name('company.taxi_addons.store');
    Route::put('/company/taxi-addons/{addon}', [CompanyTaxiAddonController::class, 'update'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.addons.manage'])
        ->name('company.taxi_addons.update');
    Route::delete('/company/taxi-addons/{addon}', [CompanyTaxiAddonController::class, 'destroy'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.addons.manage'])
        ->name('company.taxi_addons.destroy');
    Route::get('/company/taxi-drivers', [CompanyTaxiDriverController::class, 'index'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.drivers.view'])
        ->name('company.taxi_drivers.index');
    Route::get('/company/taxi-drivers/create', [CompanyTaxiDriverController::class, 'create'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.drivers.create'])
        ->name('company.taxi_drivers.create');
    Route::post('/company/taxi-drivers', [CompanyTaxiDriverController::class, 'store'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.drivers.create'])
        ->name('company.taxi_drivers.store');
    Route::get('/company/taxi-drivers/{driver}/edit', [CompanyTaxiDriverController::class, 'edit'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.drivers.edit'])
        ->name('company.taxi_drivers.edit');
    Route::put('/company/taxi-drivers/{driver}', [CompanyTaxiDriverController::class, 'update'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.drivers.edit'])
        ->name('company.taxi_drivers.update');
    Route::delete('/company/taxi-drivers/{driver}', [CompanyTaxiDriverController::class, 'destroy'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.drivers.delete'])
        ->name('company.taxi_drivers.destroy');
    Route::get('/company/taxi-assignments', [CompanyTaxiVehicleAssignmentController::class, 'index'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.assignments.view'])
        ->name('company.taxi_assignments.index');
    Route::get('/company/taxi-assignments/create', [CompanyTaxiVehicleAssignmentController::class, 'create'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.assignments.create'])
        ->name('company.taxi_assignments.create');
    Route::post('/company/taxi-assignments', [CompanyTaxiVehicleAssignmentController::class, 'store'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.assignments.create'])
        ->name('company.taxi_assignments.store');
    Route::get('/company/taxi-assignments/{assignment}/edit', [CompanyTaxiVehicleAssignmentController::class, 'edit'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.assignments.edit'])
        ->name('company.taxi_assignments.edit');
    Route::put('/company/taxi-assignments/{assignment}', [CompanyTaxiVehicleAssignmentController::class, 'update'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.assignments.edit'])
        ->name('company.taxi_assignments.update');
    Route::delete('/company/taxi-assignments/{assignment}', [CompanyTaxiVehicleAssignmentController::class, 'destroy'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.assignments.delete'])
        ->name('company.taxi_assignments.destroy');
    Route::get('/company/taxi-issues', [CompanyTaxiVehicleIssueController::class, 'index'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.issues.view'])
        ->name('company.taxi_issues.index');
    Route::get('/company/taxi-issues/create', [CompanyTaxiVehicleIssueController::class, 'create'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.issues.create'])
        ->name('company.taxi_issues.create');
    Route::post('/company/taxi-issues', [CompanyTaxiVehicleIssueController::class, 'store'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.issues.create'])
        ->name('company.taxi_issues.store');
    Route::get('/company/taxi-issues/{issue}/edit', [CompanyTaxiVehicleIssueController::class, 'edit'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.issues.edit'])
        ->name('company.taxi_issues.edit');
    Route::put('/company/taxi-issues/{issue}', [CompanyTaxiVehicleIssueController::class, 'update'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.issues.edit'])
        ->name('company.taxi_issues.update');
    Route::delete('/company/taxi-issues/{issue}', [CompanyTaxiVehicleIssueController::class, 'destroy'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.issues.delete'])
        ->name('company.taxi_issues.destroy');
    Route::get('/company/taxi-trips', [CompanyTaxiTripController::class, 'index'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.trips.view'])
        ->name('company.taxi_trips.index');
    Route::get('/company/taxi-trips/create', [CompanyTaxiTripController::class, 'create'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.trips.create'])
        ->name('company.taxi_trips.create');
    Route::post('/company/taxi-trips', [CompanyTaxiTripController::class, 'store'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.trips.create'])
        ->name('company.taxi_trips.store');
    Route::get('/company/taxi-trips/{trip}/edit', [CompanyTaxiTripController::class, 'edit'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.trips.edit'])
        ->name('company.taxi_trips.edit');
    Route::put('/company/taxi-trips/{trip}', [CompanyTaxiTripController::class, 'update'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.trips.edit'])
        ->name('company.taxi_trips.update');
    Route::delete('/company/taxi-trips/{trip}', [CompanyTaxiTripController::class, 'destroy'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.trips.delete'])
        ->name('company.taxi_trips.destroy');
    Route::get('/company/taxi-payroll', [CompanyTaxiPayrollController::class, 'index'])
        ->middleware(['module:taxipark','feature:taxi','perm:taxi.payroll.view'])
        ->name('company.taxi_payroll.index');
    Route::get('/company/vehicle-expenses', [CompanyVehicleExpenseController::class, 'index'])
        ->middleware(['module:rentacar','feature:vehicles','perm:vehicles.view'])
        ->name('company.vehicle_expenses.index');
    Route::post('/company/vehicle-expenses', [CompanyVehicleExpenseController::class, 'store'])
        ->middleware(['module:rentacar','feature:vehicles','perm:vehicles.edit'])
        ->name('company.vehicle_expenses.store');
    Route::prefix('company/whatsapp-campaigns')->middleware(['feature:whatsapp_campaigns','perm:notify.send|whatsapp.campaigns'])->name('company.whatsapp_campaigns.')->group(function () {
        Route::get('/', [WhatsAppCampaignController::class, 'index'])->name('index');
        Route::get('/create', [WhatsAppCampaignController::class, 'create'])->name('create');
        Route::post('/', [WhatsAppCampaignController::class, 'store'])->name('store');
    });

    // Risk assessments
    Route::get('/risk-assessments/create', [RiskAssessmentController::class, 'create'])->middleware(['feature:risk','module:leasing'])->name('risk_assessments.create');
    Route::post('/risk-assessments', [RiskAssessmentController::class, 'store'])->middleware(['feature:risk','module:leasing'])->name('risk_assessments.store');
    Route::get('/risk-assessments/{riskAssessment}', [RiskAssessmentController::class, 'show'])->middleware(['feature:risk','module:leasing'])->name('risk_assessments.show');

    // Risk factor definitions (Company Options)
    Route::prefix('company/risk-factors')->name('company_options.risk_factors.')->middleware(['feature:risk','module:leasing'])->group(function () {
        Route::get('/', [RiskFactorDefinitionController::class, 'index'])->name('index');
        Route::get('/create', [RiskFactorDefinitionController::class, 'create'])->name('create');
        Route::post('/', [RiskFactorDefinitionController::class, 'store'])->name('store');
        Route::get('/{riskFactor}/edit', [RiskFactorDefinitionController::class, 'edit'])->name('edit');
        Route::put('/{riskFactor}', [RiskFactorDefinitionController::class, 'update'])->name('update');
        Route::patch('/{riskFactor}/toggle', [RiskFactorDefinitionController::class, 'toggle'])->name('toggle');
        Route::delete('/{riskFactor}', [RiskFactorDefinitionController::class, 'destroy'])->name('destroy');
    });
    // BHPH Accounts routes
    Route::middleware(['feature:bhph','module:leasing'])->group(function () {
        Route::get('/bhph-accounts', [\App\Http\Controllers\BhphAccountController::class, 'index'])
            ->name('bhph_accounts.index');

        Route::get('/bhph-accounts/create', [\App\Http\Controllers\BhphAccountController::class, 'create'])
            ->name('bhph_accounts.create');

        Route::post('/bhph-accounts', [\App\Http\Controllers\BhphAccountController::class, 'store'])
            ->name('bhph_accounts.store');

        Route::get('/bhph-accounts/{account}', [\App\Http\Controllers\BhphAccountController::class, 'show'])
            ->name('bhph_accounts.show');

        Route::get('/bhph-accounts/{account}/edit', [\App\Http\Controllers\BhphAccountController::class, 'edit'])
            ->name('bhph_accounts.edit');

        Route::put('/bhph-accounts/{account}', [\App\Http\Controllers\BhphAccountController::class, 'update'])
            ->name('bhph_accounts.update');

        // amortization edit/update (payment writing)
        Route::get('/bhph-accounts/{account}/amortization/{amortization}/edit', [\App\Http\Controllers\AmortizationController::class, 'edit'])
            ->name('amortization.edit');

        Route::put('/bhph-accounts/{account}/amortization/{amortization}', [\App\Http\Controllers\AmortizationController::class, 'update'])
            ->name('amortization.update');

        Route::delete('/bhph-accounts/{account}', [\App\Http\Controllers\BhphAccountController::class, 'destroy'])
            ->name('bhph_accounts.destroy');
        Route::get('/bhph-accounts/{account}/documents/{document}', [AccountDocumentController::class, 'download'])
            ->name('bhph_accounts.documents.download');
    });
});

// Leasing Options
Route::get('/company/leasing-options', [LeasingOptionController::class, 'edit'])
    ->middleware(['auth','feature:settings','perm:settings.edit','module:leasing'])
    ->name('company.leasing_options.edit');

Route::post('/company/leasing-options', [LeasingOptionController::class, 'update'])
    ->middleware(['auth','feature:settings','perm:settings.edit','module:leasing'])
    ->name('company.leasing_options.update');

// Penalty Options
Route::get('/company/penalty-options', [PenaltyOptionController::class, 'edit'])
    ->middleware(['auth','feature:payments','perm:settings.edit','module:leasing'])
    ->name('company.penalty_options.edit');

Route::post('/company/penalty-options', [PenaltyOptionController::class, 'update'])
    ->middleware(['auth','feature:payments','perm:settings.edit','module:leasing'])
    ->name('company.penalty_options.update');

// Penalties panel
Route::get('/penalties', [PenaltyController::class, 'index'])
    ->middleware(['auth','feature:payments','perm:payments.view','module:leasing'])
    ->name('penalties.index');

// PAYMENT OPTIONS
Route::get('/company/payment-options', [PaymentOptionController::class, 'edit'])
    ->middleware(['auth','feature:payments','perm:settings.edit','module:leasing'])
    ->name('company.payment_options.edit');

Route::post('/company/payment-options', [PaymentOptionController::class, 'update'])
    ->middleware(['auth','feature:payments','perm:settings.edit','module:leasing'])
    ->name('company.payment_options.update');

// Company wallet / payouts
Route::middleware(['auth','feature:payments','module:leasing'])
    ->prefix('company')
    ->name('company.')
    ->group(function () {
        Route::get('wallet', [CompanyWalletController::class, 'index'])
            ->middleware('perm:payments.view')
            ->name('wallet.index');
        Route::post('wallet/card', [CompanyWalletController::class, 'registerCard'])
            ->middleware('perm:payments.create')
            ->name('wallet.card');
        Route::post('wallet/payout', [CompanyWalletController::class, 'requestPayout'])
            ->middleware('perm:payments.create')
            ->name('wallet.payout');
    });

Route::middleware(['auth','feature:document_automation','perm:settings.edit','module:leasing'])
    ->prefix('company/document-templates')
    ->name('company.document_templates.')
    ->group(function () {
        Route::get('/', [DocumentTemplateController::class, 'index'])->name('index');
        Route::post('/', [DocumentTemplateController::class, 'store'])->name('store');
        Route::get('/{template}/preview/{account}', [DocumentTemplateController::class, 'preview'])
            ->name('preview');
        Route::delete('/{template}', [DocumentTemplateController::class, 'destroy'])
            ->name('destroy');
    });

Route::middleware(['auth'])
    ->prefix('company')
    ->name('company.')
    ->group(function () {
        Route::get('transactions', [CompanyGatewayTransactionController::class, 'index'])
            ->middleware('perm:payments.view|settings.edit')
            ->name('transactions.index');
    });

// CUSTOMERS (M??t?ril?r)
Route::get('/customers', [CustomerController::class, 'index'])
    ->middleware(['auth','feature:customers','perm:customers.view'])
    ->name('customers.index');

Route::get('/customers/create', [CustomerController::class, 'create'])
    ->middleware(['auth','feature:customers','perm:customers.create'])
    ->name('customers.create');

Route::post('/customers', [CustomerController::class, 'store'])
    ->middleware(['auth','feature:customers','perm:customers.create'])
    ->name('customers.store');

Route::get('/customers/{customer}/edit', [CustomerController::class, 'edit'])
    ->middleware(['auth','feature:customers','perm:customers.edit'])
    ->name('customers.edit');

Route::put('/customers/{customer}', [CustomerController::class, 'update'])
    ->middleware(['auth','feature:customers','perm:customers.edit'])
    ->name('customers.update');

Route::delete('/customers/{customer}', [CustomerController::class, 'destroy'])
    ->middleware(['auth','feature:customers','perm:customers.delete'])
    ->name('customers.destroy');

// Vehicles
Route::middleware(['auth','feature:vehicles'])->group(function () {
    Route::get('/vehicles/{vehicle}/gps', [VehicleController::class, 'gps'])
        ->middleware('feature:gps')
        ->name('vehicles.gps');
    Route::get('/vehicles/{vehicle}/gps/position', [VehicleController::class, 'gpsPosition'])
        ->middleware(['perm:vehicles.gps','feature:gps'])
        ->name('vehicles.gps.position');
    Route::get('/vehicles/{vehicle}/authorizations', [VehicleAuthorizationController::class, 'index'])
        ->name('vehicles.authorizations.index');
    Route::get('/vehicles/authorizations', [VehicleAuthorizationController::class, 'indexAll'])
        ->name('vehicles.authorizations.all');
    Route::post('/vehicles/{vehicle}/authorizations', [VehicleAuthorizationController::class, 'store'])
        ->name('vehicles.authorizations.store');
    Route::delete('/vehicles/authorizations/{authorization}', [VehicleAuthorizationController::class, 'destroy'])
        ->name('vehicles.authorizations.destroy');
    Route::post('/vehicles/{vehicle}/geofence', [VehicleController::class, 'saveGeofence'])
        ->middleware(['perm:vehicles.gps','feature:gps'])
        ->name('vehicles.geofence.save');
    Route::post('/vehicles/{vehicle}/command', [VehicleController::class, 'sendCommand'])
        ->middleware(['perm:vehicles.gps','feature:gps'])
        ->name('vehicles.command');
    Route::get('/vehicles/gps-setup', [VehicleController::class, 'gpsSetup'])
        ->name('vehicles.gps_setup');
    Route::resource('vehicles', VehicleController::class)->except(['show']);

    Route::get('/company/gps', [VehicleController::class, 'gpsAll'])
        ->middleware(['perm:vehicles.gps','feature:gps'])
        ->name('company.gps');
    Route::get('/company/gps/positions', [VehicleController::class, 'gpsPositions'])
        ->middleware(['perm:vehicles.gps','feature:gps'])
        ->name('company.gps.positions');
    Route::get('/company/gps/history/{unitId}', [VehicleController::class, 'gpsHistory'])
        ->middleware(['perm:vehicles.gps','feature:gps'])
        ->name('company.gps.history');
    Route::post('/company/gps/command', [VehicleController::class, 'gpsCommand'])
        ->middleware(['perm:vehicles.gps','feature:gps'])
        ->name('company.gps.command');
});

// Tickets (company users)
Route::middleware(['auth'])->group(function () {
    Route::get('/tickets', [TicketController::class, 'index'])->name('tickets.index');
    Route::get('/tickets/create', [TicketController::class, 'create'])->name('tickets.create');
    Route::post('/tickets', [TicketController::class, 'store'])->name('tickets.store');
    Route::get('/tickets/{ticket}', [TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', [TicketController::class, 'reply'])->name('tickets.reply');
});

Route::post('/bhph-accounts/{account}/payments/cash', [\App\Http\Controllers\PaymentController::class, 'storeCash'])
    ->middleware(['auth','feature:bhph','perm:payments.create','module:leasing'])
    ->name('payments.cash.store');

// Payroll
Route::middleware(['auth','feature:payroll','company.owner','perm:users.manage','module:leasing'])->group(function () {
    Route::get('/company/payroll', [\App\Http\Controllers\PayrollController::class, 'index'])->name('company.payroll.index');
});

// Company Users
Route::middleware(['auth', 'feature:users', 'perm:users.manage'])
    ->prefix('company')
    ->name('company.')
    ->group(function () {

    Route::get('users', [CompanyUserController::class, 'index'])->name('users.index');
    Route::get('users/create', [CompanyUserController::class, 'create'])->name('users.create');
    Route::post('users', [CompanyUserController::class, 'store'])->name('users.store');

    Route::get('users/{user}/edit', [CompanyUserController::class, 'edit'])->name('users.edit');
    Route::put('users/{user}', [CompanyUserController::class, 'update'])->name('users.update');
    Route::post('users/{user}/reset-password', [CompanyUserController::class, 'resetPassword'])->name('users.reset_password');

    Route::delete('users/{user}', [CompanyUserController::class, 'destroy'])->name('users.destroy');
});

// Public site / theme management
Route::middleware(['auth', 'feature:public_theme'])
    ->prefix('company')
    ->name('company.')
    ->group(function () {
    Route::get('theme', [\App\Http\Controllers\Company\PublicThemeController::class, 'edit'])->middleware('perm:public.theme')->name('theme.edit');
    Route::put('theme', [\App\Http\Controllers\Company\PublicThemeController::class, 'update'])->middleware('perm:public.theme')->name('theme.update');
    Route::get('theme/preview/{theme}', [\App\Http\Controllers\Company\PublicThemeController::class, 'previewImage'])->middleware('perm:public.theme')->name('theme.preview');

    Route::get('blog', [\App\Http\Controllers\Company\BlogController::class, 'index'])->middleware('perm:public.blog')->name('blog.index');
    Route::get('blog/create', [\App\Http\Controllers\Company\BlogController::class, 'create'])->middleware('perm:public.blog')->name('blog.create');
    Route::post('blog', [\App\Http\Controllers\Company\BlogController::class, 'store'])->middleware('perm:public.blog')->name('blog.store');

    Route::get('pages', [\App\Http\Controllers\Company\PublicPageController::class, 'index'])->middleware('perm:public.pages')->name('pages.index');
    Route::get('pages/create', [\App\Http\Controllers\Company\PublicPageController::class, 'create'])->middleware('perm:public.pages')->name('pages.create');
    Route::post('pages', [\App\Http\Controllers\Company\PublicPageController::class, 'store'])->middleware('perm:public.pages')->name('pages.store');

    Route::get('test-drives', [\App\Http\Controllers\Company\TestDriveController::class, 'index'])->middleware('perm:public.test_drives')->name('test_drives.index');
    Route::put('test-drives/{testDrive}', [\App\Http\Controllers\Company\TestDriveController::class, 'update'])->middleware('perm:public.test_drives')->name('test_drives.update');
});

// Notifications & chat (bütün autentifikasiya olunan istifadəçilər üçün)
Route::middleware(['auth'])
    ->prefix('company')
    ->name('company.')
    ->group(function () {
        // realtime notifications (feed)
        Route::get('/notifications-feed', [\App\Http\Controllers\NotificationController::class, 'index'])->name('notifications.index');
        Route::get('/notifications-send', [\App\Http\Controllers\NotificationController::class, 'form'])->middleware('perm:notify.send|whatsapp.manual')->name('notifications.form');
        Route::post('/notifications-send', [\App\Http\Controllers\NotificationController::class, 'store'])->middleware('perm:notify.send|whatsapp.manual')->name('notifications.store');
        Route::post('/notifications/{notification}/read', [\App\Http\Controllers\NotificationController::class, 'markRead'])->name('notifications.read');

        Route::get('chat', [\App\Http\Controllers\ChatController::class, 'index'])->name('chat.index');
        Route::get('chat/rooms/{room}/messages', [\App\Http\Controllers\ChatController::class, 'messages'])->name('chat.messages');
        Route::post('chat/rooms/{room}/messages', [\App\Http\Controllers\ChatController::class, 'storeMessage'])->name('chat.messages.store');
        Route::post('chat/rooms', [\App\Http\Controllers\ChatRoomController::class, 'store'])->middleware('perm:users.manage')->name('chat.rooms.store');
        Route::post('chat/rooms/{room}/users', [\App\Http\Controllers\ChatRoomController::class, 'attachUsers'])->middleware('perm:users.manage')->name('chat.rooms.users');
        Route::get('chat/default-room', [\App\Http\Controllers\ChatController::class, 'defaultRoom'])->name('chat.default');
        Route::get('chat/contacts', [\App\Http\Controllers\ChatController::class, 'contacts'])->name('chat.contacts');
        Route::get('chat/direct/{target}', [\App\Http\Controllers\ChatController::class, 'directRoom'])->name('chat.direct');
    });

// Public company pages (must stay last to avoid route conflicts)
require __DIR__.'/public.php';

