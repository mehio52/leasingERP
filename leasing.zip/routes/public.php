<?php

use App\Http\Controllers\PublicThemeController;
use Illuminate\Support\Facades\Route;

$appDomain = parse_url(config('app.url'), PHP_URL_HOST);
$appDomainWww = $appDomain ? ('www.' . $appDomain) : null;
$mainDomains = array_filter([$appDomain, $appDomainWww]);

if (!empty($mainDomains)) {
    foreach ($mainDomains as $domain) {
        Route::domain($domain)
            ->middleware(['resolve.public.company'])
            ->group(function () {
                Route::any('/{companySlug}/{path?}', [PublicThemeController::class, 'handle'])
                    ->where('path', '.*')
                    ->name('public.theme');
            });
    }
} else {
    Route::middleware(['resolve.public.company'])->group(function () {
        Route::any('/{companySlug}/{path?}', [PublicThemeController::class, 'handle'])
            ->where('path', '.*')
            ->name('public.theme');
    });
}

Route::middleware(['resolve.public.domain'])->group(function () {
    Route::any('/{path?}', [PublicThemeController::class, 'handle'])
        ->where('path', '.*')
        ->name('public.theme.domain');
});
