<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\CompanyRegisterController;
use App\Http\Controllers\TraccarWebhookController;

Route::get('/register-company', [CompanyRegisterController::class, 'show'])
    ->middleware('guest')
    ->name('api.company.register.form');

Route::post('/register-company', [CompanyRegisterController::class, 'store'])
    ->middleware('guest')
    ->name('api.company.register');

// Traccar webhook (overspeed və digər eventlər)
Route::post('/traccar/webhook', [TraccarWebhookController::class, 'handle']);
