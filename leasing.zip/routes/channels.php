<?php

use App\Models\User;
use Illuminate\Support\Facades\Broadcast;

Broadcast::channel('notifications.{userId}', function (User $user, $userId) {
    return (int)$user->id === (int)$userId;
});

Broadcast::channel('company.{companyId}', function (User $user, $companyId) {
    return (int)$user->company_id === (int)$companyId;
});

Broadcast::channel('role.{role}', function (User $user, $role) {
    if ($role === 'superadmin') {
        return $user->isSuperAdmin();
    }
    if ($role === 'owner') {
        return $user->is_owner || $user->role === 'owner';
    }
    return false;
});

Broadcast::channel('global.notifications', function (User $user) {
    return true;
});

Broadcast::channel('chat.room.{roomId}', function (User $user, $roomId) {
    return $user->chatRooms()->where('chat_room_id', $roomId)->exists();
});
